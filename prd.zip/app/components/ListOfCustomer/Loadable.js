/**
 *
 * Asynchronously loads the component for ListOfCustomer
 *
 */

import loadable from 'loadable-components';

export default loadable(() => import('./index'));
