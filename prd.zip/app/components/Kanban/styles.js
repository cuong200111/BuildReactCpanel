const styles = theme => ({
  'react-trello-lane': {
    backGroundColor: 'red',
  },
});

export default styles;
