/**
 *
 * Asynchronously loads the component for LiabilitiesCustomer
 *
 */

import loadable from 'loadable-components';

export default loadable(() => import('./index'));
