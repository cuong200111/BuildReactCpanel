/**
 *
 * Asynchronously loads the component for AsyncComponent
 *
 */

import loadable from 'loadable-components';

export default loadable(() => import('./index'));
