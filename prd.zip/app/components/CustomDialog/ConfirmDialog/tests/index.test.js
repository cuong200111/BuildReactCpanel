// import React from 'react';
// import { mount } from 'enzyme';
// import { enzymeFind } from 'styled-components/test-utils';

// import DialogAcceptRemove from '../index';

describe('<DialogAcceptRemove />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
