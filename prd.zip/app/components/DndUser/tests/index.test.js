// import React from 'react';
// import { mount } from 'enzyme';
// import { enzymeFind } from 'styled-components/test-utils';

// import DndUser from '../index';

describe('<DndUser />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
