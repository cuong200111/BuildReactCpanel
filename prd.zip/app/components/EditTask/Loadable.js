/**
 *
 * Asynchronously loads the component for EditTask
 *
 */

import loadable from 'loadable-components';

export default loadable(() => import('./index'));
