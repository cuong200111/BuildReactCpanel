// import React from 'react';
// import { mount } from 'enzyme';
// import { enzymeFind } from 'styled-components/test-utils';

// import EditTask from '../index';

describe('<EditTask />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
