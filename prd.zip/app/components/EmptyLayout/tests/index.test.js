// import React from 'react';
// import { mount } from 'enzyme';
// import { enzymeFind } from 'styled-components/test-utils';

// import EmptyLayout from '../index';

describe('<EmptyLayout />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
