// import React from 'react';
// import { mount } from 'enzyme';
// import { enzymeFind } from 'styled-components/test-utils';

// import Category from '../index';

describe('<Category />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
