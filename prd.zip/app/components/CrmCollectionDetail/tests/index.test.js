// import React from 'react';
// import { mount } from 'enzyme';
// import { enzymeFind } from 'styled-components/test-utils';

// import CrmCollectionDetail from '../index';

describe('<CrmCollectionDetail />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
