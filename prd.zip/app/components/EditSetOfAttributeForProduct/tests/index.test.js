// import React from 'react';
// import { mount } from 'enzyme';
// import { enzymeFind } from 'styled-components/test-utils';

// import EditSetOfAttributeForProduct from '../index';

describe('<EditSetOfAttributeForProduct />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
