/*
 *
 * AddTemplatePage constants
 *
 */

export const DEFAULT_ACTION = 'app/ManagerTask/DEFAULT_ACTION';
export const EMPLOYEE_VIEWTASK ='/api/tasks/employeeViewTask';