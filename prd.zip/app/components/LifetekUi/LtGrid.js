// import React from 'react';
import { Grid, withStyles } from '@material-ui/core';

const styles = theme => ({
  container: {
    // padding: `0 0px`,
    color: '#1d1d1f ',
  },
});
export default withStyles(styles)(Grid);
