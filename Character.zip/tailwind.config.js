/** @type {import('tailwindcss').Config} */
module.exports = {
    content: [],
    theme: {

    },
    plugins: [

    ],
}