import anime from "animejs";
import React, { useEffect, useRef, useState } from "react";
  const animate = useRef(null)
    useEffect(() => {
    anime({
      targets: animate.current,
      opacity: 0,
      duration: 0,
      easing: 'easeInOutSine',
      complete: () => {
        anime({
          targets: animate.current,
          opacity: 1,
          duration: 200,
          easing: 'easeInOutSine'
        });
      }
    });
  }, []);