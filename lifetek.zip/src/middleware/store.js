import { createStore } from "redux";
import reducer from "../redux/reducer";
import { applyMiddleware } from "redux";
import createSagaMiddleware from "@redux-saga/core";
import watchState from "./saga";
const sagaMiddlware = createSagaMiddleware()
const store = createStore(
    reducer,applyMiddleware(sagaMiddlware)
)
sagaMiddlware.run(watchState)

export default store