import {

  reqGetAccountSucsess,
  reqGetAccount,
} from "../redux/action";
import { put, takeLatest } from "redux-saga/effects";


function* handleGetSaga(action) {
  try {
    const { name } = action.payload;
    yield put({ type: reqGetAccountSucsess, payload: { name } });
  } catch (error) {}
}

export default function* watchState() {
  yield takeLatest(reqGetAccount, handleGetSaga);
}
