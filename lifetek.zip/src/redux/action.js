
export const reqGetAccountSucsess = 'reqGetAccountSucsess'
export const reqGetAccount = 'reqGetAccount'

export const handleData = (name,email,pass)=>({
    type:reqGetAccount,
    payload:{name,email,pass}
})