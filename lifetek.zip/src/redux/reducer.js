import { reqGetAccountSucsess } from "./action";

const reducer = (state = [],action)=>{
switch (action.type) {
  case reqGetAccountSucsess:
    
    return action.payload

  default:
    return state
}
}


export default reducer