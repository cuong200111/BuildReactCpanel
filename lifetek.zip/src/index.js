import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './sass/index.scss'
import store from './middleware/store';
import { Provider } from 'react-redux';

const root = ReactDOM.createRoot(document.getElementById('root'));

root.render(
 
  <Provider store={store}>
    <App />
  </Provider >
);

