
import Layout from "./components/Layout";
import axios from "axios";
function App() {
axios.get('/').then(item=>console.log(item))

  return (
    <div className="App">
<Layout/>
    </div>
  );
}

export default App;
