import React, { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { pathLogin, pathLogout } from "./pathHeader/path";
const Header = () => {
  const [online, setOnline] = useState(0);
  const [textTime, setTexttime] = useState(null);
  const Active  = useRef('')


  useEffect(() => {
    const now = new Date();
    if (now.getHours() >= 0 && now.getHours() <= 9) {
      setTexttime("buổi sáng");
    } else if (now.getHours() >= 10 && now.getHours() <= 13) {
      setTexttime("buổi trưa");
    } else if (now.getHours() >= 14 && now.getHours() <= 17) {
      setTexttime("buổi chiều");
    } else if (now.getHours() >= 18 && now.getHours() <= 24) {
      setTexttime("buổi tối");
    }
  }, []);

    const handleClick = (event) => {
    event.preventDefault();
    if (Active.current) {
      Active.current.classList.toggle("active");
    }
  };
  function handleClickOutside(event) {


    const headerUser = document.querySelector(".Header_right_content_user");
  
    const logoutButton = document.querySelector(".Header_right_content_user_logout");
 const formSign = document.querySelector(".Header_right_content_user_form");
  
    
    if (headerUser&&!headerUser.contains(event.target)) {
   
      formSign.classList.remove('active')
    }
    else if (headerUser&&!headerUser.contains(event.target)) {
   
      logoutButton.classList.remove("active");
    }

    
  }
  

  document.addEventListener("click", handleClickOutside);
  return (
    <div className="Header_main">
      <div className="Header">
        <div className="Header_left">
          <div className="Header_left_title">
            <h1 className="fml fz18 fw600">CHÀO BẠN: Nguyễn Ngọc Minh</h1>
          </div>
          <div className="Header_left_description">
            <h5 className="fml fz15 fw600">
              {" "}
              Chúc bạn có một {textTime} tốt lành
            </h5>
          </div>
        </div>

        <div className="Header_right">
          <div className="Header_right_content">
            <div>
              <svg
                width="22"
                height="22"
                viewBox="0 0 22 22"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  fillRule="evenodd"
                  clipRule="evenodd"
                  d="M9.2 20.82C9.66 21.43 10.31 21.78 11 21.78C11.69 21.78 12.34 21.43 12.8 20.82L14.3 18.82C14.35 18.76 14.42 18.72 14.5 18.72H15C19.42 18.72 21.75 16.39 21.75 11.97V6.97C21.75 2.55 19.42 0.220001 15 0.220001H7C2.58 0.220001 0.25 2.55 0.25 6.97V11.97C0.25 17.59 2.83 18.72 7 18.72H7.5C7.55 18.73 7.67 18.78 7.7 18.82L9.2 20.82ZM1.75 6.97C1.75 3.39 3.42 1.72 7 1.72H15C18.58 1.72 20.25 3.39 20.25 6.97V11.97C20.25 15.55 18.58 17.22 15 17.22H14.5C13.95 17.22 13.43 17.48 13.1 17.92L11.6 19.92C11.25 20.38 10.75 20.38 10.4 19.92L8.9 17.92C8.59 17.51 8.01 17.22 7.5 17.22H7C3.3 17.22 1.75 16.49 1.75 11.97V6.97ZM10 9.97C10 10.52 10.44 10.97 11 10.97C11.56 10.97 12 10.52 12 9.97C12 9.42 11.55 8.97 11 8.97C10.45 8.97 10 9.42 10 9.97ZM14 9.97C14 10.52 14.44 10.97 15 10.97C15.56 10.97 16 10.52 16 9.97C16 9.42 15.55 8.97 15 8.97C14.45 8.97 14 9.42 14 9.97ZM6 9.97C6 10.52 6.44 10.97 7 10.97C7.56 10.97 8 10.52 8 9.97C8 9.42 7.55 8.97 7 8.97C6.45 8.97 6 9.42 6 9.97Z"
                  fill="#626266"
                />
              </svg>
            </div>
            <div>
              <svg
                width="46"
                height="46"
                viewBox="0 0 46 46"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <rect width="46" height="46" rx="23" fill="#F4F4FF" />
                <path
                  fillRule="evenodd"
                  clipRule="evenodd"
                  d="M17.7747 19.8149C17.7747 17.4717 19.3161 15.4831 21.4387 14.8095C22.1797 14.6023 22.9779 14.5437 23.8215 14.6492L23.8242 14.6495C24.0716 14.6795 24.3161 14.7295 24.5586 14.7952C26.7031 15.456 28.2747 17.4621 28.2747 19.8149V22.7049C28.2747 23.1001 28.3561 23.5556 28.4689 23.967C28.582 24.3793 28.743 24.8068 28.9351 25.1397L28.9349 25.1398L28.9422 25.1518L30.0916 27.0608L30.0919 27.0613C30.5056 27.7517 30.17 28.6446 29.4193 28.8928L29.417 28.8936C27.6913 29.4702 25.909 29.8073 24.1172 29.905H21.9221C20.1308 29.8074 18.3491 29.4704 16.6238 28.8941C16.167 28.7391 15.9042 28.4539 15.7942 28.157C15.6846 27.8608 15.6983 27.4755 15.9472 27.0618L15.9473 27.0616L17.0972 25.1518L17.0972 25.1518L17.0989 25.149C17.2992 24.813 17.4639 24.3825 17.5786 23.9693C17.6932 23.5563 17.7747 23.1003 17.7747 22.7049V19.8149ZM19.187 31.0931C18.1613 30.9088 17.1453 30.6498 16.147 30.3163L16.1442 30.3153C15.3018 30.0302 14.67 29.4407 14.3876 28.6779C14.1048 27.9141 14.201 27.0545 14.662 26.2883L14.6621 26.2881L15.8105 24.3809L15.8112 24.3796C15.9207 24.1955 16.0407 23.9016 16.1332 23.5681C16.2261 23.2336 16.2747 22.9196 16.2747 22.7049V19.8149C16.2747 16.9333 18.0862 14.4699 20.6311 13.5027C21.0985 12.6612 21.9962 12.095 23.0245 12.095C24.0541 12.095 24.9528 12.6627 25.4197 13.5059C27.9598 14.4769 29.7747 16.9431 29.7747 19.8149V22.7049C29.7747 22.9198 29.8233 23.2343 29.9155 23.5703C30.0065 23.9023 30.1241 24.1973 30.2312 24.3847L31.3772 26.2881L31.3778 26.2891C32.2834 27.7983 31.5595 29.7644 29.8912 30.3167C28.8833 30.6534 27.8574 30.914 26.8216 31.0987C26.3108 32.7204 24.7893 33.905 23.0046 33.905C21.9112 33.905 20.8979 33.4517 20.1779 32.7317C19.7287 32.2824 19.3832 31.719 19.187 31.0931Z"
                  fill="#626266"
                />
              </svg>
            </div>
            <div
              className="Header_right_content_user"
              onClick={(e)=>{handleClick(e)}}
              onContextMenu={(e) => {
                handleClick(e);
              }}
            >
              <img width={33} src="/img/icon.png" alt="" />
              {online ?(
                <div className="Header_right_content_user_logout" ref={Active}>
                  <Link
                    to={pathLogout[0].path}
                    className="Header_right_content_user_logout_name"
                  >
                    <img width={30} src="/img/icon.png" alt="" />{" "}
                    <span> {pathLogout[0].name} </span>
                  </Link>
                  {pathLogout.slice(1).map((item, index) => (
                    <Link key={index} className="fz15 Header_right_content_user_logout_container" to={item.path}>
                      <div>
                        <img width={30} height={25} src={`${item.icon}`} alt="" />
                        <span>{item.name}</span>
                      </div>
                    </Link>
                  ))}
                </div>
              ) :(
                <div className="Header_right_content_user_form" ref={Active}>
                  {pathLogin.map((item, index) => (
                    <Link key={index} className="fz15" to={item.path}>
                      <div>{item.name} </div>
                    </Link>
                  ))}
                </div>
              )  }
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Header;
