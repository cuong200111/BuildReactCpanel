import React from "react";
import LoadingButton from "@mui/lab/LoadingButton";
import Box from "@mui/material/Box";
import VisibilityIcon from '@mui/icons-material/Visibility';

const LoadingButtonsTransition = () => {
  const [loading, setLoading] = React.useState(false);
  const handleClick = () => {
    setLoading(true);
  };

  return (

      <Box>
        <Box sx={{ "& > button": { m: 1 } }}>
          <LoadingButton
            color="success"
            onClick={handleClick}
            loading={loading}
            loadingPosition="start"
            startIcon={<VisibilityIcon />}
            variant="contained"
          >
            <span>See</span>
          </LoadingButton>
        </Box>
      </Box>

  );
};
const button ={
  Loading: LoadingButtonsTransition,
};
export default button
