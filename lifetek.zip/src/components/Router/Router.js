import React, { useEffect } from "react";
import { Routes, Route, useLocation } from "react-router-dom";
import Aboutus from "../Container/About_us";
import Progress from "../Container/Progress";
import Contact from "../Container/Contact";
import Admin from "../../admin/Admin";
import SignUp from "../Container/Signup";
import SignIn from "../Container/SignIn";
const Router = () => {
  const path = useLocation().pathname;
  useEffect(() => {
    const body = document.querySelector("body");
    const hide = () => {
      body.querySelector(".main_container").style = "left:0;width:100%;";
      body.querySelector(".Header_main").style = "display:none";
      body.querySelector(".Navbar_main").style = "display:none";
    };
    const hideOne = () => {
      body.querySelector(".Header_main").style = "display:none";
    };
    if (path === "/admin") {
      return hide();
    } else {
      body.querySelector(".Header_main").style = "display:flex";
      body.querySelector(".Navbar_main").style = "display:block";
    }
    if (path === "/contact") {
      return hideOne();
    } else {
      body.querySelector(".Header_main").style = "display:flex";
      body.querySelector(".Navbar_main").style = "display:block";
    }
    if (path === "/about_us") {
      return hideOne();
    } else {
      body.querySelector(".Header_main").style = "display:flex";
      body.querySelector(".Navbar_main").style = "display:block";
    }
    if (path === "/signup") {
      return hide();
    } else {
      body.querySelector(".Header_main").style = "display:flex";
      body.querySelector(".Navbar_main").style = "display:block";
    }
    if (path === "/signin") {
      return hide();
    } else {
      body.querySelector(".main_container").style = "left:20%;width:80%;";
      body.querySelector(".Header_main").style = "display:flex";
      body.querySelector(".Navbar_main").style = "display:block";
    }
  }, [path]);
  return (
    <div className="Router">
      <Routes>
        <Route path="*" element={<Progress />} />
        <Route path="/" element={<Progress />} />
        <Route path="contact" element={<Contact />} />
        <Route path="about_us" element={<Aboutus />} />
        <Route path="/signin" element={<SignIn/>} />
        <Route path="/signup" element={<SignUp />} />
        <Route path="/admin" element={<Admin />} />
      </Routes>
    </div>
  );
};
const RouterAdmin = () => {
  return (
    <div className="Router">
      <Routes>
        <Route path="/admin" element={<Admin />} />
      </Routes>
    </div>
  );
};
const router = {
  RouterAdmin: RouterAdmin,
  Router: Router,
};
export default router;
