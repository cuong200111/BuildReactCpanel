import React, { useState } from "react";
import { Link } from "react-router-dom";
import { handleData } from "../../redux/action";
import {  useDispatch } from "react-redux";
import PersonAddAltIcon from "@mui/icons-material/PersonAddAlt";
import axios from "axios";
const SignUp = () => {
  const [name,setName]=useState('')
  const [email,setEmail]=useState('')
  const [pass,setPass]=useState('')
  const [confirmPass,setConfirmpass]=useState('')
  const dispatch = useDispatch();
  const handleSignUp = (event) => {
    event.preventDefault();
  dispatch(handleData('1','2','3'))
  }
  return (
    <div className="login">
      <form className="login_form">
        <p className="login_form_title">Sign up account</p>
        <div className="login_form_input">
          <input placeholder="Your name" type="text" onChange={(e)=>{setName(e.target.value)}} />
          <span>
            <PersonAddAltIcon />
          </span>
        </div>
        <div className="login_form_input">
          <input placeholder="Your Email" type="email" onChange={(e)=>{setEmail(e.target.value)}} />

          <span>
            <svg
              stroke="currentColor"
              viewBox="0 0 24 24"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M16 12a4 4 0 10-8 0 4 4 0 008 0zm0 0v1.5a2.5 2.5 0 005 0V12a9 9 0 10-9 9m4.5-1.206a8.959 8.959 0 01-4.5 1.207"
                strokeWidth="2"
                strokeLinejoin="round"
                strokeLinecap="round"
              ></path>
            </svg>
          </span>
        </div>
        <div className="login_form_input">
          <input placeholder="Password" type="password" onChange={(e)=>{setPass(e.target.value)}} />
          <span>
            <svg
              stroke="currentColor"
              viewBox="0 0 24 24"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"
                strokeWidth="2"
                strokeLinejoin="round"
                strokeLinecap="round"
              ></path>
              <path
                d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"
                strokeWidth="2"
                strokeLinejoin="round"
                strokeLinecap="round"
              ></path>
            </svg>
          </span>
        </div>
        <div className="login_form_input">
          <input placeholder="Confirm password" type="password" onChange={(e)=>{setConfirmpass(e.target.value)}} />
          <span>
            <svg
              stroke="currentColor"
              viewBox="0 0 24 24"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"
                strokeWidth="2"
                strokeLinejoin="round"
                strokeLinecap="round"
              ></path>
              <path
                d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"
                strokeWidth="2"
                strokeLinejoin="round"
                strokeLinecap="round"
              ></path>
            </svg>
          </span>
        </div>
        <button
          className="submit"
          type="submit"
          onClick={(e) => {
            handleSignUp(e);
          }}
        >
          Sign up
        </button>

        <p className="signup-link">
          Have an account?
          <Link to="/signin">Sign In</Link>
        </p>
      </form>
    </div>
  );
 
};

export default SignUp;
