import React, { useEffect, useRef, useState } from "react";
import Table from "../Table/Table";
import anime from "animejs";
const Progress = () => {
  const animate = useRef(null)
    useEffect(() => {
    anime({
      targets: animate.current,
      opacity: 0,
      duration: 0,
      easing: 'easeInOutSine',
      complete: () => {
        anime({
          targets: animate.current,
          opacity: 1,
          duration: 200,
          easing: 'easeInOutSine'
        });
      }
    });
  }, []);
  return (
    
    <div className="Progress" ref={animate}>
         <title>Lifetek-Progress</title>
      <div className="Progress_container">
        <div className="Progress_container_top">
          <h1 className="fml">Web-Progress</h1>
        </div>
        <div className="Progress_container_bottom">
        <Table/>
        </div>
      </div>
    </div>
  );
};

export default Progress;
