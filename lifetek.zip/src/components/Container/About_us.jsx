import React from 'react'

const Article = () => {
  return (
    <div>
         <title>Lifetek-About_us</title>
    </div>
  )
}

export default Article