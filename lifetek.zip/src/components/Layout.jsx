import React from 'react'
import { BrowserRouter } from 'react-router-dom'
import Header from './Header/Header'
import Navbar from './Navbar/Navbar'
import Router from './Router/Router'

const Layout = () => {


  return (

    <BrowserRouter>  
 
   <div className='main'>
   <Navbar/>
    <div className='main_container'>
      <Header />
      <Router.Router/>
    </div>
   </div>
      
    </BrowserRouter>
  )


}

export default Layout