import Cookies from "js-cookie";
import React, { useEffect, useRef, useState } from "react";
import SendIcon from "@mui/icons-material/Send";
import "./scss/chat.scss";
import axios from "axios";
import { pathApi } from "../../Config/pathApi";
import { socket } from "../../socket";

const Chat = () => {
  const [sendChat, setChatValue] = useState("");
  const [dataChatJson, setdataChat] = useState([]);
  const [num, setNum] = useState(0); //data cua nguoi dung gui den
  const [socketData, setSocketData] = useState("");
  const scrollview = useRef(null);
  const email = Cookies.get("emailUser");
  useEffect(() => {
    const dataChat = async () => {
      const dataChats = await axios.get(`${pathApi}/chatdata/${email}`);
      setdataChat(dataChats.data);
      setTimeout(() => {
        scrollview.current.scrollTop = scrollview.current.scrollHeight;
      }, 0);
    };
    dataChat();
  }, [email, num]);

  socket.emit("room", "idroom");
  socket.on("receive", data=>{
    console.log(data);
  });
  console.log(socketData);
  const SendHandle = (e) => {
    e.preventDefault();
    socket.emit("send", "idroom", sendChat);
    setNum(num + 1);
    const chatHandler = new Promise(async (resolve, reject) => {
      if (Cookies.get("AccessToken")) {
     
        
        const lifeTekChat = await axios.post(`${pathApi}/lifeTekChat`, {
          permiss: "user",
          token: Cookies.get("AccessToken"),
          sendChat,
          email,
          atDate: new Date().getTime(),
        });

        if (lifeTekChat) {
          setTimeout(() => {
            scrollview.current.scrollTop = scrollview.current.scrollHeight;
          }, 1000);
        }
        resolve(lifeTekChat);
      } else if (Cookies.get("admin")) {
        const lifeTekChat = await axios.post(`${pathApi}/lifeTekChat`, {
          permiss: "admin",
          token: Cookies.get("admin"),
          sendChat,
          email,
          atDate: new Date().getTime(),
        });

        if (lifeTekChat) {
          setTimeout(() => {
            scrollview.current.scrollTop = scrollview.current.scrollHeight;
          }, 1000);
          resolve(lifeTekChat);
        }
      }
    });
    chatHandler.then((item) => item);
  };

  return (
    <section className="chatbox">
      <section className="chat-window" ref={scrollview}>
        {dataChatJson.map((item, index) => (
          <article
            className={`msg-container ${
              item.is === "admin" ? " msg-remote" : " msg-self"
            }`}
            id="msg-0"
          >
            {" "}
            {/*self*/}
            <div className="msg-box">
              <img
                className="user-img"
                id="user-0"
                src="/img/lifeTek.png"
                alt=""
              />
              <div className="flr">
                <div className="messages">
                  <p className="msg" id="msg-0">
                    {item.msg}
                  </p>
                </div>
                <span className="timestamp">
                  <span className="username">Name</span>&bull;
                  <span className="posttime">Now</span>
                </span>
              </div>
            </div>
          </article>
        ))}
      </section>
      <form className="chat-input">
        <input
          type="text"
          onChange={(e) => {
            setChatValue(e.target.value);
          }}
          placeholder="Nhập tin của bạn"
        />
        <button
          onClick={(e) => {
            SendHandle(e);
          }}
          className="Button_chat"
        >
          <SendIcon />
        </button>
      </form>
    </section>
  );
};

export default Chat;
