import Cookies from "js-cookie";

export const tokenProfile = `${Cookies.get('AccessToken')}`



const arr = ({
    name:'ssss',
    pass:'sss'
},{
    name:'ssss',
    pass:'sss'
},{
    name:'ssss',
    pass:'sss'
},{
    name:'ssss',
    pass:'sss'
})