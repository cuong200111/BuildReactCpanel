import { put, call, takeLatest, takeEvery } from "redux-saga/effects";
import { pathApi } from "../../Config/pathApi";
import axios from "axios";
import { dataJob } from "../action";
import { requestData } from "../action";
import { fail } from "../action";
import Cookies from "js-cookie";
import { tokenProfile } from "../../Token/token";
const cookiesAssessToken = Cookies.get("AccessToken");

function* fetchDataJob() {
  try {
    const data = yield axios.get(`${pathApi}/profile`, {
      headers: { Authorization: `${cookiesAssessToken}` },
    });

    const resChat = yield axios.get(`${pathApi}/chat`, {
      headers: { Authorization: `${tokenProfile}` },
    });


    yield put(dataJob({ data, resChat: resChat.data }));
  } catch (error) {
    yield put(fail(error));
  }
}

function* rootSaga() {
  yield takeLatest(requestData, fetchDataJob);
}
export default rootSaga;
