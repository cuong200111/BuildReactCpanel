const iniState = {
  data: [],
  loading: false,
  error: null,
};
const reducer = (state = iniState, action) => {
  switch (action.type) {
    case "requestData":
      return { ...state, loading: true };
    case "responseData":
      
      return {...state,data:action.payload, loading: false};
    case "failData":
        return {...state,error:action.payload, loading: false};
    default:
    return state
  }
};
export default reducer