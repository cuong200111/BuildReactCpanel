

const susess = 'responseData'
export const requestData = 'requestData'
const failData = 'failData'

export const request = ()=>({
    type:requestData,
})
export const dataJob = (data)=>({
    type:susess,
    payload:data
})

 export const fail = (err)=>({
    type:failData,
    payload:err
})


