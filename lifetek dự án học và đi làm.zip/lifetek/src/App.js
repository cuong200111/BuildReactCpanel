import axios from "axios";
import Cookies from "js-cookie";
import { useEffect, useMemo, useState } from "react";
import Layout from "./components/Layout";
import { pathApi } from "./Config/pathApi";
import LayoutAdmin from "./admin/LayoutAdmin";
import React from 'react';
import CircularProgress from '@mui/material/CircularProgress';
import { request } from "./redux/action";
import { useDispatch, useSelector } from "react-redux";
import ChatLayout from "./components/Chat/ChatLayout";
function App() {
  const [dataUser, setDataUser] = useState([]);
  const [dataJob, setDataJob] = useState([]);
  const [loading,setLoading]=useState(true)
  const [onlineAdmind, setOnlineadmin] = useState(null);
  const dispatch = useDispatch();
  const cookiesAssessToken = Cookies.get("AccessToken");
 const load =  useMemo(()=>{
const fetchData = async()=>{
const data = await axios.get(`${pathApi}/profile`,{headers:{Authorization:`${cookiesAssessToken}`}})

if(data){
  setLoading(false)

}else{
  setLoading(true)
}
return data
} 

return fetchData()
},[cookiesAssessToken])
  useEffect(() => {
    dispatch(request());
  }, [dispatch]);

  useEffect(() => {
    if (window.location.pathname === "/chat") {
      Cookies.set("chat", true);
    } else {
      Cookies.set("chat", false);
    }
  }, []);

  const chat = Cookies.get("chat");
  useEffect(() => {
    const getUser = async () => {
      const user = await axios.get(`${pathApi}/admin`, {
        headers: { Authorization: `${Cookies.get("admin")}` },
      });

      if (user) {
        setDataUser(user.data.userFind);
        setDataJob(user.data.findJob);
        setOnlineadmin(user.data.onlineAdmin);
      }
    };
    getUser();
  }, []);

  if (chat === "true") {
    return (
      <div className="App">
        <ChatLayout />
      </div>
    );
  } else if (chat === "false") {
    if (onlineAdmind === true) {
      return (
        <div className="App">
          <LayoutAdmin dataUser={dataUser} dataJob={dataJob} />
        </div>
      );
    } else if (onlineAdmind === false) {
    

    return (
      <div className="App">
        {loading? <div className="LoadingApp">
 <CircularProgress disableShrink /></div> :<Layout />}
      
      </div>
    );

  
    
    }
  }
}

export default App;
