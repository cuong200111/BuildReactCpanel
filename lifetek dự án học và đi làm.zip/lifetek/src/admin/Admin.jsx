import React from 'react'
import { Link } from 'react-router-dom'
// import './css/admin.css'
const Admin = (props) => {
   
 const links = [
  {
    link:'addjob',
    des:'fdsf ',
    title:'fsdf'
  },
  {
    link:'userupdate',
    des:'fsdf',
    title:'fdsf'
  },
 ]


  return (
    <div>
     <a style={{textDecoration: "none"}} href="/">
        <button>
            <span><i className="fa-solid fa-arrow-left"></i> Home</span>
          </button>
    </a>
    <div className="main_admin" >
     
        {links.map((item,index)=>(
  <Link key={index} to={`/${item.link}`}>
  <div className="card-border">
      <div className="card-bg">
          <div className="container-logo">
              <div className="logo"></div>
              <div className="logo-inside">
                  <div className="first"></div>
                  <div className="second"></div>
              </div>
          </div>
          <div id="blur-area"></div>
          <div className="marquee">
              <div className="marquee__inner" aria-hidden="true">
                  <span className="viper">viper viper viper viper</span>
                  <span className="viper">viper viper viper viper</span>
                  <span className="viper">viper viper viper viper</span>
              </div>
          </div>

      </div>
      <div className="mist-container">
          <div className="mist"></div>
      </div>
      <strong id="text-ext" className="bg-clip-text">{item.des}</strong>
      <strong id="text-border">{item.title}</strong>
  </div>
</Link>
      ))}
          
    
    </div>
    </div>

  )
}

export default Admin