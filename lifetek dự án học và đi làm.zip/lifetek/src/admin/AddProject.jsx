import axios from "axios";
import React, { useState } from "react";
import { pathApi } from "../Config/pathApi";
// import "./css/job.css";
const AddProject = (props) => {
  const [project, setProject] = useState({
    email: "",
    dev: "",
    job: "",
    noti:""
  });
  
  const [file, setFile] = useState(null)
  const [status, setStatus] = useState('')
  const HandleProject = (e) => {
    e.preventDefault();

    const { className, value } = e.target;
    setProject({
      ...project,
      [className]: value,
    });
  };
  const HandleAddProject = async (e) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append("email", project.email);
    formData.append("dev", project.dev);
    formData.append("job", project.job);
    formData.append("noti", project.noti);
    formData.append("date", new Date().getTime());
    formData.append('docx', file);
    const Project = await axios.post(`${pathApi}/addProject`, formData, {
      headers: {'Content-Type': 'multipart/form-data'}
    });
    if(Project.data === 'them thanh cong'){
      setStatus('them thanh cong')
      return window.location.href = './addProject'
    }else{
      alert('khong thanh cong')
    }
  };
  return (
    <div>
      <span><h1>{status}</h1></span>
      <a id="back" href="/admin">
        <button className="cta">
          <span className="hover-underline-animation">Trở về Admin</span>
        </button>
      </a>
      <form encType="multipart/form-data">
        <label>Khách hàng</label>
        <select
          onChange={(e) => {
            HandleProject(e);
          }}
          className="email"
        >
          <option value=""></option>
          {props.dataUser.map((item, index) => (
            <option key={index} value={item.email}>{item.email}</option>
          ))}
        </select>
        <div className="input-container">
          <input
            onChange={(e) => {
              HandleProject(e);
            }}
            className="dev"
            type="text"
            id="input"
            required=""
          />
          <label htmlFor="input" className="label">
            Dev Làm việc.
          </label>
          <div className="underline"></div>
        </div>
        <div className="input-container">
          <input
            onChange={(e) => {
              HandleProject(e);
            }}
            className="noti"
            type="text"
            id="input"
            required=""
          />
          <label htmlFor="input" className="label">
            Thông báo cho người dùng.
          </label>
          <div className="underline"></div>
        </div>
        <label>Tên job</label>
        <select
          onChange={(e) => {
            HandleProject(e);
          }}
          className="job"
          name="theloai"
        >
          <option value=""></option>
          {props.dataJob.map((item, index) => (
            <option key={index} value={item.job}>{item.job}</option>
          ))}
        </select>
        <div className="input-container">
          <label>Chọn tệp docx</label>
          <input onChange={(e)=>{setFile(e.target.files[0])}}
            accept=".docx"
            type="file"
            name="docx"
            id="input"
            required=""
          />
        </div>

        <button
          onClick={(e) => {
            HandleAddProject(e);
          }}
          id="add"
          type="submit"
        >
          Xác Nhận Thêm
        </button>
      </form>
    </div>
  );
};

export default AddProject;
