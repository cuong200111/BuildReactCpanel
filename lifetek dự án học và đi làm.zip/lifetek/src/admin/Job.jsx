import axios from 'axios'
import React, { useEffect, useState } from 'react'
import { pathApi } from '../Config/pathApi'
// import './css/job.css'
const Job = (props) => {

const [job,setJob]= useState('')


const HandeladdJob =  async (e)=>{
    e.preventDefault()
const statusJob = await axios.post(`${pathApi}/addJob`,{job,date:new Date().getTime()})

}

    
  return (
    <div>
   
    <a id="back" href="/admin"><button className="cta">
        <span className="hover-underline-animation">Trở về Admin</span>
    
    </button></a>
    <form>

        <div className="input-container">
            <input onChange={(e)=>{setJob(e.target.value)}} type="text" id="input" required=""/>
            <label for="input" className="label">Nhập tên Job</label>
            <div className="underline"></div>
        </div>

        <button onClick={(e)=>{HandeladdJob(e)}} id="add" type="submit">Xác Nhận Thêm</button>
    </form>

    <script src="/reload/reload.js"></script>

    </div>
  )
}

export default Job