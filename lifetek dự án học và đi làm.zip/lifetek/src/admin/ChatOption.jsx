import axios from 'axios'
import React from 'react'
import { pathApi } from "../Config/pathApi";
import { useNavigate } from 'react-router-dom';
import Cookies from 'js-cookie';

const ChatOption = (props) => {

  const user = props.dataUser ? props.dataUser:[]
  const navigate = useNavigate()
  const OptionUser = async (e)=>{

    const option = await axios.get(`${pathApi}/getAdminChat/${e.target.value}`)
if(option){
  Cookies.set('emailUser',option.data)
  window.location.href = '/chat'
}
  }

  return (
    <div>
      <div>
      {user.map((item,index)=>(
       <div key={index}>
        <button value={item.email} onClick={(e)=>{OptionUser(e)}}> {item.email}</button>
       </div>
      ))}
      </div>
    </div>
  )
}

export default ChatOption