import React from "react";
import { Routes, Route, BrowserRouter } from "react-router-dom";
import Admin from "./Admin";
import UserUpdate from "./ChatOption";
import Job from "./Job";
import AddProject from "./AddProject";

import ChatOption from "./ChatOption";

const LayoutAdmin = (props) => {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="*" element={<Admin dataUser={props.dataUser} />} />
        <Route path="/admin" element={<Admin dataUser={props.dataUser} />} />
        <Route path="/addjob" element={<Job dataUser={props.dataUser} />} />
        <Route
          path="/chatoption"
          element={<ChatOption dataUser={props.dataUser} />}
        />
        <Route
          path="/addProject"
          element={
            <AddProject dataUser={props.dataUser} dataJob={props.dataJob} />
          }
        />
       
      </Routes>
    </BrowserRouter>
  );
};

export default LayoutAdmin;
