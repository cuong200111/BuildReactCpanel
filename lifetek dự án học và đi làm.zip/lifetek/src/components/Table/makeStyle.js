import { makeStyles } from "@mui/styles"

export const useStyle = makeStyles({
    down:{
        color:'#1c931c',
        fontSize:'30px'
    },
    notifica:{
        color:'rgba(0,0,0,0.53)',
        fontSize:'30px',
        cursor:'pointer'
    }
})