import React, { useEffect, useRef, useState } from "react";
import PropTypes from "prop-types";
import { useTheme } from "@mui/material/styles";
import Box from "@mui/material/Box";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableFooter from "@mui/material/TableFooter";
import TablePagination from "@mui/material/TablePagination";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import IconButton from "@mui/material/IconButton";
import FirstPageIcon from "@mui/icons-material/FirstPage";
import KeyboardArrowLeft from "@mui/icons-material/KeyboardArrowLeft";
import KeyboardArrowRight from "@mui/icons-material/KeyboardArrowRight";
import LastPageIcon from "@mui/icons-material/LastPage";
import TableHead from "@mui/material/TableHead";
import Buttons from "../Button/Button";
import Status from "../Status/Status";
import { useStyle } from "./makeStyle";
import FileDownloadIcon from "@mui/icons-material/FileDownload";
import { request } from "../../redux/action";
import { useDispatch, useSelector } from "react-redux";
export default function CustomPaginationActionsTable() {
  const classes = useStyle();
  const dispatch = useDispatch()
  const User = useSelector((item) => item.data.data.data);
  useEffect(()=>{
    dispatch(request())
  },[dispatch])
  const mobile = window.innerWidth < 600;
  function TablePaginationActions(props) {
    const theme = useTheme();
    const { count, page, rowsPerPage, onPageChange } = props;

    const handleFirstPageButtonClick = (event) => {
      onPageChange(event, 0);
    };

    const handleBackButtonClick = (event) => {
      onPageChange(event, page - 1);
    };

    const handleNextButtonClick = (event) => {
      onPageChange(event, page + 1);
    };

    const handleLastPageButtonClick = (event) => {
      onPageChange(event, Math.max(0, Math.ceil(count / rowsPerPage) - 1));
    };

    return (
      <Box sx={{ flexShrink: 0, ml: 2.5 }}>
        <IconButton
          onClick={handleFirstPageButtonClick}
          disabled={page === 0}
          aria-label="first page"
        >
          {theme.direction === "rtl" ? <LastPageIcon /> : <FirstPageIcon />}
        </IconButton>
        <IconButton
          onClick={handleBackButtonClick}
          disabled={page === 0}
          aria-label="previous page"
        >
          {theme.direction === "rtl" ? (
            <KeyboardArrowRight />
          ) : (
            <KeyboardArrowLeft />
          )}
        </IconButton>
        <IconButton
          onClick={handleNextButtonClick}
          disabled={page >= Math.ceil(count / rowsPerPage) - 1}
          aria-label="next page"
        >
          {theme.direction === "rtl" ? (
            <KeyboardArrowLeft />
          ) : (
            <KeyboardArrowRight />
          )}
        </IconButton>
        <IconButton
          onClick={handleLastPageButtonClick}
          disabled={page >= Math.ceil(count / rowsPerPage) - 1}
          aria-label="last page"
        >
          {theme.direction === "rtl" ? <FirstPageIcon /> : <LastPageIcon />}
        </IconButton>
      </Box>
    );
  }

  TablePaginationActions.propTypes = {
    count: PropTypes.number.isRequired,
    onPageChange: PropTypes.func.isRequired,
    page: PropTypes.number.isRequired,
    rowsPerPage: PropTypes.number.isRequired,
  };





 const rows = useSelector(item =>item.data.data.data.findJobs)

 rows.sort((a,b)=>{
  return b.atDate - a.atDate
})
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const [barCell, setBarcell] = useState(null);
  // Avoid a layout jump when reaching the last page with empty rows.
  const emptyRows =
    page > 0 ? Math.max(0, (1 + page) * rowsPerPage - rows.length) : 0;

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };
  const HandlebarTable = (index) => {
    if (barCell === index) {
      setBarcell(null);
    } else {
      setBarcell(index);
    }
  };

  if (window.innerWidth > 1024) {
    return (
      <TableContainer component={Paper}>
        <Table sx={{ minWidth: 500 }} aria-label="custom pagination table">
          <TableHead>
            <TableRow>
              <TableCell align="center">Dev</TableCell>
              <TableCell align="center">Job</TableCell>
              <TableCell align="center">Web-type</TableCell>
              <TableCell align="center">Status</TableCell>
              <TableCell align="center">Status-report</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {(rowsPerPage > 0
              ? rows.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
              : rows
            ).map((row, index) => (
              <TableRow key={index}>
                <TableCell align="center" component="th" scope="row">
                  {row.dev}
                </TableCell>
                <TableCell align="center">{row.job}</TableCell>
                <TableCell align="center">{row.docx}</TableCell>
                <TableCell align="center">
                  <Status.Button User={User} />
                </TableCell>
                <TableCell align="center">
                  <Buttons.Loading docx={row.docx} />
                </TableCell>
              </TableRow>
            ))}

            {emptyRows > 0 && (
              <TableRow style={{ height: 53 * emptyRows }}>
                <TableCell colSpan={6} />
              </TableRow>
            )}
          </TableBody>
          <TableFooter>
            <TableRow>
              <TablePagination
                rowsPerPageOptions={[5, 10, 25, { label: "All", value: -1 }]}
                colSpan={3}
                count={rows.length}
                rowsPerPage={rowsPerPage}
                page={page}
                SelectProps={{
                  inputProps: {
                    "aria-label": "rows per page",
                  },
                  native: true,
                }}
                onPageChange={handleChangePage}
                onRowsPerPageChange={handleChangeRowsPerPage}
                ActionsComponent={TablePaginationActions}
              />
            </TableRow>
          </TableFooter>
        </Table>
      </TableContainer>
    );
  } else if (mobile) {
    return (
      <div>
        <TableContainer
          className="Table"
          component={Paper}
          sx={{
            overflow: "visible",
            maxWidth: "100%",
            "&::-webkit-scrollbar": { height: "0.4em" },
            "&::-webkit-scrollbar-thumb": { backgroundColor: "#3f51b5" },
          }}
        >
          <Table
            className="Table_container"
            aria-label="custom pagination table"
          >
            <TableHead className="Table_container_head">
              <TableRow>
                <TableCell align="center">Job</TableCell>
                <TableCell align="center">Web-type</TableCell>
                {window.innerWidth < 600 ? (
                  <TableCell align="center">Bars</TableCell>
                ) : (
                  <div>
                    <TableCell align="center">Dev</TableCell>
                    <TableCell align="center">Status</TableCell>
                    <TableCell align="center">Status-report</TableCell>
                  </div>
                )}
              </TableRow>
            </TableHead>

            <TableBody className="Table_container_body">
              {(rowsPerPage > 0
                ? rows.slice(
                    page * rowsPerPage,
                    page * rowsPerPage + rowsPerPage
                  )
                : rows
              ).map((row, index) => (
                <TableRow key={index} className="Table_container_body_bars">
                  <TableCell align="center">{row.job}</TableCell>
                  <TableCell align="center">{row.docx}</TableCell>

                  <TableCell align="center">
                    <FileDownloadIcon
                      className={`barsIcon ${classes.down}`}
                      onClick={() => {
                        HandlebarTable(index);
                      }}
                    />
                  </TableCell>

                  <TableCell
                    className={`Table_container_body_bars_content ${
                      barCell === index ? "active" : ""
                    }`}
                    align="center"
                  >
                    <div className="Table_container_body_bars_content_dev">
                      {" "}
                      {row.dev}
                    </div>
                    <Status.Button User={User} />

                    <Buttons.Loading docx={row.docx} />
                  </TableCell>
                </TableRow>
              ))}

              {emptyRows > 0 && (
                <TableRow style={{ height: 53 * emptyRows }}>
                  <TableCell colSpan={6} />
                </TableRow>
              )}
            </TableBody>
            <TableFooter className="Table_container_footer">
              <TableRow>
                <TablePagination
                  rowsPerPageOptions={[5, 10, 25, { label: "All", value: -1 }]}
                  colSpan={3}
                  count={rows.length}
                  rowsPerPage={rowsPerPage}
                  page={page}
                  SelectProps={{
                    inputProps: {
                      "aria-label": "rows per page",
                    },
                    native: true,
                  }}
                  onPageChange={handleChangePage}
                  onRowsPerPageChange={handleChangeRowsPerPage}
                  ActionsComponent={TablePaginationActions}
                />
              </TableRow>
            </TableFooter>
          </Table>
        </TableContainer>
      </div>
    );
  }
}
