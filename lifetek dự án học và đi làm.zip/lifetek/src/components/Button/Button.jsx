import React from "react";
import LoadingButton from "@mui/lab/LoadingButton";
import Box from "@mui/material/Box";
import VisibilityIcon from '@mui/icons-material/Visibility';
import axios from "axios";
import { pathApi } from "../../Config/pathApi";
import fileSaver from 'file-saver'
import Cookies from "js-cookie";
import { useLocation } from "react-router-dom";
const LoadingButtonsTransition = (props) => {

  const [loading, setLoading] = React.useState(false);
  const location = useLocation()

  const handleClick =  async () => {
    setLoading(false)
    const docx =props.docx
    const download = await axios.get(`${pathApi}/download/${docx}`,{headers:{Authorization:`${Cookies.get('AccessToken')}`},responseType:'json'})
    console.log(download); 

    if(download){
      if(download.data.status === 'sucssues'){
   
        const docDownload = await axios.get(`${pathApi}/docxdownload/${download.data.datas.a}/${download.data.datas.b}`,{headers:{Authorization:`${Cookies.get('AccessToken')}`},responseType:'blob'})
        if(docDownload){
    
          setLoading(false)
          const blob  = new Blob([docDownload.data],{type:'application/vnd.openxmlformats-officedocument.wordprocessingml.document'})
          fileSaver.saveAs(blob,`${docx}`)
        }
     
      }else if(download.data.status === "failed"){
   
        const docxdelete = await axios.delete(`${pathApi}/docxdelete/${download.data.datas.a}/${download.data.datas.b}`,{headers:{Authorization:`${Cookies.get('AccessToken')}`}})
        console.log(docxdelete);
      }
    }

   
  };



























  return (

      <Box>
        <Box sx={{ "& > button": { m: 1 } }}>
          <LoadingButton
            color="success"
            onClick={handleClick}
            loading={loading}
            loadingPosition="start"
            startIcon={<VisibilityIcon />}
            variant="contained"
          >
            <span>See</span>
          </LoadingButton>
        </Box>
      </Box>

  );
};
const button ={
  Loading: LoadingButtonsTransition,
};
export default button
