import React, { useState, useEffect } from 'react';
import io from 'socket.io-client';
const Article = () => {

  
  const socket = io('http://localhost:2000');
  

    const [messages, setMessages] = useState([]);
    const [newMessage, setNewMessage] = useState('');
  console.log(messages);
    useEffect(() => {
      // Listen for new message event from server
      socket.on('newMessage', message => {
        setMessages([...messages, message]);
      });
  
      // Clean up function to disconnect socket when component unmounts
      return () => {
        socket.disconnect();
      };
    }, [messages,socket]);
  
    const handleNewMessage = e => {
      setNewMessage(e.target.value);
    };
  
    const handleSubmit = e => {
      e.preventDefault();
  
      // Emit new message event to server
      socket.emit('newMessage', {
        content: newMessage,
        sender: 'me',
        receiver: 'you'
      });
  
      setNewMessage('');
    };
  
    return (
      <div>
        <ul>
          {messages.map((message, index) => (
            <li key={index}>
              {message.sender}: {message.content}
            </li>
          ))}
        </ul>
        <form onSubmit={handleSubmit}>
          <input type="text" value={newMessage} onChange={handleNewMessage} />
          <button type="submit">Send</button>
        </form>
      </div>
    );
  }
  
  export default Article;