import React, { useEffect, useRef, useState } from "react";
import { Link, useNavigate} from "react-router-dom";
import axios from "axios";
import { pathApi } from "../../Config/pathApi";
import Stack from "@mui/material/Stack";
import Snackbar from "@mui/material/Snackbar";
import MuiAlert from "@mui/material/Alert";
import Cookies from "js-cookie";
import {useCookies} from 'react-cookie'


const SignIn = () => {
  console.log("%c Đừng quên đặt lại http và sercu cho cookie signp login","color:red; font-size:20px  ; font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;");
  console.log("%c Sửa đổi thay props header sang dùng redux","color:red; font-size:20px  ; font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;");
  console.log("%c thay prop1.User sang sử dụng redux biến User ở thẻ button trong bảng table","color:red; font-size:20px  ; font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;");

  const [cookies, setCookie, removeCookie] = useCookies();

  const [email, setEmail] = useState("");
  const [pass, setPass] = useState("");
  const [status, setStatus] = useState("");
  const [open, setOpen] = React.useState(false);
const navigate = useNavigate()

  const Alert = React.forwardRef(function Alert(props, ref) {
    return <MuiAlert elevation={6} ref={ref} variant="filled" {...props} />;
  });

  const HandleSignIn = async (event) => {
    event.preventDefault();

    setOpen(true);
   const signIn = await axios.post(`${pathApi}/login`,{
    email,pass
   })
   console.log(signIn);
    if(signIn.data.status === 'Hi Admin'){
      if(cookies.AccessToken){
        removeCookie('AccessToken')
        return setCookie('admin', signIn.data.token,{expires:new Date(Date.now()+(360000*24*365))})
      }else{
        return setCookie('admin', signIn.data.token,{expires:new Date(Date.now()+(360000*24*365))})
      }

    }else{
      if(signIn && signIn.data.token){
        if(cookies.admin){
          removeCookie('admin')
          setCookie('AccessToken',signIn.data.token,{expires:new Date(Date.now()+(360000*24*365))})
          return window.location.href = '/'
        }else{
          setCookie('AccessToken',signIn.data.token,{expires:new Date(Date.now()+(360000*24*365))})
          return window.location.href = '/'
        }
  
      }
    }
   
  };

  
  const messages = [
    { title: "warning", desc: "warning", msg: "Mật khẩu không hợp lệ" },
    { title: "info", desc: "info", msg: "Ô nhập không được bỏ trống" },
    { title: "success", desc: "success", msg: "Đăng Nhập thành công" },
  ];
  return (
    <div className="login">
      <Stack spacing={2} sx={{ width: "100%", position: "absolute" }}>
        {messages
          .filter((item) => item.title === status)
          .map((item, index) => (
            <Snackbar key={index} open={open} autoHideDuration={4000}>
              <Alert severity={item.desc}>{item.msg}</Alert>
            </Snackbar>
          ))}
      </Stack>
    
        {/* <form className="login_access">
          <div className="login_access_content fz12 fw600 fml">
            <h1>Xác thực người dùng</h1>
          </div>
          <div className="login_access_token">
            <div className="login_access_token_content">
              <input
                onChange={(e) => {
          
                }}
                type="text"
                maxLength={1}
              />
              <input
                onChange={(e) => {
        
                }}
                type="text"
                maxLength={1}
              />
              <input
                onChange={(e) => {
           
                }}
                type="text"
                maxLength={1}
              />
              <input
                onChange={(e) => {
               
                }}
                type="text"
                maxLength={1}
              />
            </div>
          </div>
          <button
            className="submit"
            onClick={(e) => {
              HandleSignInToken(e);
            }}
            type="submit"
          >
            Verify
          </button>
        </form> */}

        <form className="login_form" action="/">
          <p className="login_form_title">Sign in to your account</p>
          <div className="login_form_input">
            <input
              placeholder="Enter email"
              name="email"
              type="email"
              onChange={(e) => {
                setEmail(e.target.value);
              }}
            />
            <span>
              <svg
                stroke="currentColor"
                viewBox="0 0 24 24"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M16 12a4 4 0 10-8 0 4 4 0 008 0zm0 0v1.5a2.5 2.5 0 005 0V12a9 9 0 10-9 9m4.5-1.206a8.959 8.959 0 01-4.5 1.207"
                  strokeWidth="2"
                  strokeLinejoin="round"
                  strokeLinecap="round"
                ></path>
              </svg>
            </span>
          </div>
          <div className="login_form_input">
            <input
         
              placeholder="Enter password"
              name="password"
              type="password"
              onChange={(e) => {
                setPass(e.target.value);
              }}
            />

            <span>
              <svg
                stroke="currentColor"
                viewBox="0 0 24 24"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"
                  strokeWidth="2"
                  strokeLinejoin="round"
                  strokeLinecap="round"
                ></path>
                <path
                  d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"
                  strokeWidth="2"
                  strokeLinejoin="round"
                  strokeLinecap="round"
                ></path>
              </svg>
            </span>
          </div>
          <button
            className="submit"
            onClick={(e) => {
              HandleSignIn(e);
            }}
            type="submit"
          >
            Sign in
          </button>

          <p className="signup-link">
            No account?
            <Link to="/signup">Sign up</Link>
          </p>
        </form>
    </div>
  );
};
//
export default SignIn;
