import React, { useState } from "react";
import { Link } from "react-router-dom";
import { pathApi } from "../../Config/pathApi";
import validator from "validator";
import PersonAddAltIcon from "@mui/icons-material/PersonAddAlt";
import Stack from "@mui/material/Stack";
import Snackbar from "@mui/material/Snackbar";
import MuiAlert from "@mui/material/Alert";
import axios from "axios";
import Cookies from "js-cookie";
import {useCookies} from "react-cookie"
const SignUp = () => {
  console.log("%c Đừng quên đặt lại http và sercu cho cookie signp login","color:red; font-size:20px  ; font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;");
const [cookie,setCookie,removeCookie] = useCookies()

  const Alert = React.forwardRef(function Alert(props, ref) {
    return <MuiAlert elevation={6} ref={ref} variant="filled" {...props} />;
  });
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [pass, setPass] = useState("");
  const [statusVerify, setstatusVerify] = useState(false);
  const [codeVerify, setCodeVerify] = useState("");
  const [confirmPass, setConfirmpass] = useState("");
  const [status, setStatus] = useState("");
  const [open, setOpen] = React.useState(false);

  const handleClose = (event, reason) => {
    if (reason === "clickaway") {
      return;
    }
    setOpen(false);
  };
  const handleSignUp = async (event) => {
    event.preventDefault();
    setOpen(true);

    let bool = true;

    const invalidate = () => {
      if (
        pass.length === 0 ||
        confirmPass.length === 0 ||
        email.length === 0 ||
        name.length === 0
      ) {
        setStatus("info2");
        return (bool = false);
      }
      if (name <= 6)
        if (pass !== confirmPass) {
          setStatus("warning");
          return (bool = false);
        }
      if (pass.length <= 8) {
        setStatus("error");
        return (bool = false);
      }
      if (!validator.isEmail(email)) {
        setStatus("enail");
        return (bool = false);
      }
      return bool;
    };
    if (invalidate()) {
      const register = await axios.post(`${pathApi}/register`, {
        name,
        pass,
        email,
      });
      console.log(register);
      if (register && register.status === 200) {
    
        setCookie('token',register.data.accessToken,{maxAge:1800})
        setstatusVerify(true);
        setTimeout(()=>{
          alert(`mã đăng kí của bạn là ${register.data.verify.id}`)
        }
        ,1000)
      }
    }
  };
  const Handleverify = async (e) => {
    e.preventDefault();
    const cookie = Cookies.get('token')
    const verifytoken = await axios.post(`${pathApi}/verifytoken`, {
     token: cookie,
      codeVerify,
      email,
      pass,name
    });
    if(verifytoken.data.status === 'dang ki thanh cong'){
        console.log(verifytoken);
        Cookies.set(`AccessToken`,`${verifytoken.data.token}`,{expires:new Date(new Date().getTime()+(360000000*3))})
    }else if(verifytoken.data ==='tai khoan ton tai'){
      console.log('tai khoan dda ton tai');
    }

  };

  const messages = [
    { title: "error", desc: "error", msg: "Mật khẩu phải đủ 8 kí tự" },
    { title: "warning", desc: "warning", msg: "Mật khẩu không trùng nhau" },
    { title: "enail", desc: "warning", msg: "Email không hợp lệ" },
    { title: "info", desc: "info", msg: "Tài khoản đã tồn tại" },
    { title: "info2", desc: "info", msg: "Ô nhập không được bỏ trống" },
    { title: "success", desc: "success", msg: "Đăng kí thành công" },
  ];

  return (
    <div className="login">
      <Stack spacing={2} sx={{ width: "100%", position: "absolute" }}>
        {messages
          .filter((item) => item.title === status)
          .map((item, index) => (
            <Snackbar
              key={index}
              open={open}
              autoHideDuration={4000}
              onClose={handleClose}
            >
              <Alert severity={item.desc}>{item.msg}</Alert>
            </Snackbar>
          ))}
      </Stack>
      {statusVerify ? (
        <div className="verifyToken">
          <input
            type="text"
            onChange={(e) => {
              setCodeVerify(e.target.value);
            }}
          />
          <button
            onClick={(e) => {
              Handleverify(e);
            }}
          >
            Verify
          </button>
        </div>
      ) : (
        <form className="login_form">
          <p className="login_form_title">Sign up account</p>
          <div className="login_form_input">
            <input
            name="name"
              placeholder="Your name"
              type="text"
              onChange={(e) => {
                setName(e.target.value);
              }}
            />
            <span>
              <PersonAddAltIcon />
            </span>
          </div>
          <div className="login_form_input">
            <input
            name="email"
              placeholder="Your Email"
              type="email"
              onChange={(e) => {
                setEmail(e.target.value);
              }}
            />

            <span>
              <svg
                stroke="currentColor"
                viewBox="0 0 24 24"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M16 12a4 4 0 10-8 0 4 4 0 008 0zm0 0v1.5a2.5 2.5 0 005 0V12a9 9 0 10-9 9m4.5-1.206a8.959 8.959 0 01-4.5 1.207"
                  strokeWidth="2"
                  strokeLinejoin="round"
                  strokeLinecap="round"
                ></path>
              </svg>
            </span>
          </div>
          <div className="login_form_input">
            <input
            name="password"
              placeholder="Password"
              type="password"
              onChange={(e) => {
                setPass(e.target.value);
              }}
            />
            <span>
              <svg
                stroke="currentColor"
                viewBox="0 0 24 24"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"
                  strokeWidth="2"
                  strokeLinejoin="round"
                  strokeLinecap="round"
                ></path>
                <path
                  d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"
                  strokeWidth="2"
                  strokeLinejoin="round"
                  strokeLinecap="round"
                ></path>
              </svg>
            </span>
          </div>
          <div className="login_form_input">
            <input
            name="confirmPassword"
              placeholder="Confirm password"
              type="password"
              onChange={(e) => {
                setConfirmpass(e.target.value);
              }}
            />
            <span>
              <svg
                stroke="currentColor"
                viewBox="0 0 24 24"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"
                  strokeWidth="2"
                  strokeLinejoin="round"
                  strokeLinecap="round"
                ></path>
                <path
                  d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"
                  strokeWidth="2"
                  strokeLinejoin="round"
                  strokeLinecap="round"
                ></path>
              </svg>
            </span>
          </div>
          <button
            className="submit"
            type="submit"
            onClick={(e) => {
              handleSignUp(e);
            }}
          >
            Sign up
          </button>

          <p className="signup-link">
            Have an account?
            <Link to="/signin">Sign In</Link>
          </p>
        </form>
      )}
    </div>
  );
};

export default SignUp;
