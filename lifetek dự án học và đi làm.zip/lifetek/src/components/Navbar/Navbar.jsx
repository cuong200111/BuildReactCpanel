import React from 'react'
import { Link } from 'react-router-dom'

const Navbar = () => {
  return (
    <div className="Navbar_main">
         <div className='Navbar'>
      <div className="Navbar_Logo">
    <img src="/img/lifetek.png" alt="" />
      </div>
      <div className="Navbar_content">
     <ul>
      <li>
        <Link to="/">Tiến độ</Link>
      </li>
      <li>
        <Link to="/contact">Liên hệ</Link>
      </li>
      <li>
        <Link to="/about_us">Về chúng tôi</Link>
      </li>

     </ul>
      </div>
    </div>
    </div>
  )
}

export default Navbar