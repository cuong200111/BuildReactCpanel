import axios from "axios";
import Cookies from "js-cookie";
import React, { useEffect, useRef, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { pathApi } from "../../Config/pathApi";
import { pathLogin, pathLogout } from "./pathHeader/path";
import NotificationsNoneOutlinedIcon from "@mui/icons-material/NotificationsNoneOutlined";
import CloseIcon from "@mui/icons-material/Close";
import DehazeIcon from "@mui/icons-material/Dehaze";
import { useStyle } from "../Table/makeStyle";
import { useSelector } from "react-redux";
import { socket } from "../../socket";
const Header = (props) => {
  const naviga = useNavigate()
  const [textTime, setTexttime] = useState(null);
  const [headerRight, setHeaderRight] = useState("");
  const [ActiveMobile, setActiveMobile] = useState("");
  const [notChat, setnotChat] = useState([]);
  //Style classes ở tables
  const classes = useStyle();
  const emailChat = useSelector((item) => item.data.data.data);
  const dat = useSelector((item) => item.data.data.data.findJobs);
  const User = useSelector((item) => item.data.data.data);
  const emailUser = useSelector((item) => item.data.resChat);


  const notChatFilter = notChat.filter(
    (item) => item.is === "admin" && item.seenUser === false
  );
  const activeNoti = useRef(null);
  const Active = useRef("");
  const mobile = window.innerWidth < 600;
  const pc = window.innerWidth > 1024;

  useEffect(() => {
    const now = new Date();
    if (now.getHours() >= 0 && now.getHours() <= 9) {
      setTexttime("buổi sáng");
    } else if (now.getHours() >= 10 && now.getHours() <= 13) {
      setTexttime("buổi trưa");
    } else if (now.getHours() >= 14 && now.getHours() <= 17) {
      setTexttime("buổi chiều");
    } else if (now.getHours() >= 18 && now.getHours() <= 24) {
      setTexttime("buổi tối");
    }
  }, []);
  useEffect(() => {
    const notiChat = async () => {
      const dataNotiCHat = await axios.get(
        `${pathApi}/notifyChat/${emailChat.name}`
      );
      if (dataNotiCHat) {
        setnotChat(dataNotiCHat.data);
      } else {
        console.log("notichat loi");
      }
    };
    notiChat();
  }, [emailChat]);
  const handleClick = (event) => {
    event.preventDefault();

    if (Active.current) {
      Active.current.classList.toggle("active");
    }
  };

  const HandleNoti = async (e) => {
    e.preventDefault();
    if (activeNoti.current) {
      activeNoti.current.classList.toggle("active");
    }
    if (document.querySelector(".notifica_header_content.active")) {
      const notification = await axios.get(`${pathApi}/notifications`, {
        headers: { Authorization: `${dat[0].email}` },
      });
    }
  };
  const handleClickmobile = (event) => {
    event.preventDefault();
    setActiveMobile("active");
  };
  const CloseHead = (event) => {
    event.preventDefault();
    setActiveMobile("");
  };

  function handleClickOutside(event) {

    const headerUser = document.querySelector(".Header_right_content_user");
    const logoutButton = document.querySelector(
      ".Header_right_content_user_logout"
    );
    const notifica = document.querySelector(".notifica_header_icon");

    const formSign = document.querySelector(".Header_right_content_user_form");

    if (notifica && !notifica.contains(event.target)) {
      document
        .querySelector(".notifica_header_content")
        .classList.remove("active");
    }
    if (headerUser && !headerUser.contains(event.target)) {
      if (formSign) {
        formSign.classList.remove("active");
      }
    }
    if (headerUser && !headerUser.contains(event.target)) {
      if (logoutButton) {
        logoutButton.classList.remove("active");
      }
    }
  }

  document.addEventListener("click", handleClickOutside);

  dat.sort((a, b) => {
    return b.atDate - a.atDate;
  });
  const notifi = dat.slice(0, 4);
  const seen = notifi.filter((item) => item.seen === true);

  const dayNoti = notifi.map((item) => {
    const dateNow = new Date().getTime();

    const dateUpdate = dateNow - Number(item.atDate);
    const minNoti = Math.floor(dateUpdate / (1000 * 60));
    const monthNoti = Math.floor(dateUpdate / (1000 * 60 * 60 * 24 * 30));
    const dayNoti = Math.floor(dateUpdate / (1000 * 60 * 60 * 24));
    const hourNoti = Math.floor(dateUpdate / (1000 * 60 * 60));
    let result = "";
    if (minNoti < 60) {
      return (result = { ...item, atDate: minNoti + "Phút trước" });
    }
    if (minNoti > 60) {
      return (result = { ...item, atDate: hourNoti + "Giờ trước" });
    } else if (hourNoti > 24) {
      return (result = { ...item, atDate: dayNoti + "Ngày trước" });
    } else if (dayNoti > 30) {
      return (result = { ...item, atDate: monthNoti + "Tháng trước" });
    }
    return result;
  });
  const HandleLogout = async () => {
    Cookies.remove("AccessToken");
    window.location.reload();
  };

  const ChatHandle = async () => {
    const chatRes = await axios.get(`${pathApi}/chatopen`, {
      headers: {
        Authorization: `${emailUser.email} ${
          emailUser.name
        } ${new Date().getTime()}`,
      },
    });
    if (chatRes) {
     
      console.log(chatRes.data); //status và email
      Cookies.set("emailUser", chatRes.data.email);

      window.location.href = "./chat";
    }
  };
  return (
    <div className="Header_main">
      <div className="Header">
        <div className="Header_left">
          <div className="Header_left_title">
            <h1 className="fml fz18 fw600">CHÀO BẠN: {User.name}</h1>
          </div>
          <div className="Header_left_description">
            <h5 className="fml fz15 fw600">
              {" "}
              Chúc bạn có một {textTime} tốt lành
            </h5>
          </div>
        </div>

        <div className="Header_right">
          <div className="Header_right_content">
            <div
              className="Header_right_content_chat"
              onClick={ChatHandle}
              style={{ cursor: "pointer" }}
            >
              <div className="Header_right_content_chat_seen">
                {notChatFilter.length === 0 ? "" : notChatFilter.length}
              </div>
              <div></div>
              <svg
                width="22"
                height="22"
                viewBox="0 0 22 22"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  fillRule="evenodd"
                  clipRule="evenodd"
                  d="M9.2 20.82C9.66 21.43 10.31 21.78 11 21.78C11.69 21.78 12.34 21.43 12.8 20.82L14.3 18.82C14.35 18.76 14.42 18.72 14.5 18.72H15C19.42 18.72 21.75 16.39 21.75 11.97V6.97C21.75 2.55 19.42 0.220001 15 0.220001H7C2.58 0.220001 0.25 2.55 0.25 6.97V11.97C0.25 17.59 2.83 18.72 7 18.72H7.5C7.55 18.73 7.67 18.78 7.7 18.82L9.2 20.82ZM1.75 6.97C1.75 3.39 3.42 1.72 7 1.72H15C18.58 1.72 20.25 3.39 20.25 6.97V11.97C20.25 15.55 18.58 17.22 15 17.22H14.5C13.95 17.22 13.43 17.48 13.1 17.92L11.6 19.92C11.25 20.38 10.75 20.38 10.4 19.92L8.9 17.92C8.59 17.51 8.01 17.22 7.5 17.22H7C3.3 17.22 1.75 16.49 1.75 11.97V6.97ZM10 9.97C10 10.52 10.44 10.97 11 10.97C11.56 10.97 12 10.52 12 9.97C12 9.42 11.55 8.97 11 8.97C10.45 8.97 10 9.42 10 9.97ZM14 9.97C14 10.52 14.44 10.97 15 10.97C15.56 10.97 16 10.52 16 9.97C16 9.42 15.55 8.97 15 8.97C14.45 8.97 14 9.42 14 9.97ZM6 9.97C6 10.52 6.44 10.97 7 10.97C7.56 10.97 8 10.52 8 9.97C8 9.42 7.55 8.97 7 8.97C6.45 8.97 6 9.42 6 9.97Z"
                  fill="#626266"
                />
              </svg>
            </div>
            <div
              className="notifica_header"
              onClick={(e) => {
                HandleNoti(e);
              }}
            >
              <div className="notifica_header_seen">
                {seen.length === 0 ? "" : seen.length}
              </div>
              <NotificationsNoneOutlinedIcon
                className={`notifica_header_icon ${classes.notifica}`}
              />
              <div className={`notifica_header_content`} ref={activeNoti}>
                {dayNoti.map((item, index) => (
                  <div key={index}>
                    <h5>{item.notifica}</h5>
                    <span>{item.atDate}</span>
                  </div>
                ))}
              </div>
            </div>
            {pc && (
              <div
                className="Header_right_content_user"
                onClick={(e) => {
                  handleClick(e);
                }}
                onContextMenu={(e) => {
                  handleClick(e);
                }}
              >
                <img width={33} src="/img/icon.png" alt="" />
                <div className="Header_right_content_user_logout" ref={Active}>
                  <Link
                    to={pathLogout[0].path}
                    className="Header_right_content_user_logout_name"
                  >
                    <img width={30} src="/img/icon.png" alt="" />{" "}
                    <span style={{ wordBreak: "break-word" }}>
                      {" "}
                      {User.name}{" "}
                    </span>
                  </Link>

                  <Link
                    onClick={(e) => {
                      HandleLogout();
                    }}
                    className="fz15 Header_right_content_user_logout_container"
                  >
                    <div>
                      <img
                        width={30}
                        height={25}
                        src={`${pathLogout[2].icon}`}
                        alt=""
                      />
                      <span>{pathLogout[2].name}</span>
                    </div>
                  </Link>
                </div>
              </div>
            )}
            {mobile && (
              <div>
                <div
                  className="Header_right_content_user"
                  onClick={(e) => {
                    handleClickmobile(e);
                  }}
                >
                  <img width={33} src="/img/icon.png" alt="" />
                </div>

                <div
                  style={{ marginLeft: 0 }}
                  className={`Header_right_content_user_logout_mobile ${ActiveMobile}`}
                >
                  <div
                    className="close_user"
                    onClick={(e) => {
                      CloseHead(e);
                    }}
                  >
                    {" "}
                    <CloseIcon />
                  </div>
                  <Link
                    to={pathLogout[0].path}
                    className="Header_right_content_user_logout_mobile_name"
                  >
                    <img width={30} src="/img/icon.png" alt="" />{" "}
                    <span style={{ wordBreak: "break-word" }}>
                      {" "}
                      Chào Bạn {User.name}
                      <br />
                    </span>
                  </Link>

                  <Link
                    onClick={(e) => {
                      HandleLogout();
                    }}
                    className="fz15 Header_right_content_user_logout_mobile_container"
                  >
                    <div>
                      <img
                        width={30}
                        height={25}
                        src={`${pathLogout[2].icon}`}
                        alt=""
                      />
                      <span>{pathLogout[2].name}</span>
                    </div>
                  </Link>
                </div>
              </div>
            )}
          </div>
        </div>
        {mobile && (
          <div className="header_mobile">
            <div className="header_mobile_right">
              <div
                onClick={() => {
                  setHeaderRight("active");
                }}
                className="header_mobile_right_icon"
              >
                <DehazeIcon />
              </div>
              <div
                onClick={() => {
                  setHeaderRight("");
                }}
                className={`header_mobile_right_bg ${headerRight}`}
              ></div>
              <div className={`header_mobile_right_content ${headerRight}`}>
                <div className="header_mobile_right_content_logo">
                  <div className="header_mobile_right_content_logo_left">
                    <img width={140} src="/img/lifetek.png" alt="" />
                  </div>{" "}
                  <div className="header_mobile_right_content_logo_right">
                    <div>
                      <h4>LifeTek</h4>
                    </div>
                    <div>
                      <h5>Đồng hành cùng bạn</h5>
                    </div>
                  </div>
                </div>
                <div className="header_mobile_right_content_href">
                  {" "}
                  <div className="header_mobile_right_content_href_content">
                    <a href="/">
                      <img width={30} src="/img/progress.png" alt="" />
                      <h5>Progress</h5>
                      <img
                        className="header_mobile_right_content_href_content_next"
                        src="/img/right-arrow.png"
                        alt=""
                      />
                    </a>
                    <a href="/contact">
                      <img width={30} src="/img/contact.png" alt="" />
                      <h5>Contact</h5>
                      <img
                        className="header_mobile_right_content_href_content_next"
                        src="/img/right-arrow.png"
                        alt=""
                      />
                    </a>
                    <a href="/about_us">
                      <img width={30} src="/img/team.png" alt="" />
                      <h5>About_us</h5>
                      <img
                        className="header_mobile_right_content_href_content_next"
                        src="/img/right-arrow.png"
                        alt=""
                      />
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Header;
