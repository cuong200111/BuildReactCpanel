export const pathLogin = [
  {
    path: "/signup",
    name: "SignUp",
  },
  {
    path: "/signin",
    name: "SignIn",
  },
];
export const pathLogout = [
  {
    path: "/user",
    name: "",
    icon:""
  },
  {
    path: "/changepassword",
    name: "ChangePassword",
    icon:"/img/changePass.png"
  },
  {
    path: "/login",
    name: "Logout",
    icon:"/img/logout.png"
  },
];
