import React from 'react'

const Status = () => {
  return (
    <div className='status_table'>
       <button className='fz15 fw600 fml' style={{ color:"white",padding:"10px 2px",outline:"none",background:"green",userSelect:"none",border:"1px solid black",borderRadius:"3px"}}>
        Đang tiến hành
       </button>
    </div>
  )
}
const buttons={
    Button:Status,
}
export default buttons