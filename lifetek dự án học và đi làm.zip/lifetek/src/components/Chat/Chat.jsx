import Cookies from "js-cookie";
import React, { useEffect, useRef, useState } from "react";
import SendIcon from "@mui/icons-material/Send";
import "./scss/chat.scss";
import axios from "axios";
import { pathApi } from "../../Config/pathApi";
import { socket } from "../../socket";

const Chat = () => {

  const [dataChatJson, setdataChat] = useState([]);
  const [num, setNum] = useState(0); //data cua nguoi dung gui den
  const [newMesseges, setNewMesseges] = useState("");
  const email = Cookies.get("emailUser");
  const scrollview = useRef(null);
  const permiss = Cookies.get("AccessToken") ? "user" : "admin";
  useEffect(() => {
    const dataChat = async () => {
      const dataChats = await axios.get(`${pathApi}/chatdata/${email}`);
      setdataChat(dataChats.data);
      setTimeout(() => {
        scrollview.current.scrollTop = scrollview.current.scrollHeight;
      }, 0);
    };
    dataChat();
  }, [email, num]);
  useEffect(() => {
    socket.on("newMessage", ({ msg, seenUser, is, atDate, email }) => {
      const newArr = Array.from(dataChatJson);
      newArr.push({ msg, seenUser, is, atDate, email });
      setdataChat(newArr);
    });
    return ()=>{
      socket.on("disconnect", (reason) => {
       
      });
    }
  }, [dataChatJson]);
  const SendHandle = async (e) => {
    e.preventDefault();

  socket.emit("newMessage", {
      msg: newMesseges,
      seenUser: false,
      is: permiss,
      atDate: Date.now(),
      email: email,
    });

    const postchat = await axios.post(`${pathApi}/postChat`,{
      sendChat:newMesseges,
          seenUser: false,
          is: permiss,
          atDate: Date.now(),
          email: email
        })
  console.log(postchat);
  };
  console.log(dataChatJson);
  return (
    <section className="chatbox">
      <section className="chat-window" ref={scrollview}>
        {dataChatJson.map((item, index) => (
          <article
            className={`msg-container ${
              item.is === "admin" ? " msg-remote" : " msg-self"
            }`}
            id="msg-0"
          >
            {" "}
            {/*self*/}
            <div className="msg-box">
              <img
                className="user-img"
                id="user-0"
                src="/img/lifeTek.png"
                alt=""
              />
              <div className="flr">
                <div className="messages">
                  <p className="msg" id="msg-0">
                    {item.msg}
                  </p>
                </div>
                <span className="timestamp">
                  <span className="username">Name</span>&bull;
                  <span className="posttime">Now</span>
                </span>
              </div>
            </div>
          </article>
        ))}
      </section>
      <form className="chat-input">
        <input
          type="text"
          onChange={(e) => {
            setNewMesseges(e.target.value);
          }}
          placeholder="Nhập tin của bạn"
        />
        <button
          onClick={(e) => {
            SendHandle(e);
          }}
          className="Button_chat"
        >
          <SendIcon />
        </button>
      </form>
    </section>
  );
};

export default Chat;
