import React from 'react'
import { BrowserRouter } from 'react-router-dom'
import RouterChat from './RouterChat'

const ChatLayout = () => {
  return (
    <BrowserRouter>
  <RouterChat/>
     </BrowserRouter>
  )
}

export default ChatLayout