import React from "react";
import { BrowserRouter } from "react-router-dom";
import Header from "./Header/Header";
import Navbar from "./Navbar/Navbar";
import Router from "./Router/Router";
import axios from "axios";
import Cookies from "js-cookie";
import { request } from "../redux/action";
import { useDispatch } from "react-redux";
import { useEffect, useState } from "react";
import { pathApi } from "../Config/pathApi";
import RouterSign from "./Router/RouterSign";
const Layout = () => {
  const [online, setOnline] = useState(null);
  const [name, setName] = useState(null);
  const [Uid, setUidUser] = useState(null);
  const [dataJob, setDataJob] = useState(null);
  const cookiesAssessToken = Cookies.get("AccessToken");

  useEffect(() => {
    const getData = async () => {
      const data = await axios.get(`${pathApi}/profile`, {
        headers: { Authorization: `${cookiesAssessToken}` },
      });

      setName(data.data.name);
      setOnline(data.data.online);
      setUidUser(data.data.uid);
      setDataJob(data.data.findJobs);
    };
    getData();
  }, [cookiesAssessToken, online]);
  const User = {
    online,
    Uid,
    dataJob,
    name,
  };

  if (online === true) {
    return (
      <BrowserRouter>
        <div className="main">
          <Navbar />

          <div className="main_container">
            <Header User={User} />
            <Router.Router User={User} />
          </div>
        </div>
      </BrowserRouter>
    );
  } else if (online === false) {
    return (
      <BrowserRouter>
        <RouterSign />
      </BrowserRouter>
    );
  }
};

export default Layout;
