import React, { useEffect } from "react";
import { Routes, Route, useLocation } from "react-router-dom";

import SignUp from "../Container/Signup";
import SignIn from "../Container/SignIn";


const RouterSign = () => {
 
  return (
    <div className="Router">
      <Routes>
      <Route path="*" element={<SignIn />} />
        <Route path="/signin" element={<SignIn />} />
        <Route path="/signup" element={<SignUp />} />
      </Routes>
    </div>
  );
};


export default RouterSign;
