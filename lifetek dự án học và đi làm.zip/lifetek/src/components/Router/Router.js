import React, { useEffect, useMemo, useState } from "react";
import { Routes, Route, useLocation } from "react-router-dom";
import Aboutus from "../Container/About_us";
import Progress from "../Container/Progress";
import Contact from "../Container/Contact";
import Chat from "../Chat/Chat";
import Cookies from "js-cookie";
import axios from "axios";
import { pathApi } from "../../Config/pathApi";
import Stack from "@mui/material/Stack";
import LinearProgress from "@mui/material/LinearProgress";
const Router = (props) => {
  const [loading, setLoading] = useState(true);
  const cookiesAssessToken = Cookies.get("AccessToken");
  const load = useMemo(() => {
    const fetchData = async () => {
      const data = await axios.get(`${pathApi}/profile`, {
        headers: { Authorization: `${cookiesAssessToken}` },
      });

      if (data) {
        setLoading(false);
      } else {
        setLoading(true);
      }
      return data;
    };

    return fetchData();
  }, [cookiesAssessToken]);

  // useEffect(() => {
  //   const body = document.querySelector("body");
  //   const hide = () => {
  //     body.querySelector(".main_container").style = "left:0;width:100%;";
  //     body.querySelector(".Header_main").style = "display:none";
  //     body.querySelector(".Navbar_main").style = "display:none";
  //   };
  //   const hideOne = () => {
  //     body.querySelector(".Header_main").style = "display:none";
  //   };

  //   if (path === "/admin") {
  //     return hide();
  //   } else {
  //     body.querySelector(".Header_main").style = "display:flex";
  //     body.querySelector(".Navbar_main").style = "display:block";
  //   }
  //   if (path === "/contact") {
  //     return hideOne();
  //   } else {
  //     body.querySelector(".Header_main").style = "display:flex";
  //     body.querySelector(".Navbar_main").style = "display:block";
  //   }
  //   if (path === "/about_us") {
  //     return hideOne();
  //   } else {
  //     body.querySelector(".Header_main").style = "display:flex";
  //     body.querySelector(".Navbar_main").style = "display:block";
  //   }
  //   if (path === "/signup") {
  //     return hide();
  //   } else {
  //     body.querySelector(".Header_main").style = "display:flex";
  //     body.querySelector(".Navbar_main").style = "display:block";
  //   }
  //   if (path === "/signin") {
  //     return hide();
  //   } else {
  //     body.querySelector(".main_container").style = "left:20%;width:80%;";
  //     body.querySelector(".Header_main").style = "display:flex";
  //     body.querySelector(".Navbar_main").style = "display:block";
  //   }
  // }, [path]);

  return (
    <div className="Router">
      {loading ? (
        <Stack style={{
          height: "30vh",
          marginTop:"15vh",
          display: "flex",
          justifyContent: "space-between",
          flexDirection: "column",
        }} sx={{ width: "100%", color: "grey.500" }} spacing={2}>
          <LinearProgress
            
            color="success"
          />
          <LinearProgress style={{}} color="warning" />
          <LinearProgress style={{}} color="inherit" />
        </Stack>
      ) : (
        <Routes>
          <Route path="*" element={<Progress />} />
          <Route path="/" element={<Progress />} />
          <Route path="contact" element={<Contact />} />
          <Route path="about_us" element={<Aboutus />} />
          <Route path="chat" element={<Chat />} />
        </Routes>
      )}
    </div>
  );
};

const router = {
  Router: Router,
};
export default router;
