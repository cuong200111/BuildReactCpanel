import React, { useEffect, useState } from 'react';
import moment from 'moment';
const Time = () => {
  const timeNow = moment();

  const [times, setTimes] = useState({
    time: 0,
  });
  useEffect(() => {
    const time = setInterval(() => {
      setTimes({ time: times.time + 1 });
    }, 1000);
    return () => {
      clearInterval(time);
    };
  }, [times.time]);
  // momentSettings
  const { DD, MM, YYYY, HH, mm, ss } = {
    DD: timeNow.format('DD'),
    MM: timeNow.format('MM'),
    YYYY: timeNow.format('YYYY'),
    HH: timeNow.format('HH'),
    mm: timeNow.format('mm'),
    ss: timeNow.format('ss'),
  };
  return (
    <div style={{ fontSize: '12px', position: 'absolute', left: '42%' }}>
      <h1>
        {' '}
        {HH} Giờ {mm} Phút {ss} Giây
      </h1>
    </div>
  );
};

export default Time;
