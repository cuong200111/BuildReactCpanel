import { Close, CakeOutlined, DoubleArrowOutlined } from '@material-ui/icons';
import React, { useContext, useEffect, useState } from 'react';
import {
  TextField,
  Grid,
  InputAdornment,
  AppBar,
  Toolbar,
  IconButton,
} from '@material-ui/core';
import { makeStyles } from '@material-ui/styles';
import { MyContext } from 'containers/Layout/index';
import HistoryIcon from '@material-ui/icons/History';
import Time from 'components/Time/time';

{
  /* The comment below provides a prompt for the missing hint */
}
{
  /* Please provide a hint for the missing text alignment */
}
const useStyles = makeStyles({
  hoverSucsess: {
    background: 'rgb(237, 247, 237)',
    '&:hover': {
      background: 'rgb(210 243 210)',
    },
  },
  flexCenter: {
    display: 'flex',
    position: 'relative',
  },
  iconClose: {
    marginBottom: '12px',
  },
  GridContent: {
    marginTop: '20px !important',
    margin: '0 12px !important',
  },
  iconButton: {
    background: '#1755c77a',
    padding: '5px',
    borderRadius: '3px',
    cursor: 'pointer',
    '&:hover': {
      background: '#1755c7ab',
    },
  },
});
const arrInput = [
  {
    topic: 'Tính ngày sinh của bạn',
    label: 'Nhập ngày sinh',
    titleInput: 'Ngày sinh của bạn',
    name: 'Age',
  },
  {
    topic: 'Thời gian đầu tuần tuần',
    label: 'Ngày hiện tại',
    titleInput: 'Ngày hiện tại',
    name: 'Age',
  },
  {
    topic: 'Thời gian cuối tuần',
    label: 'Ngày hiện tại',
    titleInput: 'Ngày hiện tại',
    name: 'Age',
  },
  {
    topic: 'Thời gian đầu tháng',
    label: 'Ngày hiện tại',
    titleInput: 'Ngày hiện tại',
    name: 'Age',
  },
  {
    topic: 'Thời gian cuối tháng',
    label: 'Ngày hiện tại',
    titleInput: 'Ngày hiện tại',
    name: 'Age',
  },
];
const Moment = props => {
  // Classes css
  const classes = useStyles();
  const { onClose } = props;
  // lấy moment từ useContext
  const value = useContext(MyContext);
  const { moment } = value;
  const [num, setNumber] = useState(0);
  // State

  const [state, setState] = useState({
    inputUser: [
      {
        content: null,
      },
    ],
    output: [
      {
        sum: null,
      },
      {
        sum: null,
      },
      {
        sum: null,
      },
      {
        sum: null,
      },
      {
        sum: null,
      },
    ],
  });

  const handleitem = index => {
    setNumber(index);
    if (index === 0) {
      const timeNow = moment();

      const dateNow = moment(timeNow, 'YYYY-MM-DD');
      const birth = moment(state.inputUser[0].content, 'YYYY-MM-DD');
      const diffInDays =
        timeNow.diff(birth, 'year') || 'Nhập vào ngày sinh của bạn';

      setState({
        ...state,
        output: [
          {
            ...state.output[0],
            sum: String(diffInDays),
          },
          ...state.output.slice(1),
        ],
      });
    } else if (index === 1) {
      const timeNow = moment();
      const dateNow = moment(timeNow, 'YYYY-MM-DD');
      const diffInDays = dateNow
        .startOf('week')
        .add(1, 'days')
        .format('DD-MM-YYYY');
      const dayOfWeek = dateNow.day();
      const day =
        dayOfWeek === 0
          ? 'Chủ nhật'
          : dayOfWeek === 1
          ? 'Thứ 2'
          : dayOfWeek === 2
          ? 'Thứ 3'
          : dayOfWeek === 3
          ? 'Thứ 4'
          : dayOfWeek === 4
          ? 'Thứ 5'
          : dayOfWeek === 5
          ? 'Thứ 6'
          : dayOfWeek === 6
          ? 'Thứ 7'
          : '';

      setState({
        ...state,
        output: [
          ...state.output.slice(0, 1),
          {
            ...state.output[1],
            sum: `${day} ${diffInDays}`,
          },
          ...state.output.slice(2),
        ],
      });
    } else if (index === 2) {
      const timeNow = moment();
      const dateNow = moment(timeNow, 'YYYY-MM-DD');
      const month = timeNow.endOf('week');
      const endMonth = month.diff(dateNow, 'days') + 1;
      const diffInDays = dateNow
        .endOf('week')
        .add(1, 'days')
        .format('DD-MM-YYYY');
      const dayOfWeek = dateNow.day();
      const day =
        dayOfWeek === 0
          ? 'Chủ nhật'
          : dayOfWeek === 1
          ? 'Thứ 2'
          : dayOfWeek === 2
          ? 'Thứ 3'
          : dayOfWeek === 3
          ? 'Thứ 4'
          : dayOfWeek === 4
          ? 'Thứ 5'
          : dayOfWeek === 5
          ? 'Thứ 6'
          : dayOfWeek === 6
          ? 'Thứ 7'
          : '';

      setState({
        ...state,
        output: [
          ...state.output.slice(0, 2),
          {
            ...state.output[2],
            sum: `${day} ${diffInDays} còn ${endMonth} ngày nữa`,
          },
          ...state.output.slice(3),
        ],
      });
    } else if (index === 3) {
      const timeNow = moment();
      const dateNow = moment(timeNow, 'YYYY-MM-DD');
      const diffInDays = dateNow.startOf('month').format('DD-MM-YYYY');
      const dayOfWeek = dateNow.day();

      const day =
        dayOfWeek === 0
          ? 'Chủ nhật'
          : dayOfWeek === 1
          ? 'Thứ 2'
          : dayOfWeek === 2
          ? 'Thứ 3'
          : dayOfWeek === 3
          ? 'Thứ 4'
          : dayOfWeek === 4
          ? 'Thứ 5'
          : dayOfWeek === 5
          ? 'Thứ 6'
          : dayOfWeek === 6
          ? 'Thứ 7'
          : '';

      setState({
        ...state,
        output: [
          ...state.output.slice(0, 3),
          {
            ...state.output[3],
            sum: `${day} ${diffInDays}`,
          },
          ...state.output.slice(4),
        ],
      });
    } else if (index === 4) {
      const timeNow = moment();
      const dateNow = moment(timeNow, 'YYYY-MM-DD');
      const month = timeNow.endOf('month');
      const endMonth = month.diff(dateNow, 'days');
      const diffInDays = dateNow.endOf('month').format('DD-MM-YYYY');

      const dayOfWeek = dateNow.day();

      const day =
        dayOfWeek === 0
          ? 'Chủ nhật'
          : dayOfWeek === 1
          ? 'Thứ 2'
          : dayOfWeek === 2
          ? 'Thứ 3'
          : dayOfWeek === 3
          ? 'Thứ 4'
          : dayOfWeek === 4
          ? 'Thứ 5'
          : dayOfWeek === 5
          ? 'Thứ 6'
          : dayOfWeek === 6
          ? 'Thứ 7'
          : '';

      setState({
        ...state,
        output: [
          ...state.output.slice(0, 4),
          {
            ...state.output[4],
            sum: `${day} ${diffInDays} còn ${endMonth} ngày nữa`,
          },
        ],
      });
    }
  };
  const dateNowSlice = new Date().toISOString().slice(0, 10);

  return (
    <>
      {/* header */}
      <AppBar className={classes.flexCenter}>
        <Toolbar>
          <IconButton
            className={classes.iconButton}
            onClick={() => {
              onClose && onClose();
            }}
            color="inherit"
            sx={{ mr: 2 }}
          >
            <Close />
          </IconButton>
        </Toolbar>
        {/* gan vao day */}
        <Time />
      </AppBar>
      {/* container */}
      <Grid className={classes.GridContent} item md={12}>
        <Grid item>
          {arrInput.map((items, index) => (
            <Grid container key={index}>
              <Grid item xs={12} style={{ textAlign: 'left' }}>
                <Grid style={{ margin: '12px 0', marginRight: '5em' }}>
                  {items.topic}
                </Grid>
                <Grid container alignItems="center">
                  <TextField
                    onChange={e => {
                      setState({
                        ...state,
                        inputUser: [
                          {
                            ...state.inputUser[0],
                            content: e.target.value,
                          },
                        ],
                      });
                    }}
                    color="primary"
                    type="date"
                    defaultValue={dateNowSlice}
                    focused
                    label={items.label}
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start">
                          {index === 0 ? <CakeOutlined /> : <HistoryIcon />}
                        </InputAdornment>
                      ),
                    }}
                  />
                  <DoubleArrowOutlined
                    onClick={() => handleitem(index)}
                    className={classes.hoverSucsess}
                    style={{
                      margin: '0 20px',
                      cursor: 'pointer',

                      padding: '5px',
                      borderRadius: '5px',
                    }}
                  />
                  {index === num ? (
                    state.output[num].sum !== null ? (
                      <Grid item>
                        {String(state.output[num].sum)
                          ? num === 0
                            ? state.output[num].sum
                            : num === 1
                            ? state.output[num].sum
                            : num === 2
                            ? state.output[num].sum
                            : num === 3
                            ? state.output[num].sum
                            : num === 4
                            ? state.output[num].sum
                            : ''
                          : state.output[num].sum}
                      </Grid>
                    ) : (
                      ''
                    )
                  ) : (
                    ''
                  )}
                </Grid>
              </Grid>
            </Grid>
          ))}
        </Grid>
      </Grid>
    </>
  );
};

export default Moment;
