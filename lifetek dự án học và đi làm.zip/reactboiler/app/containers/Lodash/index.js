import { Close, CakeOutlined, DoubleArrowOutlined } from '@material-ui/icons';
import React, { useContext, useEffect, useMemo, useRef, useState } from 'react';
import Time from 'components/Time/time';
import _ from 'lodash';
import anime from 'animejs';
import {
  Grid,
  Button,
  InputLabel,
  FormControl,
  Select,
  MenuItem,
  AppBar,
  Toolbar,
  IconButton,
  TextField,
  Box,
} from '@material-ui/core';
import { makeStyles } from '@material-ui/styles';
import { MyContext } from 'containers/Layout/index';

{
  /* The comment below provides a prompt for the missing hint */
}
{
  /* Please provide a hint for the missing text alignment */
}

const useStyles = makeStyles({
  flexCenter: {
    display: 'flex',
    position: 'relative',
  },

  iconButton: {
    background: '#1755c77a',
    padding: '5px',
    borderRadius: '3px',
    cursor: 'pointer',
    '&:hover': {
      background: '#1755c7ab',
    },
  },
  heightItem: {
    height: '80%',
  },
  margin: {
    margin: '1em',
  },
});

const Moment = props => {
  // Classes css
  const classes = useStyles();
  const [data, setData] = useState(null);
  const [data2, setData2] = useState(null);
  const [lodash, setLodash] = useState(null);
  const [arr, setArr] = useState(null);
  const { onClose } = props;
  // lấy moment từ useContext
  const Print = useRef(null);
  const PrintMemo = useRef(null);

  const useMm = useMemo(() => {
    const str = data;
    return str;
  }, [data]);

  const handleanime = useRef(null);
  const handleanimemm = useRef(null);
  const animePrint1 = () => {
    anime({
      targets: handleanime.current,
      opacity: [0, 1],
      duration: 1000,
    });
  };
  const animePrint2 = () => {
    anime({
      targets: handleanimemm.current,
      opacity: [0, 1],
      duration: 1000,
    });
  };
  const methodLodash = ['map', 'filter', 'sortBy'];
  const lodashInput = useRef(null);
  const arrLodash = useRef(null);
  const [dataLodash, setDataLodash] = useState(null);
  return (
    <>
      <Box height="100vh">
        {/* header */}
        <AppBar className={classes.flexCenter}>
          <Toolbar>
            <IconButton
              className={classes.iconButton}
              onClick={() => {
                onClose && onClose();
              }}
              color="inherit"
              sx={{ mr: 2 }}
            >
              <Close />
            </IconButton>
          </Toolbar>
          {/* gan vao day */}
          <Time />
        </AppBar>
        {/* container */}{' '}
        <Box style={{ marginTop: '20px', height: '80vh' }}>
          <Grid container>
            <Grid
              style={{ display: 'flex', alignItems: 'center' }}
              item
              xs={12}
            >
              {' '}
              <Button
                onClick={() => {
                  animePrint2();
                  setLodash(null);
                  setData(Print.current.value);
                }}
                className={classes.margin}
                variant="outlined"
                color="default"
              >
                Click
              </Button>
              <TextField
                inputRef={Print}
                style={{ width: '20%' }}
                variant="outlined"
                inputProps={{
                  style: {},
                }}
                label="useMemo nhập vào kí tự bất kì"
              />
            </Grid>
            <Grid
              style={{ display: 'flex', alignItems: 'center' }}
              item
              xs={12}
            >
              <Button
                onClick={() => {
                  animePrint1();
                  setLodash(null);
                  setData2(PrintMemo.current.value);
                }}
                className={classes.margin}
                variant="outlined"
                color="default"
              >
                Click
              </Button>
              <TextField
                inputRef={PrintMemo}
                style={{ width: '20%' }}
                variant="outlined"
                label="useRef nhập vào kí tự bất kì"
              />
            </Grid>

            <Grid
              style={{ display: 'flex', alignItems: 'center' }}
              item
              xs={12}
            >
              <Button
                onClick={e => {
                  setArr(null);
                  setLodash(lodashInput.current.value);
                }}
                className={classes.margin}
                variant="outlined"
                color="default"
              >
                Click
              </Button>
              <FormControl
                style={{ width: 300 }}
                variant="filled"
                className={classes.formControl}
              >
                <InputLabel htmlFor="filled-age-native-simple">
                  Option Method Lodash
                </InputLabel>
                <Select inputRef={lodashInput} native>
                  {methodLodash.map(item => (
                    <option>{item}</option>
                  ))}
                </Select>
              </FormControl>
            </Grid>
          </Grid>
          <Box
            display="flex"
            justifyContent="center"
            className={classes.heightItem}
          >
            <Box
              borderRadius={10}
              marginTop={10}
              padding="20px"
              width="60vw"
              boxShadow={5}
            >
              {lodash ? (
                <>
                  {arr ? (
                    <>
                      <Grid item xs={12}>
                        Mảng hiện tại {arr}
                      </Grid>
                      <Grid container>
                        <Grid item xs={8}>
                          {lodash === 'map' ? (
                            <Button
                              variant="outlined"
                              color="secondary"
                              onClick={() => {
                                const methodLodash =
                                  lodash === 'map'
                                    ? _.map
                                    : lodash === 'filter'
                                      ? _.filter
                                      : lodash === 'sortBy'
                                        ? _.sortBy
                                        : null;
                                const lodashMap = methodLodash(
                                  JSON.parse(arr),
                                  item => {
                                    return item;
                                  },
                                );
                                setDataLodash(JSON.stringify(lodashMap));
                              }}
                            >
                              Chuyển chuỗi hoặc số thành mảng
                            </Button>
                          ) : lodash === 'filter' ? (
                            <Button
                              variant="outlined"
                              color="secondary"
                              onClick={() => {
                                const methodLodash =
                                  lodash === 'map'
                                    ? _.map
                                    : lodash === 'filter'
                                      ? _.filter
                                      : lodash === 'sortBy'
                                        ? _.sortBy
                                        : null;

                                const lodashMap = methodLodash(
                                  JSON.parse(arr),
                                  (item, index) => {
                                    if(item % 2 === 0) {
                                      return item
                                    }
                                
                                  },
                                );
                                setDataLodash(JSON.stringify(lodashMap));
                              }}
                            >
                              Trả về mảng có số chẵn với lodash
                            </Button>
                          ) : lodash === 'sortBy' ? (
                            <>
                              <Button
                                   variant="outlined"
                                   color="secondary"
                                   onClick={() => {
                                     const methodLodash =
                                    lodash === 'map'
                                      ? _.map
                                      : lodash === 'filter'
                                      ? _.filter
                                      : lodash === 'sortBy'
                                        ? _.sortBy
                                        : null;
                                     const lodashMap = methodLodash(JSON.parse(arr));
                            
                                     setDataLodash(JSON.stringify(lodashMap));
                                   }}
                                 >
                                sắp xếp tăng dần bằng Lodash
                                 </Button>
                              <Button
                                   variant="outlined"
                                   color="secondary"
                                   onClick={() => {
                                     const methodLodash =
                                    lodash === 'map'
                                      ? _.map
                                      : lodash === 'filter'
                                         ? _.filter
                                         : lodash === 'sortBy'
                                           ? _.sortBy
                                           : null;
                                     const lodashMap = methodLodash(JSON.parse(arr),item=>-item);
                                     setDataLodash(JSON.stringify(lodashMap));
                                   }}
                                 >
                                sắp xếp giảm dần bằng Lodash
                                 </Button>
                                 </>
                        
                          ) : (
                            ''
                          )}
                        </Grid>
                        <Grid item xs={12}>
                          output: {dataLodash}
                        </Grid>
                      </Grid>
                    </>
                  ) : (
                    <Grid
                      style={{ display: 'flex', alignItems: 'center' }}
                      item
                      xs={12}
                    >
                      <Button
                        onClick={() => {
                          setArr(arrLodash.current.value);
                        }}
                        style={{
                          marginRight: '20px',
                          textTransform: 'lowercase',
                        }}
                        variant="outlined"
                        color="default"
                      >
                        {lodash} with Lodash
                      </Button>
                      <TextField
                        inputRef={arrLodash}
                        style={{ width: '60%' }}
                        variant="outlined"
                        placeholder={
                          lodash === 'map'
                            ? `abcxyz or 123456`
                            : lodash === 'filter'
                              ? `[1,2,3,4,5]`
                              : lodash === 'sortBy'
                                ? `[1,2,3,4,5,6]`
                                : ''
                        }
                        label={
                          lodash === 'map'
                            ? `Nhập vào là số hoặc string`
                            : lodash === 'filter'
                              ? `Nhập vào là 1 mảng`
                              : lodash === 'sortBy'
                                ? `Nhập vào là 1 mảng`
                                : ''
                        }
                      />
                    </Grid>
                  )}
                </>
              ) : (
                <>
                  <span> Biến useMem sử dụng useMemo có giá trị là: </span>
                  <h4 ref={handleanimemm}>{useMm}</h4>
                  Gía trị ref đã được set vào state:{' '}
                  <h4 ref={handleanime}>{data2}</h4>
                </>
              )}
            </Box>
          </Box>
        </Box>
      </Box>
    </>
  );
};

export default Moment;
