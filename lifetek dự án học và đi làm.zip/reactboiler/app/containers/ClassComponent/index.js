import {
  Box,
  Grid,
  SwipeableDrawer,
  TextField,
  createMuiTheme,
  MuiThemeProvider,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  FormHelperText,
  NativeSelect,
  InputBase,
} from '@material-ui/core';
import { Alert, Skeleton } from '@material-ui/lab';
import React, { useEffect, useRef } from 'react';
import { withStyles, makeStyles } from '@material-ui/styles';
import { gitApi } from '../Api';
import anime from 'animejs';
import axios from 'axios';
import cookiejs from 'js-cookie';
import moment from 'moment/moment';
const teststyle = makeStyles({
  test: {
    border: '1px solid red',

  },
});
const theme = createMuiTheme({
  overrides: {
    MuiInput: {
      formControl: {
        '&:before': {
          content: '',
          borderBottom: '1px solid transparent !important',
        },
      },
    },
  },
});

const useStyles = them => ({
  margin:{
margin:"0 !important",
flexDirection:"row !important"
  },
  borderGrid: {
    boxShadow: '0 0 5px 2px #bb9191db',
    padding: '10px 20px',
    cursor: 'pointer',
    borderRadius: '5px',
    backgroundColor: 'white',
    transition: '0.4s',
    marginRight: '10px',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    '&:hover': {
      color: 'white',
      backgroundColor: 'black',
    },
  },
  tokenValues: {
    border: '1px solid gray',
  },
});
const AlertAnime = () => {
  const animeError = useRef(null);
  const animeAlert = () => {
    return anime({
      targets: animeError.current,
      translateX: [500, 0],

      duration: 700,
    });
  };
  useEffect(() => {
    animeAlert();
  }, []);
  return (
    <Alert
      style={{ width: '80%' }}
      ref={animeError}
      variant="outlined"
      severity="error"
    >
      Tên owner của bạn không đúng ví dụ owner được đánh dấu màu đỏ.
      https://github.com/
      {<span style={{ color: 'red' }}>cuongnvb2001</span>}
      /$token
    </Alert>
  );
};
const AlertAnimes = () => {
  const animeError = useRef(null);
  const animeAlert = () => {
    return anime({
      targets: animeError.current,
      translateX: [500, 0],

      duration: 700,
    });
  };
  useEffect(() => {
    animeAlert();
  }, []);
  return (
    <Alert
      style={{ width: '80%' }}
      ref={animeError}
      variant="outlined"
      severity="success"
    >
      Xóa thành công
    </Alert>
  );
};
const AlertAnimeCreate = () => {
  const animeError = useRef(null);
  const animeAlert = () => {
    return anime({
      targets: animeError.current,
      translateX: [500, 0],

      duration: 700,
    });
  };
  useEffect(() => {
    animeAlert();
  }, []);
  return (
    <Alert
      style={{ width: '80%' }}
      ref={animeError}
      variant="outlined"
      severity="error"
    >
      Thêm thất bại
    </Alert>
  );
};
const AlertAnimesCreate = () => {
  const animeError = useRef(null);
  const animeAlert = () => {
    return anime({
      targets: animeError.current,
      translateX: [500, 0],

      duration: 700,
    });
  };
  useEffect(() => {
    animeAlert();
  }, []);
  return (
    <Alert
      style={{ width: '80%' }}
      ref={animeError}
      variant="outlined"
      severity="success"
    >
      Thêm thành công
    </Alert>
  );
};

class ClassComponent extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      arrRepo: [],
      ownerFound: false,
      loadSucsess: false,
      loadSucsessControl:false,
      removeValueText: '',
      loadSucsesscreate: false,
      loadFailurecreate: false,
      nameRepo: '',
      checkApis: false,
      tokenValue: JSON.parse(localStorage.getItem('token'))
        ? JSON.parse(localStorage.getItem('token'))
        : '',
    };
  }

  componentWillMount() {

  }
  async componentDidMount() {


    const strn = '';
    if (!JSON.parse(localStorage.getItem('token'))) {
      localStorage.setItem('token', JSON.stringify(strn));
 
    } else {
     this.setState({ loadSucsessControl:true})
      const com = this.state.tokenValue.lastIndexOf('.com/') + 5;
      const endcom = this.state.tokenValue.lastIndexOf('/');
      const owner = this.state.tokenValue.slice(com, endcom);
      const tokenGit = this.state.tokenValue.slice(endcom + 1);
      this.setState({ checkApis: true });
      if (this.state.tokenValue.includes('.com')) {
        const checkApi = await axios.get(`${gitApi}/gitApi/check/${tokenGit}`);

        if (checkApi.data.datas === 'sucsess') {
          this.setState({ loadSucsessControl:false})
          const mapRepo = checkApi.data.dataRepo.map(item => item.name);
          this.setState({ arrRepo: mapRepo });
          localStorage.setItem('token', JSON.stringify(this.state.tokenValue));
        }
      }
    }
  }
  componentWillUpdate() {
 
  }
  componentDidUpdate(nextProps, nextState) {

  }
 
  componentWillUnmount() {}
  UNSAFE_componentWillReceiveProps() {
   
  }
  shouldComponentUpdate(nextProps, nextState) {

    if (nextState.tokenValue !== nextProps.tokenValue) {
      return true;
    }
    if (nextProps.nameRepo !== nextState.nameRepo) {
      return true;
    }
    if (nextProps.ownerFound !== nextState.ownerFound) {
      return true;
    }
    if (nextProps.loadSucsesscreate !== nextState.loadSucsesscreate) {
      return true;
    }
    if (nextProps.loadFailurecreate !== nextState.loadFailurecreate) {
      return true;
    }
    if (nextProps.removeValueText !== nextState.removeValueText) {
      return true;
    }
  }
  handleClick = () => {
    this.setState({ count: this.state.count + 1 });
  };

  render() {
   
    const { classes } = this.props;

    const placehoder = 'https://github.com/cuong200111/token';
    const placehoder1 = 'Tên muốn thêm: GitNewRepository';
    const placehoder2 = 'Tên muốn xóa: GitNameRepository';
    const delRep = async () => {
      const endcom = this.state.tokenValue.lastIndexOf('/');
      const tokenGit = this.state.tokenValue.slice(endcom + 1);
      const com = this.state.tokenValue.lastIndexOf('.com/') + 5;
      const nameFormat = this.state.nameRepo.includes('https://github.com/')
        ? this.state.nameRepo.slice(this.state.nameRepo.lastIndexOf('/') + 1)
        : this.state.nameRepo;
      const owners = this.state.tokenValue.slice(com, endcom);
      const createRepo = await axios.post(`${gitApi}/gitApi/delete`, {
        auth: `${tokenGit}`,
        name: `${nameFormat}`,
        owners,
      });
      this.setState({loadSucsess : true });
      if (createRepo.data === 'owner not found') {
        return this.setState({ ownerFound: true });
      } else {
        this.setState({ loadSucsess: true });
        setTimeout(() => {
          return this.setState({ loadSucsess: false });
        }, 2000);
      }
    };

    return (
      <>
        <Box padding={10} height="100vh" width="100vw">
          {this.state.checkApis ? (
            <>
              <Grid container>
                {this.state.ownerFound ? (
                  <>
                    {' '}
                    <Grid
                      item
                      xs={2}
                      onClick={async () => {
                        if (this.state.ownerFound) {
                          localStorage.setItem('token', JSON.stringify(''));
                          this.setState({ checkApis: false });
                        } else {
                          delRep();
                        }
                      }}
                      className={classes.borderGrid}
                    >
                      <span>Xóa token</span>
                    </Grid>{' '}
                    <Grid
                      item
                      xs={2}
                      onClick={async () => {
                        this.setState({ ownerFound: false });
                        setTimeout(() => {
                          delRep();
                        }, 0);
                      }}
                      className={classes.borderGrid}
                    >
                      <span>Nhập lại repository và xóa</span>
                    </Grid>
                  </>
                ) : (
                  <Grid
                    item
                    xs={2}
                    onClick={async () => {
                      if (this.state.ownerFound) {
                        localStorage.setItem('token', JSON.stringify(''));
                        this.setState({ checkApis: false });
                      } else {
                        delRep();
                      }
                    }}
                    className={classes.borderGrid}
                  >
                    <span>Xóa</span>
                  </Grid>
                )}
          
                <FormControl className={classes.margin}>
                {this.state.loadSucsessControl?
           <Skeleton variant="rect" width={210} height={78} />
                :     <>
                 <InputLabel >Chọn repositories muốn xóa</InputLabel>
                <NativeSelect onChange={(e)=>{
                  if (confirm("Bạn có chắc muốn xóa không")) {
                  this.setState({nameRepo:e.target.value});
                  } else {
                  alert('yep__')
                  }
           
                    }}>
                  <option />
                  {this.state.arrRepo.map((item,index) => (
                    <option  key={index}>{item}</option>
                  ))}
                </NativeSelect>
                </>
                }
                </FormControl>
                <Grid item xs={7} className="text">
                  <TextField
                    onChange={e => {
                      this.setState({ nameRepo: e.target.value });
                    }}
                    style={{ width: '100%', marginTop: 20 }}
                    variant="outlined"
                    placeholder={placehoder2}
                    label="Nhập Repositories muốn xóa"
                  />
                </Grid>
                <Grid style={{ marginTop: 10 }} item xs={10}>
                  {this.state.ownerFound ? (
                    <div style={{ overflow: 'hidden', width: '100%' }}>
                      <AlertAnime />
                    </div>
                  ) : this.state.loadSucsess ? (
                    <AlertAnimes />
                  ) : (
                    ''
                  )}
                </Grid>
              </Grid>
              <Grid style={{ marginTop: 20 }} container>
                <Grid
                  item
                  xs={2}
                  onClick={async () => {
                    const endcom = this.state.tokenValue.lastIndexOf('/');
                    const tokenGit = this.state.tokenValue.slice(endcom + 1);
                    const createRepo = await axios.post(
                      `${gitApi}/gitApi/create`,
                      {
                        auth: `${tokenGit}`,
                        name: `${this.state.nameRepo}`,
                      },
                    );
                    if (createRepo.data === 'tạo thành công') {
                      this.setState({ loadSucsesscreate: true });
                      setTimeout(() => {
                        this.setState({ loadSucsesscreate: false });
                      }, 2000);
                    } else if (createRepo.data === 'tệp đã tồn tại') {
                      this.setState({ loadFailurecreate: true });
                      setTimeout(() => {
                        this.setState({ loadFailurecreate: false });
                      }, 2000);
                    }
                  }}
                  className={classes.borderGrid}
                >
                  <span>Thêm</span>
                </Grid>
                <Grid item xs={8} className="text">
                  <TextField
                    onChange={e => {
                      this.setState({ nameRepo: e.target.value });
                    }}
                    defaultValue=""
                    style={{ width: '100%' }}
                    variant="outlined"
                    placeholder={placehoder1}
                    label="Nhập Repositories muốn thêm"
                  />
                </Grid>
              </Grid>
              <Grid
                style={{ marginTop: 10, width: '100%', overflow: 'hidden' }}
              >
                {' '}
                {this.state.loadSucsesscreate ? (
                  <AlertAnimesCreate />
                ) : this.state.loadFailurecreate ? (
                  <AlertAnimeCreate />
                ) : (
                  ''
                )}
              </Grid>
            </>
          ) : (
            <Grid container>
              <Grid
                item
                xs={2}
                onClick={async () => {
                  const com = this.state.tokenValue.lastIndexOf('.com/') + 5;
                  const endcom = this.state.tokenValue.lastIndexOf('/');
                  const owner = this.state.tokenValue.slice(com, endcom);
                  const tokenGit = this.state.tokenValue.slice(endcom + 1);

                  if (this.state.tokenValue.includes('.com')) {
                    const checkApi = await axios.get(
                      `${gitApi}/gitApi/check/${owner}/${tokenGit}`,
                    );

                    if (checkApi.data.datas === 'sucsess') {
                      const mapRepo = checkApi.data.dataRepo.map(
                        item => item.name,
                      );
                      this.setState({ arrRepo: mapRepo });
                      this.setState({ checkApis: true });
                      this.setState({ ownerFound: false });
                      localStorage.setItem(
                        'token',
                        JSON.stringify(this.state.tokenValue),
                      );

                
                    } else if (checkApi.data === 'error') {
                
                    }
                  } else {
                    alert(
                      'hãy nhập link github của bạn và thêm token vào cuối link',
                    );
                  }
                }}
                className={classes.borderGrid}
              >
                <span>Thêm</span>
              </Grid>
              <Grid item xs={8}>
                <MuiThemeProvider theme={theme}>
                  <TextField
                    autoComplete="name"
                    onChange={e => {
                      this.setState({ tokenValue: e.target.value });
                    }}
                    style={{ width: '100%' }}
                    className={classes.tokenValues}
                    placeholder={placehoder}
                    label="Nhập vào link đường link kèm token của bạn"
                  />
                </MuiThemeProvider>
              </Grid>
            </Grid>
          )}
        </Box>
      </>
    );
  }
}

export default withStyles(useStyles)(ClassComponent);
