export const gitApi = 'http://localhost:22000'

const tokentest = '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'