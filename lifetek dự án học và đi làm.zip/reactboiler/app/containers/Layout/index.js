import React, { createContext, useEffect, useState } from 'react';
import { SwipeableDrawer, Box, Grid } from '@material-ui/core';
import { makeStyles } from '@material-ui/styles';
import Moment from 'containers/moment';
import Lodash from 'containers/Lodash';
import moment from 'moment';
import { useHistory } from "react-router-dom";
const useStyle = makeStyles({
  lists: {
    boxShadow: '0 0 2px 1px #00000066',
    marginTop: '1em',
    margin: '0 1em',
    textAlign: 'center',
    cursor: 'pointer',
    borderRadius: '3px',
    transition: '0.5s',
    padding: '10px !important',
    '&:hover': {
      backgroundColor: 'black',
      color: 'white',
    },
  },

  Grid: {
    width: '100%',
  },
});
export const MyContext = createContext();

function Layout(props) {
  let history = useHistory();
  
  const classes = useStyle();
  const [state, setState] = useState({
    open: false,
    momentActive: false,
    lodashActive: false,
  });

  const arr = [
    {
      list: 'moment',
    },
    {
      list: 'lodash',
    },
  ];

  const ar = [1, 2, 3];
  const sum = ar.reduce((a, b) => a + b, 0);
  const a = ar.map(item => sum - item);

  return (
    <MyContext.Provider value={{ moment }}>
      <Box sx={{ flex: 1 }}>
        <Grid container>
        <Grid
              onClick={()=>{
                history.push("/classComponent");
              }}
              item
              xs={2}
              className={classes.lists}
    
            >
       classComponent
            </Grid>
          {arr.map((item, index) => (
            <Grid
              onClick={() => {
                if (item.list === 'moment') {
                  setState({
                    open: true,
                    momentActive: true,
                    lodashActive: false,
                  });
                } else {
                  setState({
                    open: true,
                    lodashActive: true,
                    momentActive: false,
                  });
                }
              }}
              item
              xs={2}
              className={classes.lists}
              key={index}
            >
              {item.list}
            </Grid>
          ))}
        </Grid>
        <SwipeableDrawer
          anchor="right"
          onClose={() => {
            setState({ open: false });
          }}
          open={state.open}
          onOpen={() => {
            setState({ open: true });
          }}
        >
          <div style={{ marginTop: '0px', width: `${window.innerWidth}px` }}>
            {state.momentActive ? (
              <Moment
                onClose={() => {
                  setState({ open: false });
                }}
              />
            ) : (
              ''
            )}
            {state.lodashActive ? (
              <Lodash
                onClose={() => {
                  setState({ open: false });
                }}
              />
            ) : (
              ''
            )}
          </div>
        </SwipeableDrawer>
      </Box>
    </MyContext.Provider>
  );
}
export default Layout;
