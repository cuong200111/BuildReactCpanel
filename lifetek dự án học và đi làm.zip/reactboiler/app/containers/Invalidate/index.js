import React from 'react';
import './invalidate.css';
import { Alert } from '@material-ui/lab';
import { useEffect } from 'react';
import anime from 'animejs';
import { useRef } from 'react';
function AlertComponent(props) {
    const refMsg = useRef(null)
    

    const animeRef = ()=>{
      return  anime({
            targets: refMsg.current,
            duration:5000,
            translateX: 250,
        
        })
    }
  useEffect(() => {
    if(props.lengthMsg>0){
        animeRef()
    }
   
 
  }, [props.lengthMsg]);
  return (
    <>
      {' '}
      <div style={{position:'absolute',left:"5%",bottom:"5%", display: 'flex', flexDirection: 'column' }}>
        {props.msg.reverse().slice(1,5).map(item => (
          <Alert
     ref={refMsg}
            color="success"
            style={{
                margin:10,
              width: '100%',
              height: 59,
            }}
          >
            {item.item}
          </Alert>
        ))}{' '}
      </div>
    </>
  );
}

class Invalidate extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      msg: [],
      invalidates: {
        Firstname: '',
        Lastname: '',
        email: '',
        password: '',
        currentPassword: '',
      },
    };
  }

  componentDidUpdate(prevProps, prevState) {
    if (prevState.invalidates !== this.state.invalidates) {
      return true;
    }
    if (prevState.msg !== this.state.msg) {
      return true;
    }
  }

  render() {
    const handleSignup = e => {
      e.preventDefault();
    };

    const invaliDat = () => {
      const {
        Firstname,
        Lastname,
        email,
        password,
        currentPassword,
      } = this.state.invalidates;
      const invalEmail = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;

      if (password !== currentPassword) {
        if (this.state.msg.length<  0) {
          this.setState(prevState => {
            return {
              msg: [],
            };
          });
        } else {
          this.setState(prevState => {
            return {
              msg: [...prevState.msg, { item: 'Mật khẩu không trùng nhau' }],
            };
          });
      
        }
      }
      if (email.includes('.com') || email.includes('.co')) {
        if (this.state.msg.length < 0) {
          this.setState(prevState => {
            return {
              msg: [],
            };
          });
        } else {
          if (!invalEmail.test(email)) {
            this.setState(prevState => {
              return {
                msg: [...prevState.msg, { item: 'email không hợp lệ' }],
              };
            });
       
          }
        }
      }
    };

    const handleInvalidate = e => {
      if (e.target && e.target.name) {
        if (e.persist) e.persist();
        this.setState(prevState => ({
          invalidates: {
            ...prevState.invalidates,
            [e.target.name]: e.target.value,
          },
        }));
      }
      invaliDat();
    };

    console.log(this.state.msg);
    return (
      <div
        style={{
          height: '100vh',
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
        }}
      >
        <form class="formI">
          <p class="title">Register </p>
          <p class="message">Signup now and get full access to our app. </p>
          <div class="flex">
            <label>
              <input
                name="Firstname"
                onChange={e => {
                  handleInvalidate(e);
                }}
                required=""
                placeholder=""
                type="text"
                class="input"
              />
              <span>Firstname</span>
            </label>

            <label>
              <input
                name="Lastname"
                onChange={e => {
                  handleInvalidate(e);
                }}
                required=""
                placeholder=""
                type="text"
                class="input"
              />
              <span>Lastname</span>
            </label>
          </div>

          <label>
            <input
              name="email"
              onChange={e => {
                handleInvalidate(e);
              }}
              required=""
              placeholder=""
              type="text"
              class="input"
            />
            <span>email</span>
          </label>

          <label>
            <input
              name="password"
              onChange={e => {
                handleInvalidate(e);
              }}
              required=""
              placeholder=""
              type="password"
              class="input"
            />
            <span>Password</span>
          </label>
          <label>
            <input
              name="currentPassword"
              onChange={e => {
                handleInvalidate(e);
              }}
              required=""
              placeholder=""
              type="password"
              class="input"
            />
            <span>Confirm password</span>
          </label>
          <button
            onClick={e => {
              handleSignup(e);
            }}
            class="submit"
          >
            Submit
          </button>
          <p class="signin">
            Already have an acount ? <a href="#">Signin</a>{' '}
          </p>
        </form>
        <AlertComponent msg={this.state.msg} lengthMsg={this.state.msg.length} />
      </div>
    );
  }
}

export default Invalidate;
