import React from "react";
import ReactDOM from "react-dom";
import {
  BrowserRouter as Router,
  Switch,
  Route,
  useParams
} from "react-router-dom";
import HomePage from 'containers/Layout';
import NotFoundPage from 'containers/NotFoundPage/Loadable';

import GlobalStyle from '../../global-styles';
import ClassComponent from '../ClassComponent';
import Invalidate from '../Invalidate';
export default function App() {
  const arr = ['1',2,3]
  function callAction(){
      return arr.map(item=>Number(item)).sort((a,b)=>b-a)
  }
  return (
    <div>
      {/* <BrowserRouter>
        <Switch>
          <Route exact path="/" component={HomePage} />
          <Route path="/classComponent" component={ClassComponent} />
          <Route component={NotFoundPage} />
        </Switch>
        <GlobalStyle />
      </BrowserRouter> */}
      <Router>
        <Switch>
          <Route exact path="/" component={HomePage} />
          <Route path="/classComponent" component={(props)=><ClassComponent  callAction={callAction}  />} />
          <Route path="/invalidate" component={(props)=><Invalidate   />} />
          <Route component={NotFoundPage} />
        </Switch>
      </Router>
    </div>
  );
}
