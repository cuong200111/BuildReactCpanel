const express =require('express')
const history = require('connect-history-api-fallback')
const app = express()
const static = express.static(__dirname +'/build')
app.use(static)
app.use(history({
    disableDotRule:true,
    verbose:true
}))
app.use(static);
app.listen()