const axios = require('axios')
const fs = require('fs')
const cheerio = require('cheerio')
const request = require('request')
const url = `https://nettruyenfull.com/truyen-tranh/chuyen-sinh-thanh-that-hoang-tu-s2980/chap-106/596650`

request(url,(err,res,html)=>{
    if (!err && res.statusCode === 200) {
        const $ = cheerio.load(html)
        const texts = $('.lazy')
        
        texts.each((index, element) => {
            const src = $(element).attr('data-original')

            axios({
                url: src,
                responseType: 'stream',
              }).then(response => new Promise((resolve, reject) => {
                response.data.pipe(fs.createWriteStream('images/'+$(element).attr('data-original').split('/').pop()))
                  .on('finish', () => resolve())
                  .on('error', e => reject(e));
              }));
          });
      }
})

