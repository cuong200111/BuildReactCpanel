import { createSlice } from "@reduxjs/toolkit";

export const onlogin = createSlice({
    name: "onlogin",
    initialState: { Onlogin: false },
    reducers: {
        update: (state, action) => {
            state.Onlogin = action.payload.onlogin;

        },
    },
});


export const { update } = onlogin.actions;
export default onlogin.reducer;