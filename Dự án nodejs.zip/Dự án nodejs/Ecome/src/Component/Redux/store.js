import { configureStore } from "@reduxjs/toolkit";
import Cart from "./Cart";
import reducer_popup from "./reducer";
import use_reducer from "./use_reducer";
import Onlogin from "./Onlogin";
export default configureStore({
  reducer: {

    popups: reducer_popup,
    register: use_reducer,
    onlogin: Onlogin,
    Cart: Cart,
  },
});
