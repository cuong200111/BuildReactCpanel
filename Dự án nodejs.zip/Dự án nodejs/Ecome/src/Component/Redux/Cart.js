import { createSlice } from "@reduxjs/toolkit";
import { useEffect } from "react";
const iniState = {
    item: localStorage.getItem('cartArr') ? JSON.parse(localStorage.getItem('cartArr')) : [],

}

const Carts = createSlice({
    name: "cart",
    initialState: iniState,
    reducers: {
        updateCart: (state, action) => {
            const { quantity } = action.payload
            const find = state.item.findIndex(item => item.category === action.payload.category)
            if (find >= 0) {
                state.item[find].quantity += quantity
            }
            else {
                const temp = { ...action.payload, quantity }
                state.item.push(temp)

                localStorage.setItem("cartArr", JSON.stringify(state.item))

            }
        },
        removeCart: (state, action) => {
            const remove = state.item.filter(item => item.category !== action.payload.category)
            state.item = remove

            localStorage.setItem("cartArr", JSON.stringify(state.item))
        }


    }

})
export const { removeCart } = Carts.actions
export const { updateCart } = Carts.actions
export default Carts.reducer