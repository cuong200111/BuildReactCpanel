import React, { useState } from "react";
import { Link } from "react-router-dom";
import classes from "./LoginPage.module.css";
import { useDispatch, useSelector } from "react-redux";
import { update } from "../Redux/Onlogin";
const LoginPage = () => {
  let isValidate = false
  const dispatch = useDispatch()
  const [name, setName] = useState('')
  const [pass, setPass] = useState('')
  console.log(useSelector((state) => state.onlogin))
  const handleSumbit = (event) => {
    event.preventDefault()

    const user = JSON.parse(localStorage.getItem('useArr'))

    user.filter((e) => {
      if (e.fullname === name && e.password === pass) {
        isValidate = true
      }
    })


    if (isValidate) {
      dispatch(update({ onlogin: true }))
      localStorage.setItem('user', JSON.stringify(user.filter((e) => e.fullname === name)))
    }




  }





  return (
    <form onSubmit={handleSumbit}>
      <div className={classes.loginpage}>
        <div className={classes.loginpages}>
          <div className={classes.loginpage_img}>
            <img src="/image/banner2.jpg" alt="" />
          </div>
          <div className={classes.loginpage_box}>
            <h1>Sign In</h1>

            <p>
              <input placeholder="Email" onChange={(event) => setName(event.target.value)} />

            </p>
            <p>
              <input placeholder="Password" onChange={(event) => setPass(event.target.value)} />
            </p>

            <button type="submit">SIGN IN</button>
            <p>
              Create an account ? <Link to="/register"> Sign up</Link>
            </p>
          </div>
        </div>
      </div>
    </form>

  );
};

export default LoginPage;
