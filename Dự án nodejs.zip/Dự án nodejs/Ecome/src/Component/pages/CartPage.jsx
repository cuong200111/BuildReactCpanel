import React from "react";

import { Link } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import classes from "./CartPage.module.css";
import { removeCart } from "../Redux/Cart";
const CartPage = () => {
  const dispatch = useDispatch()
  const cart = useSelector(item => item.Cart.item
  )

  let i = 0;

  const total = (cart.map(item => item.item.price * item.item.quantity))
  const remove = cart.filter(item => item.category === 'watch')
  console.log(remove)
  const totalarr = total.map(item => { return i += item })
  const totalOver = totalarr.pop((item) => item)
  const quanti = useSelector((state) => {
    return state.Cart.item.map(item => item.quantity)
  })
  return (
    <div className={classes.cartpage}>
      <div className={classes.cartpage_content}>
        <div className={classes.registerpage_banner}>
          <div className={classes.registerpage_banner_left}>CART</div>
          <div className={classes.registerpage_banner_right}>CART</div>
        </div>
        <div className={classes.cartpage_info}>
          <h3>SHOPPING CART</h3>
          <div className={classes.cartpage_infos}>
            <div className={classes.cartpage_infos_left}>
              <div className={classes.cartpage_infos_left_top}>
                <div className={classes.cartpage_infos_left_tops}>
                  <p>IMAGE</p>
                  {cart.map(item => (<img width="100% " src={item.item.img1} />))}

                </div>
                <div className={classes.cartpage_infos_left_tops}>
                  <p>PRODUCT</p>
                  {cart.map(item => (<p>{item.item.name}</p>))}
                </div>
                <div className={classes.cartpage_infos_left_tops}>
                  <p>PRICE</p>
                  .item                  {cart.map(item => (<p>{item.item.price}</p>))}
                </div>
                <div className={classes.cartpage_infos_left_tops}>
                  <p>QUANTITY</p>
                  {cart.map(item => (<p>{item.quantity}</p>))}
                </div>
                <div className={classes.cartpage_infos_left_tops}>
                  <p>TOTAL</p>
                  {cart.map(item => (<p>{item.item.price * item.quantity}</p>))}
                </div>
                <div className={classes.cartpage_infos_left_tops}>
                  <p>REMOVE</p>
                  {cart.map((item, index) => (
                    <button key={index} onClick={() => { dispatch(removeCart(item)) }}>
                      <i className="fa-regular fa-trash-can"></i>
                    </button>))}
                </div>
              </div>
              <div className={classes.cartpage_infos_left_bottom}>
                <div>
                  <button>
                    <i className="fa-solid fa-arrow-left"></i>{" "}
                    <Link to="/shop">Continue Shopping</Link>
                  </button>
                </div>
                <div>
                  <button>
                    <Link to="/checkout">Proceed to checkout</Link>
                    <i className="fa-solid fa-arrow-right"></i>
                  </button>
                </div>
              </div>
            </div>
            <div className={classes.cartpage_infos_right}>
              <div className={classes.cartpage_infos_right_content}>
                <h4>CART TOTAL</h4>
                <div className={classes.cartpage_infos_right_contents}>
                  <div className={classes.cartpage_infos_right_content_top}>
                    <h6>SUBTOTAL</h6>
                    <span>{totalOver}</span>
                  </div>
                  <div className={classes.cartpage_infos_right_content_bottom}>
                    <h6>TOTAL</h6>
                    <span>19.779.000 VND</span>
                  </div>
                </div>

                <input placeholder="Enter your counpon" />
                <button>
                  <i className="fa-solid fa-gift"></i> Apply coupon
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div >
  );
};

export default CartPage;
