import React from "react";

import { Link } from "react-router-dom";
import classes from "./CheckOutPage.module.css";
const CheckOutPage = () => {
  return (
    <div className={classes.checkoutpage}>
      <div className={classes.checkoutpage_content}>
        <div className={classes.registerpage_banner}>
          <div className={classes.registerpage_banner_left}>CHECKOUT</div>
          <div className={classes.registerpage_banner_right}>
            HOME/CART/<span>CHECKOUT</span>
          </div>
        </div>
        <div className={classes.checkoutpage_info}>
          <h5>BILLING DETAILS</h5>
          <div className={classes.checkoutpage_infos}>
            <div className={classes.checkoutpage_infos_left}>
              <div>
                <p>FULL NAME:</p>
                <input placeholder="Enter Your Full Name Here!" />
              </div>
              <div>
                <p>EMAIL:</p>
                <input placeholder="Enter Your Email Here!" />
              </div>
              <div>
                <p>PHONE NUMBER:</p>
                <input placeholder="Enter Your Phone Number Here!" />
              </div>
              <div>
                <p>ADDRESS:</p>
                <input placeholder="Enter Your Address Here!" />
              </div>

              <button>Place order</button>
            </div>
            <div className={classes.checkoutpage_infos_rights}>
              <div className={classes.checkoutpage_infos_right}>
                <div className={classes.checkoutpage_infos_right_content}>
                  <h4>YOUR ORDER</h4>
                  <div className={classes.checkoutpage_infos_right_contents}>
                    <div
                      className={classes.checkoutpage_infos_right_content_top}
                    >
                      <h6>Apple Iphone 11 64GB</h6>
                      <span>10.979.000 VNDx1</span>
                    </div>

                    <div
                      className={
                        classes.checkoutpage_infos_right_content_bottom
                      }
                    >
                      <h6>Apple Airpod 3rd gen</h6>
                      <span>4.390.000 VNDx2</span>
                    </div>
                    <div
                      className={
                        classes.checkoutpage_infos_right_content_bottoms
                      }
                    >
                      <h6>TOTAL</h6>
                      <span>19.779.000 VND</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CheckOutPage;
