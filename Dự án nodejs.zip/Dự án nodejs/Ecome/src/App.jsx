import React, { useEffect } from "react";
import { Routes, Route } from "react-router-dom";
import DetailPage from "./Component/pages/DetailPage";
import HomePage from "./Component/pages/HomePage";
import CartPage from "./Component/pages/CartPage";
import ShopPage from "./Component/pages/ShopPage";
import CheckOutPage from "./Component/pages/CheckOutPage";
import LoginPage from "./Component/pages/LoginPage";
import RegisterPage from "./Component/pages/RegisterPage";
// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAUWJaN65T0kxdSKu5HdQKUUXnHVoOmK1s",
  authDomain: "ecome-df4a5.firebaseapp.com",
  projectId: "ecome-df4a5",
  storageBucket: "ecome-df4a5.appspot.com",
  messagingSenderId: "910975893114",
  appId: "1:910975893114:web:8c5a86d2e2135e9423c5c3"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

const App = () => {


  return (
    <Routes>
      <Route exact path="/" element={<HomePage />} />
      <Route path="/detail/:id/:filId" element={<DetailPage />} />
      <Route path="/shop" element={<ShopPage />} />
      <Route path="/cart" element={<CartPage />} />
      <Route path="/checkout" element={<CheckOutPage />} />
      <Route path="/login" element={<LoginPage />} />
      <Route path="/register" element={<RegisterPage />} />
    </Routes>
  );
};
export default App;
