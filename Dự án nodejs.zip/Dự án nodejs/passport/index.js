const express = require("express");

const app = express();



let arr = ["a", "b"];

arr.push(function() {
  return 'ss'
})

; // ?

console.log(arr[2]())




app.listen(2000);
