import React, { useState } from 'react'
import axios from 'axios'
import { useLocation, useNavigate } from 'react-router-dom'
const Footer = (props) => {  
const [prom, setprom]= useState('')
const [status, setstatus]= useState(false)
const navigate = useNavigate()

const handle = (e)=>{
  e.preventDefault()
 
  navigate('/',{state:{
    text:'',
    status: true
  }})

const model = "text-davinci-003";
const maxTokens = 2048;
const temperature = 0;
  const data = {
    prompt: prom,
    model: model,
    max_tokens: maxTokens,
    temperature: temperature
  };
  const config = {
    headers: {
        'Authorization': `Bearer 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`,
        "Content-type": "application/json"
    }
  };
  axios.post('https://api.openai.com/v1/completions', data, config).then((response) => {
    if(response.status === 200) {
      setstatus(false)
    }
    navigate('/',{state:{
      text:response.data.choices[0].text,
      status: false
    }})
    })
    .catch((error) => {
        console.error(error);
    });
}


  return (
  
    <form action='' className='footer'>
    
    
      <input type="text" onChange={(e)=>{setprom(e.target.value)}}/>
      <div className="background-button">
    <button type='submit' onClick={(e)=>{handle(e)}} className="button">
      Slap
    </button>
  </div>
  </form>
  )
}

export default Footer