import React, { useEffect, useState } from 'react'
import { useLocation } from 'react-router-dom'
import hljs from 'highlight.js';
import 'highlight.js/styles/vs.css';
const Container = () => {
const text = useLocation()
const status = text.state===null?false:text.state
const [errorload,setError]= useState(false)
const codeWithLineBreaks = status.text
console.log(codeWithLineBreaks);
useEffect(() => {
  hljs.configure({
    languages: ['javascript', 'html', 'css'],
    tabReplace: '    ', 
    useBR: true,
    
  });
  hljs.highlightBlock(document.getElementById('code'));
}, []);
useEffect(() => {
  if(status.status){
    setTimeout(()=>{
      setError(true)
    },60000)
  }else{
    setError(false)
  }
},[errorload,status.status])

  return (
    <div className='container'>
 

     
       
        {errorload?<span style={{textAlign:'center',display:'block'}}>Hãy nhập lại dữ liệu</span>:``}
    <div className='Content'>
    <span>{status.status?<svg class="pl" width="240" height="240" viewBox="0 0 240 240">
	<circle class="pl__ring pl__ring--a" cx="120" cy="120" r="105" fill="none" stroke="#000" stroke-width="20" stroke-dasharray="0 660" stroke-dashoffset="-330" stroke-linecap="round"></circle>
	<circle class="pl__ring pl__ring--b" cx="120" cy="120" r="35" fill="none" stroke="#000" stroke-width="20" stroke-dasharray="0 220" stroke-dashoffset="-110" stroke-linecap="round"></circle>
	<circle class="pl__ring pl__ring--c" cx="85" cy="120" r="70" fill="none" stroke="#000" stroke-width="20" stroke-dasharray="0 440" stroke-linecap="round"></circle>
	<circle class="pl__ring pl__ring--d" cx="155" cy="120" r="70" fill="none" stroke="#000" stroke-width="20" stroke-dasharray="0 440" stroke-linecap="round"></circle>

</svg>  :<div>
    <b>Bot:</b><code id="code"  className="language-js">{codeWithLineBreaks}</code>
      </div>}</span>
    </div>

    </div>
  )
}

export default Container