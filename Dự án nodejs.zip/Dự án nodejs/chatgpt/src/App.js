import { BrowserRouter } from 'react-router-dom'
import Container from './components/Container'
import Footer from './components/Footer'
import './index.css'
// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDNLJfVN3WAMeKuuEXEmYwtnIGvfuXpyoU",
  authDomain: "linb-54460.firebaseapp.com",
  projectId: "linb-54460",
  storageBucket: "linb-54460.appspot.com",
  messagingSenderId: "304749089118",
  appId: "1:304749089118:web:2248111df8bb8df9337fcf"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
function App() {

  let text = ''
 
  return (
    <BrowserRouter>
    <div className='main'>
    <Container/>
    <Footer text={text}/>
    </div>
    </BrowserRouter>
  )
}

export default App;
