const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Users = require("../../model/mondb").users;
const express = require("express");
const router = express.Router();
const jobName = require("../../model/mondb").jobName;
const jobs = require("../../model/mondb").jobs;
const admin = require("../../model/mondb").admins;
const path = require("path");
const fs = require("fs");

router.get("/download/:id", async (req, res) => {
  const Auth = req.headers["authorization"];
  const email = await Users.find({ token: Auth });
  try {
    if (email && email.length > 0) {
      const fileName = req.params.id;
      const filePath = path.join(`./Doc/${email[0].email}`, fileName);
      const findPath = fs.existsSync(
        path.join(`./Doc/${email[0].email}`, fileName)
      );
      if (findPath) {
        res.send({
          status: "sucssues",
          datas: { a: email[0].email, b: fileName },
        });
      } else {
        res.send({
          status: "failed",
          datas: { a: email[0].email, b: fileName },
        });
      }
    } else {
      res.send("email not found");
    }
  } catch (error) {
    console.log(error);
  }
});
//chatOption
router.get('/getAdminChat/:id', async (req, res) => {
 try {
  const id = req.params.id;
  res.send(id)
 } catch (error) {
  res.status(503).send('loi server')
 }
});

router.get("/docxdownload/:a/:b", async (req, res) => {
  const { a, b } = req.params;
  const findPath = fs.existsSync(path.join(`./Doc`, a, b));

  try {
    if (findPath === true) {
      return res.download(path.join(`./Doc/${a}`, b));
    }
  } catch (error) {
    console.log(error);
  }
});
router.get("/profile", async (req, res, next) => {
  try {
    const authHeader = req.headers["authorization"];

    if (authHeader === "undefined") {
      res.send({ uid: false, online: false });
    } else {
      const userFind = await Users.find({ token: authHeader });

      const findJobs = await jobs.find({ email: userFind[0].email });

      res.send({
        uid: userFind[0].email,
        name: userFind[0].name,
        online: true,
        findJobs,
      });
    }
  } catch (error) {
    res.send({ online: false });
  }
});

router.get("/admin", async (req, res, next) => {
  try {
    const authHeader = req.headers["authorization"];

    if (authHeader === "undefined") {
      res.send({ onlineAdmin: false });
    } else {
      const findadmin = await admin.find({ token: authHeader });
      const jwtCompiler = jwt.verify(authHeader, findadmin[0].pass);
      if (jwtCompiler.id === findadmin[0].admin) {
        const userFind = await Users.find({});
        const findJob = await jobName.find({});
        res.send({ userFind: userFind, findJob: findJob, onlineAdmin: true });
      }
    }
  } catch (error) {
    res.send({ onlineAdmin: true });
  }
});
router.get("/notifications", async (req, res, next) => {
  const email = req.headers["authorization"];
  try {
    const update = await jobs.updateMany(
      { email: email },
      { $set: { seen: false } }
    );
    if (update) {
      res.send("seenDataUpdated");
    } else {
      res.send("unseend");
    }
  } catch (error) {
    res.status(503).send("loi he thong");
  }

  next();
});
router.get("/chat", async (req, res, next) => {
  const token = req.headers["authorization"];
  try {
    const userFind = await Users.find({ token: token });
    res.send(userFind[0]);
  } catch (err) {
    res.send("loi server error");
  }
});
router.get("/chatdata/:id", async (req, res, next) => {
try {
  const dataMsg = JSON.parse(fs.readFileSync(path.join(`./chat/${req.params.id}.json`)))
  res.send(dataMsg)
} catch (error) {
  res.send(['bạn chưa chọn người chát'])
}
});
router.get("/chatAdmindata/:id", async (req, res, next) => {
  const dataMsg = JSON.parse(fs.readFileSync(path.join(`./chat/${req.params.id}.json`)))
  res.send(dataMsg)
});
router.get("/chatopen", async (req, res, next) => {
  const emailUser = req.headers["authorization"];
  const users = emailUser.split(" "); //0 email 1 name 2 date
  const pathexit = path.join(`./chat/${users[0]}.json`);
  const pathAt = fs.existsSync(pathexit);
  if(pathAt === true){
    const dataFile = JSON.parse(fs.readFileSync(pathexit))
    const newData = []
    dataFile.forEach(item=>{
      if(item.is === 'admin'){
        item.seenUser = true
        newData.push(item)
      }else{
        newData.push(item)
      }
    })
    fs.writeFileSync(pathexit,JSON.stringify(newData))
    res.send({status:'path at',email:users[0]})
  }else if(pathAt === false){
    fs.writeFileSync(
      pathexit,
      `[ {"users":"Chào mừng bạn đến với lifeTek hãy đặt câu hỏi cho chúng tôi nhân viên sẽ trả lời bạn trong ít phút","seenUser":true,  "isUser": "admin","atDate":${users[2]},"email":"${users[0]}"}]`
    );
    res.send(users[0]);
  }
  
  // const arrChat = JSON.parse(fs.readFileSync(path.join(`./chat/${emailUser}.json`)))
});
router.get("/notifyChat/:id", async (req, res, next) => {
  if(fs.existsSync(path.join(`./chat/${req.params.id}.json`))){
    const dataMsg = JSON.parse(fs.readFileSync(path.join(`./chat/${req.params.id}.json`)))
    res.send(dataMsg)
  }
  next()
});
module.exports = router;
