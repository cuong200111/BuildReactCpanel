
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Users = require("../../model/mondb").users;


const accessTokenRandom = () => {
  const access1 = Math.floor((Math.random() * 9999-1000+1)+1000);
  return access1;
};


const SignUp = async (req, res, next) => {

  const uid = await Users.find({ email: req.body.email });
  if (uid.length > 0) {

    return res.send("account already");
  } else {
    try {
      const users = new Users({
        name: req.body.name,
        email: req.body.email,
        password: bcrypt.hashSync(req.body.pass, 8),
        token:''
      });
      const saveDb = await users.save();
      if (saveDb) {


        return res.send("save Success");
      }
    } catch (err) {
  
      return res.send("error Server");
    }
  }
};

const SignIn = async (req, res, next) => {
  const { email, pass } = req.body;
  const user = await Users.find({ email: email });
  if (user) {
    if(pass){
      try {
        const comparePass  = await bcrypt.compare(pass,user[0].password)
      if (comparePass) {
        const randomToken = accessTokenRandom();
       const tokensign = jwt.sign({id:randomToken},user[0].email,{expiresIn:'10d'})
      const sendToken = jwt.verify(tokensign,user[0].email)
        res.send({status:"sucsess Login",token:tokensign,sendToken:sendToken});
      
      } else {
        res.send({status:"failure Login",});
      }
      } catch (error) {
        res.send({status:"failure Login",});
      }
    }else{
      res.send({status:"pass not defined",});
    }
   
  }
};
const SignInTk = async (req, res, next) => {
  
  const {joinAccess,pass,accessToken,email} = req.body


 try {
  const token = jwt.verify(accessToken,pass)
  const tokenRequest = Number(joinAccess)

 if(token.id===tokenRequest){
try { 
  const emailFind = await Users.find({email:email})
  if(emailFind.length>0){
   
    const tokenUser = jwt.sign({id:tokenRequest},email,{expiresIn:'1d'})
    await Users.findOneAndUpdate({email:email},{$set:{token:tokenUser}},{multi:true})
    res.send('token sucsess')
  }
} catch (error) {
  res.send('error 503')
}

 }else{
  res.send('token failed')
 }
 } catch (error) {
  res.send('token đã hết hạn')
 }
next()

};
const qUser = async (req, res, next) => {
  const user = await Users.find({});
  res.send(user);
  next();
};

// ------------------------------------------------------------------------------------------------------------------------------------------------------------------------
const getSigninTk = async(req,res)=>{
  const auth =req.headers.authorization
 const email = await Users.find({email:`${auth}`})

 if(email[0].token){
  try {
    jwt.verify(email[0].token,auth)
  res.send('true')
  } catch (error) {
    res.send('false')
  }
 }else{
  res.send('false')
 }

}
module.exports = {
  SignUp: SignUp,
  SignIn: SignIn,
  qUser: qUser,
  SignInTk:SignInTk,
  getSigninTk:getSigninTk
};
