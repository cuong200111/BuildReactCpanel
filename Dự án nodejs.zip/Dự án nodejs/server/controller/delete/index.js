
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Users = require("../../model/mondb").users;
const jobs = require("../../model/mondb").jobs;
const express = require('express')
const router = express.Router()
const fs = require('fs')
const path = require('path')


router.delete('/docxdelete/:a/:b', async (req,res,next)=>{
    const {a,b}=req.params
    try {
        const pathDel = path.join(`./Doc`,a,b)
    fs.unlinkSync(pathDel)
   const delJob =await jobs.deleteMany({email:a,docx:b})
    if(delJob){
        res.send('delete thanh cong')
    }else{
        res.send('delete khong thanh cong')
    }
    } catch (error) {
        const delJob =await jobs.deleteMany({email:a,docx:b})
        if(delJob){
            res.send('delete thanh cong')
        }else{
            res.send('delete khong thanh cong')
        }
       
    }

})



module.exports = router