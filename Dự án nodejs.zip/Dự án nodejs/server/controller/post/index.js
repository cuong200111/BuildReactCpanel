const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const path = require("path");
const Users = require("../../model/mondb").users;
const jobName = require("../../model/mondb").jobName;
const jobs = require("../../model/mondb").jobs;
const admins = require("../../model/mondb").admins;
const fs = require("fs");
const express = require("express");
const multer = require("multer");
const iconv = require("iconv-lite");
const { default: axios } = require("axios");

//True là đã xem
//False là chưa xem




require("dotenv").config();
const router = express.Router();

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    try {
      fs.mkdirSync(path.join(`./Doc/${req.body.email}`))
      cb(null, path.join(`./Doc/${req.body.email}`));
    } catch (error) {
      cb(null, path.join(`./Doc/${req.body.email}`));
    }
  },
  filename: (req, file, cb) => {
    cb(null, iconv.decode(file.originalname, "utf8"));
  },
});

const upload = multer({ storage: storage });
const accessTokenRandom = () => {
  const access1 = Math.floor(Math.random() * 9999 - 1000 + 1 + 1000);
  return access1;
};

router.post(
  "/addProject",
  upload.fields([{ name: "docx", maxCount: 1 }]),
  async (req, res, next) => {
    try {
      const file = req.files;
      const { email, dev, job ,noti,date} = req.body;
    
      const findJob = await jobs.find({ email: email, job: job });
      // if (findJob.length === 0) {
        const jobUpdate = new jobs({atDate:date,notifica:noti,email,job,dev,docx:iconv.decode(file.docx[0].originalname,'utf8')});
        jobUpdate.save();
     
        res.send('them thanh cong')
      // }else{
      //   res.send('tệp hoặc người dùng đã tồn tại')
      // }
    } catch (error) {
      console.log(error);
      res.status(503).send("loi server");
    }
    next();
  }
);
const generateAccessToken = (user, accsess) => {
  return jwt.sign({ id: user }, accsess, { expiresIn: "30m" });
};
const generateRefreshToken = (user, accsess) => {
  return jwt.sign({ id: user }, accsess, { expiresIn: "365d" });
};
const verifyJwt = (a, b) => {
  return jwt.verify(a, b);
};
router.post("/register", async (req, res) => {
  const finduser = await Users.find({ email: req.body.email });
  if (finduser.length === 0) {
    const accessToken = generateAccessToken(
      accessTokenRandom(),
      req.body.email
    );
    const verify = verifyJwt(accessToken, req.body.email);
    return res.status(200).send({ accessToken: accessToken, verify });
  } else {
    return res.send("tai khoan ton tai");
  }
});
router.post("/verifytoken", async (req, res, next) => {
  const finduser = await Users.find({ email: req.body.email });
  if (finduser.length === 0) {
    try {
      const verify = verifyJwt(req.body.token, req.body.email);
      if (verify.id === Number(req.body.codeVerify)) {
        const { name, email, pass } = req.body;
        const refreshToken = generateRefreshToken(
          req.body.email,
          req.body.email
        );
        const hashpassword = await bcrypt.hash(pass, 10);
        const user = new Users({
          name: name,
          email: email,
          password: hashpassword,
          token: refreshToken,
        });
        user.save();
        res.send({ status: "dang ki thanh cong", token: refreshToken });
      } else {
        res.send("sai ma code");
      }
    } catch (error) {
      res.send(error);
    }
  } else {
    return res.send("tai khoan ton tai");
  }

  next();
});
router.post("/login", async (req, res) => {
  try {
    const { email, pass } = req.body;
    const findAdmin = await admins.find({})
    const filterAdmin = findAdmin.filter(item => item.admin === email && item.pass ===pass);
    if(filterAdmin.length === 1){
      const token = generateRefreshToken(findAdmin[0].admin,findAdmin[0].pass)
     await admins.findOneAndUpdate({admin:findAdmin[0].admin},{$set:{token:token}})
      return res.send({status:'Hi Admin',token:token})
    } else{
      const user = await Users.find({ email: email });
      const isPass = await bcrypt.compare(pass, user[0].password);
      if (user) {
        if (isPass) {
          const token = generateRefreshToken(user[0]._id, email);
          await Users.findOneAndUpdate(
            { email: email },
            { $set: { token: token } }
          );
          res.send({ token: token });
        } else {
          res.send("mat khau sai");
        }
      } else {
        res.send("email khong hop le");
      }
    }

  } catch (error) {
    res.send(error);
  }
});
router.post("/addJob", async (req, res, next) => {
  const { job,date } = req.body;
  const findJob = await jobName.find({ job: job });

  try {
    if (findJob.length === 0) {
      const addJob = new jobName({ job: job,atDate:date });
      addJob.save();
      res.send("Thêm job thành công");
    } else {
      res.send("job đã tồn tại");
    }
  } catch (error) {
    res.status(503);
  }
  next();
});
router.post("/postChat", async (req, res, next) => {
  const {sendChat,email,atDate,is,token}= req.body

    const dataChat = await JSON.parse(fs.readFileSync(path.join(`./chat/${email}.json`)))
    dataChat.push(
      {
        msg: sendChat,
        seenUser: false,
        is: is,
        atDate: atDate,
        email: email
      }
    )
    if(dataChat){
      fs.writeFileSync(path.join(`./chat/${email}.json`),JSON.stringify(dataChat))
    res.send('nhan thanh cong')
    }
   
axios.get('',Autho)
});

module.exports = router;