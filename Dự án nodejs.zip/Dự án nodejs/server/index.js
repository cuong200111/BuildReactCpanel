const express = require("express");
const bodyParser = require("body-parser");
const path = require("path");
const db = require("./model/mondb");
const compression = require("compression");
const fs = require("fs");
const cookie = require("cookie-parser");
const jwt = require("jsonwebtoken");
const axios = require("axios");
const post = require("./controller/post/index");
const http = require("http");
const get = require("./controller/get/index");
const del = require("./controller/delete/index");
const { Server } = require("socket.io");
const cors = require("cors");
const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: "http://localhost:3000",
    methods: ["GET", "POST"],
    transports: ["websocket"],
    credentials: true,
  },
  allowEIO3: true,
});

app.use(compression());
app.use(
  cors({
    origin: true,
  })
);
app.use(cookie());
app.use(express.static(path.join(__dirname, "public")));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use("/", post);
app.use("/", get);
app.use("/", del);

io.on("connection", (socket) => {
socket.on('newMessage', ({msg,seenUser,is,atDate,email})=>{
  console.log(msg,seenUser,is,atDate,email);
  socket.broadcast.emit('newMessage',{msg,seenUser,is,atDate,email})

})


// msg: sendChat,
// seenUser: false,
// is: permiss,
// atDate: atDate,
// email: email



    // socket.on('newMessage', async ({ content, sender, receiver }) => {
    //   console.log('New message received:', content, sender, receiver);

    //   socket.broadcast.emit('newMessage', { content, sender, receiver });
    // });

    socket.on('disconnect', () => {
      console.log('Client disconnected');
    });
  });

server.listen(2000);
