const mongoose = require('mongoose')
const {Schema}= require('mongoose')
mongoose.connect('mongodb+srv://test:Dcuong2kk1@cluster0.bvs40lg.mongodb.net/lifeTek')
const usersSchema = new Schema({
    name:{type:String},
    email:{type:String,unique:true},
    password:{type:String},
    token:{type:String}
})
const jobNameSchema = new Schema({
    job: {type:String, unique:true},
    atDate:{type:String}
})
const jobSchema = new Schema({
    email:{type:String},
    job: {type:String},
    docx:{type:String},
    dev:{type:String},
    notifica:{type:String},
    atDate:{type:String},
    seen:{type:Boolean, default: true}
})
const adminSchema = new Schema({
    admin:{type:String},
    pass: {type:String},
    token: {type:String},

})
const users = mongoose.model('users',usersSchema)
const jobName = mongoose.model('jobName',jobNameSchema)
const jobs = mongoose.model('jobs',jobSchema)
const admins = mongoose.model('admins',adminSchema)
module.exports = {
    users:users,
    jobName:jobName,
    jobs:jobs,
    admins:admins
}