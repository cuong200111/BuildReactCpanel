const express = require("express");
const routes = express.Router();
const db = require("../../model/db");
require('dotenv').config()

    routes.post("/login",require('../Auth/Auth').login);
routes.post("/register",require('../Auth/Auth').register);
routes.post("/adminUp",require('../Auth/Auth').admin);

module.exports = routes;
