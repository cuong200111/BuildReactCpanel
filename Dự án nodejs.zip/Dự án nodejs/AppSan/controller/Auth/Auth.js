const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const randomstring = require("randomstring");
require('dotenv').config()
const code = randomstring.generate(7)
exports.register = (req, res) => {
  const { name, password, passwordConfirm, phone } = req.body;

  req.db.query(
    `SELECT * FROM account where phone= ?`,
    [`${phone}`],
    async (err, data) => {
      if (err) throw err;
      if (data.length > 0) {
        return res.render("register", {
          msg: "Số điện thoại đã tồn tại",
        });
      } else if (password !== passwordConfirm) {
        return res.render("register", {
          msg: "Mật khẩu không khớp",
        });
      }
      let hashpassword = await bcrypt.hash(password, 8);

     req.db.query("SELECT *from account",(err,data)=>{
const length = data.length;
        req.db.query(`insert into account (uid,name,pass,phone,coin,code,FreezeCoin) value(?,?,?,?,?,?)`,[length+1,`${name}`,`${hashpassword}`,`${phone}`,0,`${code}`,0],(err)=>{
            res.render("register",{
                msg: "Đăng kí thành công",
              })
          })
     })
     
    }
  );
};

exports.login = (req, res) => {
    const {phone, pass} = req.body
    req.db.query(
        `SELECT * FROM account where phone= ?`,[`${phone}`], async(err,data)=>{
            if(err)throw err
            if(data.length === 0){
               return res.render("login",{msg:'Số điện thoại không tồn tại'})
            }
           const user = data[0]
           const isPasswordValid = await bcrypt.compare(pass, user.pass)
           if (!isPasswordValid) {
            return res.render("login", {
              msg: "Mật khẩu không đúng",
            });
          }
            const token = jwt.sign({id:user.uid},process.env.Scret,{
                expiresIn:'7d'
            })
        res.cookie('Token',token,{httpOnly:true});
        res.redirect("/")
        })  
    
};

exports.admin = (req, res) => {
  req.db.query(`Update account set coin = ${req.body.coin}+coin,FreezeCoin = ${req.body.FreezeCoin}+FreezeCoin where uid =${req.body.id}`)
    res.redirect(`/adminUp/${req.body.id}`)

};
