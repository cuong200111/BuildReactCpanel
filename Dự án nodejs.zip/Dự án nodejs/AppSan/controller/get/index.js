const express = require('express');
const routes = express.Router();
const jwt = require('jsonwebtoken');
const path = require('path');
const fs = require('fs');
require('dotenv').config()

routes.get('/',(req,res)=>{
    if(req.token){
        const user = [{
            account :'9zf**dksg',
            coin:'120.00'
        },{
            account :'96f**dksg',
            coin:'130.00'
        },{
            account :'675f**dksg',
            coin:'150.00'
        },{
            account :'8675f**dksg',
            coin:'20.00'
        },{
            account :'865f**dksg',
            coin:'60.00'
        },,{
            account :'34f**dksg',
            coin:'60.00'
        },,{
            account :'543f**dksg',
            coin:'90.00'
        },,{
            account :'23f**dksg',
            coin:'20.00'
        },]
        const imgBn = fs.readdirSync(path.join('image/banner'))
        return res.render('home',{Bn:imgBn ,user:user})
    }
    return res.render('login')
  
})
routes.get('/cskh',(req,res)=>{
   res.render('cskh')
})
routes.get('/user',(req,res)=>{

   if(req.token){
   
   return res.render('user',{id:req.token})
   }
   res.render('login')
 })
routes.get('/login',(req,res)=>{
    try {
    const token = req.cookies
    const tokenVerify = jwt.verify(token.Token,process.env.Scret)
    res.render('login',{token:tokenVerify.id})
    } catch (error) {
        res.render('login',{token:0})
    }
    }
 )
 routes.get('/admin',(req, res) => {
    res.render('admin')
 })
 routes.get('/adminUp/:id',(req,res,next)=>{
   req.db.query(`Select * from account where uid = ${req.params.id}`,(err,data)=>{
    res.render('adminUp',{dataAdmin:data})
   })
    
 })
 routes.get('/register',(req,res)=>{
    res.render('register',{msg:''})
 })
 routes.get('/chat',(req,res)=>{
    res.render('chat')
 })
module.exports = routes