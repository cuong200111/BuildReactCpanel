const banner = document.querySelector('.banner')
const banner_slider = document.querySelector('.banner_slider')
const slides = document.querySelectorAll('.slides')


const clientwidth = slides[0].clientWidth
let index = 0
const runSlider = (i)=>{
    banner_slider.style = `transform: translateX(-${clientwidth*i + (clientwidth*(0.2*i))}px);`
}

setInterval(()=>{
    index++

    if(index ==slides.length){
        index = 0
    }
    runSlider(index)
    
},5000)

const styles = document.getElementById('styles').sheet;
const marquee = document.querySelector('.marquee')
const tag_contents = document.querySelector('.tag_contents')


styles.insertRule(`
    @keyframes marquee {
        0%{
    transform: translateX(${tag_contents.clientWidth+10}px);
        }
        100%{
            transform: translateX(-100%);
        }
      }
`);