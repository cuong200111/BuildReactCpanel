const express = require('express')
const http = require('http')
const bodyParser = require('body-parser');
const session = require('express-session')
const path = require('path')
const db = require('./model/db')
const jwt = require('jsonwebtoken')
const Currency = require('currency.js')
const Button = require('@mui/material/Button')
const cookies = require('cookie-parser')
require('dotenv').config()
const Get = require('./controller/get/index')
const Post = require('./controller/post/index')
const uid = require("uid-safe");
let newuid = uid.sync(6);
const app = express()

app.use((req, res) =>{
    res.locals.Button = Button
   
})
app.use(bodyParser.urlencoded({extended:true}))
app.use(bodyParser.json())
app.use(session({
    secret:'invalsjks',
    resave:false,
    saveUninitialized:false
}))
app.use(cookies())
app.use((req,res)=>{
    res.locals.uids = newuid
 
})
app.use((req,res)=>{
    req.db =db
    next()
})
app.use((req,res)=>{
 try {
        const token = req.cookies
        const tokenVerify = jwt.verify(token.Token,process.env.Scret)
        req.token = tokenVerify.id
        } catch (error) {
            req.token = 0
        }

})

app.use((req,res)=>{
   
    db.query(`SELECT * FROM account where uid =${req.token}`,(err,datas)=>{
        try {
            const monney = datas[0].coin
        const monneyFz = Currency(datas[0].FreezeCoin).divide(23000)
        const monney_usd = Currency(monney).divide(23000)
        db.query(`SELECT * FROM account `,(err,data)=>{
            res.locals.data = {
                monneyFz:monneyFz.value,
                monney:monney_usd.value,
                data:datas[0],
                datas:data
            }
        
        })
        } catch (error) {
       
        }
       
    
     })


})

app.use(express.static(path.join(__dirname, 'public',)))
app.use('/img', express.static(path.join(__dirname, 'image')))
app.set('views', path.join(__dirname,'views' ))
app.set('view engine', 'ejs')
app.use('/',Get)
app.use('/',Post)

app.listen(3000)
