module.exports = {
  apps: [
    {
      name: '20_APP_CRM',
      script: './index.js',
      watch: false,
      instance_var: 'INSTANCE_ID',
      instances: 2,
      exec_mode: 'cluster',
      env: {
        NODE_ENV: 'production',

        PORT: 10020,
        JWT_SECRET: '0a6b944d-d2fb-46fc-a85e-0295c986cd9f',

        MONGO_HOST: `mongodb://172.16.100.39:27017/AppCRM`,
        MONGO_USERNAME: 'dunglv',
        MONGO_PASSWORD: '12345678',

        NAME: '20_CRM',

        TOKEN_URL: `https://g.lifetek.vn:201/oauth/token`,
        REDIRECT: `https://g.lifetek.vn:220/api/oauth/callback`,
        RESOURCE_URL: `https://g.lifetek.vn:201/users/me?include=client`,
        CLIENT_ID: '20_CRM',
        CLIENT_SECRET: 'secret',
        API_ROLE_GROUPS: `https://g.lifetek.vn:201/role-groups?clientId=20_CRM`,
        API_ROLE_GROUPS_01: `https://g.lifetek.vn:201`,
        AMQP_HOST: '172.16.100.107',
        AMQP_PORT: 5672,
        AMQP_AUTH: true,
        AMQP_USERNAME: 'messenger_pub',
        AMQP_PASSWORD: 'messenger_pub',
      },
    },
  ],
};
