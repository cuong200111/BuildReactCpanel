const init = {
  crmSource: [
    {
      title: 'Nguồn',
      canDragDrop: true,
      code: 'S06',
    },
    {
      title: 'Nguồn vốn',
      canDragDrop: true,
      code: 'S18',
    },
    {
      title: 'Loại hợp đồng',
      canDragDrop: true,
      code: 'S15',
    },
    {
      title: 'Phương thức thanh toán',
      canDragDrop: true,
      code: 'S17',
    },
    {
      title: 'Loại danh nghiệp',
      canDragDrop: true,
      code: 'S14',
    },
    {
      title: 'Nhân viên',
      canDragDrop: true,
      code: 'S13',
    },
    {
      title: 'Ngành nghề',
      canDragDrop: true,
      code: 'S12',
    },
    {
      title: 'Loại trao đổi/thỏa thuận',
      canDragDrop: true,
      code: 'S11',
    },
    {
      title: 'Khu vực địa lý',
      canDragDrop: true,
      code: 'S10',
    },
    {
      title: 'Giao dịch mới',
      canDragDrop: true,
      code: 'S09',
    },
    {
      title: 'Loại khách hàng',
      canDragDrop: true,
      code: 'S08',
    },
    {
      title: 'Nhóm khách hàng',
      canDragDrop: true,
      code: 'S07',
    },
    {
      title: 'Loại sự kiện',
      canDragDrop: true,
      code: 'S16',
    },
    {
      title: 'Phân cấp khách hàng',
      canDragDrop: false,
      code: 'pckh',
    },
    {
      title: 'Loại đơn vị',
      canDragDrop: false,
      code: 'S01',
    },
    {
      title: 'Mặt hàng kinh doanh',
      canDragDrop: false,
      code: 'S02',
    },
    {
      title: 'Hình thức trao đổi',
      canDragDrop: false,
      code: 'S03',
    },
    {
      title: 'Ngân hàng',
      canDragDrop: false,
      code: 'S04',
    },
    {
      title: 'Công đoạn',
      canDragDrop: false,
      code: 'S05',
    },
    {
      title: 'Loại công văn',
      canDragDrop: false,
      code: 'S19',
    },
    {
      title: 'Độ khẩn',
      canDragDrop: false,
      code: 'S20',
    },
    {
      title: 'Độ mật',
      canDragDrop: false,
      code: 'S21',
    },
    {
      title: 'Nơi lưu trữ công văn',
      canDragDrop: false,
      code: 'S22',
    },
    {
      title: 'Nơi phát hành công văn',
      canDragDrop: false,
      code: 'S23',
    },
    {
      title: 'Loại chi phí',
      canDragDrop: false,
      code: 'S24',
    },
    {
      title: 'Phân loại nhà cung cấp',
      canDragDrop: false,
      code: 'S25',
    },
    {
      title: 'Tình trạng thanh toán',
      canDragDrop: false,
      code: 'S40',
      data: [
        {
          title: 'Khả thi thanh toán',
          index: 1,
          value: 'kha thi thanh toan',
        },
        {
          title: 'Khó đòi',
          index: 2,
          value: 'kho doi',
        },
      ],
    },
  ],
  hrmSource: [
    {
      title: 'Trạng thái lao động',
      canDragDrop: false,
      code: 'S01',
      data: [{ title: 'Đang làm việc', value: 'DLV' }, { title: 'Đã nghỉ hưu', value: 'DNH' }],
    },
    {
      title: 'Trạng thái hôn nhân',
      canDragDrop: false,
      code: 'S02',
      data: [
        {
          title: 'Đã kết hôn',
          value: 'ĐKH',
        },
        {
          title: 'Độc thân',
          value: 'ĐT',
        },
      ],
    },
    {
      title: 'Loại hợp đồng',
      canDragDrop: false,
      code: 'S03',
      data: [
        {
          title: 'Nhân viên chính thức',
          value: 'CT',
        },
        {
          title: 'Nhân viên thử việc',
          value: 'TV',
        },
        {
          title: 'Học việc/Thực tập',
          value: 'HV',
        },
      ],
    },
    {
      title: 'Chức danh',
      canDragDrop: false,
      code: 'S04',
      data: [
        { title: 'Giám đốc điều hành', value: 'GĐĐH' },
        { title: 'Giám đốc sản xuất', value: 'GĐSX' },
        { title: 'Phó giám đốc', value: 'PGĐ' },
        { title: 'Trợ lý Giám đốc', value: 'TLGĐ' },
        { title: 'Trưởng phòng', value: 'TP' },
        { title: 'Phó trưởng phòng', value: 'PTP' },
      ],
    },
    {
      title: 'Hệ đào tạo',
      canDragDrop: false,
      code: 'S05',
    },
    {
      title: 'Ngành học',
      canDragDrop: false,
      code: 'S06',
    },
    {
      title: 'Trình độ',
      canDragDrop: false,
      code: 'S07',
      data: [{ title: 'ĐH', value: 'ĐH' }, { title: 'CĐ', value: 'ĐH' }],
    },
    {
      title: 'Tin học',
      canDragDrop: false,
      code: 'S08',
    },
    {
      title: 'Ngoại ngữ 1',
      canDragDrop: false,
      code: 'S09',
    },
    {
      title: 'Ngoại ngữ 2',
      canDragDrop: false,
      code: 'S10',
    },
    {
      title: 'Dân tộc',
      canDragDrop: false,
      code: 'S11',
      data: [
        { title: 'Dân tộc Thái', value: 'Thai' },
        { title: 'Dân tộc Nùng', value: 'Nung' },
        { title: 'Dân tộc Ê-đê', value: 'EDe' },
        { title: 'Dân tộc Kinh', value: 'Kinh' },
      ],
    },
    {
      title: 'Tôn giáo',
      canDragDrop: false,
      code: 'S12',
    },
    {
      title: 'Ca làm việc',
      canDragDrop: false,
      code: 'S13',
      data: [
        { title: 'Sáng', value: '1234' },
        { title: 'Chiều', value: '2345' },
        { title: 'Tối', value: '567' },
        { title: 'Ca Hành Chính', value: 'CA001' },
      ],
    },
    {
      title: 'Trường tốt nghiệp',
      canDragDrop: false,
      code: 'S14',
    },
    {
      title: 'Nhóm máu',
      canDragDrop: false,
      code: 'S15',
      data: [
        { title: 'nhóm máu O', value: 'O' },
        { title: 'nhóm máu A', value: 'A' },
        { title: 'nhóm máu B', value: 'B' },
      ],
    },
    {
      title: 'Chức vụ',
      canDragDrop: false,
      code: 'S16',
      data: [
        {
          title: 'Giám đốc điều hành',
          value: 'gim-c-iu-hnh',
        },
        {
          title: 'Giám đốc sản xuất',
          value: 'gim-c-sn-xut',
        },
        {
          title: 'Phó giám đốc',
          value: 'ph-gim-c',
        },
        {
          title: 'Trợ lý Giám đốc',
          value: 'tr-l-gim-c',
        },
        {
          title: 'Trưởng phòng',
          value: 'trng-phng',
        },
        {
          title: 'Phó trưởng phòng',
          value: 'ph-trng-phng',
        },
        {
          title: 'Trưởng phòng lập trình',
          value: 'trng-phng-lp-trnh',
        },
        {
          title: 'Phó trưởng phòng lập trình',
          value: 'ph-trng-phng-lp-trnh',
        },
        {
          title: 'Trưởng nhóm kỹ thuật',
          value: 'trng-nhm-k-thut',
        },
        {
          title: 'Nhân viên',
          value: 'nhn-vin',
        },
        {
          title: 'Kế toán trưởng',
          value: 'k-ton-trng',
        },
        {
          title: 'Trưởng nhóm lập trình',
          value: 'trng-nhm-lp-trnh',
        },
        {
          title: 'Trưởng nhóm tài liệu và quản lý chất lượng',
          value: 'trng-nhm-ti-liu-v-qun-l-cht-lng',
        },
      ],
    },
    {
      title: 'Thời gian làm việc',
      canDragDrop: false,
      code: 'S17',
    },
    {
      title: 'Mức kỷ luật',
      canDragDrop: false,
      code: 'S18',
    },
    {
      title: 'Loại nghỉ phép',
      canDragDrop: false,
      code: 'S19',
      data: [
        {
          title: 'Nghỉ phép',
          value: 'S19_NP',
          disableDelete: true,
        },
        {
          title: 'Nghỉ không phép',
          value: 'NKP',
          disableDelete: true,
        },
        {

          title: 'Xin đi muộn',
          value: 'XĐM',
          disableDelete: true,
        },
        {

          title: 'Xin về sớm',
          value: 'XVS',
          disableDelete: true,
        },
        {
          title: 'Làm Online',
          value: 'LOL001',
          disableDelete: true,
        },
        {
          title: 'Làm onsite',
          value: 'OS001',
          disableDelete: true,
        }
      ],
    },
    {
      title: 'Cách tính thời gian',
      canDragDrop: false,
      code: 'S20',
    },
    {
      title: 'Độ tuổi',
      canDragDrop: false,
      code: 'S21',
    },
    {
      title: 'Vị trí tuyển dụng',
      canDragDrop: false,
      code: 'S30',
      data: [
        {
          title: 'Testter',
          index: 1,
          value: 'Testter',
        },
        {
          title: 'dev',
          index: 2,
          value: 'dev',
        },
      ],
    },
    {
      title: 'Kênh tuyển dụng',
      canDragDrop: false,
      code: 'S31',
      data: [
        {
          title: 'Facebook',
          index: 1,
          value: 'FB',
        },
        {
          title: 'Trang tuyển dụng',
          index: 2,
          value: 'webTT',
        },
      ],
    },
    {
      title: 'Hình thức đào tạo',
      canDragDrop: false,
      code: 'S32',
      data: [
        {
          title: 'Hình thức A',
          index: 1,
          value: 'HHA',
        },
      ],
    },
    {
      title: 'Trung tâm đào tạo',
      canDragDrop: false,
      code: 'S33',
      data: [
        {
          title: 'Trung tâm A',
          index: 1,
          value: 'TTA',
        },
      ],
    },
    {
      title: 'Trạng thái Đào tạo',
      canDragDrop: false,
      code: 'S34',
      data: [
        {
          title: 'Trung tâm A',
          index: 1,
          value: 'TTA',
        },
      ],
    },
    {
      title: 'Xếp loại đào tạo',
      canDragDrop: false,
      code: 'S35',
      data: [
        {
          title: 'Trung tâm A',
          index: 1,
          value: 'TTA',
        },
      ],
    },
    {
      title: 'Chứng chỉ đào tạo',
      canDragDrop: false,
      code: 'S36',
      data: [],
    },
    {
      title: 'Loại thời gian',
      canDragDrop: false,
      code: 'S37',
      data: [],
    },
  ],
  crmConfig: [
    {
      name: 'Trạng thái cơ hội kinh doanh',
      order: 1,
      code: 'CRM-Config-01',
      kind: 1,
      data1: [
        {
          name: 'Công việc mới',
          order: 1,
          code: 'CV1',
          status: 'init',
        },
        {
          name: 'Công việc thành công',
          order: 1,
          code: 'CV2',
          status: 'success',
        },
        {
          name: 'công việc thất bại',
          order: 1,
          code: 'CV3',
          status: 'failing',
        },
      ],
    },
    {
      name: 'Nguồn',
      order: 2,
      code: 'CRM-Config-02',
      kind: 2,
      data2: [],
    },
    {
      name: 'Loại hợp',
      order: 3,
      code: 'CRM-Config-03',
      kind: 2,
      data2: [],
    },
    {
      name: 'Loại doanh nghiệp',
      order: 4,
      code: 'CRM-Config-04',
      kind: 2,
      data2: [],
    },
    {
      name: 'Nhân viên',
      order: 5,
      code: 'CRM-Config-05',
      kind: 2,
      data2: [],
    },
    {
      name: 'Ngành nghề',
      order: 6,
      code: 'CRM-Config-06',
      kind: 2,
      data2: [],
    },
    {
      name: 'Loại trao đổi /thảo thuận',
      order: 7,
      code: 'CRM-Config-07',
      kind: 2,
      data2: [],
    },
    {
      name: 'Trạng thái hóa đơn',
      order: 8,
      code: 'CRM-Config-08',
      kind: 2,
      data2: [],
    },
    {
      name: 'Trạng thái cơ hội kinh doanh',
      order: 9,
      code: 'CRM-Config-09',
      kind: 1,
      data1: [
        {
          name: 'Công việc mới',
          order: 1,
          code: 'CV1',
          status: 'init',
        },
        {
          name: 'Công việc thành công',
          order: 1,
          code: 'CV2',
          status: 'success',
        },
        {
          name: 'công việc thất bại',
          order: 1,
          code: 'CV3',
          status: 'failing',
        },
      ],
    },
    {
      name: 'Giao dịch mới',
      order: 10,
      code: 'CRM-Config-10',
      kind: 2,
      data2: [],
    },
    {
      name: 'Trạng thái báo giá',
      order: 11,
      code: 'CRM-Config-11',
      kind: 1,
      data1: [
        {
          name: 'Công việc mới',
          order: 1,
          code: 'CV1',
          status: 'init',
        },
        {
          name: 'Công việc thành công',
          order: 1,
          code: 'CV2',
          status: 'success',
        },
        {
          name: 'công việc thất bại',
          order: 1,
          code: 'CV3',
          status: 'failing',
        },
      ],
    },
    {
      name: 'Trạng thái hợp đồng',
      order: 12,
      code: 'CRM-Config-12',
      kind: 2,
      data2: [],
    },
    {
      name: 'Trạng thái gọi điện',
      order: 13,
      code: 'CRM-Config-13',
      kind: 2,
      data2: [],
    },
    {
      name: 'Loại sự kiện',
      order: 14,
      code: 'CRM-Config-14',
      kind: 2,
      data2: [],
    },
  ],
  shiftInit: [
    {
      name: 'Hành chính',
      symbol: 'X',
      type: {
        title: 'Vào đầu, ra cuối',
        value: 'vo-u-ra-cui',
      },
      data: [
        {
          title: 'Ca 1',
          startTime: '08:00',
          endTime: '12:00',
        },
      ],
      breakTime: 1,
      hoursDeducted: true,
      finishSoon: 1,
      late: 1,
      minOtBeforeShift: 1,
      minOtAfterShift: 1,
      maxOtBeforeShift: 1,
      maxOtAfterShift: 1,
      startTimeOtBefore: '08:00',
      startTimeOtAfter: '17:30',
      addBreakTime: true,
    },
  ],
  formulaInit: [
    {
      status: 1,
      name: 'Công thức lương',
      code: 'CTL',
    },
  ],
  roundExamInit: [
    {
      autoSend: true,
      name: 'V1 Test IQ',
      code: '1',
      note: 'Làm câu hỏi trắc nghiệm',
    },
  ],
  examInit: [
    {
      name: 'Trắc nghiệm',
      code: 'TN',
      note: 'Trả lời trắc nghiệm',
      pointLadder: 100,
    },
  ],
  questionInit: [
    {
      scores: 10,
      ratio: 100,
      name:
        'Có một đàn vịt, cho biết 1 con đi trước thì có 2 con đi sau, 1 con đi sau thì có 2 con đi trước, 1 con đi giữa thì có 2 con đi 2 bên. Hỏi đàn vịt đó có mấy con?',
      data: [
        {
          checked: false,
          content: '1',
        },
        {
          checked: false,
          content: '2',
        },
        {
          checked: true,
          content: '3',
        },
        {
          checked: false,
          content: '4',
        },
      ],
      type: 'checkbox',
      obligatory: true,
      correctAnswer: '3',
    },
    {
      scores: 10,
      ratio: 100,
      name: 'Người đẹp Monalisa không có thứ gì?',
      data: [
        {
          checked: false,
          content: 'Tiền',
        },
        {
          checked: false,
          content: 'Chồng',
        },
        {
          checked: false,
          content: 'Lông chân',
        },
        {
          checked: true,
          content: 'Lông mày',
        },
      ],
      type: 'checkbox',
      obligatory: true,
      correctAnswer: 'Lông mày',
    },
    {
      scores: 10,
      ratio: 100,
      name: 'Những loài thú nào sau đây ăn cơm:',
      data: [
        {
          checked: false,
          content: 'Cọp',
        },
        {
          checked: false,
          content: 'Hà mã',
        },
        {
          checked: true,
          content: 'Sư tử',
        },
        {
          checked: false,
          content: 'Voi',
        },
      ],
      type: 'checkbox',
      obligatory: true,
      correctAnswer: 'Sư tử',
    },
    {
      scores: 10,
      ratio: 100,
      name: 'Vì sao thích một mình nhưng lại sợ cô đơn',
      type: 'text',
      obligatory: true,
      correctAnswer: 'Không biết',
    },
  ],
};
module.exports = {
  init,
};
