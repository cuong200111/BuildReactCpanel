
/* eslint-disable  */
const inputs = [{ name: 'fullName', title: 'Họ tên', type: 'text' }, { name: 'birthDate', title: 'ngày sinh', type: 'date' },];
  let inputhtml = '';
  inputs.forEach((item) => {
    inputhtml += ` <div>
  <label for="${item.name}">${item.title}</label>
  <input type = "${item.type}" name="${item.name}" id="${item.name}" >
</div>`;
  });
  const html = `
<button id="myBtn">!</button>

<div id="myModal" class="modal">

<div class="modal-content">
  <span class="close">&times;</span>
  <form id="buttonSubmit"  method="POST" >
${inputhtml}
<div>
  <button  type="submit" >Send my greetings</button>
</div>
</form>
</div>

</div>

<style>
body {font-family: Arial, Helvetica, sans-serif;}

#myBtn{
position:absolute;
right:20px;
bottom:20px;
border-radius:50%;
height:50px;
width:50px;
}
.modal {
display: none; /* Hidden by default */
position: fixed; /* Stay in place */
z-index: 1; /* Sit on top */
padding-top: 100px; /* Location of the box */
left: 0;
top: 0;
width: 100%; /* Full width */
height: 100%; /* Full height */
overflow: auto; /* Enable scroll if needed */
background-color: rgb(0,0,0); /* Fallback color */
background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}

/* Modal Content */
.modal-content {
background-color: #fefefe;
margin: auto;
padding: 20px;
border: 1px solid #888;
width: 80%;
}

/* The Close Button */
.close {
color: #aaaaaa;
float: right;
font-size: 28px;
font-weight: bold;
}

.close:hover,
.close:focus {
color: #000;
text-decoration: none;
cursor: pointer;
}
</style>

`;


  function postData(url = '', data = {}) {
// Default options are marked with *
    return fetch(url, {
      method: 'POST', // *GET, POST, PUT, DELETE, etc.
      mode: 'cors', // no-cors, cors, *same-origin
      cache: 'no-cache', // *default, no-cache, reload, force-cache, only-if-cached
      credentials: 'same-origin', // include, *same-origin, omit
      headers: {
        'Content-Type': 'application/json',
          // 'Content-Type': 'application/x-www-form-urlencoded',
      },
      redirect: 'follow', // manual, *follow, error
      referrer: 'no-referrer', // no-referrer, *client
      body: JSON.stringify(data), // body data type must match "Content-Type" header
    })
  .then(response => response.json()); // parses JSON response into native JavaScript objects
  }

  document.querySelector('body').insertAdjacentHTML('afterbegin', html);

  const modal = document.getElementById('myModal');
  const btn = document.getElementById('myBtn');
  const span = document.getElementsByClassName('close')[0];
  btn.onclick = function() {
    modal.style.display = 'block';
  };
  span.onclick = function() {
    modal.style.display = 'none';
  };
  window.onclick = function(event) {
    if (event.target == modal) {
      modal.style.display = 'none';
    }
  };
  document.querySelector('#buttonSubmit').addEventListener('submit', (e) => {
    e.preventDefault();
    const body = {};
    const formData = new FormData(document.querySelector('#buttonSubmit'));
    inputs.forEach((item) => {
      body[item.name] = formData.get(item.name);
    });
    postData('http://example.com/answer', body)
.then(data => console.log(JSON.stringify(data))) // JSON-string from `response.json()` call
.catch(error => console.error(error));
    console.log(body);
  });
