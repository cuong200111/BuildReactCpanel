
/* eslint-disable  */
const baseUrl =  'http://localhost:10020';

const Bitrix24FormLoader = {

  init() {
    this.yaId = null;
    this.forms = {};
    this.eventHandlers = [];
    this.frameHeight = '200';
    this.defaultNodeId = 'cni-form';

    if (!window.CNIFormObject || !window[window.CNIFormObject]) { return; }
    if (!window[window.CNIFormObject].forms) { return; }

    const forms = window[window.CNIFormObject].forms;
    forms.ntpush = forms.push;
    forms.push = function (params) {
      forms.ntpush(params);
      this.preLoad(params);
    }.bind(this);
    forms.forEach(this.preLoad, this);
  },
  preLoad(params) {
    const _this = this;
    switch (params.type)		{
      case 'click': {
        break;
      }
      case 'button':
        this.getButton(params);
        break;
      case 'inline': {
        this.getInline(params);
        break;
      }
      default:
        break;
    }
  },

 async getInline(params) {
    const {id} = params
   await this.getPropsForm({ id });
   if (this.data) {
     const { fields } = this.data;
     const node = window.document.getElementById(this.defaultNodeId);
     if (node) {
      console.log(node.parentElement)
       node.parentElement.insertAdjacentHTML('beforeend', `<div id="map" style="width:100%;height:auto">
          <iframe src="${params.base_url}/ren/form/5d79a458526cc326c05a9646" width="100%"
          frameborder="0" style="border:0" allowfullscreen></iframe>
      </div>
     `)

     }
   }
  },
//  async getInline(params) {
//     const {id} = params
//    await this.getPropsForm({ id });
//    if (this.data) {
//     const { fields } = this.data;
//      const node =  window.document.getElementById(this.defaultNodeId);
//      if (node) {

//        node.parentElement.insertAdjacentHTML('beforeend',`<div class="container-form">
//        <form id="buttonSubmit" class="form-con"  method="POST">
//        <div class="form-top">
//       <h2 class="title-top">${this.data.name}</h2>
//        </div>
//           <div class='form-content'>
//           ${
//             fields.reduce((accumulator, currentValue) => {
//               return accumulator+ `
//               <div class="row-form">
//                  <div class="col-25">
//                    <label for="fname">${currentValue.title}:${currentValue.isRequire?`<span style="color:red">*</span>`:''}</label>
//                  </div>
//                  <div class="col-75">
//                    <input required="${currentValue.isRequire}" type="text" id="${currentValue.name}" name="${currentValue.name}" placeholder="${currentValue.title}">
//                  </div>
//               </div>
//               `
//             },'')

//           }
//             <div class="row-form">
//             <div class="col-25">

//                  </div>
//                  <div class="col-75">
//                  <input type="submit"  value="Gửi phản hồi">
//                                </div>

//           </div>
//          </div>
//        </form>
//        <div id="popup1" class="overlay">
// 	<div class="popup">
// 		<h2>Gửi phản hồi thành công</h2>
// 		<a class="close" href="#">&times;</a>
//     <div class="content">
// 			<p>Cảm ơn bạn đã gửi phản hồi, chúng tôi sẽ sớm liên hệ với bạn.</p>
// 		</div>
// 	</div>
// </div>
//      </div>
//      <style>
//      /* Style inputs, select elements and textareas */
//      input[type=text], select, textarea{
//        width: 100%;
//        padding: 12px;
//       border: 1px solid #ccc;
//        border-radius: 4px;
//        box-sizing: border-box;
//        resize: vertical;
//      }

//      /* Style the label to display next to the inputs */
//      label {
//        padding: 12px 12px 12px 0;
//        display: inline-block;
//      }

//      /* Style the submit button */
//      input[type=submit] {
//        background-color: #00AEEF;
//        color: white;
//        padding: 12px 20px;
//        border: none;
//        border-radius: 4px;
//        cursor: pointer;
//        float: right;
//      }
//      .title-top{
//       text-align:center;
//       margin: 0;
//     padding: 20px;
//      }
//      .form-top{
//        background-color:#FCFCFC;
//       border-bottom: 1px solid gainsboro;
//      }
//      .form-content{
//        margin:20px;
//      }
//      /* Style the container */
//      .container-form {
//       font-family: tahoma;
//        border-radius: 5px;
//       //  background-color: #E8EEEF;
//        padding: 20px;
//        width:600px;
//        margin:0 auto;
//        box-shadow: 0 3px 6px rgba(0,0,0,0.16), 0 3px 6px rgba(0,0,0,0.23);
//      }
//      .form-con{
//       border: 1px solid gainsboro;

//      }
//      /* Floating column for labels: 25% width */
//      .col-25 {
//        float: left;
//        width: 25%;
//        margin-top: 6px;
//      }

//      /* Floating column for inputs: 75% width */
//      .col-75 {
//        float: left;
//        width: 75%;
//        margin-top: 6px;
//      }

//      /* Clear floats after the columns */
//      .row-form:after {
//        content: "";
//        display: table;
//        clear: both;
//      }

//      /* Responsive layout - when the screen is less than 600px wide, make the two columns stack on top of each other instead of next to each other */
//      @media screen and (max-width: 600px) {
//        .col-25, .col-75, input[type=submit] {
//          width: 100%;
//          margin-top: 0;
//        }
//      }


//     .overlay {
//       position: fixed;
//       top: 0;
//       bottom: 0;
//       left: 0;
//       right: 0;
//       background: rgba(0, 0, 0, 0.7);
//       transition: opacity 500ms;
//       visibility: hidden;
//       opacity: 0;
//     }
//     .overlay:target {
//       visibility: visible;
//       opacity: 1;
//     }

//     .popup {
//       margin: 70px auto;
//       padding: 20px;
//       background: #fff;
//       border-radius: 5px;
//       width: 30%;
//       position: relative;
//       transition: all 5s ease-in-out;
//     }

//     .popup h2 {
//       margin-top: 0;
//       color: #333;
//       font-family: Tahoma, Arial, sans-serif;
//     }
//     .popup .close {
//       position: absolute;
//       top: 20px;
//       right: 30px;
//       transition: all 200ms;
//       font-size: 30px;
//       font-weight: bold;
//       text-decoration: none;
//       color: #333;
//     }
//     .popup .close:hover {
//       color: #06D85F;
//     }
//     .popup .content {
//       max-height: 30%;
//       overflow: auto;
//     }
//     .active{
//       visibility: visible;
//     opacity: 1;
//     }
//      </style>
//      `)
//      }
//      document.querySelector('.popup .close').addEventListener('click', e => {
//        e.preventDefault();
//        this.hidenNoti();
//      })
//      document.querySelector('#buttonSubmit').addEventListener('submit', (e) => {
//        e.preventDefault();
//       const body = {};
//        const formData = new FormData(document.querySelector('#buttonSubmit'));

//        fields.forEach((item) => {
//         body[item.name] = formData.get(item.name);
//       });
//       this.postData(baseUrl+'/api/contact-center/form/'+id, body)
//   .then(data => this.showNoti())
//   .catch(error => {this.showNoti()});
//       console.log(body);
//     });
//    }
//   },
 async getButton(params) {
    const {id} = params
   await this.getPropsForm({ id });
   if (this.data) {
    const { fields } = this.data;
     const node =  window.document.getElementById(this.defaultNodeId);
     if (node) {

       node.parentElement.insertAdjacentHTML('beforeend',`
       <input type="button"  value="Gửi phản hồi" id="myBtn">
       <div class="model" id="myModal">
       <div class="container-form">
       <form id="buttonSubmit" class="form-con"  method="POST">
       <div class="form-top">
      <h2 class="title-top">${this.data.name}</h2>
       </div>
          <div class='form-content'>
          ${
            fields.reduce((accumulator, currentValue) => {
              return accumulator+ `
              <div class="row-form">
                 <div class="col-25">
                   <label for="fname">${currentValue.title}:${currentValue.isRequire?`<span style="color:red">*</span>`:''}</label>
                 </div>
                 <div class="col-75">
                   <input required="${currentValue.isRequire}" type="text" id="${currentValue.name}" name="${currentValue.name}" placeholder="${currentValue.title}">
                 </div>
              </div>
              `
            },'')

          }
            <div class="row-form">
            <div class="col-25">

                 </div>
                 <div class="col-75">
                 <input type="submit"  value="Gửi phản hồi">
                               </div>

          </div>
         </div>
       </form>
      <div id="popup1" class="overlay">
    <div class="popup">
      <h2>Gửi phản hồi thành công</h2>
      <a class="close" href="#">&times;</a>
      <div class="content">
        <p>Cảm ơn bạn đã gửi phản hồi, chúng tôi sẽ sớm liên hệ với bạn.</p>
      </div>
    </div>
  </div>
     </div>
     </div>
     <style>
     /* Style inputs, select elements and textareas */
     input[type=text], select, textarea{
       width: 100%;
       padding: 12px;
      border: 1px solid #ccc;
       border-radius: 4px;
       box-sizing: border-box;
       resize: vertical;
     }

     /* Style the label to display next to the inputs */
     label {
       padding: 12px 12px 12px 0;
       display: inline-block;
     }

     /* Style the submit button */
     input[type=button] {
       background-color: #00AEEF;
       color: white;
       padding: 12px 20px;
       border: none;
       border-radius: 4px;
       cursor: pointer;
     }
     /* Style the submit button */
     input[type=submit] {
       background-color: #00AEEF;
       color: white;
       padding: 12px 20px;
       border: none;
       border-radius: 4px;
       cursor: pointer;
     }
     .title-top{
      text-align:center;
      margin: 0;
      padding: 20px;
     }
     .form-top{
       background-color:#FCFCFC;
      border-bottom: 1px solid gainsboro;
     }
     .form-content{
       margin:20px;
     }
     #myModal{
      display: none; /* Hidden by default */
      position: fixed; /* Stay in place */
      z-index: 1; /* Sit on top */
      left: 0;
      top: 0;
      width: 100%; /* Full width */
      height: 100%; /* Full height */
      overflow: auto; /* Enable scroll if needed */
      background-color: rgb(0,0,0); /* Fallback color */
      background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
     }
     /* Style the container */
     .container-form {

      font-family: tahoma;
       border-radius: 5px;
      //  background-color: #E8EEEF;
       padding: 20px;
       width:600px;
       margin:0 auto;
       box-shadow: 0 3px 6px rgba(0,0,0,0.16), 0 3px 6px rgba(0,0,0,0.23);
       background-color: #fefefe;
  margin: 15% auto; /* 15% from the top and centered */
  padding: 20px;
     }
     .form-con{
      border: 1px solid gainsboro;

     }
     /* Floating column for labels: 25% width */
     .col-25 {
       float: left;
       width: 25%;
       margin-top: 6px;
     }

     /* Floating column for inputs: 75% width */
     .col-75 {
       float: left;
       width: 75%;
       margin-top: 6px;
     }

     /* Clear floats after the columns */
     .row-form:after {
       content: "";
       display: table;
       clear: both;
     }

     /* Responsive layout - when the screen is less than 600px wide, make the two columns stack on top of each other instead of next to each other */
     @media screen and (max-width: 600px) {
       .col-25, .col-75, input[type=submit] {
         width: 100%;
         margin-top: 0;
       }
     }


    .overlay {
      position: fixed;
      top: 0;
      bottom: 0;
      left: 0;
      right: 0;
      background: rgba(0, 0, 0, 0.7);
      transition: opacity 500ms;
      visibility: hidden;
      opacity: 0;
    }
    .overlay:target {
      visibility: visible;
      opacity: 1;
    }

    .popup {
      margin: 70px auto;
      padding: 20px;
      background: #fff;
      border-radius: 5px;
      width: 30%;
      position: relative;
      transition: all 5s ease-in-out;
    }

    .popup h2 {
      margin-top: 0;
      color: #333;
      font-family: Tahoma, Arial, sans-serif;
    }
    .popup .close {
      position: absolute;
      top: 20px;
      right: 30px;
      transition: all 200ms;
      font-size: 30px;
      font-weight: bold;
      text-decoration: none;
      color: #333;
    }
    .popup .close:hover {
      color: #06D85F;
    }
    .popup .content {
      max-height: 30%;
      overflow: auto;
    }
    .active{
      visibility: visible;
    opacity: 1;
    }
     </style>
     `)
     }
     // Get the modal
var modal = document.getElementById("myModal");

// Get the button that opens the modal
var btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks the button, open the modal
btn.onclick = function() {
  modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}
     document.querySelector('.popup .close').addEventListener('click', e => {
       e.preventDefault();
       this.hidenNoti();
     })
     document.querySelector('#buttonSubmit').addEventListener('submit', (e) => {
       e.preventDefault();
      const body = {};
       const formData = new FormData(document.querySelector('#buttonSubmit'));

       fields.forEach((item) => {
        body[item.name] = formData.get(item.name);
      });
      this.postData(baseUrl+'/api/contact-center/form/'+id, body)
  .then(data => this.showNoti())
  .catch(error => {this.showNoti()});
      console.log(body);
    });
   }
  },
  async getPropsForm(props) {
    const { id } = props;

    const data = await this.getData(baseUrl + '/api/contact-center/'+id);
    this.data = data;
  }, postData(url = '', data = {}) {

        return fetch(url, {
          method: 'POST',
          headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(data)
        })

      .then(response => response.json());
  },
   getData(url = '', data = {}) {
        return fetch(url, {
          method: 'GET',
          mode: 'cors',
          cache: 'no-cache',
          credentials: 'same-origin',

          redirect: 'follow',
          referrer: 'no-referrer',
        })
      .then(response => response.json());
  },
  showNoti() {
    window.document.querySelector('#popup1').className = "active overlay"
  },
  hidenNoti() {
    window.document.querySelector('#popup1').className = " overlay";

  }
};

Bitrix24FormLoader.init();
