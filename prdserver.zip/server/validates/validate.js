function validateEmail(email) {
  const re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  return re.test(String(email).toLowerCase());
}
function validatePhone(phone) {
  const phoneno = /((09|03|07|08|05)+([0-9]{8})\b)/g;
  if (phone.match(phoneno)) {
    return true;
  } else {
    return false;
  }
}

module.exports = {
  validateEmail,
  validatePhone
};
