
const timeReload = 60;
const outOfDate = [1, 6, 10];


module.exports = function noticeTask() {
  console.log('NOTICE ______');
  const updateTask = async () => {
    console.log('NOTICE _START_.....');
    const Task = require('../api/task/task.model')();
    const { sendNotice } = require('../api/task/task.controller');
    const outDate1 = new Date();
    const outDate2 = new Date();
    const outDate3 = new Date();
    outDate1.setMinutes(outDate1.getMinutes() + outOfDate[0]);
    outDate2.setMinutes(outDate2.getMinutes() + outOfDate[1]);
    outDate3.setMinutes(outDate3.getMinutes() + outOfDate[2]);
    const outEnd1 = new Date(outDate1);
    const outEnd2 = new Date(outDate2);
    const outEnd3 = new Date(outDate3);
    outEnd1.setMinutes(outEnd1.getMinutes() + timeReload);
    outEnd2.setMinutes(outEnd2.getMinutes() + timeReload);
    outEnd3.setMinutes(outEnd3.getMinutes() + timeReload);
    const task1 = await Task.find({ endDate: { $gt: outDate1, $lt: outEnd1 }, taskStatus: { $ne: 3 } });
    const task2 = await Task.find({ endDate: { $gt: outDate2, $lt: outEnd2 }, taskStatus: { $ne: 3 } });
    const task3 = await Task.find({ endDate: { $gt: outDate3, $lt: outEnd3 }, taskStatus: { $ne: 3 } });
    console.log('TASK_#_________.....#_____________TASK', task3);

    const allNotice = [];
    function addNotice(list, name, date) {
      list.forEach((element) => {
        const notices = element[name].map(async (i) => {
          const dataNotice = {
            title: `Công việc/dự án ${element.name} đã quá hạn ${date} ngày`,
            content: `Công việc/dự án ${element.name} đã quá hạn ${date} ngày`,
            type: 'System',
            link: `/Task/${element._id.toString()}`,
            to: i.toString(),
          // from: 'Task',
            date: new Date(),
          };
          await sendNotice(dataNotice);
        });
        allNotice.concat(notices);
      });
    }

    addNotice(task1, 'join', outOfDate[0]);
    addNotice(task2, 'inCharge', outOfDate[1]);
    addNotice(task3, 'taskManager', outOfDate[2]);


    await Promise.all(allNotice);
  };


  setInterval(updateTask, timeReload * 60 * 1000);
};

