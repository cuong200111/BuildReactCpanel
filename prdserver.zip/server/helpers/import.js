/* eslint-disable prefer-const */
/* eslint-disable no-param-reassign */
/* eslint-disable consistent-return */
/* eslint-disable no-continue */
/* eslint-disable no-redeclare */
const mongoose = require('mongoose');
const httpStatus = require('http-status');
const STATUS = require('../variables/CONST_STATUS').STATUS;
const https = require('https');
const mergeRole = require('../api/roleTask/specialRole');
const roleTask = require('../api/roleTask/role.model');
const OrganizationUnit = require('../api/organizationUnit/organizationUnit.model');
const axios = require('axios');
const qs = require('querystring');
const User = require('../api/oauth/user.model');
const defaultColumn = require('../../defaultColumns');
const crmStatus = require('../api/crmStatus/crmStatus.model')
const moment = require('moment');

const {
  getDescendantProp,
  setDescendantProp,
  parseGenderSafety,
  isSourceEle,
  getSourceEleTitle,
  convertToSlug,
} = require('../helpers/common');

const APIError = require('../helpers/APIError');
const Employee = require('../api/employee/employee.model')();
const FIELD = require('../variables/FIELDS');
const _ = require('lodash');
const { FIELD_IS_NUMBER } = require('../variables/CONST_STATUS');

// // eslint-disable-next-line no-unused-vars
// async function importFormClient(req, res, next) {
//   // console.log(await mongoose.models.Tag.findOne());
//   const result = await mongoose.models.Tag.findOne();
//   res.json({ data: result });
// }

async function roleUpdateItems(req, res, next) {
  try {
    const roleErr = [];
    const { data, filterUpdate, modelName, methodImport } = req.body;
    console.log(global.hshCollections[modelName]);

    const dataByRole = await global.hshCollections[modelName].list({ user: req.user.user, selector: filterUpdate });
    // const existData = await global.hshCollections[modelName].findOne(filterUpdate);

    await Promise.all(
      data.map(async (item) => {
        if (!item[filterUpdate]) return item;

        const existData = await global.hshCollections[modelName].findOne({ filterUpdate: item[filterUpdate] });
        if (!existData) {
          return roleErr.push({
            success: false,
            message: `Bản ghi ${filterUpdate} = ${item[filterUpdate]} không tồn tại`,
          });
        }

        if (dataByRole && !dataByRole.data.find((el) => el[filterUpdate] === item[filterUpdate])) {
          return roleErr.push({
            success: false,
            message: `Bạn không có quyền chỉnh sửa bản ghi có ${filterUpdate} = ${item[filterUpdate]}`,
          });
        }
      }),
    );

    return res.json(roleErr);
  } catch (error) {
    console.log(error);
  }
}

// eslint-disable-next-line no-unused-vars
async function importFormClient(req, res, next) {
  const { modelName, filterUpdate, methodImport, exchangingAgreement } = req.body;
  let data = req.body.data;
  if (exchangingAgreement) {
    data.map((item) => {
      item.exchangingAgreement = exchangingAgreement;
    });
  }
  let checkNameExist = false;
  const user = await Employee.findById(req.user.user);
  // eslint-disable-next-line new-cap
  // const user = await Employee.findById(mongoose.Types.ObjectId('61b95f646fb41f521d6d7d68'));
  if (!user) return res.json(new APIError('Unauthorized', 401, true));
  let checkWarning = true;
  const Model = mongoose.models[modelName];

  if (modelName === 'Customer') {
    data = data.filter(
      (item, index) =>
        index === data.findIndex((it) => it.code === item.code) &&
        index === data.findIndex((it) => it.phoneNumber === item.phoneNumber) &&
        index === data.findIndex((it) => it.email === item.email),
    );
  }
  data = data.map((item) => {
    const newItem = {};
    Object.keys(item).forEach((key) => {
      if (isSourceEle(item[key]) && !item[key].title) return;
      newItem[key] = item[key];
    });
    return newItem;
  });
  let listRoleGroups = [];
  if (modelName === 'hrm') {
    const [responseData] = await Promise.all([
      axios.get(`${process.env.API_ROLE_GROUPS_01}/role-groups?clientId=${process.env.CLIENT_ID}`),
    ]);
    // console.log('responseData', responseData);
    // let { data: listRoleGroups } = responseData.data;
    // if (!listRoleGroups) {
    //   listRoleGroups = [];
    // }
    if (responseData.data) {
      listRoleGroups = responseData.data;
    }
  }
  const listRequired = checkRequired(modelName);
  const listEnum = checkEnum(modelName);
  const listDate = columnsDate(modelName);
  if (methodImport === 'add') {
    const modelSaveds = [];
    let itemName;
    for (let i = 0; i < data.length; i += 1) {
      try {
        let item = data[i];
        // Check kiểu dữ liệu trường
        let isInsert = true;
        Object.keys(item).forEach((key) => {
          if (FIELD_IS_NUMBER.includes(key) && isNaN(Number(item[key]))) {
            isInsert = false;
            const nameVN = getNameFieldVN(modelName, key);
            checkWarning = false;
            modelSaveds.push({
              success: false,
              errors: [`Dữ liệu trường ${nameVN} không hợp lệ: ${item[key]}, vui lòng nhập số.`],
            });
          }
        });
        if (!isInsert) continue;
        // end Check
        item[FIELD.UID] = user._id;
        // item[FIELD.OID] = user.organizationUnit ? user.organizationUnit.organizationUnitId : null;
        item.organizationUnit = user.organizationUnit ? user.organizationUnit.organizationUnitId : null;
        item.createdBy = user._id;
        const arrError = [];

        if (arrError.length !== 0) {
          checkWarning = false;
          modelSaveds.push({
            success: false,
            errors: arrError,
          });
          continue;
        }

        const filterOne = { [filterUpdate]: item[filterUpdate], status: { $ne: STATUS.DELETED } };
        let model = await Model.findOne(filterOne);
        // console.log('model::', model || 'loi');
        if (item.name && modelName === 'Calendar') {
          const filterOneName = {
            name: item.name,
            [filterUpdate]: { $ne: item[filterUpdate] },
            status: { $ne: STATUS.DELETED },
          };
          item.kanbanStatus = !item.kanbanStatus ? "1" : item.kanbanStatus;
          // (!req.body.kanbanStatus)? item.kanbanStatus = 1 : item.kanbanStatus = req.body.kanbanStatus;
          const modelNameCheck = await Model.findOne(filterOneName);
          if (modelNameCheck) {
            checkWarning = false;
            itemName = item.name;
            checkNameExist = true;
            modelSaveds.push({
              success: false,
              errors: [`${itemName} đã tồn tại`], 
            });

          (!req.body.kanbanStatus)? Model.kanbanStatus = 1 : Model.kanbanStatus = req.body.kanbanStatus

            
            continue;
            // continue;
          }
      }


        if (modelName === 'Task') {

          if(req.body.mettingScheduleId){
            item.mettingSchedule = req.body.mettingScheduleId;
          }
          if (!item.parentId) {
            item.parentId = null;
          }
          if(req.body.documentaryId){
            console.log("documentary",req.body.documentaryId);
            item.documentary = req.body.documentaryId;
          }
        }
        const keys = Object.keys(item);
        for (let i = 0; i < keys.length; i++) {
          //console.log(modelName, keys[i], item[keys[i]], listRequired.includes(keys[i]));
          if (listRequired.includes(keys[i])) {

            if (item[keys[i]] === '' || item[keys[i]] === 'undefined' || item[keys[i]] === null) {
              checkWarning = false;
              modelSaveds.push({
                success: false,
                errors: [`${keys[i]} là trường bắt buộc`],
              });
              continue;
            }
            // if (modelName == 'Calendar' && keys[i] == 'name') {
            //   const filterOneName = { name: item[keys[i]] || '', status: { $ne: STATUS.DELETED } };
            //   const modelNameCheck = await Model.findOne(filterOneName);
            //   if (modelNameCheck) {
            //     checkWarning = false;
            //     modelSaveds.push({
            //       success: false,
            //       errors: [`${model.name} đã tồn tại`],
            //     });
            //     continue;
            //   }
            // }
          }

          if (listEnum.find((e) => e.name === keys[i])) {
            const column = listEnum.find((e) => e.name === keys[i]);
            const value = column.menuItem.map((i) => i.code);
            if (column.menuItem && !column.menuItem.find((el) => el.code == item[keys[i]])) {
              checkWarning = false;
              modelSaveds.push({
                success: false,
                errors: [`${column.title} giá trị không hợp lệ trong ${value}`],
              });
              continue;
            }
          }

          if (listDate.includes(keys[i])) {
            const date = item[keys[i]].substring(1);
            if (!moment(`${date}`, 'YYYY-MM-DD HH:mm:ss').isValid()) {
              checkWarning = false;
              modelSaveds.push({
                success: false,
                errors: [`${item[keys[i]]} không hợp lệ`],
              });
              continue;
            }
          }
          //console.log(keys[i]);
          if (
            !(keys[i] === 'uid' || keys[i] === 'organizationUnit' || keys[i] === 'parentId')
          ) {
            if (keys[i] === 'receivingUnit') {
              console.log('hello');
            }
            if(keys[i] === "createdBy"){
              const code =await Employee.findById(item[keys[i]])
              //console.log(code);
              item[keys[i]] = code.code
            } 
            if(typeof item[keys[i]] === "object"){
                for (let k in item[keys[i]]){
                  let key = `${keys[i]}.${k}`;
                  keys.push(key);
                  item[key] = item[keys[i]][k];
                }
            }
            console.log(":>>>>:",keys[i],item[keys[i]]);
            const convertValue = await convertToObjectId(modelName, keys[i], item[keys[i]]);

            console.log(111111,keys[i],convertValue );
            if (typeof convertValue === 'object' && convertValue !== null && convertValue.hasOwnProperty('status')) {
              checkWarning = false;
              modelSaveds.push({
                success: false,
                errors: [convertValue.message],
              });
              continue;
            }
            if(keys[i] === 'pricePolicy'){
              item[keys[i]];
              continue;
            }
            else {
              item[keys[i]] = convertValue;
            }
          }
        }
        if (modelName === 'Calendar') {
          model.kanbanStatus = 1;
          item.createdBy = {
            name: user.name,
            employeeId: user._id,
          };
          if(req.body.kanbanStatus){
            item.kanbanStatus = req.body.kanbanStatus;
          }else{
            item.kanbanStatus = 1;
          }
          if (req.body.documentaryId) {
            item.documentary = req.body.documentaryId;
          }
        }
        if (modelName === 'Stock') {
          if (item.otherInfo) {
            item.otherInfo = {
              endDayForSale: moment(item.otherInfo.endDayForSale, 'DD/MM/YYYY').format('YYYY/MM/DD'),
              startDayForSale: moment(item.otherInfo.startDayForSale, 'DD/MM/YYYY').format('YYYY/MM/DD'),
              expirationDate: moment(item.otherInfo.expirationDate, 'DD/MM/YYYY').format('YYYY/MM/DD'),
            };
          }
        }
        if (modelName === 'Customer') {
          const kanban = await crmStatus.findOne({code: 'ST18'})
          kanban.data.map((i) => {
            if(i.code === 1){
              item.kanbanStatus = i._id;
            }
          })
        }
        if (modelName === 'hrm') {
          if (!data[i].email || !data[i].code || !data[i].name || !data[i].organizationUnit) {
            checkWarning = false;
            modelSaveds.push({
              success: false,
              errors: ['Thiếu trường bắt buộc'],
            });
            continue;
          }
          if (model) {
            if (model.email !== item.email) {
              const exists = await existsEmail(item.email);
              if (exists) {
                checkWarning = false;
                modelSaveds.push({
                  success: false,
                  errors: [`${item.email} đã tồn tại`],
                });
                continue;
              }
            }
          }
          // else if(){

          // }
          let foundRoleGroup;
          if (item.role) {
            foundRoleGroup = listRoleGroups.find((l) => l.code === item.role);
            if (!foundRoleGroup) {
              checkWarning = false;
              modelSaveds.push({
                success: false,
                errors: [`Không tìm thấy nhóm quyền với Mã nhóm quyền = ${item.role}`],
              });
            } else {
              item.role = { roleCode: foundRoleGroup.code, roleName: foundRoleGroup.name };
            }
          }
        }

        if (model) {
          if (modelName === 'hrm') {
            if (item.portal) {
              const newUser = {};
              newUser.username = item.email;
              newUser.code = item.code;
              newUser.email = item.email;
              newUser.name = item.name;
              newUser.password = '12345678';
              hrmService.requestCreate(newUser, item.organizationUnit, item.role.roleCode);
            }
          }

          Object.keys(item).forEach((key) => {
            model[key] = item[key];
          });
          modelSaveds.push({
            success: true,
            data: await model.save(),
          });
          continue;
        }

        if (Object.keys(Model().schema.paths).includes('code')) {
          // if (!item.code && modelName !== 'Task' && modelName !== 'Documentary') {
          //   checkWarning = false;
          //   modelSaveds.push({
          //     success: false,
          //     errors: ['Thiếu trường code là trường bắt buộc'],
          //   });
          //   continue;
          // }

          if (!item.code && modelName !== 'hrm') {
            checkWarning = false;
            modelSaveds.push({
              success: false,
              errors: ['Thiếu trường code là trường bắt buộc'],
            });
            continue;
          }

          let arr = 0;
          const arrEr = ['code', 'email', 'phoneNumber'];
          const modelFind = await Model.findOne({ code: item.code, status: { $ne: STATUS.DELETED } });
          let modelFindEmail = false;
          let modelFindPhone = false;
          if (modelName === 'Customer') {
            modelFindEmail = await Model.findOne({ email: item.email, status: { $ne: STATUS.DELETED } });
            //  console.log("FFF",modelFindEmail);

            if (modelFindEmail) arr = 1;

            modelFindPhone = await Model.findOne({ phoneNumber: item.phoneNumber, status: { $ne: STATUS.DELETED } });
            //  console.log("FFEEEF",modelFindPhone);
            if (modelFindPhone) arr = 2;
          }

          if (modelFind || modelFindEmail || modelFindPhone) {
            checkWarning = false;
            modelSaveds.push({
              success: false,
              errors: [`Đã tồn tại một bản ghi với ${arrEr[arr]} = ${item[arrEr[arr]]}`],
            });
            continue;
          }

          if (modelName === 'hrm' && item.portal) {
            const newUser = {};
            newUser.username = item.email;
            newUser.code = item.code;
            newUser.email = item.email;
            newUser.name = item.name;
            newUser.password = '12345678';
            hrmService.requestCreate(newUser, item.organizationUnit, item.role.roleCode);
          }

          
          console.log(44444,Model);
          const checkPresent = await Model.findOne({status: 1, code:item.code }) 
          if(!checkPresent){
            const saved = await new Model(item).save();
            modelSaveds.push({
              success: true,
              data: saved,
            });
          }
          
        }
        // else if (!checkNameExist) {
        //   modelSaveds.push({
        //     success: false,
        //     errors: [`${itemName} đã tồn tại`],
        //   });
        // continue;
        // }
        else if (!checkNameExist) {
          const saved = await new Model(item).save();
          modelSaveds.push({
            success: true,
            data: saved,
          });
        }
      } catch (error) {
        console.log('error', error.message);
        checkWarning = false;
        modelSaveds.push({
          success: false,
          errors: [error.message],
        });
      }
    }
    res.json({ success: checkWarning, data: modelSaveds });
  } else {
    // chỉ chỉnh sửa
    const modelUpdated = await Promise.all(
      data.map(async (item) => {
        const model = await Model.findOne({ [filterUpdate]: item[filterUpdate], status: { $ne: STATUS.DELETED } });
        const keys = Object.keys(item);
        for (let i = 0; i < keys.length; i++) {
          // console.log(modelName, keys[i], item[keys[i]]);
          if (listRequired.includes(keys[i])) {
            if (item[keys[i]] === '' || item[keys[i]] === 'undefined' || item[keys[i]] === null) {
              checkWarning = false;
              return {
                success: false,
                errors: [`${keys[i]} là trường bắt buộc`],
              };
            }
          }

          if (listEnum.find((e) => e.name === keys[i])) {
            const column = listEnum.find((e) => e.name === keys[i]);
            const value = column.menuItem.map((i) => i.code);
            if (column.menuItem && !column.menuItem.find((el) => el.code == item[keys[i]])) {
              checkWarning = false;
              return {
                success: false,
                errors: [`${column.title} giá trị không hợp lệ trong ${value}`],
              };
            }
          }

          if (listDate.includes(keys[i])) {
            const date = item[keys[i]].substring(1);
            if (!moment(`${date}`, 'DD/MM/YYYY').isValid()) {
              checkWarning = false;
              return {
                success: false,
                errors: [`${item[keys[i]]} không hợp lệ 2`],
              };
            }
          }

          const convertValue = await convertToObjectId(modelName, keys[i], item[keys[i]]);
          // if (convertValue) {
          //   item[keys[i]] = convertValue;
          // }
          if (convertValue && convertValue.status === false) {
            checkWarning = false;
            return {
              success: false,
              errors: [convertValue.message],
            };
          }
          item[keys[i]] = convertValue;
        }
        if (model) {
          // Object.keys(item).map(async (key) => {
          for (const key of Object.keys(item)) {
            model[key] = item[key];
            if (isSourceEle(item[key])) {
              const ModelRef = mongoose.models[Model.schema.paths[`${key}._id`].options.ref];
              const sourceCodeUpdate = Model.schema.paths[`${key}._id`].options.sourceCode;
              // console.log(sourceCodeUpdate);
              if (sourceCodeUpdate) {
                const findItem = await ModelRef.findOne({ code: sourceCodeUpdate })
                  .lean()
                  .exec();
                // console.log('findItem', findItem);
                if (findItem) {
                  const compareFind = findItem.data.find(
                    (element) => element.title.toLowerCase() === item[key].title.toLowerCase(),
                  );
                  model[key] = compareFind;
                  // console.log('compareFind', model[key]);
                  if (!compareFind) {
                    const createItemDataUpdate = await ModelRef.findOneAndUpdate(
                      { code: sourceCodeUpdate },
                      {
                        $push: {
                          data: {
                            title: item[key].title,
                            value: convertToSlug(item[key].title),
                          },
                        },
                      },
                      { new: true },
                    )
                      .lean()
                      .exec();
                    if (createItemDataUpdate) {
                      const itemCreated = createItemDataUpdate.data.find(
                        (element) =>
                          element.title === item[key].title && element.value === convertToSlug(item[key].title),
                      );
                      // console.log(itemCreated);
                      model[key] = itemCreated;
                      console.log((model[key] = itemCreated));
                    }
                  }
                  await model.save();
                  if (modelName === 'hrm' && item.portal) {
                    const newUser = {};
                    newUser.username = item.email;
                    newUser.code = item.code;
                    newUser.email = item.email;
                    newUser.name = item.name;
                    newUser.password = '12345678';
                    hrmService.requestCreate(newUser, item.organizationUnit);
                  }
                }
              }
            }
          }
          // });
          return {
            success: true,
            errors: '',
          };
        }
        // console.log('model', model);
        // if (model) {
        //   return {
        //     success: true,
        //     errors: model.save(),
        //   };
        // }

        checkWarning = false;
        return {
          success: false,
          errors: [`Không tìm thấy với 1 ${filterUpdate} = ${item[filterUpdate]}`],
        };
      }),
    );
    res.json({ success: checkWarning, data: modelUpdated });
  }
}
async function importInField(req, res, next) {
  try {
    const { identiferField, imports } = req.body;
    let data = req.body.data;
    const user = await Employee.findById(req.user.user);
    if (!user) return res.json(new APIError('Unauthorized', 401, true));
    if (!imports || !imports.model || !imports.importField || !data) {
      return res.json({
        status: 0,
        message: 'Vui lòng nhập đúng cấu trúc',
        body: {
          model: 'String',
          identiferField: 'String',
          importField: 'String',
          data: 'Array',
          importByCode: 'Array',
        },
      });
    }

    let importByCode = [];
    const findDataByCode = ({ modelRef, code, field }) => {
      try {
        return new Promise((resolve) =>
          setTimeout(async () => {
            const item = {
              field,
              value: null,
            };
            const model = mongoose.model(modelRef);
            if (model) {
              const doc = await model.findOne({ code });
              if (doc) item.value = doc._id;
            }
            resolve(item);
          }),
        );
      } catch (error) {
        console.log('findDataByCode:: ', error);
        throw error;
      }
    };

    if (imports.importByCode && imports.importByCode.length) {
      importByCode = imports.importByCode;
    }

    if (data && !data.length) {
      return res.json({
        status: 0,
        message: 'Vui lòng nhập vào dữ liệu',
        field: 'data',
      });
    }

    const Model = mongoose.models[imports.model];
    if (!Model) {
      return res.json({
        status: 0,
        message: 'Không tìm thấy model',
        error: 'model',
      });
    }
    data = data.map((item) => {
      if (Object.prototype.hasOwnProperty.call(item, 'gender')) {
        item.gender = parseGenderSafety(item.gender);
      }
      const newItem = {};
      Object.keys(item).forEach((key) => {
        if (isSourceEle(item[key]) && !item[key].title) return;
        newItem[key] = item[key];
      });
      return newItem;
    });

    const [responseData] = await Promise.all([
      axios.get(`${process.env.API_ROLE_GROUPS_01}/role-groups?clientId=${process.env.CLIENT_ID}`),
    ]);
    // console.log('responseData', responseData);
    let { data: listRoleGroups } = responseData.data;
    if (!listRoleGroups) {
      listRoleGroups = [];
    }
    // chỉ chỉnh sửa
    let count = 0;
    const arrayErr = [];
    await Promise.map(data, async (item, i) => {
      const keys = Object.keys(item);
      const index = keys.findIndex((f) => f === imports.codeImport);
      for (let k = 0; k < importByCode.length; k++) {
        const valueKey = await findDataByCode({
          modelRef: importByCode[k].modelRef,
          field: importByCode[k].field,
          code: item[importByCode[k].field],
        });
        if (valueKey) {
          item[valueKey.field] = valueKey.value;
        } else {
          arrayErr.push({
            errors: [`Không tìm thấy mã ${item[importByCode[k].field]} ở dòng ${i + 1}`],
            success: false,
            field: i,
          });
        }
      }
      if (index === -1) {
        arrayErr.push({
          errors: [`Vui lòng thêm trường ${imports.codeImport} ở bản ghi thứ ${i + 1}}`],
          success: false,
          field: i,
        });
      } else {
        const itemFind = imports.value ? imports.value : item[imports.codeImport];
        const modelData = await Model.findOne({ [imports.code]: itemFind });
        if (!modelData) {
          arrayErr.push({
            errors: [`Không tìm thấy mã ${item[imports.codeImport]} ở dòng ${i + 1}`],
            success: false,
            field: i,
          });
        }
        try {
          if (modelData) {
            const arrayKey = imports.importField.split('.');
            let value = modelData[arrayKey[0]];
            for (let j = 1; j < arrayKey.length; j++) {
              value = value[arrayKey[j]];
            }

            if (!value) {
              value = [];
            } else if (!Array.isArray(value)) {
              value = [value];
            }
            if (identiferField) {
              const indexV = value.findIndex((f) => f[identiferField] === item[identiferField]);
              if (indexV === -1) {
                value.push(item);
              } else {
                value[indexV] = item;
              }
            } else {
              value.push(item);
            }
            modelData[imports.importField] = value;
            const dataUp = await Model.findByIdAndUpdate(modelData._id, { $set: modelData }, { new: true });
            if (dataUp) {
              count++;
            }
          }
        } catch (error) {
          arrayErr.push({
            errors: [`Có lỗi với bản ghi import ở dòng ${i + 1}`],
            success: false,
            field: i,
            error: String(error),
          });
        }
      }
    });
    if (!arrayErr.length) {
      res.json({
        status: 1,
        success: true,
        data: arrayErr,
        count,
      });
    } else {
      res.json({
        success: false,
        status: 0,
        data: arrayErr,
        count,
      });
    }
  } catch (error) {
    next(error);
  }
}

function checkRequired(modelName) {
  const viewConfig = defaultColumn.find((item) => item.code === modelName);
  if (viewConfig) {
    const columns = viewConfig.listDisplay.type.fields.type.columns;
    const listRequired = columns.filter((item) => {
      if (item.isRequire && item.importTable) return item.name;
    });
    const list = listRequired.map((el) => el.name);
    return list;
  }
}

function checkEnum(modelName) {
  const viewConfig = defaultColumn.find((item) => item.code === modelName);
  if (viewConfig) {
    const columns = viewConfig.listDisplay.type.fields.type.columns;
    const listColumns = columns.filter((item) => {
      if (item.type === 'MenuItem' && item.importTable) return item;
    });
    // const list = listRequired.map((el) => el.name);
    return listColumns;
  }
}

function columnsDate(modelName) {
  const viewConfig = defaultColumn.find((item) => item.code === modelName);
  if (viewConfig) {
    const columns = viewConfig.listDisplay.type.fields.type.columns;
    const listColumns = columns.filter((item) => {
      if (item.type === 'Date' && item.importTable) return item;
    });
    const list = listColumns.map((el) => el.name);
    return list;
  }
}

function getNameFieldVN(modelName, key) {
  const viewConfig = defaultColumn.find((item) => item.code === modelName);
  if (viewConfig) {
    const columns = viewConfig.listDisplay.type.fields.type.columns;
    const listColumns = columns.filter((item) => item.name === key);
    let list = '';
    if (listColumns.length) list = listColumns[0].title;
    return list;
  }
}

function validateDate(date) {
  const regex = new RegExp(
    '([0-9]{4}[-](0[1-9]|1[0-2])[-]([0-2]{1}[0-9]{1}|3[0-1]{1})|([0-2]{1}[0-9]{1}|3[0-1]{1})[-](0[1-9]|1[0-2])[-][0-9]{4})',
  );
  const dateOk = regex.test(date);
  if (!dateOk) {
    return false;
  }
}

async function convertToObjectId(modelName, key, value) {
  try {
    // type[0] | type[1] | type [2] | type[3]
    // type[0]: - Source: Trường liên kết.
    //          - ObjectId: Trường danh mục.
    // type[1]: - Tên bảng (+ code sau dấu "," nếu là bảng cấu hình)
    // type[2]: - Kiểu dữ liệu cần lưu (Id, Array, Value, String).
    // type[3]: - instance field.
    // type[4]: - select field.

    const viewConfig = defaultColumn.find((item) => item.code === modelName);
    if (viewConfig) {
      const column = viewConfig.listDisplay.type.fields.type.columns;
      const prop = column.find((item) => item.name === key || item.propKey === key);   
      if (!prop) {
        if(key && typeof value === "object" ){
          Object.keys(value)

        }
        return value;
      }
      if (prop.noConvert) {
        return value;
      }
      const typeSplit = prop.type.split('|');
      const type = typeSplit.map((item, idx) => (typeSplit.length - 1 === idx ? item : item.replace(/ /g, '')));
      let modelRef = type[1];
      let model;
      let selector;
      let code;
      let instance;
      selector = type[4] ? type[4] : '_id';
      instance = type[3] ? type[3] : '';

      // trường liên kết
      if (type && type[0] !== 'ObjectId' && type[0] !== 'Source' && type[0] !== 'Date' && type[0] !== 'Datetime'){
        return value;
      }
      if (type && modelRef && type[0] === 'ObjectId') {
        model = global.hshCollections[modelRef] ? global.hshCollections[modelRef] : mongoose.models[modelRef];
        if (!model) return false;
        if (type[2] && type[2] !== '' && type[2] === 'Array') {
          const valSplit = value.replace(/ /g, '').split(',');
          const vals = [];
          if (valSplit && !valSplit.includes('')) {
            for (let i = 0; i < valSplit.length; i++) {
              const item = await model
                .findOne({ code: valSplit[i], status: { $ne: STATUS.DELETED } })
                .select(selector || '_id');
              if (!item) {
                return {
                  status: false,
                  message: `${valSplit} không hợp lệ `,
                };
              }

              if (instance && instance === 'Instance' && instance !== '') {
                const field = instanceField(type[1]);
                const newItem = {};
                newItem[field] = item._id;
                newItem.name = item.name;
                vals.push(newItem);
              } else {
                vals.push(item);
              }
            }
          }
          return vals;
        }
        if (value === '') return null;
        const item = await model
          .findOne({
            $or: [{ code: value, status: { $ne: STATUS.DELETED } }, { name: value, status: { $ne: STATUS.DELETED } }],
          })
          .select(selector || '_id');
        if (!item) {
          return {
            status: false,
            message: `${value} không hợp lệ`,
          };
        }
        if (instance && instance === 'Instance' && instance !== '') {
          const field = instanceField(type[1]);
          const newItem = {};
          newItem[field] = item._id;
          newItem.name = item.name;
          return newItem;
        }
        return item._id;
      }
      // Danh mục
      if (type && type[0] === 'Source' && modelRef) {
        const modelRefSplit = modelRef.split(',');
        modelRef = modelRefSplit[0];
        code = modelRefSplit[1];
        model = global.hshCollections[modelRef] ? global.hshCollections[modelRef] : mongoose.models[modelRef];

        if (code && code !== '') {
          const data = await model
            .findOne({ code, status: STATUS.ACTIVED })
            .lean()
            .exec();
          if (selector) {
            if (type[2] === 'Value') {
              const findItem = data.data.find((el) => {
                if (el[selector] === convertToSlug(value)) {
                  return el;
                }
                return null;
              });
              if (!findItem) {
                const newItem = {};
                newItem.title = value;
                newItem.value = convertToSlug(value);
                const createItem = await model.findOneAndUpdate({ code }, { $push: { data: newItem } }, { new: true });
                if (createItem) {
                  const newEl = createItem.data.find((item) => item.value === newItem.value);
                  if (newEl) return newEl;
                  return false;
                }
              }
              return findItem;
            }
            if (type[2] === 'Id') {
              const item = data.data.find((el) => el[selector].toString() === value.toString());
              if (!item) {
                return {
                  status: false,
                  message: `${value} không hợp lệ`,
                };
              }
              return item[selector];
            }
            if (type[2] === 'String') {
              const item = data.data.find((el) => el[selector].toString() === value.toString());
              if (!item) {
                return {
                  status: false,
                  message: `${value} không hợp lệ`,
                };
              }
              return item[selector];
            }
          }
        }
      }
      if ((type && type[0] === 'Date') || type[0] === 'Datetime') {
        console.log('date', modelName, key, value);
        if(modelName==="Customer"){
          value = moment(value.toString(), 'YYYY-MM-DD hh:mm:ss').format('YYYY/MM/DD');
          return value;
        }
        value = moment(value.toString(), 'DD/MM/YYYY').format('YYYY/MM/DD');
        return value;
      }
    }
  } catch (error) {
    console.log(error);
  }
}

function instanceField(modelName, fieldName) {
  // const Model = mongoose.models[modelName];
  // const schemaPaths = Object.keys(Model.schema.paths);
  // console.log(schemaPaths);
  // console.log(fieldName);
  // const instanceObjectIds = schemaPaths.filter((item) => Model.schema.paths[item].instance === 'ObjectID');
  // const field = instanceObjectIds.find((item) => item.includes(fieldName));
  // if (field) {
  //   const split = field.split('.');
  //   return split[1];
  // }
  if (modelName === 'Stock') {
    modelName = 'product';
  }
  const field = `${modelName.toLowerCase()}Id`;
  return field;
}

async function importUserFromClient(req, res, next) {
  const { modelName, filterUpdate, methodImport } = req.body;
  const data = req.body.data;
  const user = await Employee.findById(req.user.user);
  // eslint-disable-next-line new-cap
  // const user = await Employee.findById(mongoose.Types.ObjectId('61b95f646fb41f521d6d7d68'));
  if (!user) return res.json(new APIError('Unauthorized', 401, true));

  const [responseData, listOrganizations] = await Promise.all([
    axios.get(`${process.env.API_ROLE_GROUPS_01}/role-groups?clientId=${process.env.CLIENT_ID}`),
    OrganizationUnit.find({ status: STATUS.ACTIVED }).lean(),
  ]);
  // console.log('responseData', responseData);
  let { data: listRoleGroups } = responseData.data;
  if (!listRoleGroups) {
    listRoleGroups = [];
  }

  let checkWarning = true;
  const Model = mongoose.models[modelName];

  if (methodImport === 'add') {
    const modelSaveds = [];
    for (let i = 0; i < data.length; i += 1) {
      try {
        let foundRoleGroup;
        let listRoles = [];
        if (data[i].roleGroupSource) {
          foundRoleGroup = listRoleGroups.find((l) => l.code === data[i].roleGroupSource);
          if (!foundRoleGroup) {
            checkWarning = false;
            modelSaveds.push({
              success: false,
              errors: [`Không tìm thấy nhóm quyền với Mã nhóm quyền = ${data[i].roleGroupSource}`],
            });
            continue;
          }
        }
        if (!data[i].username || !data[i].email || !data[i].code || !data[i].name || !data[i].organizationUnit) {
          checkWarning = false;
          modelSaveds.push({
            success: false,
            errors: ['Thiếu trường bắt buộc'],
          });
          continue;
        }

        data[i].username = data[i].username.trim();
        if (data[i].username.length > 150) {
          checkWarning = false;
          modelSaveds.push({
            success: false,
            errors: ['Trường username không quá 150 ký tự'],
          });
          continue;
        }

        const item = data[i];
        item[FIELD.UID] = user._id;

        const org = listOrganizations.find((orgItem) => orgItem.code === item.organizationUnit.name);
        if (!org) {
          checkWarning = false;
          modelSaveds.push({
            success: false,
            errors: ['Phòng ban không tồn tại'],
          });
          continue;
        }
        const newOrg = {};
        newOrg.organizationUnitId = org._id;
        newOrg.name = org.name;
        newOrg.name_en = org.name_en;
        item.workingOrganization = org._id;
        item.organizationUnit = newOrg;
        item.createdBy = user._id;
        // if (foundRoleGroup) {
        //   if (foundRoleGroup.applyEmployeeOrgToModuleOrg) {
        //     const allowedDepartment = makeDeparts(listOrganizations, org._id);
        //     listRoles = makeRoles(foundRoleGroup.roles, allowedDepartment);
        //     item.allowedDepartment = allowedDepartment;
        //   } else if (foundRoleGroup.departments) {
        //     listRoles = makeRoles(foundRoleGroup.roles, foundRoleGroup.departments);
        //     item.allowedDepartment = foundRoleGroup.departments;
        //   }
        // }

        const model = await Model.findOne({
          code: item.code,
          username: item.username,
          // email: item.email,
          status: STATUS.ACTIVED,
        });
        if (model) {
          if (model.email !== item.email) {
            const exists = await existsEmail(item.email);
            if (exists) {
              checkWarning = false;
              modelSaveds.push({
                success: false,
                errors: [`${item.email} đã tồn tại`],
              });
              continue;
            }
          }
          if (model.roleGroupSource !== item.roleGroupSource) {
            item.firstLogin = true;
          }
          Object.keys(item).forEach((key) => {
            if (!item[key]) return;
            if (typeof item[key] === 'string' && item[key].trim().length === 0) return;
            model[key] = item[key];
          });
          await createOrUpdateHRM(item, 'update');
          // await Promise.all([createOrUpdateRoles(model._id, listRoles), updateRole(model.userId, foundRoleGroup)]);
          // await User.findOneAndUpdate({ username: model.username }, { email: model.email });
          modelSaveds.push({
            success: true,
            data: await model.save(),
          });
          continue;
        }

        if (Object.keys(Model().schema.paths).includes('code')) {
          if (!item.code) {
            checkWarning = false;
            modelSaveds.push({
              success: false,
              errors: ['Thiếu trường code là trường bắt buộc'],
            });
            continue;
          }

          let arr = 0;
          const arrEr = ['code', 'email', 'username'];
          // let modelFindCode = false;
          // let modelFindEmail = false;
          // let modelFindUsername = false;
          // let hrmCode = false;
          // let hrmEmail = false;
          // let hrmUsername = false;
          const [modelFindCode, modelFindEmail, modelFindUsername] = await Promise.all([
            Model.findOne({ code: item.code, status: { $ne: STATUS.DELETED } }),
            Model.findOne({ email: item.email, status: { $ne: STATUS.DELETED } }),
            Model.findOne({ username: item.username, status: { $ne: STATUS.DELETED } }),
          ]);
          // if (modelFindCode) arr = 0;
          // if (modelFindEmail) arr = 1;
          // if (modelFindUsername) arr = 2;
          // if (modelFindCode || modelFindEmail || modelFindUsername)
          const findCode = modelFindCode ? (arr = 0) : null;
          const findEmail = modelFindEmail ? (arr = 1) : null;
          const findUsername = modelFindUsername ? (arr = 2) : null;

          if (findCode || findEmail || findUsername) {
            checkWarning = false;
            modelSaveds.push({
              success: false,
              errors: [`Đã tồn tại một bản ghi với ${arrEr[arr]} = ${item[arrEr[arr]]}`],
            });
            continue;
          } else {
            const saved = await new Model(item).save();
            if (saved) {
              const authRes = await requestOauth({
                username: saved.username,
                password: '12345678',
                name: saved.name,
                code: saved.code,
                email: saved.email,
                groupCode: saved.roleGroupSource,
              });
              const dataUser = authRes.data || {};
              const userId = dataUser.user;
              saved.userId = userId;
              await saved.save();
              await createOrUpdateHRM(item);
            }
            // await createOrUpdateRoles(saved._id, listRoles);
            modelSaveds.push({
              success: true,
              data: saved,
            });
          }
        } else {
          const saved = await new Model(item).save();
          // await Promise.all([createOrUpdateRoles(saved._id, listRoles), updateRole(saved.userId, foundRoleGroup)]);
          modelSaveds.push({
            success: true,
            data: saved,
          });
        }
      } catch (error) {
        console.log('err', error);
        checkWarning = false;
        modelSaveds.push({
          success: false,
          errors: [error.message],
        });
      }
    }
    res.json({ success: checkWarning, data: modelSaveds });
  } else {
    const modelUpdated = await Promise.all(
      data.map(async (item) => {
        let listRoles;
        try {
          if (!item.username || !item.email || !item.code || !item.name || !item.organizationUnit) {
            checkWarning = false;
            return {
              success: false,
              errors: ['Thiếu trường bắt buộc'],
            };
          }
          let foundRoleGroup;
          if (item.roleGroupSource) {
            foundRoleGroup = listRoleGroups.find((l) => l.code === item.roleGroupSource);
            if (!foundRoleGroup) {
              checkWarning = false;
              return {
                success: false,
                errors: [`Không tìm thấy nhóm quyền với Mã nhóm quyền = ${item.roleGroupSource}`],
              };
            }
          }
          const org = listOrganizations.find((orgItem) => orgItem.code === item.organizationUnit);
          if (!org) {
            checkWarning = false;
            return {
              success: false,
              errors: ['Phòng ban không tồn tại'],
            };
          }
          const newOrg = {};
          newOrg.organizationUnitId = org._id;
          newOrg.name = org.name;
          newOrg.name_en = org.name_en;
          item.workingOrganization = org._id;
          item.organizationUnit = newOrg;
          item.createdBy = user._id;
          // if (foundRoleGroup) {
          // if (foundRoleGroup.applyEmployeeOrgToModuleOrg) {
          //   const allowedDepartment = makeDeparts(listOrganizations, org._id);
          //   listRoles = makeRoles(foundRoleGroup.roles, allowedDepartment);
          //   item.allowedDepartment = allowedDepartment;
          // } else if (foundRoleGroup.departments) {
          //   listRoles = makeRoles(foundRoleGroup.roles, foundRoleGroup.departments);
          //   item.allowedDepartment = foundRoleGroup.departments;
          // }
          // }

          // if (item[filterUpdate]) {
          const model = await Model.findOne({
            code: item.code,
            username: item.username,
            // email: item.email,
            status: STATUS.ACTIVED,
          });
          if (model) {
            if (model.email !== item.email) {
              const exists = await existsEmail(item.email, item.portalHrm);
              if (exists) {
                checkWarning = false;
                return {
                  success: false,
                  errors: [`${item.email} đã tồn tại`],
                };
              }
            }
            if (model.roleGroupSource !== item.roleGroupSource) {
              item.firstLogin = true;
            }
            Object.keys(item).forEach((key) => {
              if (!item[key]) return;
              if (typeof item[key] === 'string' && item[key].trim().length === 0) return;
              model[key] = item[key];
            });
          }
          if (model) {
            await createOrUpdateHRM(item, 'update');
            const updatedRecord = await model.save();
            if (updatedRecord) {
              await User.findOneAndUpdate({ username: updatedRecord.username }, { email: updatedRecord.email });
            }
            // await Promise.all([createOrUpdateRoles(model._id, listRoles), updateRole(model.userId, foundRoleGroup)]);
            return {
              success: true,
              errors: updatedRecord,
            };
          }
          // }
          checkWarning = false;
          return {
            success: false,
            errors: [`Không tìm thấy với ${filterUpdate} = ${item[filterUpdate]}`],
          };
        } catch (error) {
          checkWarning = false;
          return {
            success: false,
            errors: [error.message],
          };
        }
      }),
    );
    res.json({ success: checkWarning, data: modelUpdated });
  }
}

async function existsEmail(email) {
  try {
    const [employee, user] = await Promise.all([
      Employee.findOne({ email, status: STATUS.ACTIVED }),
      User.findOne({ email }),
    ]);

    if (employee || user) {
      return true;
    }
    return false;
  } catch (error) {
    console.log('error existsEmail', error);
  }
}

async function createOrUpdateHRM(data, method) {
  try {
    const newData = {};
    newData.portal = true;
    Object.keys(data).forEach((key) => {
      if (!data[key]) return;
      if (key === 'organizationUnit') return (newData[key] = data[key].organizationUnitId);
      if (key === 'gender') return (newData[key] = parseGenderSafety(data[key]));
      newData[key] = data[key];
    });
    if (method === 'update') {
      return await HrmEmployee.updateOne({ _id: data._id }, newData);
    }
    return await HrmEmployee.create(newData);
  } catch (error) {
    console.log('error createOrUpdate', error);
  }
}

async function requestOauth(element) {
  console.log('aaaa');
  const api01 = process.env.API_ROLE_GROUPS_01;
  // const url = `https://${process.env.OAUTH_HOST}:${process.env.OAUTH_PORT}/users/create-user`;
  // const url = `https://g.lifetek.vn:201/users/create-user`;
  const url = `${api01}/users/create-user`;
  return await axios.post(url, JSON.stringify(element), {
    headers: {
      'Content-Type': 'application/json',
    },
  });
}

function makeRoles(funcs, departs) {
  return funcs.map((f) => ({
    moduleCode: f.codeModleFunction,
    roles: [departs.roles[0], ...mergeRole([], f.codeModleFunction)],
  }));
}

function makeDeparts(listDepart, empOrg) {
  const allowedDepartment = {
    moduleCode: true,
    roles: [
      {
        code: 'DERPARTMENT',
        column: [
          {
            name: 'view',
            title: 'Xem',
          },
          {
            name: 'edit',
            title: 'Sửa',
          },
          {
            name: 'delete',
            title: 'Xóa',
          },
        ],
        data: listDepart.map((item) => ({
          data: item.path.includes(empOrg)
            ? { view: true, edit: true, delete: true }
            : { view: false, edit: false, delete: false },
          expand: false,
          id: item._id,
          name: item._id,
          open: true,
          slug: item.path,
        })),
        type: 0,
        name: 'Phòng ban',
        row: listDepart.map((l) => ({
          access: false,
          expand: false,
          id: l._id,
          level: l.level,
          name: l._id,
          open: false,
          parent: l.parent,
          slug: l.path,
          title: l.name,
        })),
      },
    ],
  };
  return allowedDepartment;
}

async function createOrUpdateRoles(empId, listRoles) {
  if (!empId || !listRoles || !listRoles.length) {
    return;
  }
  const insertRoles = listRoles.map((item) => ({ moduleCode: item.moduleCode, userId: empId, roles: item.roles }));
  await roleTask.remove({ userId: empId });
  roleTask.insertMany(insertRoles);
  // return await Promise.all(listRoles.map(async (item) => {
  //   const foundRole = await roleTask.findOne({ moduleCode: item.moduleCode, userId: empId });
  //   if (foundRole) {
  //     foundRole.roles = item.roles;
  //     return await foundRole.save();
  //   }
  //   return await roleTask.create({ moduleCode: item.moduleCode, userId: empId, roles: item.roles });
  // }));
}

async function updateRole(userId, foundGroup) {
  if (!foundGroup || !foundGroup._id || !userId) return;
  userId = userId.toString();
  const { roles: groupRoles, _id: groupId } = foundGroup;
  const roles = groupRoles.map((i) => ({ ...i, userId }));

  const url = `${process.env.API_ROLE_GROUPS_01}/roles/${userId}`;
  try {
    return await axios.put(`${url}`, JSON.stringify({ userId, roles, groupId }), {
      headers: {
        'Content-Type': 'application/json',
      },
    });
  } catch (error) {
    console.log('error', error);
    throw error;
  }
}

async function getSchemaByModelName(req, res, next) {
  const { modelName } = req.query;
  try {
    if (modelName) {
      res.json(mongoose.models[modelName].schema.paths);
    }
  } catch (error) {
    next(new APIError(`Not search schema by name ${modelName}`, httpStatus.BAD_REQUEST, true));
  }
}

module.exports = {
  importFormClient,
  getSchemaByModelName,
  importUserFromClient,
  roleUpdateItems,
  makeRoles,
  createOrUpdateRoles,
  updateRole,
  importInField,
};
