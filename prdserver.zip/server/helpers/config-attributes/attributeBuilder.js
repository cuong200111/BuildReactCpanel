const _ = require('lodash');

const ColorAttribute = require('./color.attribute');
const FontAttribute = require('./font.attribute');

class AttributeBuilder {
  static buildFrom(attributes) {
    let attribute = null;

    _.forEach(attributes, (value, key) => {
      switch (key) {
        case 'color':
          attribute = new ColorAttribute(attribute, value);
          break;
        case 'font':
          attribute = new FontAttribute(attribute, value);
          break;
        default:
          throw new Error('Unrecognized attributes');
      }
    });

    return attribute;
  }
}

module.exports = AttributeBuilder;
