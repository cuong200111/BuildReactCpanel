class Attributable {
  constructor(attributable) {
    if (!!attributable && !(attributable instanceof Attributable)) throw new Error('Not an attribute');
    this.wrapper = attributable;
  }

  /* eslint-disable */
  getValue() {
    return null;
  }

  getWrapper() {
    return this.wrapper;
  }

  toObject() {
    if (this.getWrapper) {
      return {
        ...this.getValue(),
        ...this.getWrapper().getValue(),
      };
    }

    return this.getValue();
  }

  toString() {
    return this.constructor.name;
  }
}
module.exports = Attributable;
