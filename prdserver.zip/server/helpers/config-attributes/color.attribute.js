const Attributable = require('./attribute.interface');

class ColorAttribute extends Attributable {
  constructor(attributable, color) {
    super(attributable);

    this.color = color;
  }

  getValue() {
    return {
      color: this.color,
    };
  }
}

module.exports = ColorAttribute;
