const Attributable = require('./attribute.interface');

class FontAttribute extends Attributable {
  constructor(attributable, font) {
    super(attributable);

    this.font = font;
  }

  getValue() {
    return {
      font: this.font,
    };
  }
}

module.exports = FontAttribute;
