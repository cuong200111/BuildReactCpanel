const ViewConfig = require('../api/viewConfig/viewConfig.model');

function getAndCacheViewConfig() {
  return new Promise((resolve, reject) => {
    ViewConfig.find({ owner: { $exists: false } })
    .then((docs) => {
      docs.forEach((doc) => {
        const code = doc.code;
        if (!Object.prototype.hasOwnProperty.call(global.hshViewConfig, code)) {
          global.hshViewConfig[code] = doc;
        }
      });
      resolve(docs);
    })
    .catch((err) => {
      reject(err);
    });
  });
}

module.exports = {
  getAndCacheViewConfig
};
