const mongoose = require('mongoose');
const Joi = require('joi');
Joi.objectId = require('joi-objectid')(Joi);

const CreatorSchema = new mongoose.Schema({
  creator: {
    type: mongoose.Schema.Types.ObjectId,
  },
  createDate: Date,
  modifier: {
    type: mongoose.Schema.Types.ObjectId,
  },
  modifyDate: Date
});

const creatorValidator = {
  creator: Joi.objectId(),
  createDate: Joi.date(),
  modifier: Joi.objectId(),
  modifyDate: Joi.date()
};

function initCreator(creator, createDate, modifier, modifyDate) {
  return {
    creator,
    createDate,
    modifier,
    modifyDate
  };
}


module.exports = { CreatorSchema, creatorValidator, initCreator };

