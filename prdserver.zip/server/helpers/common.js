/* eslint-disable array-callback-return */
/* eslint-disable consistent-return */
/* eslint-disable prefer-const */
/* eslint-disable no-param-reassign */
const _ = require('lodash');
const roleCtl = require('../api/roleTask/role.controller');
const FIELDS = require('../variables/FIELDS');
const Employee = require('../api/employee/employee.model');
const axios = require('axios');
const dot = require('dot-object');
const mergeRole = require('../api/roleTask/specialRole');
const OrganizationUnit = require('../api/organizationUnit/organizationUnit.model');
const STATUS = require('../variables/CONST_STATUS').STATUS;
const defaultColumn = require('../../defaultColumns');
const moment = require('moment');
const RoleGroup = require('../api/employee/roleGroup.model');
const roleModel = require('../api/roleTask/role.model');
const mongoose = require('mongoose');
/**
 * Create a new ExchangingAgreement
 *
 * @param {data} returrnData
 * @param {mainData} CurrentData
 *
 * @returns {data}
 */
function getTree(data, mainData, getParent) {
  data.forEach((item) => {
    const child = mainData.filter((element) => {
      // console.log(item._id == element.parent);
      if (element.parent) {
        if (item._id.toString() === element.parent.toString()) {
          return true;
        }
      }
      return false;
    });
    getTree(child, mainData);
    // eslint-disable-next-line no-param-reassign
    item.child = child;
  });
  // eslint-disable-next-line no-param-reassign
  if (getParent) {
    const dataId = data.map((m) => m._id);
    data = data.filter((item) => dataId.findIndex((i) => String(i) === String(item.parent)) === -1);
    data = data.map((item) => {
      if (item.parent) {
        item.parent = null;
      }
      return item;
    });
  } else {
    data = data.filter((item) => item.parent === null);
  }
  return data;
}

/**
 * get code unique
 *
 * @param {code} code
 * @param {Model} model
 *
 * @returns {newCode}
 */

async function getUniqueCode(code, Model, number = 0) {
  const model = number === 0 ? await Model.findOne({ code }) : await Model.findOne({ code: code + number });
  if (model) {
    // eslint-disable-next-line no-param-reassign
    number += 1;
    return getUniqueCode(code + number, Model, number);
  }
  return code;
}
function getDescendantProp(obj, desc) {
  const arr = desc.split('.');
  // eslint-disable-next-line no-cond-assign
  while (
    arr.length &&
    // eslint-disable-next-line no-param-reassign
    (obj = obj[arr.shift()])
  );
  return obj;
}

async function filterRole({ filter = null, user, filterModule = null, code }) {
  const roles = await roleCtl.getRole({ moduleCode: code, userId: user });
  const roleDerpartment = roles.roles.find((i) => i.code === 'DERPARTMENT').data.filter((item) => item.data.view);
  let listDerpartment = [];
  roleDerpartment.forEach((item) => {
    listDerpartment.push(item.id);
    const listPath = item.id.path ? item.id.path.split('/') : null;
    if (listPath) listDerpartment.concat(listPath);
  });
  const oid =
    code === 'Task' || code === 'inComingDocument' || code === 'outGoingDocument' || code === 'Documentary' || code === 'hrm'
      ? 'organizationUnit'
      : FIELDS.OID;
  // let oid;
  // oid = FIELDS.OID;
  // if (code === 'Task') oid = 'organizationUnit';

  if (['inComingDocument', 'outGoingDocument', 'Calendar', 'Documentary'].includes(code)) {
    listDerpartment = [];
    roleDerpartment.forEach((item) => {
      listDerpartment.push(item.name);
    });
  }
  // console.log('filterDerpartment', listDerpartment);
  const filterDerpartment = { [oid]: { $in: _.uniq(listDerpartment) } };
  const or = [{ [FIELDS.UID]: user }, { createdBy: user }, filterDerpartment];
  const roleA = roles.roles.find((i) => i.code === 'BUSSINES');
  if (roleA) {
    const role = roleA.data;
    switch (code) {
      case 'Customer':
        if (role.find((i) => i.name === 'managerEmployee' && i.data.view)) {
          or.push({ managerEmployee: user });
        }
        if (role.find((i) => i.name === 'viewableEmployees' && i.data.view)) {
          or.push({ viewableEmployees: { $in: [user] } });
        }
        break;
      case 'BusinessOpportunities':
        if (role.find((i) => i.name === 'responsibilityPerson' && i.data.view)) {
          or.push({ 'responsibilityPerson.employeeId': { $in: [user] } });
        }
        if (role.find((i) => i.name === 'supervisor' && i.data.view)) {
          or.push({ 'supervisor.employeeId': { $in: [user] } });
        }
        break;
      case 'ExchangingAgreement':
        if (role.find((i) => i.name === 'responsibilityPerson' && i.data.view)) {
          or.push({ 'responsibilityPerson.employeeId': { $in: [user] } });
        }
        if (role.find((i) => i.name === 'supervisor' && i.data.view)) {
          or.push({ 'supervisor.employeeId': { $in: [user] } });
        }
        break;
      case 'SalesQuotation':
        if (role.find((i) => i.name === 'commissionGroup' && i.data.view)) {
          or.push({ 'employeeId.employeeId': { $in: [user] } });
        }
        break;
      case 'Task':
        if (role.find((i) => i.name === 'taskManager' && i.data.view)) {
          or.push({ taskManager: { $in: [user] } });
        }
        if (role.find((i) => i.name === 'inCharge' && i.data.view)) {
          or.push({ inCharge: { $in: [user] } });
        }
        if (role.find((i) => i.name === 'join' && i.data.view)) {
          or.push({ join: { $in: [user] } });
        }
        if (role.find((i) => i.name === 'viewable' && i.data.view)) {
          or.push({ viewable: { $in: [user] } });
        }
        if (role.find((i) => i.name === 'support' && i.data.view)) {
          or.push({ support: { $in: [user] } });
        }
        break;
      case 'Calendar':
        // const userData = await Employee().findById(user);
        const userData = await global.hshCollections.Employee.findById(user);
        or.push({ 'createdBy.employeeId': userData._id });
        if (role.find((i) => i.name === 'people' && i.data.view && userData)) {
          // or.push({ people: { $in: [{ employeeId: userData._id, name: userData.name }] } });
          or.push({ 'people.employeeId': { $in: [userData._id] } });
        }

        if (role.find((i) => i.name === 'organizer' && i.data.view && userData)) {
          // or.push({ organizer: { employeeId: userData._id, name: userData.name } });
          or.push({ 'organizer.employeeId': userData._id });
        }
        if (role.find((i) => i.name === 'prepare' && i.data.view)) {
          or.push({ prepare: { $in: [user] } });
        }
        if (role.find((i) => i.name === 'approved' && i.data.view)) {
          or.push({ approved: user });
        }
        break;
      default:
        break;
    }
  }

  const and = [{ $or: or }];
  if (filterModule) and.push(filterModule);
  if (filter) and.push(filter);
  const toltalFilter = { $and: and };
  return toltalFilter;
}

function setDescendantProp(options, value, obj) {
  // eslint-disable-next-line no-param-reassign
  options.split('.').reduce((r, a, index) => {
    if (typeof r[a] === 'object') return r[a];
    if (options.split('.').length - 1 === index) {
      // eslint-disable-next-line no-param-reassign
      return (r[a] = value);
    }
    // eslint-disable-next-line no-param-reassign
    return (r[a] = {});
  }, obj);
  return obj;
}

function generalPopulate(model, id) {
  let stringPopulate = '';
  const schemaPaths = Object.keys(model.schema.paths);
  if (schemaPaths.length !== 0) {
    for (let j = 0; j < schemaPaths.length; j += 1) {
      const ele = schemaPaths[j];
      if (model.schema.paths[ele].instance === 'ObjectID') {
        if (model.schema.paths[ele].options.ref) {
          stringPopulate += `${model.schema.paths[ele].path} `;
        }
      }
    }
  }
  return model.findById(id).populate(stringPopulate);
}

async function filterRoleTask({ filter = null, createdBy, code }) {
  const roles = await roleCtl.getRole({ moduleCode: code, userId: createdBy });
  const roleDepartment = roles.roles.find((i) => i.code === 'DERPARTMENT').data.filter((elm) => elm.data.view);
  const roleDepartmentIds = roleDepartment.map((d) => d.name);
  let viewByOrgPermission;
  viewByOrgPermission = { organizationUnit: { $in: roleDepartmentIds } };
  if (code === 'Task') {
    const roleExtra = roles.roles.find((i) => i.code === 'EXTRA').data;
    const excludeExtra = [];
    roleExtra.forEach((item) => {
      if (item.name === 'protected' && !item.data.view) {
        excludeExtra.push(1);
      }
      if (item.name === 'hide' && !item.data.view) {
        excludeExtra.push(2);
      }
      if (item.name === 'open' && !item.data.view) {
        excludeExtra.push(3);
      }
      if (item.name === 'public' && !item.data.view) {
        excludeExtra.push(4);
      }
    });
    if (excludeExtra.length) {
      viewByOrgPermission = {
        organizationUnit: { $in: roleDepartmentIds },
        $or: [{ isProject: false }, { isProject: true, type: { $nin: excludeExtra } }],
      };
    }
  }
  if (code === 'Employee') {
    viewByOrgPermission = { 'organizationUnit.organizationUnitId': { $in: roleDepartmentIds } };
  }
  if (code === 'reportWeekTask' || code === 'reportTaskDebt') {
    viewByOrgPermission = { organizationUnit: { $in: roleDepartmentIds } };
  }
  const or = [{ createdBy }];
  let relativeCon = null;
  if (code === 'Task') {
    or.push({ taskManager: { $in: [createdBy] } });
    or.push({ inCharge: { $in: [createdBy] } });
    or.push({ join: { $in: [createdBy] } });
    or.push({ viewable: { $in: [createdBy] } });
    or.push({ support: { $in: [createdBy] } });
    relativeCon = {
      $and: [{ $or: or }, { organizationUnit: { $nin: roleDepartmentIds } }],
    };
  }

  const viewByRelativePermission = { $or: or };

  const viewFilter = [viewByOrgPermission, viewByRelativePermission];
  const and = [{ $or: viewFilter }];
  if (filter) {
    if (filter.$or && relativeCon) {
      filter.$or.push(relativeCon);
    }
    and.push(filter);
  }
  const toltalFilter = { $and: and };
  return toltalFilter;
}

function groupBy(objectArray, property) {
  return objectArray.reduce((acc, obj) => {
    const key = obj[property];
    if (!acc[key]) {
      acc[key] = [];
    }
    acc[key].push(obj);
    return acc;
  }, {});
}

function parseObjectIdArr(arr) {
  if (Array.isArray(arr) && arr.length) {
    return arr.filter((customerIdStr) => typeof customerIdStr === 'string' && customerIdStr.length === 24);
    // newFilter._id = { $in: filteredIds };
  }
  return null;
}

function isSourceEle(property) {
  return typeof property === 'object' && Object.keys(property).length === 1 && Object.keys(property).includes('title');
}

function getSourceEleTitle(propertyKey) {
  const arr = propertyKey.split('.');
  if (arr.length === 2 && arr[1] === '_id') return `${arr[0]}`;
  return '';
}

function convertToSlug(text) {
  return text
    .toLowerCase()
    .replace(/[^\w ]+/g, '')
    .replace(/ +/g, '-');
}
const MALE_VALUES = ['male', 'nam', '0', 'm'];
const FEMALE_VALUES = ['female', 'nữ', '1', 'f'];
function parseGenderSafety(value) {
  if (value === 0) return 0;
  if (value === 1) return 1;
  if (typeof value === 'string') {
    if (MALE_VALUES.includes(value.toLowerCase())) return 0;
    if (FEMALE_VALUES.includes(value.toLowerCase())) return 1;
  }
  return value;
}

function injectData2Template(moduleCode, dataSource, templateContent) {
  return templateContent;
}

function convertTemplate({ content, data, code, viewConfig, crmSource, extraFields }) {
  let newData = dot.object(data);
  newData = convertDot({ ob: data, newOb: data });
  const result = [];
  // let extra = [];
  // const extraField = extraFields.find(i => i.code === code);
  // if (extraField) extra = extraField.data;
  // const viewConfig = JSON.parse(localStorage.getItem('viewConfig'));
  function getName(codeName, refName) {
    const list = viewConfig.find((item) => item.code === codeName);
    if (list) {
      list.listDisplay.type.fields.type.columns.forEach((item) => {
        const newItem = { ...item, name: `${refName}.${item.name}` };
        result.push(newItem);
      });

      list.listDisplay.type.fields.type.others.forEach((item) => {
        const newItem = { ...item, name: `${refName}.${item.name}` };
        result.push(newItem);
      });
    }
  }

  const viewFind = viewConfig.find((item) => item.code === code).listDisplay.type.fields.type;
  const codes = [...viewFind.columns, ...viewFind.others];
  // const crmSource = _.keyBy(JSON.parse(localStorage.getItem('crmSource')), '_id');
  codes.forEach((item) => {
    if (item.type.includes('ObjectId')) {
      const ref = item.type.substring(9);
      getName(ref, item.name);
    } else if (item.type.includes('Relation')) {
      const ref = item.type.split("'")[3];
      getName(ref, item.name);
    } else if (item.type.includes('Array')) {
      // eslint-disable-next-line no-useless-escape
      const replaceArr = `<tr>(?:(?!<tr>|<\/tr>).)*?{${item.name}}(?:(?!<tr>|<\/tr>).)*?<\/tr>`;
      const regexArr = new RegExp(replaceArr, 'gs');
      const found = content.match(regexArr);
      if (found) {
        found.forEach((i) => {
          content = findReplaceArr({
            arrName: item.name,
            content,
            arrItems: item.type,
            data: newData[item.name],
            dataReplace: i,
          });
        });
      }
    } else if (item.type.length === 24) {
      if (crmSource[item.type]) {
        if (crmSource[item.type].data) {
          const foundItem = crmSource[item.type].data.find((i) => i.value === newData[item.name]);
          if (foundItem) {
            newData[item.name] = foundItem.title;
          }
        }
      }
    }
  });

  // async function replaceExtra() {
  //   for (const item of extra) {
  //     const replace = `{${item.name}}`;
  //     const regex = new RegExp(replace, 'gs');
  //     const rep = await item.function(newData);
  //     content = content.replace(regex, rep);
  //   }
  // }

  content = findCal({ content, data: newData });
  const newResult = result.concat(codes);
  newResult.forEach((item) => {
    const replace = `{${item.name}}`;
    const regex = new RegExp(replace, 'gs');
    const rep = newData[item.name] ? newData[item.name] : '';
    content = content.replace(regex, rep);
  });

  if (Array.isArray(extraFields)) {
    extraFields.forEach((item) => {
      const replace = `{${item}}`;
      const regex = new RegExp(replace, 'gs');
      const rep = newData[item] ? newData[item] : '';
      content = content.replace(regex, rep);
    });
  }
  // await replaceExtra();
  return content;
}

function findReplaceArr({ content, arrItems, data, arrName, dataReplace }) {
  if (!data) return content;
  // eslint-disable-next-line no-useless-escape
  let newReplace = '';
  const listItems = arrItems.split('|');
  if (!listItems[1]) return content;
  const items = listItems[1].split(',');
  if (items) {
    data.forEach((ele, index) => {
      let replace = dataReplace;
      replace = findCal({ content: replace, data: ele });
      replace = replace.replace(`{${arrName}}`, index + 1);
      items.forEach((e) => {
        const regex = `{${e}}`;
        replace = replace.replace(regex, ele[e]);
      });
      newReplace = `${newReplace}${replace}`;
    });
    return content.replace(dataReplace, newReplace);
  }

  return content;
}

function findCal({ content, data }) {
  const rex = /CAL\[(?!\]).*?\]/g;
  const found = content.match(rex);

  if (!found) return content;
  found.forEach((item) => {
    let newCt = item;
    Object.keys(data).forEach((pro) => {
      const reg = `{${pro}}`;
      const reg1 = new RegExp(reg, 'g');
      newCt = newCt.replace(reg1, data[pro]);
    });
    newCt = newCt.substring(4, newCt.length - 1);
    try {
      newCt = formula(newCt);
    } catch (error) {
      // console.log(error);
      newCt = '';
    }

    content = content.replace(item, newCt);
  });
  return content;
}

function convertDot({ ob, newOb = {}, prefix = false, convertArr = false }) {
  // eslint-disable-next-line no-restricted-syntax
  for (const property in ob) {
    if (isObject(ob[property])) {
      const newPrefix = prefix ? `${prefix}.${property}` : property;
      convertDot({ ob: ob[property], newOb, prefix: newPrefix, convertArr });
    } else if (isArray(ob[property]) && convertArr) {
      const newPrefix = prefix ? `${prefix}.${property}` : property;
      newOb[newPrefix] = ob[property]
        .map((it) => (it ? it.name : null))
        .filter(Boolean)
        .join();
    } else if (prefix) newOb[`${prefix}.${property}`] = ob[property];
    else newOb[property] = ob[property];
  }
  // eslint-disable-next-line no-console
  return newOb;
}

function isObject(value) {
  return value && typeof value === 'object' && value.constructor === Object;
}

function isArray(value) {
  return value && typeof value === 'object' && value.constructor === Array;
}

function removeVietnameseTones(str) {
  if (!str || typeof str !== 'string') return str;
  str = str.replace(/à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ/g, 'a');
  str = str.replace(/è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ/g, 'e');
  str = str.replace(/ì|í|ị|ỉ|ĩ/g, 'i');
  str = str.replace(/ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ/g, 'o');
  str = str.replace(/ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ/g, 'u');
  str = str.replace(/ỳ|ý|ỵ|ỷ|ỹ/g, 'y');
  str = str.replace(/đ/g, 'd');
  str = str.replace(/À|Á|Ạ|Ả|Ã|Â|Ầ|Ấ|Ậ|Ẩ|Ẫ|Ă|Ằ|Ắ|Ặ|Ẳ|Ẵ/g, 'A');
  str = str.replace(/È|É|Ẹ|Ẻ|Ẽ|Ê|Ề|Ế|Ệ|Ể|Ễ/g, 'E');
  str = str.replace(/Ì|Í|Ị|Ỉ|Ĩ/g, 'I');
  str = str.replace(/Ò|Ó|Ọ|Ỏ|Õ|Ô|Ồ|Ố|Ộ|Ổ|Ỗ|Ơ|Ờ|Ớ|Ợ|Ở|Ỡ/g, 'O');
  str = str.replace(/Ù|Ú|Ụ|Ủ|Ũ|Ư|Ừ|Ứ|Ự|Ử|Ữ/g, 'U');
  str = str.replace(/Ỳ|Ý|Ỵ|Ỷ|Ỹ/g, 'Y');
  str = str.replace(/Đ/g, 'D');
  // Some system encode vietnamese combining accent as individual utf-8 characters
  // Một vài bộ encode coi các dấu mũ, dấu chữ như một kí tự riêng biệt nên thêm hai dòng này
  str = str.replace(/\u0300|\u0301|\u0303|\u0309|\u0323/g, ''); // ̀ ́ ̃ ̉ ̣  huyền, sắc, ngã, hỏi, nặng
  str = str.replace(/\u02C6|\u0306|\u031B/g, ''); // ˆ ̆ ̛  Â, Ê, Ă, Ơ, Ư
  // Remove extra spaces
  // Bỏ các khoảng trắng liền nhau
  str = str.replace(/ + /g, ' ');
  str = str.trim();
  // Remove punctuations
  // Bỏ dấu câu, kí tự đặc biệt
  // str = str.replace(/!|@|%|\^|\*|\(|\)|\+|\=|\<|\>|\?|\/|,|\.|\:|\;|\'|\"|\&|\#|\[|\]|~|\$|_|`|-|{|}|\||\\/g, ' ');
  return str.toLowerCase();
}

// async function existRoleGroupCode(code, employee) {
//   try {
//     let foundRoleGroup;
//     let listRoles;
//     let allowedDepartment;
//     // const autoCheckView = foundRoleGroup.applyEmployeeOrgToModuleOrg;
//     const [responseData, listOrganizations] = await Promise.all([
//       axios.get(`${process.env.API_ROLE_GROUPS_01}/role-groups?clientId=${process.env.CLIENT_ID}`),
//       OrganizationUnit.find({ status: STATUS.ACTIVED }).lean(),
//     ]);
//     let { data: listRoleGroups } = responseData.data;
//     if (!listRoleGroups) {
//       listRoleGroups = [];
//     }
//     foundRoleGroup = listRoleGroups.find(l => l.code === code);
//     if (!foundRoleGroup) {
//       return false;
//     }
//     const autoCheckView = foundRoleGroup.applyEmployeeOrgToModuleOrg;
//     const org = listOrganizations.find(orgItem => orgItem._id.toString() === employee.organizationUnitId.toString());
//     if (!org) {
//       return false;
//     }

//     // if (autoCheckView || typeof autoCheckView === 'undefined') {
//     if (autoCheckView) {
//       allowedDepartment = makeDeparts(listOrganizations, org._id);
//       listRoles = makeRoles(foundRoleGroup.roles, allowedDepartment);
//     } else if (foundRoleGroup && foundRoleGroup.departments) {
//       listRoles = makeRoles(foundRoleGroup.roles, foundRoleGroup.departments);
//       allowedDepartment = foundRoleGroup.departments;
//     }
//     return { listRoles, allowedDepartment, foundRoleGroup };
//   } catch (error) {
//     console.log(error);
//   }
// }
async function existRoleGroupCode(code, employee) {
  try {
    let foundRoleGroup;
    let listRoles;
    let allowedDepartment;
    // const autoCheckView = foundRoleGroup.applyEmployeeOrgToModuleOrg;
    // const [responseData, listOrganizations] = await Promise.all([
    //   axios.get(`${process.env.API_ROLE_GROUPS_01}/role-groups?clientId=${process.env.CLIENT_ID}`),
    //   OrganizationUnit.find({ status: STATUS.ACTIVED }).lean(),
    // ]);
    // let { data: listRoleGroups } = responseData.data;
    // if (!listRoleGroups) {
    //   listRoleGroups = [];
    // }
    // foundRoleGroup = listRoleGroups.find((l) => l.code === code);
    // console.log('code:: ', code);
    // console.log('foundRoleGroup:: ', foundRoleGroup);
    foundRoleGroup = await RoleGroup.findOne({ code, clientId: process.env.CLIENT_ID }).lean();
    if (!foundRoleGroup) {
      return false;
    }
    const autoCheckView = foundRoleGroup.applyEmployeeOrgToModuleOrg;
    // const org = listOrganizations.find((orgItem) => orgItem._id.toString() === employee.organizationUnitId.toString());
    const listOrganizations = await OrganizationUnit.find({ status: STATUS.ACTIVED });
    const org = await OrganizationUnit.findOne({ status: STATUS.ACTIVED, _id: employee.organizationUnitId });
    // console.log('employee.organizationUnitId:: ', employee.organizationUnitId);
    // console.log('org:: ', org);
    if (!org) {
      return false;
    }
    const roleGroupRoles = await roleModel.find({ userId: foundRoleGroup._id }).lean();
    // console.log('autoCheckView:: ', autoCheckView);
    // if (autoCheckView || typeof autoCheckView === 'undefined') {
    if (autoCheckView) {
      allowedDepartment = makeDeparts(listOrganizations, org._id);
      listRoles = makeRoles(foundRoleGroup.roles, allowedDepartment, roleGroupRoles);
    } else if (foundRoleGroup && foundRoleGroup.departments) {
      listRoles = makeRoles(foundRoleGroup.roles, foundRoleGroup.departments, roleGroupRoles);
      allowedDepartment = foundRoleGroup.departments;
    }
    return { listRoles, allowedDepartment, foundRoleGroup };
  } catch (error) {
    console.log(error);
  }
}
function makeDeparts(listDepart, empOrg) {
  const allowedDepartment = {
    moduleCode: true,
    roles: [
      {
        code: 'DERPARTMENT',
        column: [
          {
            name: 'view',
            title: 'Xem',
          },
          {
            name: 'edit',
            title: 'Sửa',
          },
          {
            name: 'delete',
            title: 'Xóa',
          },
        ],
        data: listDepart.map((item) => ({
          data: item.path.includes(empOrg)
            ? { view: true, edit: true, delete: true }
            : { view: false, edit: false, delete: false },
          expand: false,
          id: item._id,
          name: item._id,
          open: true,
          slug: item.path,
        })),
        type: 0,
        name: 'Phòng ban',
        row: listDepart.map((l) => ({
          access: false,
          expand: false,
          id: l._id,
          level: l.level,
          name: l._id,
          open: false,
          parent: l.parent,
          slug: l.path,
          title: l.name,
        })),
      },
    ],
  };
  return allowedDepartment;
}

function makeRoles(funcs, departs, roleGroupRoles) {
  return funcs.map((f) => {
    let arr = [];
    // console.log('roleGroupRoles:: ', roleGroupRoles);
    const foundR = roleGroupRoles.find((r) => r.moduleCode === f.codeModleFunction);
    if (foundR) {
      arr = foundR.roles.filter((r) => r.code !== 'DERPARTMENT');
    }
    return {
      moduleCode: f.codeModleFunction,
      roles: [...mergeRole([departs.roles[0], ...arr], f.codeModleFunction)],
    };
  });
}

function resolve(path, obj) {
  return path.split('.').reduce((prev, curr) => (prev ? prev[curr] : null), obj);
}

async function buildNameMapping(moduleCode, data) {
  const result = {};
  const moduleColumn = defaultColumn.find((i) => i.code === moduleCode);
  const columns = moduleColumn.listDisplay.type.fields.type.columns;
  const names = columns.map((c) => c.name);
  const columnsSource = columns.filter((e) => !e.noMapping && (e.configCode || e.type === 'MenuItem'));
  const restColumns = columns.filter((e) => e.noMapping || (!e.configCode && e.type !== 'MenuItem'));
  const restObj = _.keyBy(restColumns, 'name');
  const columnsSourceObj = _.keyBy(columnsSource, 'name');
  await Promise.all(
    columnsSource.map(async (item) => {
      const obj = {};
      if (item.type === 'MenuItem') {
        item.menuItem.map((el) => {
          obj[`${el.type}`] = el.name;
        });
        result[item.name] = obj;
      }
      if (item.type.split('|').includes('Source')) {
        const inf = item.type.split('|');
        const model = inf[1].split(',')[0];
        const code = inf[1].split(',')[1];
        const Model = mongoose.models[model];
        const source = await Model.findOne({ code, status: STATUS.ACTIVED });
        if (source) {
          source.data.map((el) => {
            obj[`${el[inf[inf.length - 1]]}`] = el.name || el.title;
          });
        }
      }
      if (!result[item.name]) {
        result[item.name] = obj;
      } else {
        result[item.name] = { ...result[item.name], ...obj };
      }
    }),
  );
  let c;
  const newData = data.map((item) => {
    const newItem = {};
    names.forEach((key) => {
      const k = resolve(key, item);
      if (typeof result[key] !== 'undefined') {
        c = columnsSourceObj[key];
        if (typeof c.fn === 'function') {
          newItem[key] = c.fn(k, item, result[key]);
          return;
        }
        if (k && k.title) {
          newItem[key] = k.title;
          return;
        }
        newItem[key] = result[key][`${k}`];
      } else if (restObj[key]) {
        c = restObj[key];
        if (typeof c.fn === 'function') {
          newItem[key] = c.fn(k, item);
          return;
        }
        if (c.noMapping) {
          newItem[key] = k;
          return;
        }
        if (c.type === 'Date') {
          if (!k) {
            newItem[key] = ' ';
            return;
          }
          newItem[key] = moment(k).format('DD/MM/YYYY');
          return;
        }
        if (c.type === 'Datetime') {
          newItem[key] = moment(k).format('DD/MM/YYYY hh:mm');
          return;
        }
        if (c.type && c.type.split('|')[0] === 'ObjectId') {
          if (!k) {
            newItem[key] = '';
            return;
          }
          if (Array.isArray(k)) {
            newItem[key] = k.map((i) => i.name).join(', ');
            return;
          }
          newItem[key] = k.name;
          return;
        }
        if (c.type && c.type.split('|')[0] === 'Hard Array') {

          if (!k) {
            newItem[key] = '';
            return;
          }
          if (Array.isArray(k)) {
            let a = '';
            newItem[key] = k.map((i) => {
              for (var x in i) {
                a += `${x}: ${i[x]} `
              }
              return a;
            }).join(', ');
            return;
          }
          newItem[key] = k.name;
          return;
        }

        newItem[key] = k;
        return;
      } else {
        newItem[key] = k;
      }
    });
    if (item.others) {
      for (const key in item.others) {
        newItem[`others.${key}`] = item.others[key];
      }
    }
    return newItem;
  });
  return newData;
}

function convertNumber(str) {
  if (typeof str === 'string') {
    const split = str.split(',').join('');
    return split * 1;
  }
  return str;
}

function removeVietnameseAndReplace(str) {
  if (!str || typeof str !== 'string') return str;
  str = str.replace(/à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ/g, '');
  str = str.replace(/è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ/g, '');
  str = str.replace(/ì|í|ị|ỉ|ĩ/g, '');
  str = str.replace(/ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ/g, '');
  str = str.replace(/ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ/g, '');
  str = str.replace(/ỳ|ý|ỵ|ỷ|ỹ/g, '');
  str = str.replace(/đ/g, '');
  str = str.replace(/À|Á|Ạ|Ả|Ã|Â|Ầ|Ấ|Ậ|Ẩ|Ẫ|Ă|Ằ|Ắ|Ặ|Ẳ|Ẵ/g, '');
  str = str.replace(/È|É|Ẹ|Ẻ|Ẽ|Ê|Ề|Ế|Ệ|Ể|Ễ/g, '');
  str = str.replace(/Ì|Í|Ị|Ỉ|Ĩ/g, '');
  str = str.replace(/Ò|Ó|Ọ|Ỏ|Õ|Ô|Ồ|Ố|Ộ|Ổ|Ỗ|Ơ|Ờ|Ớ|Ợ|Ở|Ỡ/g, '');
  str = str.replace(/Ù|Ú|Ụ|Ủ|Ũ|Ư|Ừ|Ứ|Ự|Ử|Ữ/g, '');
  str = str.replace(/Ỳ|Ý|Ỵ|Ỷ|Ỹ/g, '');
  str = str.replace(/Đ/g, '');
  // Some system encode vietnamese combining accent as individual utf-8 characters
  // Một vài bộ encode coi các dấu mũ, dấu chữ như một kí tự riêng biệt nên thêm hai dòng này
  str = str.replace(/\u0300|\u0301|\u0303|\u0309|\u0323/g, ''); // ̀ ́ ̃ ̉ ̣  huyền, sắc, ngã, hỏi, nặng
  str = str.replace(/\u02C6|\u0306|\u031B/g, ''); // ˆ ̆ ̛  Â, Ê, Ă, Ơ, Ư
  // Remove extra spaces
  // Bỏ các khoảng trắng liền nhau
  str = str.replace(/ + /g, ' ');
  str = str.trim();
  // Remove punctuations
  // Bỏ dấu câu, kí tự đặc biệt
  // str = str.replace(/!|@|%|\^|\*|\(|\)|\+|\=|\<|\>|\?|\/|,|\.|\:|\;|\'|\"|\&|\#|\[|\]|~|\$|_|`|-|{|}|\||\\/g, ' ');
  str = str.replace(/\s+/g, '-');
  return str.toLowerCase();
}

module.exports = {
  convertTemplate,
  getTree,
  getDescendantProp,
  setDescendantProp,
  generalPopulate,
  getUniqueCode,
  filterRole,
  filterRoleTask,
  groupBy,
  parseObjectIdArr,
  parseGenderSafety,
  isSourceEle,
  getSourceEleTitle,
  convertToSlug,
  injectData2Template,
  removeVietnameseTones,
  existRoleGroupCode,
  buildNameMapping,
  convertNumber,
  removeVietnameseAndReplace,
};
