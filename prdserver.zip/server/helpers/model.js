/* eslint-disable no-param-reassign */
// eslint-disable-next-line no-unused-vars
const mongoose = require('mongoose');
const deepcopy = require('deepcopy');
const { MAPPING_TYPES, ALL_PROPERTIES_OF_RULE } = require('../variables/CONST_STATUS');

function parseRawModel(rawModel) {
  const schema = {};
  const titles = {};
  const validators = {};

  parseObject(rawModel, schema, titles, validators, [], 0);

  // combine title and validator to ViewConfig
  const viewconfig = {};

  Object.keys(titles).forEach((k) => {
    viewconfig[k] = {
      title: titles[k],
      type: validators[k],
      required: !!(schema[k] && schema[k].required),
      min: schema[k] && typeof schema[k].min !== 'undefined' ? schema[k].min : null,
      max: schema[k] && typeof schema[k].max !== 'undefined' ? schema[k].max : null,
      minLength: schema[k] && typeof schema[k].minLength !== 'undefined' ? schema[k].minLength : null,
      maxLength: schema[k] && typeof schema[k].maxLength !== 'undefined' ? schema[k].maxLength : null,
    };
    ALL_PROPERTIES_OF_RULE.forEach((prop) => {
      if (prop === 'required') return;
      viewconfig[k][prop] = schema[k] && typeof schema[k][prop] !== 'undefined' ? schema[k][prop] : null;
    });
  });

  return {
    schema,
    viewconfig,
  };
}

function parseObject(obj, schema, titles, validators, keys, index) {
  Object.keys(obj).forEach((k) => {
    let keyTitle = '';
    let keySchema = '';

    if (index === 0) {
      keyTitle = k;
      keySchema = k;
    } else {
      keyTitle = `${keys.join('.')}.${k}`;
      keySchema = keys[0];
    }

    // if (keyTitle === 'others' || keyTitle === 'atattributeSet') {
    //   return;
    // }

    const typeOfKey = typeof obj[k];

    if (typeOfKey === 'string') {
      // schema[k] = getMappingType(obj[k]);
      // titles[k] = k;
      // validators[k] = obj[k];

      assignValueIfNotExist(schema, keySchema, getMappingType(obj[k]));
      assignValueIfNotExist(titles, keyTitle, k);
      assignValueIfNotExist(validators, keyTitle, obj[k]);
    } else if (typeOfKey === 'function') {
      // schema[k] = getMappingType(obj[k].name);
      // titles[k] = k;
      // validators[k] = obj[k].name;
      let validatorType = getMappingType(obj[k].name);
      if (validatorType === 'ObjectId') {
        if (obj.ref) {
          validatorType += `|${obj.ref}`;
        }
      }
      assignValueIfNotExist(schema, keySchema, obj[k].name);
      assignValueIfNotExist(titles, keyTitle, k);
      assignValueIfNotExist(validators, keyTitle, validatorType);
    } else if (typeOfKey === 'object') {
      if (Object.prototype.hasOwnProperty.call(obj[k], 'type')) {
        const typeOfType = typeof obj[k].type;
        if (typeOfType === 'string') {
          // schema[k] = getMappingType(obj[k]);
          // titles[k] = k;
          // validators[k] = obj[k].type;

          // assignValueIfNotExist(schema, keySchema, getMappingType(obj[k].type));
          if (!Object.prototype.hasOwnProperty.call(schema, keySchema)) {
            const newSchema = updateObjectSchema(obj[k]);
            assignValueIfNotExist(schema, keySchema, newSchema);
          }
          assignValueIfNotExist(titles, keyTitle, k);
          assignValueIfNotExist(validators, keyTitle, obj[k].type);
        } else if (typeOfType === 'function') {
          // schema[k] = getMappingType(obj[k].name);
          // titles[k] = k;
          // validators[k] = obj[k].type.name;

          // assignValueIfNotExist(schema, keySchema, getMappingType(obj[k].type.name));

          let validatorType = getMappingType(obj[k].type.name);
          if (validatorType === 'ObjectId') {
            if (obj[k].ref) {
              validatorType += `|${obj[k].ref}`;
            }
          }

          if (!Object.prototype.hasOwnProperty.call(schema, keySchema)) {
            const newSchema = updateObjectSchema(obj[k]);
            assignValueIfNotExist(schema, keySchema, newSchema);
          }
          assignValueIfNotExist(titles, keyTitle, k);
          assignValueIfNotExist(validators, keyTitle, validatorType);
        }
      } else {
        // schema[k] = getMappingType(obj[k]);
        if (!Object.prototype.hasOwnProperty.call(schema, keySchema)) {
          const newSchema = updateObjectSchema(obj[k]);
          assignValueIfNotExist(schema, keySchema, newSchema);
        }

        if (Object.keys(obj[k]).length === 0) {
          // Current value is {}
          assignValueIfNotExist(titles, keyTitle, k);
          assignValueIfNotExist(validators, keyTitle, 'Object');
        } else if (Array.isArray(obj[k])) {
          // titles[k] = k;
          // validators[k] = 'Hard Array';
          let arrayTitle = 'Hard Array';
          if (typeof obj[k] === 'object' && !Object.prototype.hasOwnProperty.call(obj[k][0], 'type') && Object.keys(obj[k][0]).length > 0) {
            arrayTitle += `|${Object.keys(obj[k][0]).join(',')}`;
          }

          assignValueIfNotExist(titles, keyTitle, k);
          assignValueIfNotExist(validators, keyTitle, arrayTitle);
        } else {
          const thisKeys = deepcopy(keys);
          thisKeys.push(k);
          const thisIndex = index + 1;
          parseObject(obj[k], schema, titles, validators, thisKeys, thisIndex);
        }
      }
    }
  });
}

function assignValueIfNotExist(hash, key, value) {
  if (!Object.prototype.hasOwnProperty.call(hash, key)) {
    hash[key] = value;
  }
}

function updateObjectSchema(obj) {
  let updatedObj = deepcopy(obj);

  if (typeof updatedObj !== 'object') {
    const typeOfObj = typeof updatedObj;
    if (typeOfObj === 'function') {
      updatedObj = getMappingType(updatedObj.name);
    } else if (typeOfObj === 'string') {
      updatedObj = getMappingType(updatedObj);
    }
  } else if (Object.prototype.hasOwnProperty.call(updatedObj, 'type')) {
    const typeOfObj = typeof updatedObj.type;
    if (typeOfObj === 'function') {
      updatedObj.type = getMappingType(updatedObj.type.name);
    } else if (typeOfObj === 'string') {
      updatedObj.type = getMappingType(updatedObj.type);
    }
  } else {
    Object.keys(updatedObj).forEach((k) => {
      updatedObj[k] = updateObjectSchema(updatedObj[k]);
    });
  }

  // console.log(updatedObj);
  return updatedObj;
}

function getMappingType(rawType) {
  if (typeof rawType === 'object') {
    return rawType;
  }

  let ret = 'String';
  if (Object.prototype.hasOwnProperty.call(MAPPING_TYPES, rawType)) {
    ret = MAPPING_TYPES[rawType];
  }
  return ret;
}

module.exports = {
  parseRawModel,
};
