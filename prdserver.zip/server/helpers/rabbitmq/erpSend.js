const logger = require('winston');

const RABBIT_CHANNEL = require('../../variables/CONST_STATUS').RABBIT_CHANNEL;
const amqp = require('amqplib');

// eslint-disable-next-line no-unused-vars
async function initErpRabbit() {
  const connectionInfo = process.env.AMQP_CONNECT_SUB;
  const connection = amqp.connect(connectionInfo);
  connection
    .then((conn) => {
      console.log('connect success');
      return conn.createChannel();
    })
    .tap((channel) => channel.prefetch(1))
    .tap((channel) => channel.assertExchange(RABBIT_CHANNEL.erpSend_EXCHANGE, 'direct', { durable: true }))
    .then((channel) => {
      const queue = channel.assertQueue(RABBIT_CHANNEL.erpSend_EXCHANGE);
      return [channel, queue];
    })
    .spread((channel, q) => {
      // const queues = _.map(_.values({ action: 'notification' }), qName => qName);
      // _.forEach(queues, (key) => {
      // });
      channel.bindQueue(q.queue, RABBIT_CHANNEL.erpSend_EXCHANGE, RABBIT_CHANNEL.ERP_SEND);
      channel.consume(
        q.queue,
        async (msg) => {
          console.log(':< msg', msg);
          if (msg.fields.routingKey === 'erpsend') {
            try {
              channel.ack(msg);
              const data = JSON.parse(msg.content.toString());
              console.log('=============== erpsend message =================', data);
              // const result = await mawService.manipulation(data);
              // if (result) {
              //   console.log('done');
              // }
            } catch (error) {
              logger.error(`[SYNC] ${error}`);
            }
          }
        },
        { noAck: false },
      );
      return channel;
    });
}

module.exports = {
  initErpRabbit,
};
