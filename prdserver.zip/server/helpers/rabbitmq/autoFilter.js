/* eslint-disable consistent-return */
const config = require('config');
const logger = require('winston');

const connection = require('./connection').publisher;
const autoFilter = require('../../worker/autoFilter');
const RABBIT_CHANNEL = require('../../variables/CONST_STATUS').RABBIT_CHANNEL;

const schedule = require('node-schedule');

// const LogLevel = RABBIT_CHANNEL.LOG;
const _ = require('lodash');

// eslint-disable-next-line no-unused-vars
let chan = null;
function initAutoFilterRabbit() {
  chan = connection
    .then((conn) => conn.createChannel())
    .tap((channel) => channel.prefetch(config.get('amqp.prefetch')))
    // eslint-disable-next-line max-len
    .tap((channel) => channel.assertExchange(RABBIT_CHANNEL.AUTO_FILTER_EXCHANGE, 'direct', { durable: false }))
    .then((channel) => {
      // console.log('channel:: ', channel);
      const queue = channel.assertQueue('', { exclusive: true });
      return [channel, queue];
    })
    .spread((channel, q) => {
      const queues = _.map(_.values(RABBIT_CHANNEL.AUTO_FILTER), (qName) => qName);
      _.forEach(queues, (key) => {
        channel.bindQueue(q.queue, RABBIT_CHANNEL.AUTO_FILTER_EXCHANGE, `${config.get('oauth.clientId')}.${key}`);
      });
      channel.consume(
        q.queue,
        (msg) => {
          const dataQueue = JSON.parse(msg.content.toString());
          try {
            // console.log('dataQueue:: ', dataQueue);
            autoFilter(dataQueue)
              .then(() => {
                channel.ack(msg);
              })
              .catch((err) => {
                logger.error(`[WORKER] ${err}`);
                channel.ack(msg);
              });
          } catch (error) {
            logger.error(`[WORKER] ${error}`);
            channel.ack(msg);
          }
        },
        { noAck: false },
      );
      return channel;
    });
}

// const time = process.env.TIME ? process.env.TIME : '0 */2 * * * *';

// const refresh = schedule.scheduleJob(time, async () => {
//   try {
//     // console.log('aaa');
//     await initAutoFilterRabbit();
//   } catch (err) {
//     logger.error(err);
//   }
// });

module.exports = {
  // setApproval,
  initAutoFilterRabbit,
  // refresh,
};
