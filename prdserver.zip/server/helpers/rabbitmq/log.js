const connection = require('./connection').publisher;
const config = require('config');

const RABBIT_CHANNEL = require('../../variables/CONST_STATUS').RABBIT_CHANNEL;

const LogLevel = RABBIT_CHANNEL.LOG;
const _ = require('lodash');

let chan = null;
function initLogRabbit() {
  chan = connection
    .then(conn => conn.createChannel())
    .tap(channel => channel.prefetch(config.get('amqp.prefetch')))
    // eslint-disable-next-line max-len
    .tap(channel => channel.assertExchange(RABBIT_CHANNEL.LOG_EXCHANGE, 'direct', config.get('amqp.exchange.config')))
    .then((channel) => {
      // eslint-disable-next-line max-len
      const queues = _.map(_.values(LogLevel), qName => channel.assertQueue(qName, config.get('amqp.queue.config')));
      return [channel, Promise.all(queues)];
    })
    .spread((channel, queues) => {
      // console.log(queues);
      _.forEach(queues, q => channel.bindQueue(q.queue, RABBIT_CHANNEL.LOG_EXCHANGE, q.queue));

      return channel;
    });
}
// console.log('tét chan chacn chan');

function log(rawMessage, to = null, key = LogLevel.INFO) {
  const message = {
    type: 'resource',
    from: config.get('oauth.clientId'),
    to: to || config.get('oauth.clientId'),
    msg: rawMessage,
    timestamp: Date.now(),
  };
  chan.then(c => c.publish(RABBIT_CHANNEL.LOG_EXCHANGE, key, Buffer.from(JSON.stringify(message))));
}

function notify(rawMessage, key = RABBIT_CHANNEL.NOTIFY) {
  const message = {
    type: 'resource',
    from: config.get('oauth.clientId'),
    msg: rawMessage,
    timestamp: Date.now(),
  };

  chan.then(c => c.publish(RABBIT_CHANNEL.NOTIFY_EXCHANGE, key, Buffer.from(JSON.stringify(message))));
}

async function filter(rawMessage, data, key = RABBIT_CHANNEL.NOTIFY) {
  const message = {
    type: 'resource',
    from: config.get('oauth.clientId'),
    msg: rawMessage,
    automationRuleId: data.automationRuleId,
    actions: data.actions,
    path: data.path || '',
    timestamp: Date.now(),
    to: [],
  };

  message.to = [...new Set(message.to)];
  // console.log('mess: ', message.to);
  // return chan.then((c) => c.publish(RABBIT_CHANNEL.NOTIFY_EXCHANGE, key, Buffer.from(JSON.stringify(message))));
  return chan.then((c) => c.publish(config.get('amqp.auto'), `${config.get('amqp.clientAuto')}.${config.get('amqp.auto')}`, Buffer.from(JSON.stringify(message))));
}

async function featchMinhAnh(data){
  try {
    return chan.then(c => c.publish(RABBIT_CHANNEL.erpSend_EXCHANGE, RABBIT_CHANNEL.ERP_SEND, Buffer.from(JSON.stringify(data))));
  } catch (error) {
    console.log('ERROR: ', error);
    return false;
  }
}
module.exports = {
  log,
  notify,
  initLogRabbit,
  filter,
  featchMinhAnh
};
