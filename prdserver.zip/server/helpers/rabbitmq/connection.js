const amqp = require('amqplib');
const config = require('config');
const _ = require('lodash');

const logger = {
  info(msg) { console.log(msg); }, // eslint-disable-line
  debug(msg) { console.log(msg.msg); }, // eslint-disable-line
  error(msg) { console.log(msg); }}; // eslint-disable-line

const resolveAmqpOptions = (server = null) => config.get(`amqp.connections.${server || 'default'}`);

const auth = config.get('amqp.connections.auth.enabled')
  ? {
    username: config.get('amqp.connections.auth.username'),
    password: config.get('amqp.connections.auth.password'),
  } : null;

const options = {
  protocol: 'amqp',
  hostname: config.get('amqp.connections.default.host'),
  port: 5672,
  locale: 'en_US',
  frameMax: 0,
  heartbeat: 0,
  ...auth,
};

// console.log(options, resolveAmqpOptions());
const onCreate = (conn) => {
  logger.info('Connection rebbitmq  success');
  logger.debug({
    msg: 'Connection created',
    data: conn,
  });
  return conn;
};

const onFail = (err) => {
  logger.error(err);
};

const publisher = amqp
  .connect(_.assign(options, resolveAmqpOptions()))
  .then(conn => onCreate(conn))
  .catch(err => onFail(err));

module.exports = {
  publisher,
};
