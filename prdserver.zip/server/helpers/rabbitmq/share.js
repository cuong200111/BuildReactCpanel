
const config = require('config');
const logger = require('winston');

const connection = require('./connection').publisher;
const worker = require('../../worker/index');
const RABBIT_CHANNEL = require('../../variables/CONST_STATUS').RABBIT_CHANNEL;

// const LogLevel = RABBIT_CHANNEL.LOG;
const _ = require('lodash');

let chan = null;
function initShareRabbit() {
  chan = connection
  .then(conn => conn.createChannel())
  .tap(channel => channel.prefetch(config.get('amqp.prefetch')))
  // eslint-disable-next-line max-len
  .tap(channel => channel.assertExchange(RABBIT_CHANNEL.SHARE_EXCHANGE, 'direct', { durable: true }))
  .then((channel) => {
    // eslint-disable-next-line max-len
    const queues = _.map(_.values(RABBIT_CHANNEL.SHARE_QUEUE), qName => channel.assertQueue(qName, {
      exclusive: false, }));
    return [channel, Promise.all(queues)];
  })
    .spread((channel, queues) => {
      _.forEach(queues, (q) => {
        channel.bindQueue(q.queue, RABBIT_CHANNEL.SHARE_EXCHANGE);

        channel.consume(q.queue, (msg) => {
          try {
            worker(JSON.parse(msg.content.toString()).msg, RABBIT_CHANNEL.SHARE_EXCHANGE, q.queue)
            .then(() => {
              // channel.ack(msg);
            })
              .catch((err) => {
                logger.error(`[WORKER] ${err}`);
                channel.ack(msg);
              });
          } catch (error) {
            logger.error(`[WORKER] ${error}`);
            channel.ack(msg);
          }
        }, { noAck: false });
      });

      return channel;
    });
}


module.exports = {
  // setShare,
  initShareRabbit,
};
