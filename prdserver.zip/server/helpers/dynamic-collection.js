/* eslint-disable no-param-reassign */
/* eslint-disable global-require */
/* eslint-disable import/newline-after-import */
const mongoose = require('mongoose');
const logger = require('winston');
const STATUS = require('../variables/CONST_STATUS').STATUS;
const BaseDC = require('../helpers/d-collection-decorator/base-decorator');
const deepcopy = require('deepcopy');

const ViewConfig = require('../api/viewConfig/viewConfig.model');
const SystemConfig = require('../api/systemConfig/systemConfig.model');
const FunctionDecorator = require('../helpers/d-collection-decorator/function-decorator');
const VariableDecorator = require('../helpers/d-collection-decorator/variable-decorator');
const modelHelper = require('../helpers/model');

const DynamicCollection = require('../api/dynamic-collection/dynamic-collection.model');
// const MAPPING_TYPES = require('../variables/CONST_STATUS').MAPPING_TYPES;
const promise = require('bluebird');
const pluginHelper = require('../plugins/index');
const { ALL_PROPERTIES_OF_RULE } = require('../variables/CONST_STATUS');
const initViewConfigs = require('../../defaultColumns');

const moduleHistoryData = require('../historyData/helpers/dynamic-collection');
// ddd
// Init all model in system by dynamicCollection manager
// order:
// 1. model in server/api/...
// 2. model in require below
// 3. model in dynamic collection database
const modelListEn = [
  'Bill',
  'BusinessOpportunities',
  'Contract',
  'CostEstimate',
  'Customer',
  'Documentary',
  'Employee',
  'ExchangingAgreement',
  'hrm',
  'TakeLeave',
  'Stock',
  'LtAccount',
  'Calendar',
  'OrderPo',
  'SalesPolicy',
  'SalesQuotation',
  'Supplier',
  'TemplateTask',
];

async function createOrUpdateDefaultViewConfig() {
  try {
    const systemConfig = await SystemConfig.findOne();
    if (true) {
      // if (!process.env.IS_SYNC_WORKER) {
      const allCodes = initViewConfigs.map(c => c.code);
      console.log('allCodes', allCodes);
      await ViewConfig.deleteMany({ code: { $in: allCodes } });
      // await ViewConfig.deleteMany({ owner: { $exists: false }, code: { $in: allCodes } });
      const newData = initViewConfigs.map((i) => {
        let listEn;
        if (global.hshCollections[i.code]) {
          if (typeof global.hshCollections[i.code].getListEn === 'function') {
            listEn = global.hshCollections[i.code].getListEn();
          }
        }
        const listDisplay = i.listDisplay;
        // listDisplay.type.fields.type.columns = listDisplay.type.fields.type.columns.map((c) => ({
        //   ...c,
        //   title_init: c.title,
        // }));
        listDisplay.type.fields.type.columns = listDisplay.type.fields.type.columns.map((c) => {
          const result = {
            ...c,
            title_init: c.title,
          };
          if (c.type === 'String' && listEn && !listEn.find(i => i === i.name)) {
            result.hideSearchCheckBox = true;
          }
          return result;
        });
        return {
          filterField: i.filterField,
          status: 1,
          code: i.code,
          path: i.path,
          displayer: i.displayer,
          listDisplay,
          editDisplay: listDisplay,
        };
      });
      const dataInsert = await ViewConfig.insertMany(newData);
      console.log("dataInsert", dataInsert);
      systemConfig.allowRefreshConfig = false;
      await systemConfig.save();
    }
  } catch (error) {
    console.log('error', error);
  }
}

async function loadAllSchema() {
  return new Promise(async (resolve, reject) => {
    await require('../api/crmSource/crmSource.model')('Trạng thái CRM');
    await require('../api/hrmSource/hrmSource.model')('Trạng thái HRM');
    await require('../api/employee/employee.model')('Người dùng');
    await require('../api/loginLog/loginLog.model')('Lịch sử đăng nhập');
    await moduleHistoryData();
    await createOrUpdateDefaultViewConfig();
    if (!process.env.IS_REPORT_DB) {
      // createOrUpdateDefaultViewConfig();
    }
    try {
      const allDCollection = await DynamicCollection.find({
        status: STATUS.ACTIVED,
      });
      for (const col of allDCollection) {
        if (!Object.prototype.hasOwnProperty.call(global.hshCollections, col.code)) {
          addModelToCode(col.code, await addDecoratorForSchema(col), col.name);
        }
      }
      logger.info('[SERVER] Load collections successfully');
      resolve();
    } catch (err) {
      reject(err);
    }
  });
}

async function assignSchema(code, dynamicCollection) {
  //   if (!Object.prototype.hasOwnProperty.call(global.hshCollections, code)) {
  const model = await addDecoratorForSchema(dynamicCollection);
  global.hshCollections[code] = mongoose.model(code, model);

  //   }

  return global.hshCollections[code];
}

function addModelToCode(code, schema, title) {
  if (!Object.prototype.hasOwnProperty.call(global.hshCollections, code)) {
    // console.log(mongoose.model(code, schema));
    global.hshCollectionsTitle[code] = {
      title,
    };
    global.hshCollections[code] = mongoose.model(code, schema);
  }
  return global.hshCollections[code];
}

async function addDynamicCollectionFromCode(dynamicParsed, mongooseModel, code, plugins) {
  const dCollection = new DynamicCollection({
    code,
    plugins,
  });

  return addDecoratorForSchema(dCollection, mongooseModel, dynamicParsed);
}

async function addDecoratorForSchema(dCollection, mongooseSchema, parsed) {
  const code = dCollection.code;

  const origin = await ViewConfig.findOne({ owner: { $exists: false }, code });

  let dynamicParsed = parsed;
  if (!dynamicParsed) {
    dynamicParsed = modelHelper.parseRawModel(dCollection.collectionSchema);
  }

  global.hshViewConfig[code] = dynamicParsed.viewconfig;

  // if (Object.prototype.hasOwnProperty.call(global.hshViewConfig, code)) {
  //   origin = global.hshViewConfig[code];
  //   logger.info(`Code ${code} exist in hash viewconfig`);
  // }

  // add plugins to global variable
  global.hshPlugins[code] = dCollection.plugins;

  // eslint-disable-next-line max-len
  let decorator = new BaseDC(dynamicParsed ? dynamicParsed.schema : dynamicParsed, mongooseSchema, code);

  // eslint-disable-next-line max-len
  decorator = new VariableDecorator(decorator.getCollectionSchema(), decorator.getMongooseSchema(), code);

  decorator = addPlugins(dCollection, decorator, code);

  // eslint-disable-next-line max-len
  decorator = new FunctionDecorator(decorator.getCollectionSchema(), decorator.getMongooseSchema(), code);

  // compare origin and new viewconfig, save viewconfig if necessary
  if (!initViewConfigs.find(c => c.code === code)) {
    updateViewConfigFromOrigin(code, origin);
  }

  const schema = decorator.getMongooseSchema();

  return schema;
}

function addPlugins(dCollection, decorator) {
  let retDecorator = decorator;
  const code = dCollection.code;

  retDecorator = pluginHelper.addPlugins(code, dCollection.plugins, decorator);

  // dCollection.plugins.forEach((plugin) => {
  //   // Attribute Set Plugin
  //   if (plugin.code === 'PL_ATTRIBUTE_SET' && plugin.isActive) {
  //     retDecorator = new AttributeDecorator(
  //       decorator.getCollectionSchema(),
  //       decorator.getMongooseSchema(),
  //       code);
  //   }

  //   // Log Plugin
  //   if (plugin.code === 'PL_LOG' && plugin.isActive) {
  //     retDecorator = new LoggingDecorator(
  //       decorator.getCollectionSchema(),
  //       decorator.getMongooseSchema(),
  //       code);
  //   }
  // });
  return retDecorator;
}

async function updateViewConfigFromOrigin(code, origin) {
  if (!origin) {
    // isModify = true;
    // save viewconfig, init it if necessary
    try {
      // create new ViewConfig
      const mappedArray = [];
      const parsedView = global.hshViewConfig[code];
      let count = 0;
      Object.keys(parsedView).forEach((k) => {
        mappedArray.push({
          name: k,
          title: parsedView[k].title,
          type: parsedView[k].type,
          checked: true,
          order: count,
          isRequire: parsedView[k].required,
          checkedRequireForm: parsedView[k].required,
          min: parsedView[k].min,
          max: parsedView[k].max,
          minLength: parsedView[k].minLength,
          maxLength: parsedView[k].maxLength,
          checkedShowForm: true,
          isFilter: false,
          isSort: false,
        });
        count += 1;
      });

      const newViewConfig = new ViewConfig({
        code,
        // owner: null,
        path: `/crm/${code}`,
        displayer: 'web',
        listDisplay: {
          type: {
            fields: {
              type: {
                columns: mappedArray,
                others: [],
                attributes: [],
              },
            },
            action: [],
          },
        },
        editDisplay: {
          type: {
            fields: {
              type: {
                columns: mappedArray,
                others: [],
                attributes: [],
              },
            },
            action: [],
          },
        },
      });

      await newViewConfig.save();
    } catch (err) {
      logger.error(err);
    }
  } else {
    // compare and update viewConfig
    // add new field or change type
    const thisViewConfig = origin;
    const arrLconfig = thisViewConfig.listDisplay.type.fields.type.columns;
    const arrEConfig = thisViewConfig.editDisplay.type.fields.type.columns;

    const hshLConfig = changeArraytoHashByName(arrLconfig);
    const hshEConfig = changeArraytoHashByName(arrEConfig);

    const updateLCf = updateViewConfigWithHsh(code, hshLConfig);
    const updateECf = updateViewConfigWithHsh(code, hshEConfig);
    if (updateLCf.length > 0 || updateECf.length > 0) {
      await updateViewConfigWithEdit(code, updateLCf, updateECf);
    }
  }
}

async function updateViewConfigWithEdit(code, listChange, editChange) {
  try {
    const allViewConfig = await ViewConfig.find({ code });
    const allChanges = allViewConfig.map((vc) => {
      const listDisplay = deepcopy(vc.listDisplay);
      const editDisplay = deepcopy(vc.editDisplay);

      const listColumns = listDisplay.type.fields.type.columns;
      const editColumns = editDisplay.type.fields.type.columns;

      listChange.forEach((c) => {
        if (c.action === 'add') {
          listColumns.push({
            name: c.name,
            title: c.title,
            type: c.type,
            checked: true,
            order: listColumns.length,
            isRequire: c.required,
            checkedRequireForm: c.required,
            checkedShowForm: true,
            min: c.min,
            max: c.max,
            minLength: c.minLength,
            maxLength: c.maxLength,
            isFilter: false,
            isSort: false,
          });
        } else if (c.action === 'update') {
          const changeIndex = listColumns.findIndex(lc => lc.name === c.name);
          if (changeIndex !== -1) {
            listColumns[changeIndex].type = c.type;
            listColumns[changeIndex].isRequire = c.required;
            listColumns[changeIndex].checkedRequireForm = c.required || listColumns[changeIndex].checkedRequireForm;
            listColumns[changeIndex].min = c.min;
            listColumns[changeIndex].max = c.max;
            listColumns[changeIndex].minLength = c.minLength;
            listColumns[changeIndex].maxLength = c.maxLength;
          }
        } else if (c.action === 'remove') {
          const changeIndex = listColumns.findIndex(lc => lc.name === c.name);
          listColumns.splice(changeIndex, 1);
        }
      });

      editChange.forEach((c) => {
        if (c.action === 'add') {
          editColumns.push({
            name: c.name,
            title: c.title,
            type: c.type,
            checked: true,
            order: editColumns.length,
            isRequire: c.required,
            checkedRequireForm: c.required,
            checkedShowForm: true,
            min: c.min,
            max: c.max,
            minLength: c.minLength,
            maxLength: c.maxLength,
            isFilter: false,
            isSort: false,
          });
        } else if (c.action === 'update') {
          const changeIndex = editColumns.findIndex(ec => ec.name === c.name);
          if (changeIndex !== -1) {
            editColumns[changeIndex].type = c.type;
            editColumns[changeIndex].isRequire = c.required;
            editColumns[changeIndex].checkedRequireForm = c.required || editColumns[changeIndex].checkedRequireForm;
            listColumns[changeIndex].min = c.min;
            listColumns[changeIndex].max = c.max;
            listColumns[changeIndex].minLength = c.minLength;
            listColumns[changeIndex].maxLength = c.maxLength;
          }
        } else if (c.action === 'remove') {
          const changeIndex = editColumns.findIndex(ec => ec.name === c.name);
          editColumns.splice(changeIndex, 1);
        }
      });
      vc.listDisplay = listDisplay;
      vc.editDisplay = editDisplay;
      return vc.save();
    });
    await promise.all(allChanges);
  } catch (err) {
    // console.error(err);
  }
}

function updateViewConfigWithHsh(code, originHsh) {
  const modifies = [];
  const curViewConfig = global.hshViewConfig[code];
  // add or update fields
  Object.keys(curViewConfig).forEach((key) => {
    // add for new key
    if (key === 'others' || key === 'atattributeSet') {
      return;
    }

    if (!Object.prototype.hasOwnProperty.call(originHsh, key)) {
      modifies.push({
        name: key,
        ...curViewConfig[key],
        action: 'add',
      });
    } else if (
      originHsh[key].type !== curViewConfig[key].type ||
      ALL_PROPERTIES_OF_RULE.find((prop) => {
        if (
          (originHsh[key][prop] === null || typeof originHsh[key][prop] === 'undefined') &&
          (curViewConfig[key][prop] === null || typeof curViewConfig[key][prop] === 'undefined')
        ) { return false; }
        return originHsh[key][prop] !== curViewConfig[key][prop];
      })
    ) {
      // update existing
      modifies.push({
        name: key,
        ...curViewConfig[key],
        action: 'update',
      });
    }
  });

  // remove deleted key
  Object.keys(originHsh).forEach((key) => {
    if (!Object.prototype.hasOwnProperty.call(curViewConfig, key)) {
      modifies.push({
        name: key,
        ...originHsh[key],
        action: 'remove',
      });
    }
  });

  return modifies;
}

function changeArraytoHashByName(arr) {
  const rethsh = {};
  const thisArray = deepcopy(arr);
  for (let i = 0; i < thisArray.length; i += 1) {
    thisArray[i].index = i;
    rethsh[thisArray[i].name] = thisArray[i];
  }
  return rethsh;
}

module.exports = {
  loadAllSchema,
  assignSchema,
  addDecoratorForSchema,
  addDynamicCollectionFromCode,
  addModelToCode,
};
