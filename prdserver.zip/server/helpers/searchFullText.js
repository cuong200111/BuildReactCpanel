/* eslint-disable arrow-parens */
/* eslint-disable no-param-reassign */
function diacriticSensitiveRegex(string = '') {
  return string
    .toLowerCase()
    .replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
    .replace(/a|á|à|ä|ả|ạ|â|ấ|ầ|ậ|ẫ|ẩ|ă|ẳ|ắ|ằ|ẵ|ặ/g, '[a,á,à,ä,ả,ạ,â,ấ,ầ,ậ,ẫ,ẩ,ă,ẳ,ắ,ằ,ẵ,ặ]')
    .replace(/e|é|ë|ẻ|è|ẹ|ê|ế|ề|ể|ễ|ệ/g, '[e,é,ë,ẻ,è,ẹ,ê,ế,ề,ể,ễ,ệ]')
    .replace(/i|í|ï|ì|ỉ|ị/g, '[i,í,ï,ì,ỉ,ị]')
    .replace(/y|ý|ỳ|ỷ|ỹ|ỵ/g, '[y,ý,ỳ,ỷ,ỹ,ỵ]')
    .replace(/n|ñ|ń|ǹ|ņ|ṇͅͅ/g, '[n,ñ,ń,ǹ,ņ,ṇ]')
    .replace(/o|ó|ö|ò|ỏ|ò|ô|ồ|ố|ổ|ỗ|ộ|ơ|ở|ỡ|ờ|ớ|ợ/g, '[o,ó,ö,ò,ỏ,ò,ô,ồ,ố,ổ,ỗ,ộ,ơ,ở,ỡ,ờ,ớ,ợ]')
    .replace(/u|ü|ú|ù|ụ|ủ|ư|ứ|ừ|ử|ữ|ự/g, '[u,ü,ú,ù,ụ,ủ,ư,ứ,ừ,ử,ữ,ự]')
    .replace(/d|đ/g, '[d,đ]');
}

module.exports = function loadedAtPlugin(filter = {}) {
  if (typeof filter === 'object') {
    Object.keys(filter).forEach((key) => {
      if (filter[key] === 'false') {
        filter[key] = false;
      }

      if (filter[key] === 'true') {
        filter[key] = true;
      }

      if (filter[key] === 'null') {
        filter[key] = null;
      }
      if (filter[key] && typeof filter[key] === 'object' && !Array.isArray(filter[key]) && filter[key].$regex) {
        filter[key] = {
          $regex: diacriticSensitiveRegex(filter[key].$regex),
          $options: 'i',
        };
      }
      if (Array.isArray(filter[key])) {
        filter[key] = filter[key].map((m) => loadedAtPlugin(m));
      }
    });
  }
  return filter;
};
