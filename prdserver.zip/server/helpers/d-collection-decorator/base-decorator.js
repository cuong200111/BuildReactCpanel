/* eslint-disable import/newline-after-import */
/* eslint-disable func-names */
/* eslint-disable no-param-reassign */
const mongoose = require('mongoose');
const modelHelper = require('../model');
// const RoleApp = require('../../api/roleTask/role.model');
// const _ = require('lodash');
// const logger = require('winston');
// const STATUS = require('../variables/CONST_STATUS');
const FIELDS = require('../../variables/FIELDS');
const numberCount = ['First', 'Second', 'Last'];

class BaseDC {
  constructor(collectionSchema, mongooseSchema, code) {
    this.collectionSchema = collectionSchema || mongooseSchema.obj;
    this.mongooseSchema = mongooseSchema || new mongoose.Schema(this.collectionSchema, { timestamps: true });
    this.code = code;
    // this.responsePromise.bind(this);
    // this.getCode.bind(this)
    this.addOrganizationUnit();
  }

  getCode() {
    return this.code;
  }

  getCollectionSchema() {
    return this.collectionSchema;
  }

  getMongooseSchema() {
    return this.mongooseSchema;
  }

  // eslint-disable-next-line class-methods-use-this
  parseAndUpdateNewField(newObj) {
    const parsedObj = modelHelper.parseRawModel(newObj);
    this.collectionSchema = {
      ...this.collectionSchema,
      ...parsedObj.schema,
    };
    global.hshViewConfig[this.code] = {
      ...global.hshViewConfig[this.code],
      ...parsedObj.viewconfig,
    };
  }


  addOrganizationUnit() {
    this.collectionSchema[FIELDS.UID] = { type: 'ObjectId', ref: 'Employee' };
    this.collectionSchema[FIELDS.OID] = { type: 'ObjectId', ref: 'OrganizationUnit' };
    this.mongooseSchema.methods[`save${numberCount[0]}`] = async function (userId, schemaOb) {
      const user = await global.hshCollections.Employee.findOne({ _id: userId });
      if (user) {
        schemaOb[FIELDS.UID] = userId;
        schemaOb[FIELDS.OID] = user.organizationUnit.organizationUnitId;
        return schemaOb.save();
      }
      return schemaOb.save();
    };
  }

  // eslint-disable-next-line class-methods-use-this
  mergeMongoSchema(schemaA, schemaB) {
    // eslint-disable-next-line prefer-const
    let checkHook = {};
    // eslint-disable-line
    const retSchema = new mongoose.Schema(
      {
        ...schemaA.obj,
        ...schemaB.obj,
      },
      { timestamps: true },
    );


    // Update checkhook from retSchema if it is new mongoose model
    if (retSchema.s.hooks._pres && retSchema.s.hooks._pres instanceof Map) {
      for (const item of retSchema.s.hooks._pres) {
        const verb = item[0];
        item[1].forEach((func) => {
          if (
            !Object.prototype.hasOwnProperty.call(
              checkHook,
              `${this.code}_pre${verb}_${func.fn.toString().replace(/[\r\n\t\s]+/g, '')}`,
            )
          ) {
            checkHook[`${this.code}_pre${verb}_${func.fn.toString().replace(/[\r\n\t\s]+/g, '')}`] = true;
            // retSchema.pre(verb, func.fn);
          }
        });
      }

      for (const item of retSchema.s.hooks._posts) {
        const verb = item[0];
        item[1].forEach((func) => {
          if (
            !Object.prototype.hasOwnProperty.call(
              checkHook,
              `${this.code}_post${verb}_${func.fn.toString().replace(/[\r\n\t\s]+/g, '')}`,
            )
          ) {
            checkHook[`${this.code}_post${verb}_${func.fn.toString().replace(/[\r\n\t\s]+/g, '')}`] = true;
            // retSchema.post(verb, func.fn);
          }
        });
      }
    } else {
      // if (retSchema.callQueue.length > 4) {
      //   for (let i = 0; i < retSchema.callQueue.length; i += 1) {
      //       const arr = retSchema.callQueue[i];
      //     //   console.log(arr[0]);
      //           if (arr[0] === 'pre') {
      //             const verb = arr[1][0];
      //               const func = arr[1][arr[1].length-1];
      //               if (!Object.prototype.hasOwnProperty.call(checkHook, `${this.code}_pre${verb}_${func.toString().replace(/[\r\n\t\s]+/g, '')}`)) {
      //                   checkHook[`${this.code}_pre${verb}_${func.toString().replace(/[\r\n\t\s]+/g, '')}`] = true;
      //                 //   console.log(func.toString());
      //             }
      //           }
      //           if (arr[0] === 'on') {
      //             const verb = arr[1][0];
      //               const func = arr[1][arr[1].length-1];
      //               if (!Object.prototype.hasOwnProperty.call(checkHook, `${this.code}_post${verb}_${func.toString().replace(/[\r\n\t\s]+/g, '')}`)) {
      //                   checkHook[`${this.code}_post${verb}_${func.toString().replace(/[\r\n\t\s]+/g, '')}`] = true;
      //                 //   console.log(func.toString());
      //             }
      //           }
      //         }
      //   }
    }

    retSchema.methods = {
      ...schemaA.methods,
      ...schemaB.methods,
    };

    retSchema.statics = {
      ...schemaA.statics,
      ...schemaB.statics,
    };

    if (retSchema.s.hooks._pres && retSchema.s.hooks._pres instanceof Map) {
      // update callQueue
      for (const item of schemaA.s.hooks._pres) {
        const verb = item[0];
        item[1].forEach((func) => {
          if (
            !Object.prototype.hasOwnProperty.call(
              checkHook,
              `${this.code}_pre${verb}_${func.fn.toString().replace(/[\r\n\t\s]+/g, '')}`,
            )
          ) {
            checkHook[`${this.code}_pre${verb}_${func.fn.toString().replace(/[\r\n\t\s]+/g, '')}`] = true;
            retSchema.pre(verb, func.fn);
            // console.log(this.code, verb, func.fn.toString().replace(/[\r\n\t\s]+/g, ''));
          }
        });
      }
      for (const item of schemaB.s.hooks._pres) {
        const verb = item[0];
        item[1].forEach((func) => {
          if (
            !Object.prototype.hasOwnProperty.call(
              checkHook,
              `${this.code}_pre${verb}_${func.fn.toString().replace(/[\r\n\t\s]+/g, '')}`,
            )
          ) {
            checkHook[
              `${this.code}_pre${verb}_${func.fn
                .toString()
                .replace(/[\r\n\t\s]+/g, '')
                .replace(/[\r\n\t\s]+/g, '')}`
            ] = true;

            retSchema.pre(verb, func.fn);
          }
        });
      }

      for (const item of schemaA.s.hooks._posts) {
        const verb = item[0];
        item[1].forEach((func) => {
          if (
            !Object.prototype.hasOwnProperty.call(
              checkHook,
              `${this.code}_post${verb}_${func.fn.toString().replace(/[\r\n\t\s]+/g, '')}`,
            )
          ) {
            checkHook[`${this.code}_post${verb}_${func.fn.toString().replace(/[\r\n\t\s]+/g, '')}`] = true;
            retSchema.post(verb, func.fn);
          }
        });
      }
      for (const item of schemaB.s.hooks._posts) {
        const verb = item[0];
        item[1].forEach((func) => {
          if (
            !Object.prototype.hasOwnProperty.call(
              checkHook,
              `${this.code}_post${verb}_${func.fn.toString().replace(/[\r\n\t\s]+/g, '')}`,
            )
          ) {
            checkHook[`${this.code}_post${verb}_${func.fn.toString().replace(/[\r\n\t\s]+/g, '')}`] = true;
            retSchema.post(verb, func.fn);
            // console.log(this.code, verb, func.fn.toString().replace(/[\r\n\t\s]+/g, ''));
          }
        });
      }

      //   // Clear call callQueue hash
      //   for (const item of retSchema.s.hooks._pres) {
      //     const verb = item[0];
      //     item[1].forEach((func) => {
      //       if (
      //         Object.prototype.hasOwnProperty.call(
      //           checkHook,
      //           `${this.code}_pre${verb}_${func.fn.toString().replace(/[\r\n\t\s]+/g, '')}`,
      //         )
      //       ) {
      //         delete checkHook[`${this.code}_pre${verb}_${func.fn.toString().replace(/[\r\n\t\s]+/g, '')}`];
      //       }
      //     });
      //   }

      //   for (const item of retSchema.s.hooks._posts) {
      //     const verb = item[0];
      //     item[1].forEach((func) => {
      //       if (
      //         Object.prototype.hasOwnProperty.call(
      //           checkHook,
      //           `${this.code}_post${verb}_${func.fn.toString().replace(/[\r\n\t\s]+/g, '')}`,
      //         )
      //       ) {
      //         delete checkHook[`${this.code}_post${verb}_${func.fn.toString().replace(/[\r\n\t\s]+/g, '')}`];
      //       }
      //     });
      //   }
    } else {
      //   if (schemaA.callQueue.length > 4) {
      for (let i = 0; i < schemaA.callQueue.length; i += 1) {
        const arr = schemaA.callQueue[i];
        if (arr[0] === 'pre' && arr[1].length === 2) {
          const verb = arr[1][0];
          const func = arr[1][arr[1].length - 1];
          //   if (!Object.prototype.hasOwnProperty.call(checkHook, `${this.code}_pre${verb}_${func.toString().replace(/[\r\n\t\s]+/g, '')}`)) {
          checkHook[`${this.code}_pre${verb}_${func.toString().replace(/[\r\n\t\s]+/g, '')}`] = true;
          retSchema.pre(verb, func);
          // }
        }
        if (arr[0] === 'on' && arr[1].length === 2) {
          const verb = arr[1][0];
          const func = arr[1][arr[1].length - 1];
          //   if (!Object.prototype.hasOwnProperty.call(checkHook, `${this.code}_post${verb}_${func.toString().replace(/[\r\n\t\s]+/g, '')}`)) {
          checkHook[`${this.code}_post${verb}_${func.toString().replace(/[\r\n\t\s]+/g, '')}`] = true;
          retSchema.post(verb, func);
          //   }
        }
      }
      //   }
      //   if (schemaB.callQueue.length > 4) {
      for (let i = 0; i < schemaB.callQueue.length; i += 1) {
        const arr = schemaB.callQueue[i];

        if (arr[0] === 'pre' && arr[1].length === 2) {
          const verb = arr[1][0];
          const func = arr[1][arr[1].length - 1];

          // if (!Object.prototype.hasOwnProperty.call(checkHook, `${this.code}_pre${verb}_${func.toString().replace(/[\r\n\t\s]+/g, '')}`)) {
          checkHook[`${this.code}_pre${verb}_${func.toString().replace(/[\r\n\t\s]+/g, '')}`] = true;
          retSchema.pre(verb, func);
          // console.log('preB',func.toString());
          // }
        }
        if (arr[0] === 'on' && arr[1].length === 2) {
          const verb = arr[1][0];
          const func = arr[1][arr[1].length - 1];

          // if (!Object.prototype.hasOwnProperty.call(checkHook, `${this.code}_post${verb}_${func.toString().replace(/[\r\n\t\s]+/g, '')}`)) {
          checkHook[`${this.code}_post${verb}_${func.toString().replace(/[\r\n\t\s]+/g, '')}`] = true;
          retSchema.post(verb, func);
          // }
        }
      }
      //   }
    }

    return retSchema;
  }
}

module.exports = BaseDC;
