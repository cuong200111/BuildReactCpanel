const mongoose = require('mongoose');
const BaseDC = require('./base-decorator');
// eslint-disable-next-line no-unused-vars
const CreatorSchema = require('../../helpers/creator-model').CreatorSchema;
const STATE = require('../../variables/CONST_STATUS').STATE;

class VariableDecorator extends BaseDC {
  constructor(collectionSchema, mongooseSchema, code) {
    super(collectionSchema, mongooseSchema, code);

    const newObj = {
      status: {
        type: Number,
        min: 0,
        max: 3,
        default: 1,
      },
      others: {},
      state: {
        type: String,
        default: STATE.NOT_APPROVAL_REQUIREMENT,
      },
    };

    this.parseAndUpdateNewField(newObj);
    // this.mongooseSchema = new mongoose.Schema(this.collectionSchema);
    // eslint-disable-next-line max-len
    this.mongooseSchema = this.mergeMongoSchema(new mongoose.Schema(this.collectionSchema), this.mongooseSchema);
  }
}

module.exports = VariableDecorator;
