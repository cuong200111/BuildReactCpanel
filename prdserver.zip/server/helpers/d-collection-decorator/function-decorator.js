const BaseEC = require('./base-decorator');
const STATUS = require('../../variables/CONST_STATUS').STATUS;
const APIError = require('../../helpers/APIError');
const httpStatus = require('http-status');

class FunctionDecorator extends BaseEC {
  constructor(collectionSchema, mongooseSchema, code) {
    super(collectionSchema, mongooseSchema, code);

    // decorate schema
    /**
     * Methods
     */
    this.getMongooseSchema().methods = {

      // /**
      //  *
      //  * @param {string} data data want to alert
      //  */

      ...this.getMongooseSchema().methods,

      delete() {
        this.status = STATUS.DELETED;
        return this.save()
          .then(deletedDCollection => deletedDCollection)
          .catch(e => Promise.reject(e));
      }
    };

    this.getMongooseSchema().statics = {
      /**
       * Get collection
       * @param {ObjectId} id - The objectId of collection.
       * @returns {Promise<collection, APIError>}
       */

      get(id) {
        return this.findById(id)
          .exec()
          .then((collection) => {
            if (collection) {
              return collection;
            }
            const err = new APIError('No such data exists!', httpStatus.NOT_FOUND);
            return Promise.reject(err);
          });
      },

      deleteMany(arrId) {
        return this.find({ _id: { $in: arrId } })
        .then(deletedDCollections => deletedDCollections)
        .catch(e => Promise.reject(e));
      },

      // eslint-disable-next-line no-shadow
      getByCode(code) {
        return this.findOne({
          code
        })
          .exec()
          .then((collection) => {
            if (collection) {
              return collection;
            }
            const err = new APIError('No such data exists!', httpStatus.NOT_FOUND);
            return Promise.reject(err);
          });
      },

      /**
       * List collections in descending order of 'createdAt' timestamp.
       * @param {number} skip - Number of collections to be skipped.
       * @param {number} limit - Limit number of collections to be returned.
       * @returns {Promise<collection[]>}
       */
      list({
        skip = 0,
        limit = 500
      } = {}) {
        return this.find({
          status: STATUS.ACTIVED
        })
          .sort({
            createdAt: -1
          })
          .skip(+skip)
          .limit(+limit)
          .exec();
      },
      ...this.getMongooseSchema().statics
    };
  }
}

module.exports = FunctionDecorator;
