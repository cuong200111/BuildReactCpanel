const { RECEIVE } = require('./CONST');
// const Employee = require('../api/employee/employee.model');
const Notification = require('../api/notification/notification.model');

module.exports = function(socket) {
  // console.log('thang', socket.id, socket.employeeId);
  return async function(data) {
    switch (data.command) {
      case RECEIVE.NOTIFICATION.GET_NOTIFICATION: {
        const { limit = 10, skip = 0, sort, filter = {} } = data.data;
        filter.to = socket.employeeId;

        filter.date = { $lt: new Date() };
        // console.log(data);
        const notifications = await Notification.list({ limit, skip, sort, filter });
        // console.log(socket.id);
        socket.emit(socket.id, notifications);
        // socket.emit(socket.id, 'for your eyes only');

        break;
      }
      default:
        break;
    }
  };
};
