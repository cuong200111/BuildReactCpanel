// const { RECEIVE, NAMESPACE } = require('./CONST');
// const Employee = require('../api/employee/employee.model');

// module.exports = function (socket) {
//   return function (data) {
//     console.log(socket.id);
//     switch (data.command) {
//       case RECEIVE.CONNECTION: {
//         socket.emit(NAMESPACE.CONNECTION, { message: 'welcome to socket server' }); // when socket connect

//         break;
//       }
//       default:
//         break;
//     }
//   };
// };
