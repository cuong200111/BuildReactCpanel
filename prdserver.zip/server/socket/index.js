/* eslint-disable no-console */
const { NAMESPACE } = require('./CONST');
const auth = require('../middleware/auth-strategy');
const disconect = require('./disconect');
const notification = require('./notification');
const conversation = require('./conversation');
const publish = require('./publish');
const room = require('./room');

const index = function (socket) {
  auth.socketIsAuthenticated(socket);
  socket.on('publish', publish(socket));
  socket.on(NAMESPACE.NOTIFICATION, notification(socket));
  socket.on(NAMESPACE.CONVERSATION, conversation(socket));
  socket.on(NAMESPACE.DISCONNECT, disconect(socket));
  socket.on(NAMESPACE.ROOM, room(socket));
  // socket.on('on_camera_register', (data) => {
  //   const newData = { ...data, clientSid: socket.id };
  //   global.socketClientAi.emit('on_camera_register', newData);
  // });

  // socket.on('my_message', (data) => {
  //   console.log('my_message', data);
  //   const newData = { ...data, clientSid: socket.id };
  //   global.socketClientAi.emit('my_message', newData);
  // });
};

module.exports = index;
