/* eslint-disable no-unused-vars */
/* eslint-disable func-names */
// const Conversation = require('../api/conversation/conversation.model');
const Message = require('../api/conversation/message.model');
const Notification = require('../api/notification/notification.model');
const Conversation = require('../api/conversation/conversation.model');
const { RABBIT_CHANNEL } = require('../variables/CONST_STATUS');

const sendNotice = async function ({ title, content, to, link, type = 'System', auto }) {
  let sendTo = to;
  let topic = to;
  if (String(to).length === 24) {
    const emp = await global.hshCollections.Employee.findOne({
      $or: [
        {
          _id: to,
        },
        {
          userId: to,
        },
      ],
    });
    if (emp) {
      sendTo = emp._id;
    }
    if (emp && emp.userId) {
      topic = emp.userId;
    }
  }
  const newNoti = {
    title,
    content,
    type,
    link,
    to: sendTo,
    date: new Date(),
  };

  const chan = global.hshCollections.chan;
  if (chan && !auto) {
    if (newNoti.to && String(newNoti.to).length === 24) {
      const emp = await global.hshCollections.Employee.findOne({
        $or: [
          {
            _id: to,
          },
          {
            userId: to,
          },
        ],
      });
      if (emp) {
        sendTo = emp._id;
      }
      if (emp && emp.userId) {
        topic = emp.userId;
      }
    }
    if (topic) {
      const messageNov = {
        notification: {
          title: newNoti.title,
          body: newNoti.content,
        },
        topic,
      };

      const url = process.env.HOST_NAME || 'https://stagingerp.lifetek.vn';
      if (url) {
        messageNov.webpush = {
          fcm_options: {
            link: url + newNoti.link,
          },
        };
      }
      const client = process.env.CLIENT_NOTIFICATION || '08_CRM';
      chan.then((c) =>
        c.publish(
          RABBIT_CHANNEL.NOTIFICATION,
          `${client}.${RABBIT_CHANNEL.NOTIFICATION}`,
          Buffer.from(JSON.stringify(messageNov)),
        ),
      );
    }
  }
  if (global.hshUserSocket[sendTo]) {
    global.io.to(global.hshUserSocket[sendTo]).emit('notice', { content });
  }
}
// eslint-disable-next-line no-unused-vars
// eslint-disable-next-line func-names
module.exports = function(socket) {
  return async function(data) {
    switch (data.type) {
      case 'CHAT': {
        const message = {
          content: data.data.content,
          user: data.data.userId,
          toUser: data.data.toUser,
          conversation: data.data.id,
          name: data.data.name,
          userName: data.data.userName,
          userAvatar: data.data.userAvatar,
          attachFile: data.data.attachFile
        };
        // console.log(global.hshUserSocket);

        data.data.join.forEach((i) => {
          if (global.hshUserSocket[i]) {
            global.io.to(global.hshUserSocket[i]).emit('chat', data.data);
          }
          sendNotice({
            title: `${data.data.userName} gửi tin nhắn mới!`,
            content: `${data.data.content}`,
            type: 'System',
            link: '',
            to: i,
            // from: 'Task',
            date: new Date(),
            noNoti: true
          });
        });

        const dataSave = new Message(message);
        await Conversation.updateOne({ _id: data.data.id }, { updatedAt: new Date() });
        await dataSave.save();
        break;
      }
      case 'CHAT_GROUP':
        console.log('DATA', data);

        break;
      default:
        break;
    }

    // console.log("DTAAAAAAA",message);

    // console.log('FRIEND', global.hshUserSocket[data.data.friendId]);
  };
};
