/* eslint-disable no-prototype-builtins */
/* eslint-disable no-console */
/* eslint-disable func-names */
/* eslint-disable import/newline-after-import */
/* eslint-disable no-param-reassign */
const Employee = require('../../server/api/employee/employee.model');

module.exports = function(socket) {
  return async function() {
    console.log('disconnect', socket.id);
    if (global.hshSocketUser.hasOwnProperty(socket.id)) {
      // eslint-disable-next-line no-plusplus
      const user = await Employee().findById(global.hshSocketUser[socket.id]);
      if (user) {
        user.online = false;
        user.save();
      }
      global.userCount--;

      // if (global.hshSocketUser[socket.id]) {
      //   socket.leave(global.hshSocketUser[socket.id]);
      // }
      if (global.hshIdSocket.hasOwnProperty(global.hshUserSocket[global.hshSocketUser[socket.id]])) {
        delete global.hshIdSocket.hasOwnProperty(global.hshUserSocket[global.hshSocketUser[socket.id]]);
      }

      delete global.hshSocketUser[socket.id];
      delete global.hshUserSocket[global.hshSocketUser[socket.id]];
      // console.log('disconnect', global.hshSocketUser);
    }
  };
};
