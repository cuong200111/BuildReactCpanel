module.exports = {
  NAMESPACE: {
    NOTIFICATION: 'notification',
    RE_NOTIFICATION: 'reNotification',
    CONNECTION: 'connection',
    DISCONNECT: 'disconnect',
    CONVERSATION: 'conversation',
    ROOM: 'room'
  },
  RECEIVE: {
    CONNECTION: 1000,
    NOTIFICATION: {
      GET_NOTIFICATION: 1001,
    },
  },

};
