
module.exports = function() {
  return function(data) {
    const socket = global.io;
    socket.emit('subcribe', data);
  };
};
