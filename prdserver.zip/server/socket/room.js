/* eslint-disable no-unused-vars */
/* eslint-disable func-names */
// const Conversation = require('../api/conversation/conversation.model');
const Message = require('../api/conversation/message.model');
const Notification = require('../api/notification/notification.model');

// eslint-disable-next-line no-unused-vars
// eslint-disable-next-line func-names
module.exports = function(socket) {
  return async function(data) {
    socket.join(data.room);
  };


    // console.log("DTAAAAAAA",message);


    // console.log('FRIEND', global.hshUserSocket[data.data.friendId]);
};
