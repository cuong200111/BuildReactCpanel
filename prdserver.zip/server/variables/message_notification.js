module.exports = {
  NOT_ROLE: 'Bạn không có quyền, vui lòng cập nhật lại quyền',
  NOT_ROLE_ORG: (nameWorking, nameOrg) => `Vui lòng chuyển ${nameWorking} hiện tại sang ${nameOrg} để xem`,
  errorSytem: 'Có lỗi trong quá trình xử lý',
  ERROR_MODULE_CODE: 'Vui lòng nhập vào nhóm quyền',
  ERROR_ORG_WORK: 'Vui lòng chọn phòng ban hoạt động',
  NOT_ORG: 'Bạn không có quyền xem phòng ban này',
  ERROR_NOT_USER: 'Không tìm thấy tài khoản, vui lòng kiểm tra lại',
  ERROR_START_BIG_END: 'Vui lòng nhập ngày bắt đầu trước ngày ngày kết thúc',
  errorNotValue: (name) => `Vui lòng nhập vào ${name}`,
  errorValidDate: (name) => `Vui lòng ${name} đúng định dạng YYYY/MM/DD`,
  errorNotId: (name) => `Không tìm thấy ${name}, Vui lòng chọn lại`,
  ERROR_NOT_FIND_VALUE: (name) => `Không tìm thấy ${name}, Vui lòng kiểm tra lại`,
};
