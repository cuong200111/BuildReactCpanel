const COMMAND = {
  SET_APPROVE: '0',
};
module.exports = {
  COMMAND,
};
