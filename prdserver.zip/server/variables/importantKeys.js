// All following keys should be updated with consideration
module.exports = ['_id', 'createdAt', 'updatedAt', 'status', 'tranferPersonHistory', '__v'];
