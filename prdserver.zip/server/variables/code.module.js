module.exports = {
  reportsBusinessOpportunities: 'reportsBusinessOpportunities', // Báo cáo thống kê cơ hội kinh doanh
  reportsFinishLevel: 'reportsFinishLevel', // Báo cáo Mức độ hoàn thành chỉ tiêu
  reportDoingTask: 'reportDoingTask', // Báo cáo Thời gian thực hiện công việc
  reportStatsHrm: 'reportStatsHrm', // Báo cáo thống kê nhân sự
  reportMeetingCustomer: 'reportMeetingCustomer', // Báo cáo tiếp xúc khách hàng
  reportsTaskStatus: 'reportsTaskStatus', // Báo cáo trạng thái công việc
  reportCustomerUserProduct: 'reportCustomerUserProduct', // Báo cáo KH theo sản phẩm
  Kpi: 'Kpi', // Quyên kế hoạch và thực thế
};
