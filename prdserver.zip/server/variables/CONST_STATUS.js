const PLUGINS = {
  PL_ATTRIBUTE_SET: 'PL_ATTRIBUTE_SET',
  PL_LOG: 'PL_LOG',
  PL_VIEW_KANBAN: 'PL_VIEW_KANBAN',
  PL_AUTOMATION: 'PL_AUTOMATION',
  PL_NOTIFY: 'PL_NOTIFY',
};

const RABBIT_CHANNEL = {
  LOG_EXCHANGE: 'logs',
  LOG: {
    INFO: 'logs.info',
    DEBUG: 'logs.debug',
    ERROR: 'logs.error',
    WARN: 'logs.warn',
  },
  NOTIFY_EXCHANGE: 'messenger',
  erpSend_EXCHANGE: 'erpSend',
  CRM_SEMD_EXCHANGE: 'crm',
  CRM_SEMD_KEY: 'crm.send',
  NOTIFY: 'messenger',
  ERP_SEND: 'erpsend',
  APPROVE_EXCHANGE: 'approve',
  APPROVE_QUEUE: {
    APPROVE: 'approve.set',
    NOTIFICATION: 'approve.notification',
    TASK: 'approve.task',
    FIELD: 'approve.field',
    BUSSINES_OPPORTUNITIES: 'approve.businessOpportunities',
  },
  APPROVE_KEY: {
    APPROVE: 'approve.set',
    NOTIFICATION: 'approve.notification',
  },
  SHARE_EXCHANGE: 'share',
  SHARE_QUEUE: {
    NOTIFICATION: 'share.notification',
  },
  SHARE_KEY: {
    NOTIFICATION: 'share.notification',
  },
  AUTO_FILTER_EXCHANGE: 'filter',
  NOTIFICATION: 'notification',
  AUTO_FILTER: {
    ACTION: 'filter',
  },
};

const STATUS = {
  NOT_ACTIVED: 0,
  ACTIVED: 1,
  LOCKED: 2,
  DELETED: 3,
  DRAFT: 4,
};

const STATUS_SEND = {
  SENDING: 1,
  SUCCESS: 2,
  FAILED: 3,
};

const DATATYPES = {
  String: 'String',
  Number: 'Number',
  Date: 'Date',
  Password: 'Password',
  Media: 'Media',
  Enumeration: 'Enumeration',
  Boolean: 'Boolean',
  Email: 'Email',
  Phone: 'Phone',
  JSON: 'JSON',
  Relation: 'Relation',
  Array: 'Array',
  Money: 'Money',
  ObjectId: 'ObjectId',
};

const MAPPING_TYPES = {
  String: 'String',
  Number: 'Number',
  Date: 'Date',
  Password: 'String',
  Media: 'String',
  Enumeration: 'String',
  Boolean: 'Boolean',
  Email: 'String',
  Phone: 'String',
  JSON: 'String',
  Relation: 'String',
  Array: 'String',
  Money: 'String',
  ObjectId: 'ObjectId',
};

const TIME_FORMAT = {
  TWELVE_HOURS: '12h',
  MILITARY_HOURS: '24h',
};

const WEEKDAY = {
  MONDAY: 2,
  TUESDAY: 3,
  WEDNESDAY: 4,
  THURSDAY: 5,
  FRIDAY: 6,
  SATURDAY: 7,
  SUNDAY: 1,
};

const LANGUAGE = {
  VI_VN: 'vi',
  EN_US: 'en',
};

const CODE_STATUS_CANBAN = {
  START: 0,
  DOING: 1,
  SUCCESS: 2,
  FALSE: 3,
};
const CHANGE_PRICE = {
  BY_MONEY: 0,
  BY_PERCENT: 1,
};
const TYPE_CONTRACT = {
  CUSTOMER: 1,
  SIPPLIER: 2,
  MACHINING_HOUSE: 3,
};
// approval requirements
const STATE = {
  APPROVAL_REQUIREMENT: 0,
  APPROVED: 1,
  REJECTED: 2,
  NOT_APPROVAL_REQUIREMENT: 3,
  FINISHED: 4,
};

const CODE_STATUS_KANBAN = {
  START: 1,
  DOING: 2,
  SUCCESS: 3,
  FAILD: 4,
  PAUSE: 5,
};
const CONDITION = {
  EQUAL: 'Equal', // bằng (Mặc định)
  GREATEREQUAL: 'greaterEqual', // lớn hơn hoặc bằng
  LESSEQUAL: 'LessEqual', // bé hơn hoặc bằng
};
const ALL_PROPERTIES_OF_RULE = ['required', 'min', 'max', 'minLength', 'maxLength'];
const FIELD_IS_NUMBER = ['idetityCardNumber', 'bankAccountNumber', 'passportNumber'];
module.exports = {
  STATUS,
  DATATYPES,
  TIME_FORMAT,
  WEEKDAY,
  LANGUAGE,
  CODE_STATUS_CANBAN,
  MAPPING_TYPES,
  CHANGE_PRICE,
  PLUGINS,
  TYPE_CONTRACT,
  RABBIT_CHANNEL,
  STATE,
  ALL_PROPERTIES_OF_RULE,
  STATUS_SEND,
  CODE_STATUS_KANBAN,
  CONDITION,
  FIELD_IS_NUMBER,
};
