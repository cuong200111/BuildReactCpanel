const historyDataModuleStatic = require('../historyData/variables/moduleStatic.init'); 
module.exports = [
  {
    title: 'Thiết lập',
    route: 'setting',
  },
  {
    title: 'Cấu hình CRM',
    route: 'ConfigCRM',
  },
  {
    title: 'Dashboad',
    route: '',
  },
  {
    title: 'Thiết lập',
    route: 'setting',
  },
  {
    title: 'HRM',
    route: 'hrm',
  },
  {
    title: 'Tủ hồ sơ',
    route: 'file-manager',
  },
  {
    title: 'Công văn đến',
    route: 'inComingDocument',
  },
  {
    title: 'Công văn đi',
    route: 'outGoingDocument',
  },
  {
    title: 'Chính sách ưu đãi',
    route: 'SpecialOffers',
  },
  {
    title: 'Báo cáo',
    route: 'reports',
  },
  {
    title: 'Biểu mẫu động',
    route: 'DynamicForm',
  },
  {
    title: 'Field',
    route: 'Field',
  },
  {
    title: 'CRM',
    route: 'CRM',
  },
  {
    title: 'Báo cáo số dư công nợ phải thu theo thời gian',
    route: 'reportDebtReceivables',
  },
  {
    title: 'Báo cáo số dư công nợ phải trả theo thời gian',
    route: 'reportDebtToPay',
  },
  {
    title: 'Báo cáo tổng hợp công nợ theo nhân viên kinh doanh',
    route: 'reportDebtEmployees',
  },
  {
    title: 'Báo cáo tốp doanh số theo khách hàng',
    route: 'reportTopSalesCustomer',
  },
  {
    title: 'Báo cáo tốp doanh số theo sản phẩm',
    route: 'reportTopSalesProduct',
  },
  {
    title: 'Báo cáo tiếp xúc khác hàng',
    route: 'reportMeetingCustomer',
  },
  {
    title: 'Báo cáo trạng thái công việc',
    route: 'reportsTaskStatus',
  },
  {
    title: 'Báo cáo trạng thái CHKD',
    route: 'reportsBusinessOpportunities',
  },
  {
    title: 'Báo cáo thời gian thực hiện công việc',
    route: 'reportDoingTask',
  },
  {
    title: 'Báo cáo tổng hợp doanh thu, nhóm chi phí trong năm',
    route: 'reportCostRevenue',
  },
  {
    title: 'Báo cáo tổng hợp doanh thu, giá vốn trong năm',
    route: 'reportCostPrice',
  },
  {
    title: 'Báo cáo tổng hợp tồn kho theo nhóm sản phẩm',
    route: 'reportInventoryProduct',
  },
  {
    title: 'Báo cáo tổng hợp doang thu, tồn kho trong năm',
    route: 'reportRevenueInventory',
  },
  {
    title: 'Báo cáo tỷ trọng chi phí',
    route: 'reportCostRatio',
  },
  {
    title: 'Báo cáo tỷ trọng chi phí theo khoản mục',
    route: 'reportCostRatioItem',
  },
  {
    title: 'Báo cáo tổng tiền thu trong năm',
    route: 'reportStatisticalReceipt',
  },
  {
    title: 'Báo cáo khách hàng theo số lượng mua hàng',
    route: 'reportCustomerNumberSell',
  },
  {
    title: 'Báo cáo tần suất khách hàng mua hàng',
    route: 'reportCustomerFrequencySell',
  },
  {
    title: 'Báo cáo Thực hiện chỉ tiêu doanh số',
    route: 'reportkpiSales',
  },
  {
    title: 'Báo cáo mức độ hoàn thành mục tiêu',
    route: 'reportsFinishLevel',
  },
  {
    title: 'Báo cáo doanh số theo nhân viên',
    route: 'reportsEmployeeKpiSales',
  },
  {
    title: 'Báo cáo thống kê nhân sự',
    route: 'reportStatsHrm',
  },
  {
    title: 'Báo cáo số dư quỹ và các ngân hàng',
    route: 'reportbankBalance',
  },
  {
    title: 'Báo cáo tổng hợp chi phí trong năm',
    route: 'ReportFavoriteCostRatioYear',
  },
  {
    title: 'Báo cáo tổng hợp tình hình kinh doanh',
    route: 'reportBusinessSituation',
  },
  {
    title: 'Báo cáo top khách hàng thu tiền nhiều nhất trong tháng',
    route: 'reportTopCustomerReceiptsMonth',
  },
  {
    title: 'Báo cáo tiến độ công việc',
    route: 'reportProgressTask',
  },
  {
    title: 'Báo cáo tồn kho trong năm',
    route: 'reportInventoryByYear',
  },
  {
    title: 'Báo cáo chi tiết bán hàng theo nhân viên',
    route: 'ReportSalesEmployees',
  },
  {
    title: 'Báo cáo tổng hợp doanh thu',
    route: 'reportAggregateRevenue',
  },
  {
    title: 'Báo cáo tỷ lệ hoàn thành chỉ tiêu doanh số tháng',
    route: 'reportMonthlySalesTarget',
  },
  {
    title: 'Báo cáo doanh thu, doanh số nhân viên',
    route: 'reportSellEmployee',
  },
  {
    title: 'Email',
    route: 'Email',
  },
  {
    title: 'SMS',
    route: 'SMS',
  },
  {
    title: 'Cấu hình kho',
    route: 'StockConfig',
  },
  {
    title: 'Nhóm phê duyệt động',
    route: 'ApproveGroup',
  },
  {
    title: 'Tài khoản ngân hàng',
    route: 'BankAccount',
  },
  {
    title: 'Quản lý phòng họp',
    route: 'MettingRoom'
  },
  {
    title: 'Bán hàng đa kênh',
    route: 'ContactCenter'
  },
  {
    title: 'Tài khoản ngân hàng',
    route: 'BankAccount'
  },
  {
    title: 'Cấu hình CRM',
    route: 'CrmSource',
  },
  {
    title: 'Tài sản',
    route: 'Asset',
  },
  {
    title: 'Cấp phát',
    route: 'Allocate',
  },
  {
    title: 'IEVN - Báo cáo công tác tuần',
    route: 'reportWeekTask',
  },
  {
    title: 'IEVN - Báo cáo công nợ dự án',
    route: 'reportTaskDebt',
  },
  {
    title: 'IEVN - Báo cáo tổng hợp công việc',
    route: 'reportTaskSummary',
  },
  {
    title: 'IEVN - Báo cáo tổng hợp giá trị hợp đồng và thanh toán',
    route: 'reportContractValueAndPaid',
  },
  {
    title: 'IEVN - Báo cáo đã xuất bản trong tuần',
    route: 'reportContractReported',
  },
  {
    title: 'Thiết lập máy chấm công',
    route: 'TimeKeepingEquipment',
  },
  {
    title: 'Cấu hình',
    route: 'DocumentConfig',
  },
  {
    title: 'Loại biểu mẫu',
    route: 'TemplateType',
  },
  {
    title: 'Lịch sử cập nhật',
    route: 'ModuleHistory',
  },
  {
    title: 'Thai sản',
    route: 'MaternityProcess',
  },
  {
    title: 'Đào tạo',
    route: 'EducateProcess',
  },
  {
    title: 'Kiêm nhiệm',
    route: 'Concurrently',
  },
  {
    title: 'Khen thưởng con',
    route: 'BonusChild ',
  },
  {
    title: 'Công tác',
    route: 'BusinessTrip'
  },
  {
    title: 'Tiêu chí và kế hoạch',
    route: 'kpiCriteriaAndPlan'
  },
  {
    title: 'Bảng quy đổi điểm số',
    route: 'kpiScoreConversionTable'
  },
  {
    title: 'Hợp đồng khách hàng',
    route: 'crmCustomerContract'
  },
  {
    title: 'Hợp đồng nhà cung cấp',
    route: 'crmSupplierContract'
  },
  {
    title: 'Kho trên hạn mức',
    route: 'stockAboveTheLimit'
  },
  {
    title: 'Kho dưới hạn mức',
    route: 'stockBelowLimit'
  },
  {
    title: 'Nhập đơn hàng',
    route: 'stockOrderEntry'
  },
  {
    title: 'Nhập hàng PO',
    route: 'stockOderPo'
  },
  {
    title: 'Nhập hàng trực tiếp',
    route: 'stockOrderDirectly'
  },
  {
    title: 'Phê duyệt chuyển kho',
    route: 'stockWarehouseTransfeApproval'
  },
  {
    title: 'Xuất theo đơn hàng',
    route: 'stockExportByOrder'
  },
  {
    title: 'Xuất hàng trực tiếp',
    route: 'stockDirectShipment'
  },
  {
    title: 'Trả hàng',
    route: 'stockPayTheOrder'
  },
  {
    title: 'Yêu cầu chuyển kho',
    route: 'stockRequestWarehouseTransfer'
  },
  {
    title: 'Xuất hàng theo lô',
    route: 'stockShipmentInBatches'
  },
  {
    title: 'Xuất hàng theo hợp đồng',
    route: 'stockContractDelivery'
  },
  ...historyDataModuleStatic
];
