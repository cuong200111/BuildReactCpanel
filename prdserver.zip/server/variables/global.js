global.hshCollections = {};
global.hshCollectionsTitle = {};
global.hshPlugins = {};
global.hshViewConfig = {};
