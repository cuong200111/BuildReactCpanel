module.exports = {
  UID: 'uid',
  OID: 'organizationUnitId'
};
