const permissionAction = {
  READ: 1,
  INSERT: 2,
  EDIT: 3,
  DELETE: 4,
  EXPORT: 5,
  IMPORT: 6,
};

module.exports = permissionAction;
