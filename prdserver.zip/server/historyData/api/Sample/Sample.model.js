const Promise = require('bluebird');
const mongoose = require('mongoose');
const httpStatus = require('http-status');
const APIError = require('../../../helpers/APIError');
const STATUS = require('../../../variables/CONST_STATUS').STATUS;
const dynamicSchema = require('../../../helpers/dynamic-collection');
const modelHelper = require('../../../helpers/model');
const common = require('../../../helpers/common');
const orgFilter = require('../checkOrg/checkOrg');
const searchFullText = require('../../../helpers/searchFullText');
/**
 * crm-Source Schema
 */

// eslint-disable-next-line func-names
module.exports = function (title) {
  const code = 'Sample';
  const plugins = [];

  if (Object.prototype.hasOwnProperty.call(global.hshCollections, code)) {
    return global.hshCollections[code];
  }

  // eslint-disable-next-line func-names
  return (async function () {
    const SampleRaw = {
      code: String,
      name: String,
      documentDate: Date,
      status: {
        type: Number,
        enum: [0, 1, 2, 3],
        default: 1,
      },
      kanbanStatus: String,
      createAt: Date,
      isActive: Boolean,
      org: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'OrganizationUnit'
      },
      join: [
        {
          type: mongoose.Schema.Types.ObjectId,
          ref: 'Employee'
        },
      ],
      count: Number,
      type: {
        title: String,
        value: String
      },
      abstract: String,
      createdBy: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Employee'
      },
      organizationUnitId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'OrganizationUnit'
      },
    };

    const dynamicParsed = modelHelper.parseRawModel(SampleRaw);
    const SourceSchema = new mongoose.Schema(dynamicParsed.schema);
    SourceSchema.method({});
    const listEn = ['name', 'code', 'asbstract'];
    SourceSchema.pre('save', async function preSave(next) {
      try {
        listEn.forEach((field) => {
          if (this[field]) {
            this[`${field}_en`] = common.removeVietnameseTones(this[field]);
          }
        });
        if (this.createdBy) {
          const org = await global.hshCollections.Employee.findOne({ _id: this.createdBy }, 'organizationUnit');
          if (org && org.organizationUnit && org.organizationUnit.organizationUnitId) {
            this.organizationUnitId = org.organizationUnit.organizationUnitId;
          }
        }
      } catch (error) {
        next(error);
      }
    });
    SourceSchema.statics = {
      getListEn() {
        return listEn;
      },
      get(id) {
        return this.findOne({
          _id: id,
          status: STATUS.ACTIVED,
        }).populate('org')
          .populate('join', 'name code')
          .exec()
          .then((customer) => {
            if (customer) {
              return customer;
            }
            const err = new APIError('No such customer exists!', httpStatus.NOT_FOUND);
            return Promise.reject(err);
          });
      },
      async list({
        skip = 0,
        limit = 500,
        sort = {
          createdAt: -1,
        },
        filter = {
          status: 1,
        },
        user
      }) {
        searchFullText(filter);
        const filterOrg = await orgFilter.checkOrgFilter(filter, user, code);
        const filterRole = await common.filterRoleTask({ filter: filterOrg, user, code });
        const data = await this.find(filterRole)
          .populate('org')
          .populate('join', 'name code')
          .sort(sort)
          .skip(+skip)
          .limit(+limit)
          .exec();
        const count = await this.count(filterRole);
        return {
          data,
          count,
          limit,
          skip,
          filterRole
        };
      },
    };

    const schema = await dynamicSchema.addDynamicCollectionFromCode(dynamicParsed, SourceSchema, code, plugins);

    // use default controller

    return dynamicSchema.addModelToCode(code, schema, title);
  }());
};
