
const APIError = require('../../../helpers/APIError');
const httpStatus = require('http-status');
const STATUS = require('../../../variables/CONST_STATUS').STATUS;
const sample = require('./Sample.model')();
const Notice = require('../../sendNotice/sendNotice')
const moment = require('moment');

const load = async (req, res, next, id) => {
  req.sample = await sample.get(id);
  if (!req.sample) {
    next(new APIError('Item not found', httpStatus.NOT_FOUND, true));
  }
  next();
};

const list = async (req, res, next) => {
  try {
    const { sort, filter, skip, limit } = req.query;
    const user = req.user.user;
    const Sameple = await sample.list({
      skip,
      limit,
      sort,
      filter,
      user
    });
    res.json(Sameple);
  } catch (e) {
    next(e);
  }
};

const get = (req, res) => {
  res.json(req.sample);
};
const create = async (req, res, next) => {
  try {
    const body = req.body;
    const user = req.user.user;
    body.createdBy = user;
    const saveData = new sample(body);

    const dataSave = await saveData.save();
    if (body.join && Array.isArray(body.join) && body.join.length) {
      body.join.map(async (item) => {
        const notice = {
          title: `Bạn được mới tham gia công việc ${dataSave.name || ''}`,
          content: 'thông báo',
          to: item,
          link: `/Sample/${dataSave._id.toString()}`,
          subCode: 'Sample',
        };
        await Notice.sendNotice(notice);
      });
    }
    if (dataSave) {
      return res.json(dataSave);
    } else {
      return res.json({ status: 0, message: 'Can not create item' });
    }
  } catch (e) {
    next(e);
  }
};

const del = async (req, res, next) => {
  try {
    const data = req.sample;
    data.status = STATUS.DELETED;
    data
      .save()
      .then(
        res.transformer
          .noContent()
          .withStatus(httpStatus.OK)
          .dispatch(),
      )
      .catch(e => next(e));
  } catch (e) {
    next(e);
  }
};

const update = async (req, res, next) => {
  try {
    const body = req.body;
    const dataSave = req.sample;
    Object.keys(body).forEach((key) => {
      dataSave[key] = body[key];
    });
    const data = await dataSave.save();
    if (data.join && Array.isArray(data.join) && data.join.length) {
      body.join.map(async (item) => {
        const notice = {
          title: `Bạn được mới tham gia công việc ${data.name || ''}`,
          content: 'thông báo',
          to: item,
          link: `/Sample/${data._id.toString()}`,
          subCode: 'Sample',
        };
        await Notice.sendNotice(notice);
      });
    }
    return res.json(data);
  } catch (e) {
    next(e);
  }
};

async function deletedList(req, res, next) {
  try {
    const { ids } = req.body;
    const arrDataDelete = ids.map(async (item) => {
      const org = await sample.findById(item);
      if (org) {
        org.status = STATUS.DELETED;
        org.deletedBy = req.user.user;
        org.deletedAt = new Date();
        return org.save();
      }
    });
    const deletedData = await Promise.all(arrDataDelete);
    res.json({
      success: true,
      data: deletedData,
    });
  } catch (e) {
    next(e);
  }
}
module.exports = {
  load,
  list,
  get,
  create,
  update,
  del,
  deletedList
};
