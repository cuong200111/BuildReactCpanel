// eslint-disable-next-line new-cap
const express = require('express');
const X06SourceCtrl = require('./Sample.controller');
const router = express.Router();
router
  .route('/')
  .post(X06SourceCtrl.create)
  .get(X06SourceCtrl.list)
  .delete(X06SourceCtrl.deletedList);

router
  .route('/:SampleId')
  .get(X06SourceCtrl.get)
  .put(X06SourceCtrl.update);
router.param('SampleId', X06SourceCtrl.load);
module.exports = router;
