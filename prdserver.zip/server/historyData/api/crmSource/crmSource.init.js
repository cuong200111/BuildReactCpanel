
const crmSource = [
  {
    title: 'loại',
    status: 1,
    code: 'SAM0002',
    type: 'sample',
    data: [
      {
        title: 'Thực tập sinh',
        value: 1,
      },
      {
        title: 'Nhân sự thử việc',
        value: 2,
      },
      {
        title: 'Nhân viên chính thức',
        value: 3,

      },
    ],
  },
];
module.exports = {
  crmSource,
};
