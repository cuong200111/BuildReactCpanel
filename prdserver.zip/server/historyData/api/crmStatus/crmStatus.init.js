const crmStatus = [
  {
    title: 'Trạng thái mẫu',
    status: 1,
    code: 'SAM001',
    type: 'sample',
    data: [
      {
        name: 'Công việc mới',
        color: '#3EA8EB',
        isDelete: false,
        code: 1,
        type: 1,
      },
      {
        name: 'Công việc hoàn thành',
        color: '#008000',
        isDelete: false,
        code: 3,
        type: 3,
      },
      {
        name: 'Công việc thất bại',
        color: '#FF0000',
        index: 1,
        isDelete: false,
        code: 4,
        type: 4,
      },
    ],
  },
];
module.exports = {
  crmStatus,
};