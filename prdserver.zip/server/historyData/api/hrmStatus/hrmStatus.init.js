const hrmStatus = [
];

module.exports = {
  hrmStatus,
};
