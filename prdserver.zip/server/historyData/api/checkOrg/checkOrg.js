const Employee = require('../../../api/employee/employee.model');
// const Task = require('./task.model')();
const OrganizationUnit = require('../../../api/organizationUnit/organizationUnit.model');
const getTree = require('../../../helpers/common').getTree;
const STATUS = require('../../../variables/CONST_STATUS').STATUS;
const objectId = require('mongoose').Types.ObjectId;
async function checkOrgFilter(filter, user, code) {
  if (filter.$or) {
    const filterOr = { $or: filter.$or };
    const and = [];
    and.push(filterOr);
    // filter.$and = and;
    // eslint-disable-next-line no-unused-expressions
    filter.$and ? filter.$and.push(filterOr) : (filter.$and = and);
  }
  const or = [];
  let organizationIds;
  if (
    Object.keys(filter).includes('organizationUnit') ||
    Object.keys(filter).includes('organizationUnitId') ||
    Object.keys(filter).includes('organizationUnit.organizationUnitId')
  ) {
    const findEmp = await getOrganization(
      user,
      filter.organizationUnit || filter.organizationUnitId || filter['organizationUnit.organizationUnitId'],
    );
    organizationIds = findEmp.array.map(item => objectId(item._id));
    // filter.organizationUnit = organizationIds;
  }
  if (code === 'hrm') {
    if (!Object.keys(filter).includes('organizationUnit')) {
      const findEmp = await getOrganization(user);
      organizationIds = findEmp.array.map(item => objectId(item._id));
      const organizationUnit = { organizationUnit: { $in: organizationIds } };
      or.push(organizationUnit);
    } else {
      const organizationUnit = { organizationUnit: { $in: organizationIds } };
      or.push(organizationUnit);
    }
  }

  if (code === 'Employee') {
    if (!Object.keys(filter).includes('organizationUnit.organizationUnitId')) {
    } else {
      const organizationUnit = { 'organizationUnit.organizationUnitId': { $in: organizationIds } };
      or.push(organizationUnit);
    }
  }
  if (code === 'Task' || code === 'Documentary' || code === 'outGoingDocument' || code === 'inComingDocument') {
    if (!Object.keys(filter).includes('organizationUnit')) {
      const findEmp = await getOrganization(user);
      organizationIds = findEmp.array.map(item => objectId(item._id));
      const organizationUnit = { organizationUnit: { $in: organizationIds } };
      or.push(organizationUnit);
    } else {
      const organizationUnit = { organizationUnit: { $in: organizationIds } };
      or.push(organizationUnit);
    }
  }

  if (
    (!Object.keys(filter).includes('organizationUnit') && code === 'Customer') ||
    (!Object.keys(filter).includes('organizationUnit') && code === 'BusinessOpportunities')
  ) {
    const findEmp = await Employee().findById({ _id: user });
    if (findEmp.workingOrganization) {
      filter.organizationUnitId = findEmp.workingOrganization;
    }
  }
  delete filter.organizationUnit;
  // delete filter.organizationUnitId;
  delete filter['organizationUnit.organizationUnitId'];
  if (or.length !== 0) {
    filter.$or = or;
  }
  return filter;
}
async function getOrganization(employeeId, orgId) {
  try {
    if (!orgId) {
      const employee = await global.hshCollections.Employee.findOne({ _id: employeeId });
      orgId = employee.workingOrganization
        ? employee.workingOrganization
        : employee.organizationUnit.organizationUnitId;
    }

    const regex = new RegExp(`\\b${orgId}\\b`, 'i');
    const organizationUnit = await OrganizationUnit.find({ path: regex, status: STATUS.ACTIVED }).lean();
    // console.log(organizationUnit);
    if (!organizationUnit || !organizationUnit.length) {
      throw new Error('Tài khoản chưa thuộc phòng ban nào');
    }
    organizationUnit[0].parent = null;
    return {
      array: organizationUnit,
      tree: getTree(organizationUnit, organizationUnit),
    };
  } catch (error) {
    console.log('err: ', error);
    throw error;
  }
}
module.exports = {
  checkOrgFilter
}