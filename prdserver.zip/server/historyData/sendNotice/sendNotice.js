
const Employee = require('../../api/employee/employee.model')();
const Notification = require('../../api/notification/notification.model');
const { STATE, STATUS, RABBIT_CHANNEL, STATUS_ACCEPT } = require('../../variables/CONST_STATUS');

async function sendNotice({ title, content, to, link, type = 'System', auto, subCode, docId }, notice = true) {
  let sendTo = to;
  let topic = to;
  if (String(to).length === 24) {
    const emp = await Employee.findOne({
      $or: [
        {
          _id: to,
        },
        {
          userId: to,
        },
      ],
    });
    if (emp) {
      sendTo = emp._id;
    }
    if (emp && emp.userId) {
      topic = emp.userId;
    }
  }
  const notification = new Notification({
    docId,
    title,
    content,
    subCode,
    type,
    link,
    to: sendTo,
    date: new Date(),
  });
  const newNoti = await notification.save();
  if (!notice) return;
  const chan = global.hshCollections.chan;
  if (chan && !auto) {
    if (newNoti.to && String(newNoti.to).length === 24) {
      const emp = await Employee.findOne({
        $or: [
          {
            _id: to,
          },
          {
            userId: to,
          },
        ],
      });
      if (emp) {
        sendTo = emp._id;
      }
      if (emp && emp.userId) {
        topic = emp.userId;
      }
    }
    if (topic) {
      const messageNov = {
        notification: {
          title: newNoti.title,
          body: newNoti.content,
        },
        topic,
      };

      const url = process.env.HOST_NAME || 'https://g.lifetek.vn:282';
      if (url) {
        messageNov.webpush = {
          fcm_options: {
            link: url + newNoti.link,
          },
        };
      }
      const client = process.env.CLIENT_NOTIFICATION || '08_CRM';
      chan.then(c =>
        c.publish(
          RABBIT_CHANNEL.NOTIFICATION,
          `${client}.${RABBIT_CHANNEL.NOTIFICATION}`,
          Buffer.from(JSON.stringify(messageNov)),
        ),
      );
    }
  }
  if (global.hshUserSocket[sendTo]) {
    global.io.to(global.hshUserSocket[sendTo]).emit('notice', { content });
  }
}
module.exports = {
  sendNotice
};
