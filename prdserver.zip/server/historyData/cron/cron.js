// const cron = require('cron');
// const { cronDraft } = require('../taskPlan/taskPlan.service');


// const cronDraftTaskPlan = new cron.CronJob({
//   cronTime: '0 0 0 * * *',
//   onTick() {
//     cronDraft();
//   },
//   start: true,
//   timeZone: 'Asia/Ho_Chi_Minh', // Lưu ý set lại time zone cho đúng
// });


// module.exports = { cronDraftTaskPlan, };
