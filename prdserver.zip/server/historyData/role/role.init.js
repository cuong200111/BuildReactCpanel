const initRole = [
  // {
  //   code: 'NATURE',
  //   name: 'Tính năng',
  //   moduleCode: 'X06_PartyMemberInfo',
  //   type: 1,
  //   column: [{ name: 'access', title: 'Truy cập' }],
  //   row: [
  //     { name: 'all', title: 'Tất cả' },
  //     { name: 'MemberInfo', title: 'Thông tin đảng viên' },
  //     // { name: 'signalInfring', title: 'Đảng viên có dấu hiệu vi phạm' },
  //     // { name: 'infringe', title: 'Đảng viên đã vi phạm' },
  //   ],
  //   data: [
  //     { name: 'all', data: { access: true } },
  //     { name: 'MemberInfo', data: { access: true } }
  //     // { name: 'signalInfring', data: { access: true } },
  //     // { name: 'infringe', data: { access: true } },
  //   ],
  // },
];

module.exports = initRole;
