async function loadAllSchema() {
  return new Promise(async (resolve, reject) => {
    resolve(
      await require('../api/Sample/Sample.model')('Mẫu'),
    );
  });
}

module.exports = loadAllSchema;
