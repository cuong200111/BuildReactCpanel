const express = require('express');
const auth = require('../middleware/auth-strategy');
// eslint-disable-next-line new-cap
const router = express.Router();


const Sample = require('./api/Sample/Sample.route');

router.use('/sample', auth.isAuthenticated, Sample);


module.exports = router;
