module.exports = [
  {   // mẫu
    title: 'Mẫu',
    route: 'Sample'
  },
];
