const BaseDC = require('../helpers/d-collection-decorator/base-decorator');
const mongoose = require('mongoose');

class KanbanDecorator extends BaseDC {
  constructor(collectionSchema, mongooseSchema, code) {
    super(collectionSchema, mongooseSchema, code);

    const newObj = {
      kanbanStatus: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'CrmStatus',
      },
    };

    this.parseAndUpdateNewField(newObj);
    // this.mongooseSchema = new mongoose.Schema(this.collectionSchema);
    // eslint-disable-next-line max-len
    this.mongooseSchema = this.mergeMongoSchema(new mongoose.Schema(this.collectionSchema), this.mongooseSchema);
  }
}

module.exports = KanbanDecorator;
