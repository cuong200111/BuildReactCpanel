/* eslint-disable prefer-arrow-callback */
/* eslint-disable func-names */
const BaseDC = require('../helpers/d-collection-decorator/base-decorator');
const rabbitNotify = require('../helpers/rabbitmq/log').notify;
const config = require('config');
// const deepcopy = require('deepcopy');

class NotifyDecorator extends BaseDC {
  constructor(collectionSchema, mongooseSchema, code) {
    super(collectionSchema, mongooseSchema, code);
    this.mongooseSchema.pre('save', async function(next) {
      try {
        const SchemaModel = global.hshCollections[code];
        const collection = await SchemaModel.findById(this._id);
        const oldData = JSON.parse(JSON.stringify(collection));
        if (oldData) {
          oldData.oldObject = {};
          this.oldObject = oldData;
        }
        next();
      } catch (error) {
        console.log(error);
      }
    });
    this.mongooseSchema.post('save', function(doc) {
      // console.log('test notify plugin');

      const sendDoc = JSON.parse(JSON.stringify(doc.toObject()));
      // const sendDoc = doc.toObject();
      sendDoc.actionType = 'create';

      sendDoc.senderCode = code;
      sendDoc.from = config.get('local.name');
      // console.log('Send to RabbitMQ Notify!');
      rabbitNotify(sendDoc);
    });
  }
}

module.exports = NotifyDecorator;
