const PLUGIN_CODE = require('../variables/CONST_STATUS').PLUGINS;
const LoggingDecorator = require('./logging.plugin');
const NotifyDecorator = require('./notify.plugin');
const KanbanDecorator = require('./kanban.plugin');
const AutomationDecorator = require('./automation.plugin');

function addPlugins(code, plugins, decorator) {
  let retDecorator = decorator;
  plugins.forEach((plugin) => {
    if (plugin.isActive) {
      switch (plugin.code) {
      //   case PLUGIN_CODE.PL_ATTRIBUTE_SET:

      //     retDecorator = new AttributeDecorator(
      //       retDecorator.getCollectionSchema(),
      //       retDecorator.getMongooseSchema(),
      //         code);

      //     break;

        case PLUGIN_CODE.PL_VIEW_KANBAN:
          retDecorator = new KanbanDecorator(
            retDecorator.getCollectionSchema(),
            retDecorator.getMongooseSchema(),
              code);
          break;

        case PLUGIN_CODE.PL_LOG:
          retDecorator = new LoggingDecorator(
            retDecorator.getCollectionSchema(),
              retDecorator.getMongooseSchema(),
              code);
          break;

        case PLUGIN_CODE.PL_NOTIFY:
          retDecorator = new NotifyDecorator(
            retDecorator.getCollectionSchema(),
              retDecorator.getMongooseSchema(),
              code);
          break;


        case PLUGIN_CODE.PL_AUTOMATION:
          retDecorator = new AutomationDecorator(
            retDecorator.getCollectionSchema(),
              retDecorator.getMongooseSchema(),
              code);
          break;

        default:
          break;
      }
    }
  });

  return retDecorator;
}


module.exports = {
  addPlugins
};
