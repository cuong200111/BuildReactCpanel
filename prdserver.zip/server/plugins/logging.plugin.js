/* eslint-disable prefer-arrow-callback */
/* eslint-disable func-names */
const BaseDC = require('../helpers/d-collection-decorator/base-decorator');
// const rabbitLog = require('../helpers/rabbitmq/rabbit-handler').log;

class LoggingDecorator extends BaseDC {
  constructor(collectionSchema, mongooseSchema, code) {
    super(collectionSchema, mongooseSchema, code);

    // eslint-disable-next-line no-unused-vars
    this.mongooseSchema.post('save', function(doc) {
      console.log('test log plugin');

      // rabbitLog(doc);
    });
  }
}

module.exports = LoggingDecorator;
