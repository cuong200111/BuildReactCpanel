/* eslint-disable func-names */
/* eslint-disable prefer-arrow-callback */
const BaseDC = require('../helpers/d-collection-decorator/base-decorator');
// const rabbitHelper = require('../helpers/rabbitmq/rabbit-handler');

class AutomationDecorator extends BaseDC {
  constructor(collectionSchema, mongooseSchema, code) {
    super(collectionSchema, mongooseSchema, code);


    this.mongooseSchema.post('save', function (doc) {
      console.log('test automation ', doc.toObject());
    });
  }
}

module.exports = AutomationDecorator;
