/* eslint-disable consistent-return */
/* eslint-disable keyword-spacing */
const config = require('config');
const moment = require('moment');
const filter = require('../helpers/rabbitmq/log').filter;

const mongoose = require('mongoose');
// require('mongoose').model('User').schema.add({fullName: String});
module.exports =  function (data) {
  // eslint-disable-next-line consistent-return
  return new Promise(async (resolve, reject) => {
    if (data.collectionCode) {
      const models = mongoose.model(data.collectionCode);
      if (models) {
        models.schema.add({ automationRuleIds: [], checkLoop: String });
        await filterRule(models, data);
      }
    }
  });
};

async function filterRule(models, dataFiler) {
  try {
    const data = dataFiler;
   
    if (data.automationRuleId) {
      if (!global[data.automationRuleId]) {
        global[data.automationRuleId] = {
          isRun: 1,
          filter: data.filter
        };
      }
      // data = global[dataFilter.automationRuleId] = dataFilter;
      // const doc = await models.findOne({ note_en: 'sendmail' });
      const filters = global[data.automationRuleId].filter;
      let doc;
      // console.log('global[data.automationRuleId].isRun:: ', global[data.automationRuleId].isRun);
      if (global[data.automationRuleId].isRun === 1) {
        global[data.automationRuleId].isRun = 0;
        doc = await models.findOne(filters).lean();
        // if(filters.$and[0] && filters.$and[0].$or) {
        //   console.log('filters:: ', filters.$and[0].$or);
        // }
        // console.log('automationRuleId:: ', data.automationRuleId);
        // console.log('doc:: ', doc);
        if (!doc) {
          delete global[data.automationRuleId];
          return null;
        }
        const sendDoc = JSON.parse(JSON.stringify(doc));
        sendDoc.senderCode = data.collectionCode;
        sendDoc.from = config.get('local.name');
        sendDoc.automationRuleId = data.automationRuleId;
        if (sendDoc.automationRuleIds) {
          if (sendDoc.automationRuleIds && Array.isArray(sendDoc.automationRuleIds)) {
            const indexRuleId = sendDoc.automationRuleIds.findIndex((f) => String(f) === String(data.automationRuleId));
            if (indexRuleId === -1) {
              sendDoc.automationRuleIds.push(data.automationRuleId);
            }
          } else {
            sendDoc.automationRuleIds = [sendDoc.automationRuleIds, data.automationRuleId];
          }
        } else {
          sendDoc.automationRuleIds = [data.automationRuleId];
        }
        if (data.actions) {
          data.actions = await findSendTo(data.actions, doc, data.automationRuleId);
        }
        const success = await filter(sendDoc, data);
        // console.log('success:: ', success);
        global[data.automationRuleId].isRun = 1;
        if (success) {
          // console.log('sendDoc.automationRuleIds:: ', sendDoc.automationRuleIds);
          // console.log('models:: ', models);checkLoop
          const update = {
          }
          if(data.checkLoop) {
            update.checkLoop = moment().format('YYYY-MM-DD');
          } else {
            update.automationRuleIds = sendDoc.automationRuleIds;
          }
          const dataUp = await models.findByIdAndUpdate(
            sendDoc._id,
            { $set: update },
            { new: true },
          );
          if (dataUp) {
            // console.log('dataUp:: ', dataUp);
            // return await filterRule(models, data);
          }
        }
      }
      return doc;
    }
    return;
  } catch (error) {
    // console.log('filterRule:: ', error);
    // console.log('models:: ', models);
    // console.log('dataFiler:: ', dataFiler);
    delete global[dataFiler.automationRuleId];
    throw error;
  }
}

async function findSendTo(actions = [], docs, automationRuleId) {
  try {
    const action = [...actions];
    const doc = {...docs};
    // console.log('docs:: ', docs);
    return await Promise.map(action, async (ac) => {
      if (ac && ac.sendTo && Array.isArray(ac.sendTo) && ac.sendTo.length > 0) {
        ac.data = [];
        let dataConcat = [];
        dataConcat = await Promise.map(ac.sendTo, async (s) => {
          let filterData = [];
          let filterAc = [];
          // console.log('s:: ', s);
          // console.log('s.ref:: ', s.ref);
          // console.log('s.field:: ', s.field);
          if (s.ref && s.field) {
            if (typeof s.field === 'string') {
              if (String(s.field).includes('Array')) {
                const ArrayFile = String(s.field).split('|');
                const fieldDoc = ArrayFile[1];
                const fieldSend = ArrayFile[2];
                const select = ArrayFile[3];
                // console.log('fieldDoc:: ', fieldDoc);
                // console.log('ArrayFile:: ', ArrayFile);
                // console.log('fieldSend:: ', fieldSend);
                // console.log('doc:: ', doc);
                // console.log('doc fieldDoc:: ', doc[fieldDoc]);
                if (fieldDoc && doc[fieldDoc] && Array.isArray(doc[fieldDoc]) && fieldSend) {
                  if (ArrayFile.length > 3) {
                    // console.log('fieldSend:: ', fieldSend);
                    const fieldRef = fieldSend.split(',');
                    // console.log('fieldRef:: ', fieldRef);
                    if (fieldRef[0] && fieldRef[1]) {
                      let modelRef = global.hshCollections[fieldRef[1]];
                    
                      if (!modelRef) {
                        modelRef = mongoose.model(fieldRef[1]);
                      }
                      // console.log('modelRef:: ', modelRef);
                      if (modelRef) {
                        const ids = doc[fieldDoc].filter(f => f && f[fieldRef[0]] && String(f[fieldRef[0]]).length === 24).map(m => m[fieldRef[0]]);
                        // console.log('ids:: ', ids);
                        if (ids.length) {
                          const docRef = await modelRef.find({ _id: { $in: ids } }, select);
                          if (docRef && docRef.length) {
                            docRef.map(m => {
                              if (m[select]) {
                                if (Array.isArray(m[select])) {
                                  filterAc = [...filterAc, ...m[select]];
                                } else if (String(m[select]).length === 24) {
                                  filterAc.push(m[select]);
                                }
                              }
                              // console.log('filterAc ??? :: ', filterAc);
                            })
                          }
                        }
                      }
                    }
                  }
                  //  else {
                  //   s.field = doc[fieldDoc].filter(f => f[fieldSend]).map(m => String(m[fieldSend]).length === 24);
                  // }
                }
              } else {
                s.field = [s.field];
              }
            } else if (Array.isArray(s.field)) {
              await Promise.map(s.field, async fi => {
                if (String(fi).includes('Array')) {
                  const ArrayFile = String(fi).split('|');
                  const fieldDoc = ArrayFile[1];
                  const fieldSend = ArrayFile[2];
                  const select = ArrayFile[3];
                  // console.log('fieldDoc:: ', fieldDoc);
                  // console.log('ArrayFile:: ', ArrayFile);
                  // console.log('fieldSend:: ', fieldSend);
                  // console.log('doc:: ', doc);
                  // console.log('doc fieldDoc:: ', doc[fieldDoc]);
                  if (fieldDoc && doc[fieldDoc] && Array.isArray(doc[fieldDoc]) && fieldSend) {
                    if (ArrayFile.length > 3) {
                      // console.log('fieldSend:: ', fieldSend);
                      const fieldRef = fieldSend.split(',');
                      // console.log('fieldRef:: ', fieldRef);
                      if (fieldRef[0] && fieldRef[1]) {
                        let modelRef = global.hshCollections[fieldRef[1]];
                      
                        if (!modelRef) {
                          modelRef = mongoose.model(fieldRef[1]);
                        }
                        // console.log('modelRef:: ', modelRef);
                        if (modelRef) {
                          const ids = doc[fieldDoc].filter(f => f && f[fieldRef[0]] && String(f[fieldRef[0]]).length === 24).map(m => m[fieldRef[0]]);
                          // console.log('ids:: ', ids);
                          if (ids.length) {
                            const docRef = await modelRef.find({ _id: { $in: ids } }, select);
                            // console.log('select:: ', select);
                            // console.log('docRef:: ', docRef);
                            if (docRef && docRef.length) {
                              docRef.map(m => {
                                if (m[select]) {
                                  // console.log('docRef:: ', docRef);
                                  if (Array.isArray(m[select])) {
                                    filterAc = [...filterAc, ...m[select]];
                                  } else if (String(m[select]).length === 24) {
                                    filterAc.push(m[select]);
                                  }
                                }
                                // console.log('filterAc ??? :: ', filterAc);
                              })
                            }
                          }
                        }
                      }
                    }
                    //  else {
                    //   s.field = doc[fieldDoc].filter(f => f[fieldSend]).map(m => String(m[fieldSend]).length === 24);
                    // }
                  }
                }
              }) 
              
            }
            await Promise.map(s.field, async f => {
              if (Array.isArray(doc[f])) {
                await Promise.map(doc[f], async m => {
                  if (String(m).length === 24) {
                    filterAc.push(m)
                  } else if (typeof m === 'object' && !Array.isArray(m)) {
                    for (var key in m) {
                      if (key !== '_id' && key !== 'id' && String(m[key]).length === 24) {
                        filterAc.push(m[key]);
                      }
                    }
                  }
                })
              } else if (String(doc[f]).length !== 24 && typeof doc[f] === 'object' && !Array.isArray(doc[f])) {
                for (var key in doc[f]) {
                  if (key !== '_id' && key !== 'id' && String(doc[f][key]).length === 24) {
                    filterAc.push(doc[f][key]);
                  }
                }
              } else if (String(doc[f]).length === 24) {
                filterAc.push(doc[f]);
              }
            })
            const models = mongoose.model(s.ref);
            if (models && filterAc.length > 0) {
              filterData = await models.find({ _id: { $in: filterAc } });
              // console.log('filterData:: ', filterData);
            }
          }
          return filterData;
        });

        if (!dataConcat) {
          dataConcat = [];
        }
        ac.data = dataConcat.reduce((x, y) => x.concat(y));
      }
      return ac;
    });
  } catch (error) {
    console.log('findSendTo:: ', error);
    delete global[automationRuleId];
    throw error;
  }
}
