// const logger = require('winston');
// const mongoose = require('mongoose');
const notificationCtrl = require('../api/notification/notification.controller');
const Employee = require('../api/employee/employee.model');
const { RABBIT_CHANNEL } = require('../variables/CONST_STATUS');

// eslint-disable-next-line func-names
module.exports = function (data, channel) {
  return new Promise((resolve, reject) => {
    let action;

    switch (channel) {

      case RABBIT_CHANNEL.SHARE_QUEUE.NOTIFICATION:
        action = notification(data);
        break;

      default:
        break;
    }

    if (!action) {
      reject('Not found action');
    }
    action
      .then(doc =>
        resolve(doc)
      )
      .catch((err) => {
        reject(err);
      });
  });
};


async function notification(data) {
  return new Promise(async (resolve, reject) => {
    const { title,
      content,
      type,
      link,
      to,
      date, } = data;

    // eslint-disable-next-line new-cap
    const employee = await Employee().findOne({ userId: to });
    const process = notificationCtrl.createLocal({
      title,
      content,
      type,
      link,
      to: employee ? employee._id : to,
      date,
    });
    process.then(result => resolve(result)).catch(err => reject(err));
  });
}
