/* eslint-disable new-cap */
/* eslint-disable no-param-reassign */
const config = require('config');
const expressJwt = require('express-jwt');
const jwt = require('jsonwebtoken');
const deepcopy = require('deepcopy');

const roleCtl = require('../api/roleTask/role.controller');
const Employee = require('../api/employee/employee.model');
const OrganizationUnit = require('../api/organizationUnit/organizationUnit.model');

const STATUS = require('../variables/CONST_STATUS').STATUS;

function isAuthenticated(req, res, next) {
  return expressJwt({ secret: config.get('local.jwtSecret') })(req, res, next);
}

function extendedQueryFilter(req, orgIds) {
  if (!req.query) req.query = {};
  if (!req.query.filter) req.query.filter = {};
  const clientFilter = deepcopy(req.query.filter);
  req.query.filter = {
    $or: [
      {
        organizationUnit: {
          $in: orgIds,
        },
      },
      { ...clientFilter },
    ],
  };
}

function extendedBody(req, orgIds) {
  if (!req.body) req.body = {};
  req.body.allowedViewOrgIds = orgIds;
}

function extendedNormalQuery(req, orgIds) {
  if (!req.query) req.query = {};
  req.query.allowedViewOrgIds = orgIds;
}

async function checkAndInitializeSession(req, res, next) {
  if (!req.session) return next(new Error('Session not found'));
  if (!req.user || !req.user.user) {
    return next(new Error('User not authorized'));
  }

  try {
    const userId = req.user.user;

    if (!req.session.workingOrganization) {
      const employeeModel = await Employee();
      const employee = await employeeModel.findOne({ _id: userId });
      // const foundOrg = await OrganizationUnit.findOne({
      //   status: STATUS.ACTIVED,
      //   _id: employee.organizationUnit.organizationUnitId,
      // }).lean();
      const orgId = employee.workingOrganization || (employee.organizationUnit || {}).organizationUnitId;
      const foundOrg = await OrganizationUnit.findOne({
        status: STATUS.ACTIVED,
        _id: orgId,
      }).lean();
      if (!foundOrg) return next(new Error('User is not in a organization'));
      req.session.workingOrganization = foundOrg;
    }
    return next();
  } catch (error) {
    return next(error);
  }
}

function getOrgPermissionMiddleWareByModuleCode(moduleCode, method = 'GET') {
  async function applyOrganizationPermission(req, res, next) {
    const { user } = req;
    const { user: userId } = user;
    const roles = await roleCtl.getRole({ moduleCode, userId });
    const roleDepartment = roles.roles.find(i => i.code === 'DERPARTMENT').data.filter(elm => elm.data.view);
    const roleDepartmentIds = roleDepartment.map(d => d.name);
    if (method === 'GET') {
      extendedQueryFilter(req, roleDepartmentIds);
    }
    if (method === 'NORMAL_GET') {
      // extendedBody(req, roleDepartmentIds);
      extendedNormalQuery(req, roleDepartmentIds);
    }
    if (method === 'NORMAL_POST') {
      // extendedBody(req, roleDepartmentIds);
      extendedBody(req, roleDepartmentIds);
    }

    return next();
  }
  return applyOrganizationPermission;
}

const socketIsAuthenticated = (socket) => {
  socket.use((packet, next) => {
    // console.log('t', socket.handshake.query.token);
    // eslint-disable-next-line no-unused-vars
    // const [namespace, data] = packet;
    // console.log("CONNECTTTT",data);
    if (socket.handshake) {
      jwt.verify(socket.handshake.query.token, config.get('local.jwtSecret'), (err, decoded) => {
        if (decoded) {
          // eslint-disable-next-line no-param-reassign
          socket.join(global.hshSocketUser[socket.id]);
          // eslint-disable-next-line no-param-reassign
          socket.employeeId = decoded.user;

          Employee().findById(global.hshSocketUser[socket.id]).then(user => {
            if (user) {
              user.online = true;
              user.save();
            }
          });
          global.hshSocketUser[socket.id] = socket.employeeId;
          global.hshUserSocket[socket.employeeId] = socket.id;
          global.hshIdSocket[socket.id] = socket;
          global.userCount += 1;
          // console.log('TYYYYYYYY');

          // console.log();
          return next();
        }
        socket.disconnect('unauthorized');
        return next(new Error('Xác thực thất bại'));
      });
    }
  });
};

module.exports = {
  isAuthenticated,
  getOrgPermissionMiddleWareByModuleCode,
  socketIsAuthenticated,
  checkAndInitializeSession,
};
