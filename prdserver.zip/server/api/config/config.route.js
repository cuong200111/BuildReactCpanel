const router = require('express').Router(); // eslint-disable-line new-cap
const configCtrl = require('./config.controller');
const validate = require('express-validation');
const configValid = require('./config.validation');

router
  .route('/')
  /** GET /api/config - List configurations */
  .get(configCtrl.list)
  /** POST /api/config - Create a new configuration */
  .post(validate(configValid.create), configCtrl.create);

router
  .route('/:configId')
  /** PATCH /api/config/:configId - Update configuration */
  .patch(validate(configValid.update), configCtrl.update)
  /** POST /api/config/:configId - Delete configuration */
  .delete(configCtrl.deleteConfig);

router.param('configId', configCtrl.load);
module.exports = router;
