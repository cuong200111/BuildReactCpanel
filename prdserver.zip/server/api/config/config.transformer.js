const AbstractTransformer = require('d-transformer').AbstractTransformer;

/*  eslint-disable  */
class ConfigTransformer extends AbstractTransformer {
  transform(config) {
    return {
      id: config._id,
      key: config.key,
      level: config.level,
      root: config.root,
      attributes: config.attributes,
      parent: config.parent,
    };
  }
}

module.exports = ConfigTransformer;
