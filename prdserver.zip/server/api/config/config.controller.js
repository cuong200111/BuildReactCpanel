const Config = require('./config.model');
const ConfigTransformer = require('./config.transformer');
const ApiError = require('../../helpers/APIError');
const httpStatus = require('http-status');
const _ = require('lodash');

const list = async (req, res, next) => {
  try {
    const { hierarchy } = req.query;

    const configs = await Config.find({})
      .lean()
      .exec();

    if (hierarchy) res.json(hierarchyListing(configs));
    else res.transformer.collection(configs, new ConfigTransformer()).dispatch();
  } catch (e) {
    next(e);
  }
};

function getChildren(rootList, id) {
  return _.filter(rootList, e => e.parent && e.parent.toString() === id);
}

function groupInHierachy(rootList, top = null) {
  let parent = null;
  if (top) parent = _.find(rootList, e => e.id.toString() === top);
  else parent = _.find(rootList, e => e.parent === null);

  const children = getChildren(rootList, parent.id.toString());
  if (children.length === 0) return parent;
  parent.children = _.map(children, child => groupInHierachy(rootList, child.id.toString()));
  return parent;
}

function hierarchyListing(configs) {
  const cleanConfigs = _.map(configs, c => new ConfigTransformer().transform(c));
  const groupedConfigs = _.groupBy(cleanConfigs, config => config.root);

  return _.map(groupedConfigs, (value, key) => groupInHierachy(value, key));
}

const create = async (req, res, next) => {
  try {
    const { key, ...args } = req.body;
    const config = await Config.safeCreate(key, args);

    res.transformer.item(config, new ConfigTransformer()).dispatch();
  } catch (e) {
    next(e);
  }
};

const update = async (req, res, next) => {
  try {
    let config = req.config;
    config = await config.safeUpdate(req.body);
    res.transformer.item(config, new ConfigTransformer()).dispatch();
  } catch (e) {
    next(e);
  }
};

const deleteConfig = async (req, res, next) => {
  try {
    await req.config.safeDelete();

    res.transformer
      .noContent()
      .withStatus(httpStatus.OK)
      .dispatch();
  } catch (e) {
    next(e);
  }
};

const load = async (req, res, next, id) => {
  try {
    const config = await Config.findById(id);
    if (!config) next(new ApiError('Config not found', httpStatus.NOT_FOUND, true));
    req.config = config; // eslint-disable-line
    next();
  } catch (e) {
    next(e);
  }
};

module.exports = { list, create, update, deleteConfig, load };
