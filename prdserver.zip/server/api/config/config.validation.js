const Joi = require('joi');

const attributeSchema = Joi.object().keys({
  font: Joi.string().trim(),
  color: Joi.string().trim(),
});

module.exports = {
  create: {
    body: {
      key: Joi.string().trim().min(5).required(),
      parent: Joi.string().trim().allow(null).required(),
      attributes: attributeSchema,
    },
  },
  update: {
    body: {
      key: Joi.string().trim().min(5),
      parent: Joi.string().trim().allow(null),
      attributes: attributeSchema,
    },
  },
};
