const mongoose = require('mongoose');
const ApiError = require('../../helpers/APIError');
const _ = require('lodash');
const httpStatus = require('http-status');
const ConfigTransformer = require('./config.transformer');

const AttributeBuilder = require('../../helpers/config-attributes/attributeBuilder');

const configSchema = new mongoose.Schema({
  key: {
    type: String,
    index: {
      unique: true,
    },
  },
  level: {
    type: Number,
    required: true,
  },
  root: {
    type: mongoose.Schema.ObjectId,
    ref: 'Config',
  },
  parent: {
    type: mongoose.Schema.ObjectId,
    ref: 'Config',
  },
  attributes: {
    type: Object,
  },
});

configSchema.statics = {
  async safeCreate(key, data) {
    const temporaryModel = this.model('Config')();
    const { parent } = data;
    let { attributes } = data;

    const [queryKeyModel, queryParentModel] = await Promise.all([
      this.model('Config').findOne({ key }),
      parent ? this.model('Config').findById(parent) : null,
    ]);

    const existFilters = [!queryKeyModel, parent === null || queryParentModel];
    if (!_.every(existFilters, filter => !!filter)) {
      throw new ApiError('Config invalid', httpStatus.BAD_REQUEST, true);
    }

    attributes = AttributeBuilder.buildFrom(attributes);
    attributes = attributes ? attributes.toObject() : null;

    temporaryModel.key = key;
    temporaryModel.level = parent ? queryParentModel.level + 1 : 0;
    temporaryModel.root = parent ? queryParentModel.root : temporaryModel._id;
    temporaryModel.attributes = attributes;
    temporaryModel.parent = parent;

    return await temporaryModel.save();
  },
};

function getChildren(rootList, id) {
  return _.filter(rootList, e => e.parent && e.parent.toString() === id);
}

function groupInHierachy(rootList, top = null) {
  let parent = null;
  if (top) parent = _.find(rootList, e => e.id.toString() === top);
  else parent = _.find(rootList, e => e.parent === null);

  const children = getChildren(rootList, parent.id.toString());
  if (children.length === 0) return parent;
  return _.flatMapDeep([
    parent,
    _.map(children, child => groupInHierachy(rootList, child.id.toString()))]);
}

configSchema.methods = {
  async safeUpdate(data) {
    const { key } = data;
    let { attributes, parent } = data;

    let level = this.level;
    let root = this.root;

    const [queryKeyModel, queryParentModel] = await Promise.all([
      this.model('Config').findOne({ key }),
      parent ? this.model('Config').findById(parent) : null,
    ]);

    const existFilters = [!queryKeyModel, !parent || queryParentModel];
    if (!_.every(existFilters, filter => !!filter)) {
      throw new ApiError('Config invalid', httpStatus.BAD_REQUEST, true);
    }

    if (parent) {
      level = queryParentModel.level + 1;
      root = queryParentModel.root;
    } else if (parent === null) {
      level = 0;
      root = this._id;
    } else parent = this.parent;

    attributes = attributes ? AttributeBuilder.buildFrom(attributes).toObject() : this.attributes;

    this.key = key || this.key;
    this.level = level;
    this.root = root;
    this.parent = parent;
    this.attributes = attributes;
    return await this.save();
  },

  async safeDelete() {
    const configs = await this.model('Config')
      .find({ root: this.root });

    const cleanConfigs = _.map(configs,
      attribute => new ConfigTransformer().transform(attribute));

    let deletingConfigs = groupInHierachy(cleanConfigs, this._id.toString());

    deletingConfigs = Array.isArray(deletingConfigs) ?
      deletingConfigs : [deletingConfigs];

    return await Promise.all(_.map(deletingConfigs, config => this.model('Config').findByIdAndRemove(config.id)));
  },
};

module.exports = mongoose.model('Config', configSchema);
