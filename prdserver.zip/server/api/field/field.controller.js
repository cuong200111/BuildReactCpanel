const Field = require('./field.model');
// const PaymentRequire = require('../paymentRequire/paymentRequire.model')();
// const STATUS = require('../../variables/CONST_STATUS').STATUS;

/**
 * Load customer and append to req.
 *
 * @param {Request} req
 * @param {Response} res
 * @param {any} next
 * @param {ObjectId} id
 */
async function load(req, res, next, id) {
  Field.findById(id)
    .then((data) => {
      // eslint-disable-next-line no-param-reassign
      req.field = data;
      return next();
    })
    .catch((e) => {
      next(e);
    });
}

/**
 * Get a Customer
 *
 * @param {Request} req
 * @param {Response} res
 */
function get(req, res) {
  return res.json(req.field);
}

/**
 * Create a new Customer
 *
 * @param {Request} req
 * @param {Response} res
 * @param {any} next
 *
 * @returns {Customer}
 */
async function create(req, res) {
  // const { user } = req.user;
  // const organizationUnit = EM
  const {
  fields, name, code
  } = req.body;
  const field = new Field({
    fields, name, code
  });
  const savedData = await field.save();
  if (savedData) res.json(savedData);
  else res.transforemer.errorBadRequest('Can not creat field');
}

async function list(req, res, next) {
  try {
    const { limit = 500, skip = 0, sort, filter } = req.query;
    const data = await Field.list({ limit, skip, sort, filter, user: req.user.user });
    const count = await Field.count(filter);
    res.json({ data, limit, skip, count });
  } catch (error) {
    next(error);
  }
}

function removeMore(req, res) {
  const { ids } = req.body;
  Field.deleteMany({ _id: { $in: ids } }, (err, result) => {
    if (err) {
      res.send(err);
    } else {
      res.send(result);
    }
  });
}

async function update(req, res, next) {
  try {
    const field = req.field;
    const { fields, name, code } = req.body;
    field.fields = fields;
    field.name = name;
    field.code = code;
    const data = await field.save();
    res.json(data);
  } catch (error) {
    next(error);
  }
}

module.exports = { list, removeMore, create, update, get, load };
