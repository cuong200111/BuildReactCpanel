const express = require('express');
// const validate = require('express-validation');
// const customerValidation = require('./customer.validation');
const fieldCtrl = require('./field.controller');


const router = express.Router(); // eslint-disable-line new-cap

router
  .route('/')
  /** GET /api/customers - Get list of customers */
  .get(fieldCtrl.list)
  /** POST /api/customers - Create new customer */
  .post(fieldCtrl.create)
  .delete(fieldCtrl.removeMore);
router
  .route('/:fieldId')
  .get(fieldCtrl.get)
  /** PUT /api/customers/:customerId - Update customer */
  .put(fieldCtrl.update);
router.param('fieldId', fieldCtrl.load);
module.exports = router;
