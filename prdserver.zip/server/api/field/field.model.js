// eslint-disable-next-line no-unused-vars
const Promise = require('../../../node_modules/bluebird/js/release/bluebird');
const mongoose = require('mongoose');
// eslint-disable-next-line no-unused-vars
const httpStatus = require('http-status');
// eslint-disable-next-line no-unused-vars
const APIError = require('../../helpers/APIError');
// eslint-disable-next-line no-unused-vars
const STATUS = require('../../variables/CONST_STATUS').STATUS;


/**
 * measureUnit Schema
 */
// eslint-disable-next-line no-unused-vars
const mailSchema = new mongoose.Schema(
  {
    fields: [{ 
        title: { type: String, require: true }, 
        name: { type: String, require: true }, 
        value: { type: String, require: true },
        valueType: String,
        valueInfor: {},
        typeInfor: String,
        configType: String,
        configCode: String,
        options : Array,
      },
    ],
    name: { type: String, require: true },
    code: { type: String, require: true },
    status: { type: Number, default: STATUS.ACTIVED }
  },

  {
    timestamps: true,
  },
);

/**
 * measureUnit
 */

/**
 * Methods
 */
mailSchema.method({});

/**
 * Statics
 */
mailSchema.statics = {
  /**
   * Get mail
   * @param {ObjectId} id - The ObjectId of mail
   * @returns {Promise<Mail, APIError}
   */
  get(id) {
    return this.findOne({
      _id: id
    })
      .exec()
      .then((mail) => {
        if (mail) {
          return mail;
        }
        const err = new APIError('No such mail exists!', httpStatus.NOT_FOUND);
        return Promise.reject(err);
      });
  },

  /**
   * List mail in descending order of 'createdAt' timestamps
   *
   * @param {number} skip - Number of mail to be skipped.
 * @param {number} limit - Limit number of mail to be returned.
 * @returns {Promise<Mail[]>}
   */
  list({
    skip = 0,
    limit = 500,
    sort = {
      createdAt: -1
    },
    filter = {
      //   status: 1
    }
  }) {
    return this.find(filter)
      .sort(sort)
      .skip(+skip)
      .limit(+limit)
      .exec();
  }
};


module.exports = mongoose.model('Field', mailSchema);
