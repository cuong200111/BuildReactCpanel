/* eslint-disable consistent-return */
/* eslint-disable no-console */
/* eslint-disable no-param-reassign */
const Role = require('./role.model');
// const APIError = require('../../helpers/APIError');
const RoleModule = require('./roleModule');
// const httpStatus = require('http-status');
const initRole = require('./role.init');
const _ = require('lodash');
const axios = require('axios');

async function create(req, res) {
  const { userId, moduleCode, roles, groupId } = req.body;

  // if (!userId) return res.json({ success: false, message: 'userId is required' });
  const roleCheck = await Role.findOne({ userId, moduleCode, groupId });
  const roleModule = await getroleByModule(moduleCode);
  roleModule.roles = _.filter(roles, ['type', 2]);
  await roleModule.save();

  if (roleCheck) {
    roleCheck.roles = roles;
    await roleCheck.save();
    return res.json(roleCheck);
  }
  const role = new Role({ userId, moduleCode, roles, groupId });
  await role.save();
  return res.json(role);
}

async function getroleByModule(code) {
  const roles = await RoleModule.findOne({ moduleCode: code });
  if (roles) return roles;
  return new RoleModule({ roles: _.filter(initRole(code).roles, ['type', 2]), moduleCode: code });
}

async function load(req, res) {
  // eslint-disable-next-line no-param-reassign
  // try {
  //   await Role.updateRoles();
  // } catch (error) {

  // }

  if (!req.params.roleId) return res.json({ success: false });
  let role = await Role.findOne({
    $or: [
      { userId: req.params.roleId, moduleCode: req.params.moduleCode },
      { groupId: req.params.roleId, moduleCode: req.params.moduleCode }
    ]
  }).populate(
    'roles.data.id',
    'path',
  );

  if (!role) {
    role = initRole(req.params.moduleCode, req.params.roleId);
    console.log("🚀 ~ file: role.controller.js ~ line 54 ~ load ~ req.params.roleId", req.params.roleId);
    // const roleModule = await getroleByModule(req.params.moduleCode);
    // const newRole = _.uniqBy(_.concat(roleModule.roles, role.roles), 'code');
    // role.roles = role.roles;
    res.json(role);
  } else {
    let role1 = { ...role._doc, isUpdate: true };
    res.json(role1);
  }
}

async function getRole({ userId, moduleCode }) {
  const role = await Role.findOne({ userId, moduleCode }).populate('roles.data.id', 'path');
  if (!role) {
    return initRole(moduleCode, userId);
  }
  return role;
}

// async function update(req, res, next) {
//   try {
//     const {
//       roles
//     } = req.body;

//     const role = req.role;
//     role.roles = roles;
//     const roleSave = await role.save();
//     return res.json({ success: true, data: roleSave });
//   } catch (error) {
//     return next(error);
//   }
// }

async function updateRoleApp(req, res, next) {
  try {
    const { roles, userId, moduleCode, isGroup, groupId } = req.body;

    // const role = req.role;
    // role.roles = roles;
    // const roleSave = await role.save();
    let roleSave;
    const findRole = await Role.findOne({
      $or: [
        { userId, moduleCode },
        { groupId, moduleCode }
      ]
    });
    console.log("🚀 ~ file: role.controller.js ~ line 101 ~ updateRoleApp ~ findRole", findRole);
    if (findRole && isGroup) {
      roleSave = await Role.updateMany({ moduleCode, groupId }, { roles });

      // Role.updateMany({GroupId, module})
    }
    if (findRole && !isGroup) {
      roleSave = await Role.update({ userId, moduleCode }, { roles });
    }
    // else{
    //   Role.create({ userId, moduleCode, roles, groupId }).then(() => res.json('success'));
    // }


    return res.json({ success: true, data: roleSave });
  } catch (error) {
    return next(error);
  }
}


async function resetChildRole(req, res, next) {
  try {
    const { userId, roleGroupId } = req.body;
    if (userId && roleGroupId) {
      const data = await Role.remove({ userId: userId, moduleCode: { $exists: true } });
      const allRolesByGroupId = await Role.find({ userId: roleGroupId, moduleCode: { $exists: true } }).select('-_id -userId -createdAt -updatedAt -__v');
      for (let i = 0; i < allRolesByGroupId.length; i++) {
        allRolesByGroupId[i].userId = userId;
      }
      Role.insertMany(allRolesByGroupId, function (error) {
        if (error) {
          res.json(error)
        }
      })
    }
    res.json({ success: true })
  } catch (e) {
    res.json(e)
  }
}

async function adminChangePassword(req, res, next) {
  try {
    const Employee = global.hshCollections['Employee'];
    const admin = req.user.user;
    const { user, password } = req.body
    const [adminEmployee, userEmployee] = await Promise.all([
      Employee.findById(admin).lean(),
      Employee.findById(user).lean(),
    ])
    if (!adminEmployee) return res.json({ status: 0, message: 'Vui lòng đăng nhập lại' });
    if (!userEmployee) return res.json({ status: 0, message: 'Không tìm thấy người dùng' });
    const role = await Role.findOne({ userId: admin, moduleCode: 'Employee' });
    // console.log('roles', role.roles)
    let isRole = false;
    if (role && role.roles && role.roles.length) {
      const businessRole = role.roles.find(item => item.code === 'BUSSINES');
      if (businessRole && businessRole.data && businessRole.data.length) {
        const passwordRole = businessRole.data.find(m => m.name === 'password');
        if (passwordRole && passwordRole.data && passwordRole.data.changePassWord) {
          isRole = true;
        }
      }
    }
    if (!isRole) return res.json({ status: 0, message: 'Bạn không có quyền đổi mật khẩu' });
    const response = await axios.patch(`${process.env.API_ROLE_GROUPS_01}/users/admin-change-pass`, {
      // const response = await axios.patch(`http://localhost:10201/users/admin-change-pass`, {
      user: userEmployee.userId,
      password,
    });
    if (response && response.status === 200) return res.json({ status: 1, message: 'Đổi mật khẩu người dùng thành công' });
    return res.json({ status: 0, message: `${response.data.message}` })
  } catch (error) {
    res.json({ status: 0, message: error });
  }
};

module.exports = {
  resetChildRole,
  create,
  load,
  updateRoleApp,
  getRole,
  adminChangePassword,
};
