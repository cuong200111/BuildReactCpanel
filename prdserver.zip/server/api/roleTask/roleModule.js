const Promise = require('bluebird');
const mongoose = require('mongoose');
const httpStatus = require('http-status');
const APIError = require('../../helpers/APIError');
const STATUS = require('../../variables/CONST_STATUS').STATUS;
const convertToFullTextSearch = require('../../helpers/convertToFullTextSearch');

const roleModuleSchema = new mongoose.Schema(
  {
    moduleCode: String,
    roles: [
      { code: { type: String, required: true },
        name: { required: true, type: String },
        type: { type: Number },
        column: [{ name: { type: String, required: true }, title: String }],
        row: [{ name: { type: String, required: true }, title: String }],
        data: [{ name: { type: String, required: true },
          id: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'OrganizationUnit'
          },
          data: {} }]
      }
    ],

    status: {
      type: Number,
      enum: [0, 1, 2, 3],
      default: 1,
    },
  },
  {
    timestamps: true,
  },
);

/**
 * Statics
 */
roleModuleSchema.statics = {
  /**
   * Get codeConfig
   *
   * @param {ObjectId} id - The objectId of codeConfig.
   * @returns {Promise<codeConfig, APIError>}
   */
  get(id) {
    return this.findOne({
      _id: id,
      status: STATUS.ACTIVED,
    })
      .exec()
      .then((data) => {
        if (data) {
          return data;
        }
        const err = new APIError('No such role exists!', httpStatus.NOT_FOUND);
        return Promise.reject(err);
      });
  },

  /**
   * List codeConfigs in descending order of 'createdAt' timestamp.
   *
   * @param {number} skip - Number of codeConfigs to be skipped.
   * @param {number} limit - Limit number of codeConfigs to be returned.
   * @returns {Promise<codeConfig[]>}
   */
  async list({
    skip = 0,
    limit = 500,
    sort = {
      createdAt: -1,
    },
    filter = {},
  }) {
    /* eslint-disable no-param-reassign */
    filter.status = STATUS.ACTIVED;
    convertToFullTextSearch(filter);
    const data = await this.find(filter)
      .sort(sort)
      .skip(+skip)
      .limit(+limit)
      .exec();
    const count = await this.find(filter).count();
    return {
      data,
      count,
      limit,
      skip,
    };
  },
};

module.exports = mongoose.model('RoleModule', roleModuleSchema);
