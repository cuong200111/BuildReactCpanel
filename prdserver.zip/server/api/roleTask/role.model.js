const Promise = require('bluebird');
const mongoose = require('mongoose');
const httpStatus = require('http-status');
const APIError = require('../../helpers/APIError');
const STATUS = require('../../variables/CONST_STATUS').STATUS;
const convertToFullTextSearch = require('../../helpers/convertToFullTextSearch');
const Department = require('../organizationUnit/organizationUnit.model');
const _ = require('lodash');

const roleTaskSchema = new mongoose.Schema(
  {
    moduleCode: String,
    userId: { type: mongoose.Schema.Types.ObjectId },
    groupId: { type: mongoose.Schema.Types.ObjectId },
    roles: [
      { code: { type: String, required: true },
        name: { required: true, type: String },
        type: { type: Number },
        column: [{ name: { type: String, required: true }, title: String }],
        row: [{ name: { type: String, required: true }, title: String }],
        data: [{ name: { type: String, required: true },
          id: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'OrganizationUnit'
          },
          data: {} }]
      }
    ],

    status: {
      type: Number,
      enum: [0, 1, 2, 3],
      default: 1,
    },
  },
  {
    timestamps: true,
  },
);

/**
 * Statics
 */
roleTaskSchema.statics = {
  /**
   * Get codeConfig
   *
   * @param {ObjectId} id - The objectId of codeConfig.
   * @returns {Promise<codeConfig, APIError>}
   */
  get(id) {
    return this.findOne({
      _id: id,
      status: STATUS.ACTIVED,
    })
      .exec()
      .then((data) => {
        if (data) {
          return data;
        }
        const err = new APIError('No such role exists!', httpStatus.NOT_FOUND);
        return Promise.reject(err);
      });
  },

  /**
   * List codeConfigs in descending order of 'createdAt' timestamp.
   *
   * @param {number} skip - Number of codeConfigs to be skipped.
   * @param {number} limit - Limit number of codeConfigs to be returned.
   * @returns {Promise<codeConfig[]>}
   */
  async list({
    skip = 0,
    limit = 500,
    sort = {
      createdAt: -1,
    },
    filter = {},
  }) {
    /* eslint-disable no-param-reassign */
    filter.status = STATUS.ACTIVED;
    convertToFullTextSearch(filter);
    const data = await this.find(filter)
      .sort(sort)
      .skip(+skip)
      .limit(+limit)
      .exec();
    const count = await this.find(filter).count();
    return {
      data,
      count,
      limit,
      skip,
    };
  },
  async updateRole(roleData, allDepartments, allDepartmentsIds) {
    function makeNewDataFromNewDepartment(subRoleData) {
      const newData = [];
      subRoleData.forEach((data) => {
        if (allDepartmentsIds.includes(data.name)) {
          newData.push(data);
        }
        allDepartments.forEach((depart) => {
          if (depart.parent && depart.parent.toString() === data.name) {
            newData.push({
              id: depart._id,
              name: depart._id.toString(),
              data: data.data,
            });
          }
        });
      });
      return _.uniqBy(newData, 'name');
    }
    roleData.roles.map((subRole) => {
      if (subRole.code === 'DERPARTMENT') {
        subRole.data = makeNewDataFromNewDepartment(subRole.data, allDepartments, allDepartmentsIds);
      }
      return subRole;
    });
    return await roleData.save();
  },
  async updateRoles() {
    try {
      const [allDepartments, allRoles] = await Promise.all([
        Department.find({ status: 1 }),
        this.find({ status: STATUS.ACTIVED })
      ]);
      if (Array.isArray(allDepartments) && allDepartments.length && Array.isArray(allRoles) && allRoles.length) {
        const allAsyncTasks = [];
        const allDepartmentsIds = allDepartments.map(depart => depart._id.toString());
        allRoles.forEach(roleData => allAsyncTasks.push(this.updateRole(roleData, allDepartments, allDepartmentsIds)));
        await Promise.all(allAsyncTasks);
      }
    } catch (error) {
      console.log('error', error);
    }
  },
};

module.exports = mongoose.model('RoleApp', roleTaskSchema);
