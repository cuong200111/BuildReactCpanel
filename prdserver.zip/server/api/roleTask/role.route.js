const express = require('express');
// const validate = require('express-validation');
// const RoleCtl = require('./salesQuotation.validation');
const roleCtl = require('./role.controller');

const router = express.Router(); // eslint-disable-line new-cap

// router
//   .route('/')
//   /** GET /api/salesQuotations - Get list of salesQuotations */
//   /** POST /api/salesQuotations - Create new balesQuotation */

router
  .route('/admin-change-password')
  .patch(roleCtl.adminChangePassword);

router
  .route('/:moduleCode/:roleId')
  .get(roleCtl.load)
  .post(roleCtl.create)
  .put(roleCtl.updateRoleApp);
  
router.route('/resetChildRole')
  .delete(roleCtl.resetChildRole)
module.exports = router;
