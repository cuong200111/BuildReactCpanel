const historyDataRole = require('../../historyData/role/role.init');
const derparmentInit = [
  {
    code: 'DERPARTMENT',
    name: 'Phòng ban',
    type: 0,
    column: [{ name: 'view', title: 'Xem' }, { name: 'edit', title: 'Sửa' }, { name: 'delete', title: 'Xóa' }],
    row: [],
    data: [],
  },
];

const initRole = [
  {
    code: 'NATURE',
    name: 'Tính năng',
    moduleCode: 'Task',
    type: 1,
    column: [{ name: 'access', title: 'Truy cập' }],
    row: [
      { name: 'all', title: 'Tất cả' },
      { name: 'taskReated', title: 'Công việc liên quan' },
      { name: 'kaban', title: 'Kanban' },
      { name: 'task', title: 'Dự án' },
    ],
    data: [
      { name: 'all', data: { access: true } },
      { name: 'taskReated', data: { access: true } },
      { name: 'kaban', data: { access: true } },
      { name: 'task', data: { access: true } },
    ],
  },
  {
    code: 'BUSSINES',
    name: 'Nghiệp vụ',
    moduleCode: 'Task',
    type: 2,
    column: [
      { name: 'view', title: 'Xem' },
      { name: 'convertTask', title: 'Chuyển công việc' },
      { name: 'approved', title: 'Phê duyệt' },
      { name: 'updateProgress', title: 'Cập nhật tiến độ' },
      { name: 'uploadFile', title: 'Tải file' },
      { name: 'deleteFile', title: 'Xóa file' },
      { name: 'updateRatio', title: 'Cập nhật tỷ trọng' },
      { name: 'sendApprove', title: 'Gửi yêu cầu phê duyệt' },
      { name: 'edit', title: 'Thiết lập' },
    ],
    row: [
      { title: 'Quản lý dự án', name: 'taskManager' },
      { title: 'Nhóm phê duyệt', name: 'approved' },
      { title: 'Người phụ trách', name: 'inCharge' },
      { title: 'Người tham gia', name: 'join' },
      { title: 'Người được xem', name: 'viewable' },
      { title: 'Người hỗ trợ', name: 'support' },
      { title: 'Người tạo', name: 'createdBy' },
      { title: 'Khác', name: 'others' }
    ],
    data: [
      {
        name: 'taskManager',
        data: {
          convertTask: false,
          approved: false,
          updateProgress: false,
          uploadFile: false,
          deleteFile: false,
          updateRatio: false,
          view: false,
          sendApprove: true,
          edit: false,
        },
      },
      {
        name: 'approved',
        data: {
          convertTask: false,
          approved: false,
          updateProgress: false,
          uploadFile: false,
          deleteFile: false,
          updateRatio: false,
          view: false,
          sendApprove: true,
          edit: false,
        },
      },
      {
        name: 'inCharge',
        data: {
          convertTask: false,
          approved: false,
          updateProgress: false,
          uploadFile: false,
          deleteFile: false,
          updateRatio: false,
          view: false,
          sendApprove: true,
          edit: false,
        },
      },
      {
        name: 'join',
        data: {
          convertTask: false,
          approved: false,
          updateProgress: false,
          uploadFile: false,
          deleteFile: false,
          updateRatio: false,
          view: false,
          sendApprove: true,
          edit: false,
        },
      },
      {
        name: 'viewable',
        data: {
          convertTask: false,
          approved: false,
          updateProgress: false,
          uploadFile: false,
          deleteFile: false,
          updateRatio: false,
          view: false,
          sendApprove: false,
          edit: false,
        },
      },
      {
        name: 'support',
        data: {
          convertTask: false,
          approved: false,
          updateProgress: false,
          uploadFile: false,
          deleteFile: false,
          updateRatio: false,
          view: false,
          sendApprove: true,
          edit: false,
        },
      },
      {
        name: 'createdBy',
        data: {
          convertTask: true,
          approved: true,
          updateProgress: true,
          uploadFile: true,
          deleteFile: true,
          updateRatio: true,
          view: true,
          sendApprove: true,
          edit: true,
        },
      },
      {
        name: 'others',
        data: {
          convertTask: false,
          approved: false,
          updateProgress: false,
          uploadFile: false,
          deleteFile: false,
          updateRatio: false,
          view: true,
          sendApprove: false,
          edit: false,
        },
      },
    ],
  },
  {
    code: 'BUSSINES',
    name: 'Nghiệp vụ',
    moduleCode: 'Employee',
    type: 2,
    column: [
      { name: 'view', title: 'Xem' },
      { name: 'changePassWord', title: 'Đổi mật khẩu' },
    ],
    row: [
      { title: 'Mật Khẩu', name: 'password' },
    ],
    data: [
      {
        name: 'password',
        data: {
          view: false,
          changePassWord: false,
        },
      },
    ],
  },
  {
    code: 'SPECIALL',
    name: 'Đặc biệt',
    moduleCode: 'Task',
    type: 1,
    column: [{ name: 'access', title: 'Cho phép' }],
    row: [
      { name: 'add', title: 'Tạo dự án' },
      { name: 'obligate', title: 'Tạo dự án bắt buộc tham gia' },
      { name: 'addSpecial', title: 'Tạo dự án đặc biệt' },
    ],
    data: [
      { name: 'add', data: { access: false } },
      { name: 'obligate', data: { access: false } },
      { name: 'addSpecial', data: { access: false } },
    ],
  },
  {
    code: 'EXTRA',
    name: 'Mở rộng',
    moduleCode: 'Task',
    type: 1,
    column: [{ name: 'view', title: 'Xem' }, { name: 'edit', title: 'Sửa' }, { name: 'delete', title: 'Xóa' }],
    row: [
      { name: 'protected', title: 'Bảo mật' },
      { name: 'hide', title: 'Ẩn' },
      { name: 'public', title: 'Công khai' },
      { name: 'open', title: 'Mở' },
    ],
    data: [
      { name: 'protected', data: { view: false, edit: false, delete: false } },
      { name: 'hide', data: { view: false, edit: false, delete: false } },
      { name: 'public', data: { view: false, edit: false, delete: false } },
      { name: 'open', data: { view: false, edit: false, delete: false } },
    ],
  },
  {
    code: 'BUSSINES',
    name: 'Nghiệp vụ',
    moduleCode: 'BusinessOpportunities',
    type: 2,
    column: [{ name: 'view', title: 'Xem' }, { name: 'edit', title: 'Sửa' }, { name: 'delete', title: 'Xóa' }],
    row: [
      { name: 'responsibilityPerson', title: 'Người chịu trách nhiệm' },
      { name: 'supervisor', title: 'Quan sát viên' },
    ],
    data: [
      { name: 'responsibilityPerson', data: { view: false, edit: false, delete: false } },
      { name: 'supervisor', data: { view: false, edit: false, delete: false } },
    ],
  },
  {
    code: 'BUSSINES',
    name: 'Nghiệp vụ',
    moduleCode: 'ExchangingAgreement',
    type: 2,
    column: [{ name: 'view', title: 'Xem' }, { name: 'edit', title: 'Sửa' }, { name: 'delete', title: 'Xóa' }],
    row: [
      { name: 'responsibilityPerson', title: 'Người chịu trách nhiệm' },
      { name: 'supervisor', title: 'Quan sát viên' },
    ],
    data: [
      { name: 'responsibilityPerson', data: { view: false, edit: false, delete: false } },
      { name: 'supervisor', data: { view: false, edit: false, delete: false } },
    ],
  },
  {
    code: 'BUSSINES',
    name: 'Nghiệp vụ',
    moduleCode: 'Customer',
    type: 2,
    column: [{ name: 'view', title: 'Xem' }, { name: 'edit', title: 'Sửa' }, { name: 'delete', title: 'Xóa' }],
    row: [{ name: 'managerEmployee', title: 'Người quản lý' }, { name: 'viewableEmployees', title: 'Người được xem' }],
    data: [
      { name: 'managerEmployee', data: { view: false, edit: false, delete: false } },
      { name: 'viewableEmployees', data: { view: false, edit: false, delete: false } },
    ],
  },
  {
    code: 'BUSSINES',
    name: 'Nghiệp vụ',
    moduleCode: 'SalesQuotation',
    type: 2,
    column: [{ name: 'view', title: 'Xem' }, { name: 'edit', title: 'Sửa' }, { name: 'delete', title: 'Xóa' }],
    row: [{ name: 'commissionGroup', title: 'Nhân viên hưởng hoa hồng' }],
    data: [{ name: 'commissionGroup', data: { view: false, edit: false, delete: false } }],
  },
  {
    code: 'BUSSINES',
    name: 'Nghiệp vụ',
    moduleCode: 'Calendar',
    type: 2,
    column: [{ name: 'view', title: 'Xem' }, { name: 'edit', title: 'Sửa' }, { name: 'delete', title: 'Xóa' }],
    row: [
      { name: 'people', title: 'Người tham gia' },
      { name: 'organizer', title: 'Người tổ chức' },
      { name: 'prepare', title: 'Người chuẩn bị' },
      { name: 'approved', title: 'Người phê duyệt' },
    ],
    data: [
      { name: 'people', data: { view: false, edit: false, delete: false } },
      { name: 'organizer', data: { view: false, edit: false, delete: false } },
      { name: 'prepare', data: { view: false, edit: false, delete: false } },
      { name: 'approved', data: { view: false, edit: false, delete: false } },
    ],
  },
];

initRole.push(...historyDataRole);
module.exports = function initModule(code, userId = null) {
  const filterModule = initRole.filter((i) => i.moduleCode === code);
  return { roles: [...derparmentInit, ...filterModule], moduleCode: code, userId, isUpdate: false };
};
