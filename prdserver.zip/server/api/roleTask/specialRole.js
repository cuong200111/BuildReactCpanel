const specialTabs = [
  {
    code: 'NATURE',
    name: 'Tính năng',
    moduleCode: 'Task',
    type: 1,
    column: [{ name: 'access', title: 'Truy cập' }],
    row: [
      { name: 'all', title: 'Tất cả' },
      { name: 'taskReated', title: 'Công việc liên quan' },
      { name: 'kaban', title: 'Kanban' },
      { name: 'task', title: 'Dự án' },
    ],
    data: [
      { name: 'all', data: { access: true } },
      { name: 'taskReated', data: { access: true } },
      { name: 'kaban', data: { access: true } },
      { name: 'task', data: { access: true } },
    ],
  },
  {
    code: 'BUSSINES',
    name: 'Nghiệp vụ',
    moduleCode: 'Task',
    type: 2,
    column: [
      { name: 'view', title: 'Xem' },
      { name: 'convertTask', title: 'Chuyển công việc' },
      { name: 'approved', title: 'Phê duyệt' },
      { name: 'updateProgress', title: 'Cập nhật tiến độ' },
      { name: 'uploadFile', title: 'Tải file' },
      { name: 'deleteFile', title: 'Xóa file' },
      { name: 'updateRatio', title: 'Cập nhật tỷ trọng' },
      { name: 'sendApprove', title: 'Gửi yêu cầu phê duyệt' },
      { name: 'edit', title: 'Thiết lập' },
    ],
    row: [
      { title: 'Quản lý dự án', name: 'taskManager' },
      { title: 'Nhóm phê duyệt', name: 'approved' },
      { title: 'Người phụ trách', name: 'inCharge' },
      { title: 'Người tham gia', name: 'join' },
      { title: 'Người được xem', name: 'viewable' },
      { title: 'Người hỗ trợ', name: 'support' },
      { title: 'Người tạo', name: 'createdBy' },
      { title: 'Khác', name: 'others' }
    ],
    data: [
      {
        name: 'taskManager',
        data: {
          convertTask: true,
          approved: true,
          updateProgress: true,
          uploadFile: true,
          deleteFile: true,
          updateRatio: true,
          view: true,
          sendApprove: true,
          edit: true,
        },
      },
      {
        name: 'approved',
        data: {
          convertTask: true,
          approved: true,
          updateProgress: true,
          uploadFile: true,
          deleteFile: true,
          updateRatio: true,
          view: true,
          sendApprove: true,
          edit: true,
        },
      },
      {
        name: 'inCharge',
        data: {
          convertTask: true,
          approved: true,
          updateProgress: true,
          uploadFile: true,
          deleteFile: true,
          updateRatio: true,
          view: true,
          sendApprove: true,
          edit: true,
        },
      },
      {
        name: 'join',
        data: {
          convertTask: true,
          approved: true,
          updateProgress: true,
          uploadFile: true,
          deleteFile: true,
          updateRatio: true,
          view: true,
          sendApprove: true,
          edit: true,
        },
      },
      {
        name: 'viewable',
        data: {
          convertTask: true,
          approved: true,
          updateProgress: true,
          uploadFile: true,
          deleteFile: true,
          updateRatio: true,
          view: true,
          sendApprove: true,
          edit: true,
        },
      },
      {
        name: 'support',
        data: {
          convertTask: true,
          approved: true,
          updateProgress: true,
          uploadFile: true,
          deleteFile: true,
          updateRatio: true,
          view: true,
          sendApprove: true,
          edit: true,
        },
      },
      {
        name: 'createdBy',
        data: {
          convertTask: true,
          approved: true,
          updateProgress: true,
          uploadFile: true,
          deleteFile: true,
          updateRatio: true,
          view: true,
          sendApprove: true,
          edit: true,
        },
      },
      {
        name: 'others',
        data: {
          convertTask: true,
          approved: true,
          updateProgress: true,
          uploadFile: true,
          deleteFile: true,
          updateRatio: true,
          view: true,
          sendApprove: true,
          edit: true,
        },
      },
    ],
  },
  {
    code: 'SPECIALL',
    name: 'Đặc biệt',
    moduleCode: 'Task',
    type: 1,
    column: [{ name: 'access', title: 'Cho phép' }],
    row: [
      { name: 'add', title: 'Tạo dự án' },
      { name: 'obligate', title: 'Tạo dự án bắt buộc tham gia' },
      { name: 'addSpecial', title: 'Tạo dự án đặc biệt' },
    ],
    data: [
      { name: 'add', data: { access: true } },
      { name: 'obligate', data: { access: true } },
      { name: 'addSpecial', data: { access: true } },
    ],
  },
  {
    code: 'EXTRA',
    name: 'Mở rộng',
    moduleCode: 'Task',
    type: 1,
    column: [{ name: 'view', title: 'Xem' }, { name: 'edit', title: 'Sửa' }, { name: 'delete', title: 'Xóa' }],
    row: [
      { name: 'protected', title: 'Bảo mật' },
      { name: 'hide', title: 'Ẩn' },
      { name: 'public', title: 'Công khai' },
      { name: 'open', title: 'Mở' },
    ],
    data: [
      { name: 'protected', data: { view: true, edit: true, delete: true } },
      { name: 'hide', data: { view: true, edit: true, delete: true } },
      { name: 'public', data: { view: true, edit: true, delete: true } },
      { name: 'open', data: { view: true, edit: true, delete: true } },
    ],
  },
  {
    code: 'BUSSINES',
    name: 'Nghiệp vụ',
    moduleCode: 'BusinessOpportunities',
    type: 2,
    column: [{ name: 'view', title: 'Xem' }, { name: 'edit', title: 'Sửa' }, { name: 'delete', title: 'Xóa' }],
    row: [
      { name: 'responsibilityPerson', title: 'Người chịu trách nhiệm' },
      { name: 'supervisor', title: 'Quan sát viên' },
    ],
    data: [
      { name: 'responsibilityPerson', data: { view: true, edit: true, delete: true } },
      { name: 'supervisor', data: { view: true, edit: true, delete: true } },
    ],
  },
  {
    code: 'BUSSINES',
    name: 'Nghiệp vụ',
    moduleCode: 'ExchangingAgreement',
    type: 2,
    column: [{ name: 'view', title: 'Xem' }, { name: 'edit', title: 'Sửa' }, { name: 'delete', title: 'Xóa' }],
    row: [
      { name: 'responsibilityPerson', title: 'Người chịu trách nhiệm' },
      { name: 'supervisor', title: 'Quan sát viên' },
    ],
    data: [
      { name: 'responsibilityPerson', data: { view: true, edit: true, delete: true } },
      { name: 'supervisor', data: { view: true, edit: true, delete: true } },
    ],
  },
  {
    code: 'BUSSINES',
    name: 'Nghiệp vụ',
    moduleCode: 'Customer',
    type: 2,
    column: [{ name: 'view', title: 'Xem' }, { name: 'edit', title: 'Sửa' }, { name: 'delete', title: 'Xóa' }],
    row: [{ name: 'managerEmployee', title: 'Người quản lý' }, { name: 'viewableEmployees', title: 'Người được xem' }],
    data: [
      { name: 'managerEmployee', data: { view: true, edit: true, delete: true } },
      { name: 'viewableEmployees', data: { view: true, edit: true, delete: true } },
    ],
  },
  {
    code: 'BUSSINES',
    name: 'Nghiệp vụ',
    moduleCode: 'SalesQuotation',
    type: 2,
    column: [{ name: 'view', title: 'Xem' }, { name: 'edit', title: 'Sửa' }, { name: 'delete', title: 'Xóa' }],
    row: [{ name: 'commissionGroup', title: 'Nhân viên hưởng hoa hồng' }],
    data: [{ name: 'commissionGroup', data: { view: true, edit: true, delete: true } }],
  },
  {
    code: 'BUSSINES',
    name: 'Nghiệp vụ',
    moduleCode: 'Calendar',
    type: 2,
    column: [{ name: 'view', title: 'Xem' }, { name: 'edit', title: 'Sửa' }, { name: 'delete', title: 'Xóa' }],
    row: [
      { name: 'people', title: 'Người tham gia' },
      { name: 'organizer', title: 'Người tổ chức' },
      { name: 'prepare', title: 'Người chuẩn bị' },
      { name: 'approved', title: 'Người phê duyệt' },
    ],
    data: [
      { name: 'people', data: { view: true, edit: true, delete: true } },
      { name: 'organizer', data: { view: true, edit: true, delete: true } },
      { name: 'prepare', data: { view: true, edit: true, delete: true } },
      { name: 'approved', data: { view: true, edit: true, delete: true } },
    ],
  },
  {
    code: 'BUSSINES',
    name: 'Nghiệp vụ',
    moduleCode: 'Employee',
    type: 2,
    column: [
      { name: 'view', title: 'Xem' },
      { name: 'changePassWord', title: 'Đổi mật khẩu' },
    ],
    row: [
      { title: 'Mật Khẩu', name: 'password' },
    ],
    data: [
      {
        name: 'password',
        data: {
          view: false,
          changePassWord: false,
        },
      },
    ],
  },
];

module.exports = function merge(roles, moduleCode) {
  if (!moduleCode) return roles;
  const newRoles = [...roles];
  const moduleCodeSpecTabs = specialTabs.filter(item => item.moduleCode === moduleCode);
  moduleCodeSpecTabs.forEach((item) => {
    if (!newRoles.find(i => i.code === item.code)) {
      newRoles.push(item);
    }
  });
  return newRoles;
};
