const CrmConfig = require('./crmConfig.model');
const STATUS = require('../../variables/CONST_STATUS').STATUS;
const crmConfigInit = require('./crmConfig.init');
const ObjectId = require('mongoose').Types.ObjectId;
/**
 * Load crmConfig and append to req.
 *
 * @param {Request} req
 * @param {Response} res
 * @param {any} next
 * @param {ObjectId} id
 */
async function load(req, res, next, id) {
  CrmConfig.findOne({ $or: [
    { code: id.toString() },
   /* eslint new-cap: "error"*/
    { _id: new ObjectId((id.toString().length < 24) ? '5ce35d5ee35ffd1890da9e33' : id) },
  ] })
    .then((crmConfig) => {
      // eslint-disable-next-line no-param-reassign
      req.crmConfig = crmConfig;
      return next();
    })
    .catch(e => next(e));
}

/**
 * Get a CrmConfig
 *
 * @param {Request} req
 * @param {Response} res
 */
function get(req, res) {
  return res.json({
    data: req.crmConfig
  });
}

/**
 * Create a new CrmConfig
 *
 * @param {Request} req
 * @param {Response} res
 * @param {any} next
 *
 * @returns {CrmConfig}
 */
async function create(req, res, next) {
  try {
    const { name, order, code, kind, data1, data2 } = req.body;
    if (await CrmConfig.findOne({ code })) {
      return res.json({
        success: false,
        massage: 'Đã tồn tại cấu hình CRM với mã này ',
      });
    }
    const crmConfig = new CrmConfig({
      name,
      order,
      code,
      kind,
      data1,
      data2,
    });

    const crmConfigCreated = await crmConfig.save();
    return res.json({
      success: true,
      data: crmConfigCreated,
    });
  } catch (error) {
    return next(error);
  }
}

/**
 * Update existing crmConfig
 *
 * @returns {CrmConfig}
 */
async function update(req, res, next) {
  try {
    const crmConfig = req.crmConfig;
    crmConfig.name = req.body.name;
    crmConfig.order = req.body.order;
    crmConfig.kind = req.body.kind;
    if (req.body.kind === 1) {
      crmConfig.data1 = req.body.data1;
      crmConfig.data2 = [];
    } else if (req.body.kind === 2) {
      crmConfig.data2 = req.body.data2;
      crmConfig.data1 = [];
    }
    const crmConfigSaved = await crmConfig.save();
    return res.json({
      success: true,
      data: crmConfigSaved,
    });
  } catch (error) {
    return next(error);
  }
}

/**
 * Get crmConfig list.
 * @property {number} req.query.skip - Number of crmConfigs to be skipped.
 * @property {number} req.query.limit - Limit number of crmConfigs to be returned.
 * @returns {CrmConfig[]}
 */
async function list(req, res, next) {
  await init();
  const { limit = 500, skip = 0, sort, filter } = req.query;
  CrmConfig.list({ limit, skip, sort, filter })
    .then(crmConfigs => res.json(crmConfigs))
    .catch(e => next(e));
}

/**
 * Delete crmConfig.
 * @returns {CrmConfig}
 */

function remove(req, res, next) {
  const crmConfig = req.crmConfig;
  crmConfig.status = STATUS.DELETED;

  crmConfig
    .save()
    .then(
      (result) => {
        res.json({
          success: true,
          data: result,
        });
      }
    )
    .catch(e => next(e));
}


/**
 * Delete crmConfig.
 * @returns {CrmConfigs}
 */
function removeMore(req, res, next) {
  const { crmConfigs } = req.body;
  const crmConfigsRemove = crmConfigs.map(async (item) => {
    const crmConfig = await CrmConfig.findById(item);
    crmConfig.status = STATUS.DELETED;
    return crmConfig.save();
  });
  Promise.all(crmConfigsRemove).then((result) => {
    res.json({ success: true, data: result });
  }).catch(err => next(err));
}

async function init() {
  const crmConfig = await CrmConfig.find();
  if (crmConfig.length === 0) {
    await crmConfigInit.crmConfig.map(item => new CrmConfig(item).save());
  }
}

module.exports = {
  create,
  update,
  remove,
  load,
  list,
  get,
  removeMore,
  init
};
