const express = require('express');
const validate = require('express-validation');
const crmConfigValidation = require('./crmConfig.validation');
const crmConfigCtrl = require('./crmConfig.controller');

const router = express.Router(); // eslint-disable-line new-cap


router
  .route('/')
  /** GET /api/crmConfigs - Get list of crmConfigs */
  .get(crmConfigCtrl.list)

  /** POST /api/crmConfigs - Create new crmConfig */
  .post(validate(crmConfigValidation.createCustomer), crmConfigCtrl.create);

router.delete('/remove-more', crmConfigCtrl.removeMore);
router
  .route('/:crmConfigId')
  /** GET /api/crmConfigs/:crmConfigId - Get crmConfig */
  .get(crmConfigCtrl.get)

  /** PUT /api/crmConfigs/:crmConfigId - Update crmConfig */
  .put(validate(crmConfigValidation.updateCustomer), crmConfigCtrl.update)

  /** DELETE /api/crmConfigs/:crmConfigId - Delete crmConfig */
  .delete(crmConfigCtrl.remove);

/** Load crmConfig when API with crmConfigId route parameter is hit */
router.param('crmConfigId', crmConfigCtrl.load);


module.exports = router;
