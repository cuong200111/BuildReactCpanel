// const Joi = require('joi');

// const validString = Joi.string().trim().min(5).required();
// const phoneRegex = /^\+?\d{1,3}?[- .]?\(?(?:\d{2,3})\)?[- .]?\d\d\d[- .]?\d\d\d\d$/;

module.exports = {
  // POST /api/customers
  createCustomer: {
    body: {
      // code: validString,
      // name: validString,
      // phoneNumber: Joi.string().regex(phoneRegex).required(),
      // email: Joi.string().trim().email({ minDomainAtoms: 2 }).required()
    }
  },

  // PUT /api/customers/:customerId
  updateCustomer: {
    body: {
      // code: validString,
      // name: validString,
      // phoneNumber: Joi.string().regex(phoneRegex).required(),
      // email: Joi.string().trim().email({ minDomainAtoms: 2 }).required()
    },
    params: {
      // customerId: Joi.string().trim().hex().required()
    }
  }
};
