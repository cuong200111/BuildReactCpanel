/* eslint-disable new-cap */
const router = require('express').Router();
const mailCtl = require('./mail.controller');
const multer = require('multer');
const path = require('path');

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, '');
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname));
  },
});

const upload = multer({ storage });
router.route('/').get(mailCtl.list).post(mailCtl.sendNodemailer);
router.route('/upload').post(upload.array('files', 12), (req, res, next) => {
  const files = req.files;
  if (!files) {
    const error = new Error('Please upload a file');
    error.httpStatusCode = 400;
    return next(error);
  }
  res.json(files);
});
module.exports = router;
