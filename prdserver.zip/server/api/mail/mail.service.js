/* eslint-disable no-param-reassign */
/* eslint-disable no-console */
/* eslint-disable no-unused-vars */
const { STATUS_SEND } = require('../../variables/CONST_STATUS');
const nodemailer = require('nodemailer');
const sysConf = require('../systemConfig/systemConfig.model');
const Mail = require('../mail/mail.model');
const Sys = require('../systemConfig/systemConfig.model');

async function send(mails) {
  try {
    // console.log(mails);
    const mailSystem = await sysConf.findOne();
    if (!mailSystem || !mailSystem.serviceServer || !mailSystem.mailServer || !mailSystem.passServer) {
      await Mail.updateOne(
          { _id: mails._id },
          { status: STATUS_SEND.FAILED, error: 'Mail hệ thống không tồn tại' },
        );
    }
    const auth = {
      service: mailSystem.serviceServer || 'gmail',
      auth: {
        user: mailSystem.mailServer,
        pass: mailSystem.passServer,
      },
    };
    const transporter = nodemailer.createTransport(auth);
    // for (const m of mails) {

    // }
    // mails.forEach((m) => {
    transporter.sendMail(
      {
        from: mailSystem.mailServer,
        to: mails.to,
        subject: mails.subject,
        text: mails.text,
        html: mails.text,
      },
      async (err, _info) => {
        if (err) {
          return await Mail.updateOne({ _id: mails._id }, { status: STATUS_SEND.FAILED, error: err.message });
        }
        mails.status = STATUS_SEND.SUCCESS;
        return await Mail.updateOne({ _id: mails._id }, { status: STATUS_SEND.SUCCESS, error: '' });
      },
    );
    // }
    // );
  } catch (error) {
    console.log('error', error);
  }
}

async function sendMail(mails, user) {
  try {
    // console.log(mails);
    const mailSystem = await Sys.findOne();
    if (!mailSystem.serviceServer || !mailSystem.mailServer || !mailSystem.passServer) {
      mails.forEach(async (m) => {
        if (m._id) {
          return await Mail.updateOne(
            { _id: m._id },
            { status: STATUS_SEND.FAILED, error: 'Mail hệ thống chưa được cấu hình' },
          );
        } else {
          return await Mail.create({
            status: STATUS_SEND.FAILED,
            error: 'Mail hệ thống chưa được cấu hình',
            to: m.to,
            text: m.text,
            subject: m.subject,
            sender: user,
            campaignId: m.campaignId,
            customer: m.customer,
          });
        }
      });
    }
    const auth = {
      // service: mailSystem.serviceServer,
      host: 'smtp.gmail.com',
      port: 465,
      auth: {
        user: mailSystem.mailServer,
        pass: mailSystem.passServer,
      },
    };
    const transporter = nodemailer.createTransport(auth);
    // console.log(mails);
    mails.map(async (m) => {
      await transporter.sendMail(
        {
          from: mailSystem.mailServer,
          to: m.to,
          subject: m.subject,
          html: m.text,
          // html: m.html,
        },
        async (err, _info) => {
          if (err) {
            if (m._id) {
              return await Mail.updateOne({ _id: m._id }, { status: STATUS_SEND.FAILED, error: err.message });
            }
            let createM = await Mail.create({
              status: STATUS_SEND.FAILED,
              error: err.message,
              to: m.to,
              text: m.text,
              subject: m.subject,
              sender: user,
              campaignId: m.campaignId,
              customer: m.customer,
              filesSend: m.filesSend,
            });
            return createM;
          }
          m.status = STATUS_SEND.SUCCESS;
          if (m._id) {
            return await Mail.updateOne({ _id: m._id }, { status: STATUS_SEND.SUCCESS, error: '' });
          }
          return await Mail.create({
            status: STATUS_SEND.SUCCESS,
            error: err.message,
            to: m.to,
            text: m.text,
            subject: m.subject,
            sender: user,
            campaignId: m.campaignId,
            customer: m.customer,
            error: '',
          });
        },
      );
    });
  } catch (error) {
    console.log('error', error);
  }
}

async function sendMail_ENV({ mails, user, text }) {
  try {
    const auth = {
      service: process.env.SERVICE_SERVER || 'gmail',
      // host: "smtp.gmail.com",
      auth: {
        // type: "login",
        user: process.env.MAIL_SERVER || 'lifetek20@gmail.com', //
        pass: process.env.PASS_SERVER || 'lifetek@2021', //
      },
    };
    const transporter = nodemailer.createTransport(auth);
    mails.map(async (m) => {
      const body = m.html
        ? { from: process.env.MAIL_SERVER, to: m.to, subject: m.subject, html: m.html }
        : { from: process.env.MAIL_SERVER, to: m.to, subject: m.subject, text: text || m.text };
      await transporter.sendMail(body, async (err, _info) => {
        if (err) {
          console.log('sendMail_ENV: ', err);
          // await Mail.create({
          //   status: STATUS_SEND.SUCCESS,
          //   error: err,
          //   to: m.to,
          //   // text: m.text,
          //   subject: m.subject,
          //   // sender: user,
          //   // campaignId: m.campaignId,
          //   // customer: m.customer,
          // });
          return err;
        }
        // console.log('_info:: ', _info);
        return _info;
      });
    });
  } catch (error) {
    console.log('sendMail_ENV:: ', error);
    throw error;
  }
}
module.exports = {
  send,
  sendMail,
  sendMail_ENV,
};
