// eslint-disable-next-line no-unused-vars
const Promise = require('../../../node_modules/bluebird/js/release/bluebird');
const mongoose = require('mongoose');
// eslint-disable-next-line no-unused-vars
const httpStatus = require('http-status');
// eslint-disable-next-line no-unused-vars
const APIError = require('../../helpers/APIError');
// eslint-disable-next-line no-unused-vars
const STATUS = require('../../variables/CONST_STATUS').STATUS;
const STATUS_SEND = require('../../variables/CONST_STATUS').STATUS_SEND;

/**
 * measureUnit Schema
 */
// eslint-disable-next-line no-unused-vars
const mailSchema = new mongoose.Schema(
  {
    from: {
      type: String,
    },
    to: {
      type: String,
      required: true,
    },
    subject: {
      type: String,
      required: true,
    },
    text: {
      type: String,
      required: true,
    },
    customer: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Customer',
    },
    employee: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Employee',
    },
    sender: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Employee',
    },
    status: {
      type: Number,
      enum: [STATUS_SEND.SENDING, STATUS_SEND.SUCCESS, STATUS_SEND.FAILED],
      default: STATUS_SEND.SENDING,
    },
    error: String,
    campaignId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Campaign',
    },
    template: String,
  },
  {
    timestamps: true,
  },
);

/**
 * measureUnit
 */

/**
 * Methods
 */
mailSchema.method({});

/**
 * Statics
 */
mailSchema.statics = {
  /**
   * Get mail
   * @param {ObjectId} id - The ObjectId of mail
   * @returns {Promise<Mail, APIError}
   */
  get(id) {
    return this.findOne({
      _id: id,
    })
      .exec()
      .then((mail) => {
        if (mail) {
          return mail;
        }
        const err = new APIError('No such mail exists!', httpStatus.NOT_FOUND);
        return Promise.reject(err);
      });
  },

  /**
   * List mail in descending order of 'createdAt' timestamps
   *
   * @param {number} skip - Number of mail to be skipped.
   * @param {number} limit - Limit number of mail to be returned.
   * @returns {Promise<Mail[]>}
   */
  async list({
    skip = 0,
    limit = 500,
    sort = {
      createdAt: -1,
    },
    filter = {}
  }) {
    const data = await this.find(filter)
      .populate('employee', 'name')
      .populate('customer', 'name')
      .populate('campaignId', 'template name')
      .sort(sort)
      .skip(+skip)
      .limit(+limit)
      .exec();
    const count = await this.find(filter).count();
    return {
      data,
      count,
      limit,
      skip,
    };
  },
};

module.exports = mongoose.model('Mail', mailSchema);
