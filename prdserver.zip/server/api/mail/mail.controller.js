/* eslint-disable no-unused-vars */
const Sys = require('../systemConfig/systemConfig.model');
const nodemailer = require('nodemailer');
const fs = require('fs');
const Mail = require('./mail.model');
const campaign = require('../campaignEmailSms/campaignEmailSms.model');
const result = require('../task/task.model');
const nodemailerService = require('./mail.service');
const crmSourceModel = require('../crmSource/crmSource.model')();
const STATUS = require('../../variables/CONST_STATUS').STATUS;

function upload(req, res, next) {
  console.log('XXX');
}

async function list(req, res, next) {
  try {
    const { limit = 500, skip = 0, sort, filter } = req.query;
    const listMail = await Mail.list({ limit, skip, sort, filter });
    return res.json(listMail);
  } catch (error) {
    return next(error);
  }
}

async function sendMail(req, res, next) {
  try {
    const mailSystem = await Sys.findOne();
    let attachments = req.body.filesSend;

    attachments = req.body.filesSend.map(i => ({ filename: i.originalname, path: i.path }));

    const auth = {
      service: mailSystem.serviceServer,
      auth: {
        user: mailSystem.mailServer,
        pass: mailSystem.passServer,
      },
    };
    const transporter = nodemailer.createTransport(auth);
    const mainOptions = {
      from: mailSystem.smsBrandname,
      to: req.body.to,
      subject: req.body.subject,
      text: req.body.text,
      html: req.body.html,
    };

    if (attachments.length) {
      mainOptions.attachments = attachments;
    }
    transporter.sendMail(mainOptions, async (err, _info) => {
      if (err) {
        res.status(400).json({ success: false, err });
      } else {
        await Mail.create({
          from: req.body.from,
          // from: mailSystem.smsBrandname,
          to: req.body.to,
          subject: req.body.subject,
          text: req.body.text,
          html: req.body.html,
          customer: req.body.customer,
          employee: req.body.employee,
        });
        res.json({ success: true });
      }

      if (attachments) {
        attachments.forEach((i) => {
          fs.unlinkSync(i.path);
        });
      }
    });
  } catch (error) {
    next(error);
  }
}

async function sendNodemailer(req, res, next) {
  try {
    // const { listCustomer, subject, text } = req.body;
    // const mailSystem = await Sys.findOne();
    // for (let i = 0; i < listCustomer.length; i++) {
    //   if (listCustomer[i].email) {
    //     await nodemailerService(mailSystem, listCustomer[i], subject, text);
    //   }
    // }
    // res.json({ status: 1, message: 'Đã gửi mail' });
    const { listCustomer, template, viewConfig, title, html } = req.body;
    const crmSource = await crmSourceModel.find({ status: STATUS.ACTIVED }).lean();
    const listMail = await Promise.all(
      listCustomer.map(c =>
        Mail.create({
          to: c.email,
          subject: title,
          // text: injectData2Template('Customer', c, template.content),
          // text: convertTemplate({ content: template.content, data: c, code: 'Customer', viewConfig, crmSource }),
          // text: 'test',
          text: html.content,
          customer: c._id,
          sender: req.user.user,
        }),
      ),
    );
    await nodemailerService.sendMail(listMail, req.user.user);
    res.json({ status: 1, message: 'Đã gửi mail!' });
  } catch (error) {
    next(error);
  }
}

async function Nodemailer(mailSystem, listCustomer, subject, text) {
  try {
    const auth = {
      service: mailSystem.serviceServer,
      auth: {
        user: mailSystem.mailServer,
        pass: mailSystem.passServer,
      },
    };
    const transporter = nodemailer.createTransport(auth);
    const mainOptions = {
      from: mailSystem.mailServer,
      to: listCustomer.email,
      subject,
      text,
    };

    transporter.sendMail(mainOptions, async (err, _info) => {
      if (err) {
        return { success: 0, message: err };
      }
      await Mail.create({
        from: mainOptions.from,
        to: mainOptions.to,
        subject: mainOptions.subject,
        text: mainOptions.text,
        customer: listCustomer.customerId,
      });
      return { success: 1, message: 'Thành công' };
    });
  } catch (error) {
    next(error);
  }
}

async function logSendMailCampaign(campaignId, customer, content) {
  try {
    const mail = new Mail({
      campaignId,
      customer,
      text: content,
    });
    return mail.save().then(result => result);
  } catch (error) {
    console.log(error);
    next(error);
  }
}

module.exports = { sendMail, upload, sendNodemailer, list };
