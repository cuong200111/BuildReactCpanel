// eslint-disable-next-line new-cap
const express = require('express');
const router = express.Router();
const roleCtrl = require('./role.controller');

router
    .route('/derpartment')
    .post(roleCtrl.createRolebyDerpartment);
router
    .route('/checkRoleChangePass')
    .get(roleCtrl.checkRoleChangePass)
router
    .route('/derpartment/:employeeId')
    .get(roleCtrl.getRolebyDerpartment)
    .put(roleCtrl.updateRolebyDerpartment);
router
    .route('/')
    .get(roleCtrl.list)
    .post(roleCtrl.create);


router
    .route('/:roleId')
    .get(roleCtrl.get)
    .put(roleCtrl.update);
router.param('roleId', roleCtrl.load);


module.exports = router;
