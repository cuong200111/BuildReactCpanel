const Promise = require('bluebird');
const mongoose = require('mongoose');
const httpStatus = require('http-status');
const APIError = require('../../helpers/APIError');

const roleSchema = new mongoose.Schema(
  {
    userId: {
      required: true,
      type: mongoose.Schema.Types.ObjectId,
    },
    roles: [
      {
        titleFunction: {
          type: String,
          required: true,
        },
        codeModleFunction: {
          type: String,
          required: String,
        },
        clientId: {
          require: true,
          type: String,
        },
        mainRoute: String,
        methods: [
          {
            name: {
              type: String,
              enum: ['GET', 'DELETE', 'PUT', 'POST', 'IMPORT', 'EXPORT'],
            },
            allow: Boolean,
          },
        ],
      },
    ],
  },
  {
    timestamps: true,
  },
);

/**
 * Statics
 */
roleSchema.statics = {
  /**
   * Get role
   *
   * @param {ObjectId} id - The objectId of role.
   * @returns {Promise<role, APIError>}
   */
  get(id) {
    return this.findOne({
      _id: id,
    })
      .exec()
      .then((role) => {
        if (role) {
          return role;
        }
        const err = new APIError('No such role exists!', httpStatus.NOT_FOUND);
        return Promise.reject(err);
      });
  },

  /**
   * List roles in descending order of 'createdAt' timestamp.
   *
   * @param {number} skip - Number of roles to be skipped.
   * @param {number} limit - Limit number of roles to be returned.
   * @returns {Promise<role[]>}
   */
  async list({
    skip = 0,
    limit = 500,
    sort = {
      createdAt: -1,
    },
    filter = {},
  }) {
    /* eslint-disable no-param-reassign */
    const data = await this.find(filter)
      .sort(sort)
      .skip(+skip)
      .limit(+limit)
      .exec();
    const count = await this.find(filter).count();
    return {
      data,
      count,
      limit,
      skip,
    };
  },
};

module.exports = mongoose.model('Role', roleSchema);
