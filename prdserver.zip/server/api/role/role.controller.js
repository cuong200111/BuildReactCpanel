/* eslint-disable consistent-return */
/* eslint-disable camelcase */
const Role = require('./role.model');
const RoleTask = require('../roleTask/role.model');
const RoleDerpartment = require('./role.derpartment');
// const Employee = require('../employee/employee.model');
// const allModule = require('../common/common.controller');

const APIError = require('../../helpers/APIError');
const { result } = require('lodash');
// const httpStatus = require('http-status');

/**
 * Load role and append to req
 */
async function load(req, res, next, id) {
  // eslint-disable-next-line no-param-reassign
  req.role = await Role.findOne({
    $or: [{
      _id: id
    }, {
      userId: id,
    }]
  });
  if (!req.role) {
    req.role = {};
    // return next(
    //     new APIError('Item not found', httpStatus.NOT_FOUND, true));
  }
  next();
}
/**
 * list role
 */
async function list(req, res, next) {
  try {
    const { limit = 500, skip = 0, sort, filter } = req.query;
    const roles = await Role.listBy({ limit, skip, sort, filter });
    res.json(roles);
  } catch (e) {
    next(e);
  }
}
/**
 * create role
 */
// eslint-disable-next-line consistent-return
async function create(req, res, next) {
  try {
        // eslint-disable-next-line max-len
    const {
      userId,
      roles
    } = req.body;
    const role = new Role({
        // eslint-disable-next-line max-len
      userId,
      roles
    });

    return role.save()
                    .then((savedrole) => {
                      if (savedrole) res.json(savedrole);
                      else res.transforemer.errorBadRequest('Không thể tạo quyền');
                    })
      .catch((e) => {
        next(e);
      });
  } catch (e) {
    next(e);
  }
}

async function checkRoleChangePass(req, res, next) {
  try {
    const Employee = global.hshCollections['Employee'];
    const { admin, user } = req.query;
    const [adminEmployee, userEmployee] = await Promise.all([
      Employee.findOne({ userId: admin }).lean(),
      Employee.findById(user).lean(),
    ])
    if (!adminEmployee) return res.json({ status: 0, message: 'Vui lòng đăng nhập lại' });
    const adminEmployeeId = adminEmployee._id;
    const role = await RoleTask.findOne({ userId: adminEmployeeId, moduleCode: 'Employee' });
    let isRole = false;
    if (role && role.roles && role.roles.length) {
      const businessRole = role.roles.find(item => item.code === 'BUSSINES');
      if (businessRole && businessRole.data && businessRole.data.length) {
        const passwordRole = businessRole.data.find(m => m.name === 'password');
        if (passwordRole && passwordRole.data && passwordRole.data.changePassWord) {
          isRole = true;
        }
      }
    }
    if (!isRole) return res.json({ status: 0, message: 'Bạn không có quyền đổi mật khẩu'});
    else return res.json({ status: 1, user: userEmployee.userId, message: 'Kiểm tra thành công' });
  } catch (error) {
    res.json({ status: 0, message: error });
  }
}

async function getRolebyDerpartment(req, res, next) {
  try {
    const employeeId = req.params.employeeId;
    if (!employeeId) {
      res.json(new APIError('Need param employeeId'), 400, true);
      return;
    }
    const role = await RoleDerpartment.findOne({ userId: employeeId }).populate('roles.organizationUnits.organizationUnitId', 'path name code');
    res.json(role);
  } catch (error) {
    next(error);
  }
}


async function createRolebyDerpartment(req, res, next) {
  try {
    const { userId, roles } = req.body;
    // console.log("DFDFDEF");
    const check = await RoleDerpartment.findOne({ userId });
    if (check) {
      check.roles = roles;
      const data = await check.save();
      return res.json(data);
    }
    // eslint-disable-next-line max-len
    const role = new RoleDerpartment({
    // eslint-disable-next-line max-len
      userId,
      roles
    });

    const data = await role.save();
    res.json(data);
  } catch (e) {
    // console.log(e);

    next(e);
  }
}

async function updateRolebyDerpartment(req, res, next) {
  const employeeId = req.params.employeeId;
  console.log(employeeId);
}


/**
 * update role
 */
// eslint-disable-next-line consistent-return
async function update(req, res, next) {
  try {
    const {
      userId,
      roles,
      resetChild
    } = req.body;

    // if(resetChild){
    //  await Role.remove({userId:userId,moduleCode:{$exists: true}});
    // }
    if (Object.keys(req.role).length === 0) {
      const role = new Role({
        // eslint-disable-next-line max-len
        userId,
        roles
      });
      return role.save().then(async (result) => {
        res.json(result);
      }).catch((err) => {
        next(err);
      });
    }


    const role = req.role;
    role.userId = userId;
    role.roles = roles;

    return role.save().then(async (result) => {
      res.json(result);
    }).catch((err) => {
      next(err);
    });
  } catch (e) {
    next(e);
  }
}

function get(req, res) {
  // console.log(req.role);
  res.json(req.role);
}

module.exports = {
  list,
  load,
  create,
  update,
  get,
  checkRoleChangePass,
  getRolebyDerpartment,
  updateRolebyDerpartment,
  createRolebyDerpartment
};
