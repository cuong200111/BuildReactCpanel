const educateProcess = require('./hrmEducate.model')();
// const httpStatus = require('http-status');
// const APIError = require('../../helpers/APIError');
const STATUS = require('../../variables/CONST_STATUS').STATUS;
const taskCtrl = require('../task/task.controller');

async function list(req, res, next) {
  try {
    const { limit = 500, skip = 0, sort, filter } = req.query;
    await educateProcess.list({ limit, skip, sort, filter })
        .then((data) => {
          res.json(data);
        })
        .catch(e => next(e));
  } catch (e) {
    next(e);
  }
}

function load(req, res, next, id) {
  educateProcess.get(id)
        .then((data) => {
          // eslint-disable-next-line no-param-reassign
          req.educateProcess = data;
          next();
        })
        .catch(e => next(e));
}


// eslint-disable-next-line no-unused-vars
function get(req, res, next) {
  res.json(req.educateProcess);
}

async function create(req, res, next) {
  try {
    const educateProc = await educateProcess.create(req.body);
    if (educateProc && educateProc.employeeId) {
      taskCtrl.sendNotice({ 
        title: 'Bạn có khóa đào tạo', 
        content: 'Bạn đã được tham gia một khóa đào tạo', 
        to: educateProc.employeeId, 
        link: '/hrm/educate'+ educateProc._id, 
        type: 'System' 
      })
      res.status(200).json({ success: true, data: educateProc });
    }
  } catch (e) {
    next(e);
  }
}

async function update(req, res, next) {
  try {
    const updateData = await educateProcess.findByIdAndUpdate(req.params.educateProcessId, req.body, { new: true });
    res.status(200).json({ success: true, data: updateData });
  } catch (e) {
    next(e);
  }
}

async function deleteItem(req, res, next) {
    // console.log(req.educateProcess);
  const salaryStatus = req.educateProcess;
  salaryStatus.status = STATUS.DELETED;
  salaryStatus
    .save()
    .then((result) => {
      res.json({
        success: true,
        data: result,
      });
    })
    .catch(e => next(e));
}

module.exports = {
  list,
  create,
  update,
  deleteItem,
  get,
  load
};
