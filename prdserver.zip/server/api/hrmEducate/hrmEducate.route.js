const express = require('express');
// const validate = require('express-validation');
const hrmEducateCtrl = require('./hrmEducate.controller');

// eslint-disable-next-line new-cap
const router = express.Router();

router
  .route('/')
  /** GET /api/hrmEducate - Get list of hrmEducate */
  .get(hrmEducateCtrl.list)
  /** POST /api/hrmEducate - Add   hrmEducate*/
  .post(hrmEducateCtrl.create);

router
  .route('/:hrmEducateId')
  .get(hrmEducateCtrl.get)
  .put(hrmEducateCtrl.update)
  .delete(hrmEducateCtrl.deleteItem);

router.param('hrmEducateId', hrmEducateCtrl.load);
module.exports = router;
