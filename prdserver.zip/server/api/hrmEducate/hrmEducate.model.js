/* eslint-disable no-param-reassign */
const Promise = require('bluebird');
const mongoose = require('mongoose');
const httpStatus = require('http-status');
const APIError = require('../../helpers/APIError');
const STATUS = require('../../variables/CONST_STATUS').STATUS;
// const STATUS_KANBAN = require('../../variables/CONST_STATUS').CODE_STATUS_CANBAN;

const dynamicSchema = require('../../helpers/dynamic-collection');
const modelHelper = require('../../helpers/model');

const common = require('../../helpers/common');


function result(title) {
  const code = 'HrmEducate';
  const plugins = [];

  if (Object.prototype.hasOwnProperty.call(global.hshCollections, code)) {
    return global.hshCollections[code];
  }

  async function model() {
    const hrmEducateRow = {
      branch: {
        type: String,
        required: true,
      },
      pending: String,
      part: String,
      location: String,
      amount: Number,
      employeeId: {
        type: mongoose.Types.ObjectId,
        ref: 'Employee'
      },
      startDate: {
        type: Date
      },
      needDate: {
        type: Date
      },
      age: Number,
      gender: {
        type: String,
        enum: ['male', 'female', ''],
        default: ''
      },
      experience: Number,
      salary: Number,
      level: String,
      fields: String,
      reason: String,
      note: String,
      file: String,
      status: {
        type: Number,
        enum: [0, 1, 2, 3],
        default: 1,
      },
    };
    const dynamicParsed = modelHelper.parseRawModel(hrmEducateRow);
    const HrmEducateSchema = new mongoose.Schema(dynamicParsed.schema);

    HrmEducateSchema.statics = {
      /**
       * Get customer
       *
       * @param {ObjectId} id - The objectId of customer.
       * @returns {Promise<Customer, APIError>}
       */
      get(id) {
        return this.findOne({
          _id: id,
          // status: STATUS.ACTIVED,
        })

          .exec()
          .then((data) => {
            if (data) {
              return data;
            }
            const err = new APIError('No such data exists!', httpStatus.NOT_FOUND);
            return Promise.reject(err);
          });
      },

      /**
       * List data in descending order of 'createdAt' timestamp.
       *
       * @param {number} skip - Number of data to be skipped.
       * @param {number} limit - Limit number of data to be returned.
       * @returns {Promise<data[]>}
       */
      list({
        skip = 0,
        limit = 500,
        sort = {
          createdAt: -1,
        },
        filter = {},
      }) {
        filter.status = STATUS.ACTIVED;
        // convertToFullTextSearch(filter);
        return this.find(filter)

          .sort(sort)
          .skip(+skip)
          .limit(+limit)
          .exec();
      },

      async listBy({
        skip = 0,
        limit = 500,
        sort = {
          createdAt: -1,
        },
        filter = {},
        createdBy,
      }) {
        /* eslint-disable no-param-reassign */
        filter.status = STATUS.ACTIVED;
        // convertToFullTextSearch(filter);

        const filterRole = await common.filterRoleTask({ filter, createdBy, code });
        const data = await this.find(filterRole)
          .sort(sort)
          .skip(+skip)
          .limit(+limit)
          .exec();
        const count = await this.find(filterRole).count();
        return {
          data,
          count,
          limit,
          skip,
        };
      },
    };

    // eslint-disable-next-line max-len
    const schema = await dynamicSchema.addDynamicCollectionFromCode(dynamicParsed, HrmEducateSchema, code, plugins);

    // use default controller
    return dynamicSchema.addModelToCode(code, schema, title);
  }
  return model();
}

module.exports = result;
