// eslint-disable-next-line new-cap
const router = require('../../../node_modules/express').Router();
const CrmSourceCtrl = require('./crmSource.controller');

router
    .route('/')
    .post(CrmSourceCtrl.create)
    .get(CrmSourceCtrl.list);


router
    .route('/:crmSourceId')
    .put(CrmSourceCtrl.update)
    .delete(CrmSourceCtrl.del)
    .get(CrmSourceCtrl.get);

router.route('/reset').post(CrmSourceCtrl.reset);

router.param('crmSourceId', CrmSourceCtrl.load);
CrmSourceCtrl.init();
module.exports = router;
