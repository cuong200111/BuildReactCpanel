/* eslint-disable no-plusplus */
/* eslint-disable consistent-return */
const CRMSource = require('./crmSource.model')();
const APIError = require('../../helpers/APIError');
const httpStatus = require('http-status');
const STATUS = require('../../variables/CONST_STATUS').STATUS;
const crmSourceInit = require('./crmSource.init');
/**
 * Load measureUnit and append to req
 */
const load = async (req, res, next, id) => {
  // eslint-disable-next-line no-param-reassign
  req.crmSource = await CRMSource.findById(id);
  if (!req.crmSource) {
    next(new APIError('Item not found', httpStatus.NOT_FOUND, true));
  }
  next();
};
/**
 * list measureUnit
 */
const list = async (req, res, next) => {
  try {
    const { filter = {} } = req.query;
    await init();
    const crmSource = await CRMSource.list({
      filter,
      skip: req.query.page || 0,
      limit: req.query.perPage || 500,
    });
    res.json(crmSource);


    // const { limit = 500, skip = 0, sort, filter } = req.query;
    // CRMSourcev.list({ limit, skip, sort, filter })
    //     .then((crmSource) => {
    //       res.json(crmSource);
    //     })
    // .catch(e => next(e));
  } catch (e) {
    next(e);
  }
};
async function init() {
  const crmSource = await CRMSource.find();
  const newCrmSource = crmSourceInit.crmSource.filter(item => !crmSource.find(crmSourceItem => crmSourceItem.code === item.code));
  if (newCrmSource.length) {
    await Promise.all(newCrmSource.map(item => ({ ...item, originalName: item.title, canDelete: false })).map(item => new CRMSource(item).save()));
  }
}
const get = (req, res) => {
  res.json(req.crmSource);
};
const create = async (req, res, next) => {
  try {
    const { title, canDragDrop, type } = req.body;
    const crmSource = new CRMSource({ title, canDragDrop, type });

    return crmSource
      .save()
      .then((savedCrmSource) => {
        if (savedCrmSource) res.json(savedCrmSource);
        else res.transforemer.errorBadRequest('Can not create item');
      })
      .catch((e) => {
        next(e);
      });
  } catch (e) {
    next(e);
  }
};

const allArr = [];
let index = 0;
function checkChild(arr) {
  // eslint-disable-next-line no-plusplus
  for (let i = 0; i < arr.length; ++i) {
    // eslint-disable-next-line no-param-reassign
    arr[i].index = index;
    index += 1;
    allArr.push({
      index: arr[i].index,
      name: arr[i].name,
      value: arr[i].value,
    });
    if (arr[i].children) {
      checkChild(arr[i].children);
    }
  }
}
const update = async (req, res, next) => {
  try {
    const { title, data } = req.body;
    // const 0 = 0;
    const crmSource = req.crmSource;
    crmSource.title = title;
    // eslint-disable-next-line no-plusplus
    if (data) {
      crmSource.data = data;
      for (let i = 0; i < data.length; ++i) {
        data[i].index = index;
        index += 1;
        allArr.push({
          index: data[i].index,
          name: data[i].name,
          value: data[i].value,
        });
        if (data[i].children) {
          checkChild(data[i].children);
        }
      }
    }

    return crmSource
      .save()
      .then(async (result) => {
        res.json(result);
      })
      .catch((err) => {
        next(err);
      });
  } catch (e) {
    next(e);
  }
};
const del = async (req, res, next) => {
  try {
    const crmSource = req.crmSource;
    if (!crmSource.canDelete) {
      return res.json({
        status: 0,
        message: 'Không thể xóa kiểu loại mặc định'
      });
    }
    crmSource.status = STATUS.DELETED;
    crmSource
      .save()
      .then(
        res.transformer
          .noContent()
          .withStatus(httpStatus.OK)
          .dispatch(),
      )
      .catch(e => next(e));
  } catch (e) {
    next(e);
  }
};

const updateCrmSource = async (req, res, next) => {
  try {
    const { title } = req.body;
    const crmSource = req.crmSource;
    crmSource.title = title;
    return crmSource
      .save()
      .then(async (result) => {
        res.json(result);
      })
      .catch((err) => {
        next(err);
      });
  } catch (e) {
    next(e);
  }
};

const reset = async (req, res) => {
  try {
    await CRMSource.updateMany({ canDelete: true }, { status: STATUS.DELETED });
    const data = await CRMSource.find({ canDelete: false });
    if (data) {
      for (let i = 0; i < data.length; i++) {
        if (data[i].title !== data[i].originalName) {
          await CRMSource.updateOne({ _id: data[i]._id }, { title: data[i].originalName });
        }
      }
    }
    return res.json({ status: 1 });
  } catch (e) {
    return res.json({ status: 0, message: e.message });
  }
};

module.exports = {
  load,
  list,
  get,
  create,
  update,
  del,
  init,
  updateCrmSource,
  reset,
};
