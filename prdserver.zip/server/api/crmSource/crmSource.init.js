const sourceHistoryData = require('../../historyData/api/crmSource/crmSource.init');
const crmSource = [
  {
    title: 'Nguồn',
    canDragDrop: true,
    code: 'S06',
  },
  {
    title: 'Nguồn vốn',
    canDragDrop: true,
    code: 'S18',
  },
  {
    title: 'Loại hợp đồng khách hàng',
    canDragDrop: true,
    code: 'S15',
    data: [
      {
        title: 'Hợp đồng nguyên tắc',
        index: 1,
        value: '1',
        cantDelete: true,
      },
      {
        title: 'Hợp đồng kinh tế',
        index: 2,
        value: '2',
        cantDelete: true,
      },
      {
        title: 'Hợp đồng thời vụ',
        index: 3,
        value: '3',
        cantDelete: true,
      },
    ],
  },
  {
    title: 'Phương thức thanh toán',
    canDragDrop: true,
    code: 'S17',
    data: [
      {
        title: 'Chuyển Khoản',
        index: 1,
        value: '1',
        cantDelete: true,
      },
      {
        title: 'Tiền Mặt',
        index: 2,
        value: '2',
        cantDelete: true,
      },
    ],
  },
  {
    title: 'Loại danh nghiệp',
    canDragDrop: true,
    code: 'S14',
  },
  {
    title: 'Nhân viên',
    canDragDrop: true,
    code: 'S13',
  },
  {
    title: 'Ngành nghề',
    canDragDrop: true,
    code: 'S12',
  },
  {
    title: 'Loại trao đổi/thỏa thuận',
    canDragDrop: true,
    code: 'S11',
  },
  {
    title: 'Khu vực địa lý',
    canDragDrop: true,
    code: 'S10',
  },
  {
    title: 'Giao dịch mới',
    canDragDrop: true,
    code: 'S09',
  },
  {
    title: 'Loại khách hàng',
    canDragDrop: true,
    code: 'S08',
  },
  {
    title: 'Nhóm khách hàng',
    canDragDrop: true,
    code: 'S07',
  },
  {
    title: 'Loại sự kiện',
    canDragDrop: true,
    code: 'S16',
  },
  {
    title: 'Phân cấp khách hàng',
    canDragDrop: false,
    code: 'pckh',
  },
  {
    title: 'Loại đơn vị',
    canDragDrop: false,
    code: 'S01',
  },
  {
    title: 'Mặt hàng kinh doanh',
    canDragDrop: false,
    code: 'S02',
  },
  {
    title: 'Hình thức trao đổi',
    canDragDrop: false,
    code: 'S03',
  },
  {
    title: 'Ngân hàng',
    canDragDrop: false,
    code: 'S04',
  },
  {
    title: 'Công đoạn',
    canDragDrop: false,
    code: 'S05',
  },
  {
    title: 'Loại công văn',
    canDragDrop: false,
    code: 'S19',
    type: 'DocumentConfig'
  },
  {
    title: 'Độ khẩn',
    canDragDrop: false,
    code: 'S20',
    type: 'DocumentConfig'
  },
  {
    title: 'Độ mật',
    canDragDrop: false,
    code: 'S21',
    type: 'DocumentConfig'
  },
  {
    title: 'Nơi lưu trữ công văn',
    canDragDrop: false,
    code: 'S22',
    type: 'DocumentConfig'
  },
  {
    title: 'Nơi phát hành công văn',
    canDragDrop: false,
    code: 'S23',
    type: 'DocumentConfig'
  },
  {
    title: 'Loại chi phí',
    canDragDrop: false,
    code: 'S24',
    data: [
      {
        title: 'Chi phí lương',
        index: 1,
        value: 'CPTTL',
        cantDelete: true,

      },
      {
        title: 'Chi phí tuyển dụng',
        index: 2,
        value: '234',
        cantDelete: true,
      },
    ],
    type: 'RevenueExpenditureConfig'
  },
  {
    title: 'Phân loại nhà cung cấp',
    canDragDrop: false,
    code: 'S25',
  },
  {
    title: 'Tình trạng thanh toán',
    canDragDrop: false,
    code: 'S40',
    data: [
      {
        title: 'Khả thi thanh toán',
        index: 1,
        value: 'kha thi thanh toan',
        cantDelete: true,
      },
      {
        title: 'Khó đòi',
        index: 2,
        value: 'kho doi',
        cantDelete: true,
      },
    ],
  },
  {
    title: 'Phòng họp',
    canDragDrop: false,
    type: "CalendarConfig",
    code: 'S41',
    data: [
      {
        title: 'phòng họp nhóm',
        index: 1,
        value: 'nhom1',
        address: 'H_103',

      },
      {
        title: 'nhóm 2',
        index: 2,
        value: 'nhom2',
        address: 'H_104',

      },
    ],
  },
  {
    title: 'Loại hợp đồng nhà cung cấp',
    canDragDrop: true,
    code: 'S44',
    data: [
      {
        title: 'Hợp đồng nguyên tắc',
        index: 1,
        value: '1',
        cantDelete: true,
      },
      {
        title: 'Hợp đồng kinh tế',
        index: 2,
        value: '2',
        cantDelete: true,
      },
      {
        title: 'Hợp đồng thời vụ',
        index: 3,
        value: '3',
        cantDelete: true,
      },
    ],
  },
];
crmSource.push(...sourceHistoryData.crmSource);
module.exports = {
  crmSource,
};
