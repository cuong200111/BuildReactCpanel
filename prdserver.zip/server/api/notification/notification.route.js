// eslint-disable-next-line new-cap
const router = require('../../../node_modules/express').Router();
const notificationCtrl = require('./notification.controller');

router
    .route('/')
    .get(notificationCtrl.list)
    .post(notificationCtrl.create)
    .delete(notificationCtrl.deletedList);

router.route('/updateRead').get(notificationCtrl.updateRead);

router
    .route('/:notificationId')
    .get(notificationCtrl.get)
    .delete(notificationCtrl.del)
    .put(notificationCtrl.update);
router.param('notificationId', notificationCtrl.load);


module.exports = router;
