/* eslint-disable dot-notation */
/* eslint-disable consistent-return */
/* eslint-disable camelcase */
const Notification = require('./notification.model');
const config = require('config');
// const Employee = require('../employee/employee.model')();

const APIError = require('../../helpers/APIError');
const httpStatus = require('http-status');
const STATUS = require('../../variables/CONST_STATUS').STATUS;
const RABBIT_CHANNEL = require('../../variables/CONST_STATUS').RABBIT_CHANNEL;

/**
 * Load notification and append to req
 */
async function load(req, res, next, id) {
  // eslint-disable-next-line no-param-reassign
  req.notification = await Notification.findById(id);
  if (!req.notification) {
    next(new APIError('Item not found', httpStatus.NOT_FOUND, true));
  }
  next();
}
/**
 * list notification
 */
async function list(req, res, next) {
  try {
    const { limit = 5000, skip = 0, sort, filter } = req.query;
    const notifications = await Notification.list({ limit, skip, sort, filter });
    res.json(notifications);
  } catch (e) {
    next(e);
  }
}
/**
 * create notification
 */
// eslint-disable-next-line consistent-return
async function create(req, res, next) {
  try {
    // eslint-disable-next-line max-len
    const { title, content, type, link, to, date, projectCode } = req.body;
    const notification = new Notification({
      // eslint-disable-next-line max-len
      title,
      content,
      projectCode,
      type,
      link,
      to,
      date,
    });

    return notification
      .save()
      .then((savednotification) => {
        if (savednotification) res.json(savednotification);
        else res.transforemer.errorBadRequest('Can not create item');
      })
      .catch((e) => {
        next(e);
      });
  } catch (e) {
    next(e);
  }
}
/**
 * update notification
 */
// eslint-disable-next-line consistent-return
async function update(req, res, next) {
  try {
    const { title, content, type, link, to, date, isRead } = req.body;

    const notification = req.notification;
    notification.title = title;
    notification.content = content;
    notification.type = type;
    notification.link = link;
    notification.to = to;
    notification.date = date;
    notification.isRead = isRead;

    return notification
      .save()
      .then(async (result) => {
        res.json(result);
      })
      .catch((err) => {
        next(err);
      });
  } catch (e) {
    next(e);
  }
}
async function updateRead(req, res) {
  try {
    const user = req.user.user;
    // await Notification.updateMany({ status: STATUS.ACTIVED, to: user }, { $set: { isRead: true } }, { new: true });
    await Notification.updateMany({ status: STATUS.ACTIVED, to: user }, { $set: { isRead: true } }, { new: true }, (err) => {
      if (err) return res.status(400).json({ status: 0, message: 'Update failed' });
      return res.status(200).json({ status: 1, message: 'Updated done' });
    });
  } catch (error) {
    console.log(error);
  }
}
/**
 * Delete costEstimate.
 * @returns notification
 */
function del(req, res, next) {
  const notification = req.notification;
  notification.status = STATUS.DELETED;
  notification.code = '';

  notification
    .save()
    .then((result) => {
      res.json({
        success: true,
        data: result,
      });
    })
    .catch((e) => next(e));
}

async function deletedList(req, res, next) {
  try {
    const { ids } = req.body;
    const arrDataDelete = ids.map(async (notificationId) => {
      const notification = await Notification.findById(notificationId);
      if (notification) {
        notification.status = STATUS.DELETED;
        notification.code = '';
        return notification.save();
      }
    });
    const deletedData = await Promise.all(arrDataDelete);
    res.json({
      success: true,
      data: deletedData,
    });
  } catch (e) {
    next(e);
  }
}
function get(req, res) {
  res.json(req.notification);
}

// eslint-disable-next-line consistent-return
async function createLocal(body) {
  // eslint-disable-next-line max-len
  const { title, content, type, link, to, date, auto, automationRuleId } = body;
  const socket = global.io;
  // console.log('notification::::', typeof socket);
  // console.log('notification,socketId::::', socket.nsps['namespace'].adapter.rooms['room']);
  const EmployeeModel = global.hshCollections['Employee'];
  let sendTo = to;
  let topic = to;
  if (String(to).length === 24) {
    const emp = await EmployeeModel.findOne({
      $or: [
        {
          _id: to
        },
        {
          userId: to
        }
      ]
    });
    if (emp) {
      sendTo = emp._id;
    }
    if (emp && emp.userId) {
      topic = emp.userId;
    }
  }
  const notification = new Notification({
    // eslint-disable-next-line max-len
    title,
    content,
    type,
    link,
    to: sendTo,
    date,
    automationRuleId
  });

  const newNoti = await notification.save();
  const chan = global.hshCollections['chan'];
  if (chan && (!auto || automationRuleId)) {
    if (topic) {
      const messageNov = {
        notification: {
          title: newNoti.title,
          body: newNoti.content,
        },
        topic
      };

      const url = process.env.HOST_NAME || 'https://stagingerp.lifetek.vn';
      if (url) {
        messageNov.webpush = {
          fcm_options: {
            link: url + newNoti.link
          }
        };
      }
      const client = process.env.CLIENT_NOTIFICATION || '08_CRM';
      chan.then(c => c.publish(RABBIT_CHANNEL.NOTIFICATION, `${client}.${RABBIT_CHANNEL.NOTIFICATION}`, Buffer.from(JSON.stringify(messageNov))));
    }
  }
  // const newNoties = await Notification.list({ limit: 10, skip: 0 });
  socket.to(sendTo).emit('notice', newNoti);
  return newNoti;
}
// eslint-disable-next-line consistent-return
async function updateLocal(notification) {
  return await notification.save();
}


module.exports = {
  list,
  load,
  create,
  update,
  del,
  get,
  deletedList,
  createLocal,
  updateLocal,
  updateRead
};
