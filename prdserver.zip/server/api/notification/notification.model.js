const Promise = require('bluebird');
const mongoose = require('mongoose');
const httpStatus = require('http-status');
const APIError = require('../../helpers/APIError');
const STATUS = require('../../variables/CONST_STATUS').STATUS;
const convertToFullTextSearch = require('../../helpers/convertToFullTextSearch');

const notificationSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: true,
    },
    content: {
      type: String,
    },
    type: String,
    link: String,
    to: {
      type: mongoose.Schema.Types.ObjectId, // gửi đến ai
      ref: 'Employee',
    },
    from: mongoose.Schema.Types.ObjectId, // thuộc object nào
    date: {
      type: Date,
      required: true,
    },
    isRead: {
      type: Boolean,
      default: false,
    },
    status: {
      type: Number,
      enum: [0, 1, 2, 3],
      default: 1,
    },
    automationRuleId: String,
  },
  {
    timestamps: true,
  },
);

/**
 * Statics
 */
notificationSchema.statics = {
  /**
   * Get notification
   *
   * @param {ObjectId} id - The objectId of notification.
   * @returns {Promise<notification, APIError>}
   */
  get(id) {
    return this.findOne({
      _id: id,
      status: STATUS.ACTIVED,
    })
      .exec()
      .then((notification) => {
        if (notification) {
          return notification;
        }
        const err = new APIError('No such notification exists!', httpStatus.NOT_FOUND);
        return Promise.reject(err);
      });
  },

  /**
   * List notifications in descending order of 'createdAt' timestamp.
   *
   * @param {number} skip - Number of notifications to be skipped.
   * @param {number} limit - Limit number of notifications to be returned.
   * @returns {Promise<notification[]>}
   */
  async list({
    skip = 0,
    limit = 500,
    sort = {
      createdAt: -1,
    },
    filter = {},
  }) {
    /* eslint-disable no-param-reassign */
    filter.status = STATUS.ACTIVED;
    convertToFullTextSearch(filter);
    const data = await this.find(filter)
      .sort(sort)
      .skip(+skip)
      .limit(+limit)
      .exec();
    const count = await this.find(filter).count();
    const isNotRead = await this.find({ ...filter, isRead: false }).count();
    return {
      data,
      count,
      limit,
      skip,
      isNotRead,
    };
  },
};

module.exports = mongoose.model('Notification', notificationSchema);
