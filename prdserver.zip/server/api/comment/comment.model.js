const Promise = require('bluebird');
const mongoose = require('mongoose');
const httpStatus = require('http-status');
const APIError = require('../../helpers/APIError');
const STATUS = require('../../variables/CONST_STATUS').STATUS;

/**
 * Service Schema
 */
const CommentSchema = new mongoose.Schema(
  {
    id: String,                                                                   // projectID
    code: String,                                                                 // moduleCode: TASK, BusinessOpportunities
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Employee',
      required: true,
    },                                                                            // Người comment
    parentId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Comment',
    },                                                                            // Comment cha nếu có
    type: { enum: [0, 1], type: Number, default: 0 },                             // Cấp bậc cha con
    content: String,
    lastComment: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Employee',
    },                                                                            // Người comment cuối cùng
    replyUser: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Employee',
    },                                                                             // Người trả lời
    isChild: Boolean,                                                             // Có comment con không
    status: {
      type: Number,
      enum: [0, 1, 2, 3],
      default: STATUS.ACTIVED,
    },                                                                            // Trạng thái thái comment
    likeds: [],
    image: []
  },
  {
    timestamps: true,
  },
);

/**
 * Add your
 * - pre-save hooks
 * - validations
 * - virtuals
 */

/**
 * Methods
 */
CommentSchema.method({});

/**
 * Statics
 */
CommentSchema.statics = {
  /**
   * Get service
   * @param {ObjectId} id - The objectId of service.
   * @returns {Promise<Service, APIError>}
   */
  get(code) {
    return this.findOne({
      code,
      status: STATUS.ACTIVED,
    })
      .exec()
      .then((service) => {
        if (service) {
          return service;
        }
        const err = new APIError('No such service exists!', httpStatus.NOT_FOUND);
        return Promise.reject(err);
      });
  },

  /**
   * List services in descending order of 'createdAt' timestamp.
   * @param {number} skip - Number of services to be skipped.
   * @param {number} limit - Limit number of services to be returned.
   * @returns {Promise<Service[]>}
   */
  list({ skip = 0, limit = 500, filter } = {}) {
    // console.log("FILTER",filter);

    return this.find(filter)
      .populate('user', 'name avatar')
      .sort({ createdAt: -1 })
      .skip(+skip)
      .limit(+limit)
      .exec();
  },

  async listBy({ skip = 0, limit = 500, filter } = {}) {
    // console.log("FILTER",filter);

    const data = await this.find(filter)
      .populate('user', 'name avatar')
      .sort({ createdAt: -1 })
      .skip(+skip)
      .limit(+limit)
      .exec();
    const count = await this.find(filter).count();
    // console.log(data);

    return {
      data,
      count,
      limit,
      skip,
    };
  },
};

CommentSchema.index({ id: 1, parentId: 1 });
/**
 * @typedef Service
 */
module.exports = mongoose.model('Comment', CommentSchema);
