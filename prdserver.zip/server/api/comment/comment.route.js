const express = require('express');

const commentCtl = require('./comment.controller');

const router = express.Router();

router.route('/like/:id').post(commentCtl.like);

router
  .route('/')
  .get(commentCtl.getComments)
  .post(commentCtl.createComment)
  .delete(commentCtl.removeManny);

router.route('/:id')
  .delete(commentCtl.remove);

router.param('id', commentCtl.getId);
module.exports = router;
