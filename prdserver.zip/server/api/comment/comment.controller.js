const Comment = require('./comment.model');
// const Employee = require('../employee/employee.model')();
const STATUS = require('../../variables/CONST_STATUS').STATUS;
const _ = require('lodash');
// const axios = require('axios');
// // const CustomerTransformer = require('./customer.transformer');
// const httpStatus = require('http-status');
// const APIError = require('../../helpers/APIError');

async function getComments(req, res, next) {
  try {
    const { limit = 1000, skip, sort, filter = {}, id, code, parentId } = req.query;
    if (!id || !code) return res.status(500).json({ success: false, message: 'Cần có code và id' });
    filter.status = STATUS.ACTIVED;
    filter.id = id;
    filter.code = code;
    if (parentId) {
      filter.parentId = parentId;
    } else {
      filter.parentId = undefined;
    }
    const comments = await Comment.listBy({ limit, skip, sort, filter });
    if (!parentId) {
      comments.data = comments.data.map((e) => ({ ...e._doc, totalReply: 0 }));
      // eslint-disable-next-line
      for (let i = 0; i < comments.data.length; i++) {
        comments.data[i].totalReply = await Comment.find({ id, code, parentId: comments.data[i]._id }).countDocuments();
      }
    }
    return res.json(comments);
  } catch (error) {
    return next(error);
  }
}

// Thêm commnent
async function createComment(req, res, next) {
  try {
    const { user } = req.user;
    // console.log('UER', req.user);
    if (!user) return res.status(500).json({ success: true, message: 'Không thể xác định người dùng' });
    const { parentId, id, content, type, replyUser, code, image } = req.body;
    const body = { parentId, id, content, type, user, replyUser, code, image };
    if (parentId) body.type = 1;
    const comment = new Comment(body);
    const data = await comment.save();
    // eslint-disable-next-line eqeqeq
    if (parentId) {
      const parent = await Comment.findById(parentId);
      parent.lastComment = user;
      parent.isChild = true;
      await parent.save();
    }
    return res.json(data);
  } catch (error) {
    return next(error);
  }
}

async function remove(req, res, next) {
  try {
    const comment = req.comment;
    if (!comment) {
      return res.json({
        status: 0,
        message: 'Vui lòng nhập vào bản ghi cần xóa'
      })
    }
    if (String(comment.user) !== String(req.user.user)) {
      return res.json({
        status: 0,
        message: 'Bạn không có quyền xóa'
      })
    }
    req.body.ids = [comment._id];
    return removeManny(req, res, next)
  } catch (error) {
    console.log('remove:: ', error);
    next(error)
  }
}

async function removeManny(req, res, next) {
  try {
    const ids = req.body.ids;
    if (!ids) {
      return res.json({
        status: 0,
        message: 'Vui lòng nhập vào danh sách bản ghi cần xóa',
        error: 'ids'
      })
    }
    const data = await Comment.updateMany({ _id: { $in: ids } }, { $set: { status: STATUS.DELETED } });
    return res.json({
      status: 1,
      data
    })
  } catch (error) {
    console.log('removeManny:: ', error);
    next(error)
  }
}

async function getId(req, res, next, id) {
  if (!id) {
    return res.json({
      status: 0,
      message: 'Vui lòng nhập vào id',
      error: 'id'
    })
  }

  const comment = await Comment.findById(id);
  if (!comment) {
    return res.json({
      status: 0,
      message: 'Không tìm thấy bản ghi'
    })
  }
  req.comment = comment;
  next()
}

async function like(req, res, next) {
  try {
    const user = req.user.user;

    const comment = req.comment;
    if (comment) {
      if (!comment.likeds) {
        comment.likeds = [];
      }
      if (comment.likeds.includes(user)) {
        comment.likeds = comment.likeds.filter(i => i !== user);
      } else {
        comment.likeds.push(user);
      }

      await comment.save();
    }
    return res.json({ status: 1 });
  } catch (error) {
    next(error);
  }
}
module.exports = {
  getComments,
  createComment,
  getId,
  removeManny,
  remove,
  like
};
