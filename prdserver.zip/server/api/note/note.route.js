const express = require('express');
// const validate = require('express-validation');
// eslint-disable-next-line import/newline-after-import
const validate = require('express-validation');
const noteValidation = require('./note.validation');

const noteCtl = require('./note.controller');

const router = express.Router(); // eslint-disable-line new-cap

router
  .route('/')
  /** GET /api/costEstimates - Get list of costEstimates */
  .get(noteCtl.list)

  /** POST /api/costEstimates - Create new balesQuotation */
  .post(validate(noteValidation.create), noteCtl.create);

/** Load balesQuotation when API with costEstimate route parameter is hit */
router
.route('/:noteId').delete(noteCtl.remove);
router.param('noteId', noteCtl.load);

module.exports = router;
