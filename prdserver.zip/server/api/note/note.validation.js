const Joi = require('joi');

// const validString = Joi.string().trim().min(5).required();

module.exports = {
  // POST /api/sales-quotations
  create: {
    body: {
      content: Joi.string().required()
    }
  },

  // PUT /api/sales-quotations/:costEstimate
  // update: {
  //   body: {
  //     code: validString,
  //     name: Joi.string().required(),
  //   },
  //   params: {
  //     costEstimate: Joi.string().trim().hex().required()
  //   }
  // }
};
