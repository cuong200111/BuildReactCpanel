/* eslint-disable indent */
const Note = require('./note.model');

const STATUS = require('../../variables/CONST_STATUS').STATUS;

async function load(req, res, next, id) {
  Note.findById(id)
    .populate('join', 'name')
    .then((data) => {
      // eslint-disable-next-line no-param-reassign
      req.note = data;
      return next();
    })
    .catch(e => next(e));
}

function get(req, res) {
  return res.json(req.note);
}

async function create(req, res, next) {
  // console.log('UERRR', req.body);
  try {
    const { join, name, priority, content, noteStatus, time } = req.body;

    const user = req.user.user;
    if (!user) return res.status(500).json({ success: false });
    const createdBy = user;
    const body = { join, name, priority, content, noteStatus, createdBy, time };
    const data = new Note(body);
    const dataSaved = await data.save();
    // console.log("GGGGGGGGGGGGGGGGGGGGGGGGGGG",dataSaved);

    return res.json({ success: true, data: dataSaved });
  } catch (error) {
    return next(error);
  }
}

async function update(req, res, next) {
  try {
    const { join, name, priority, content, noteStatus } = req.body;
    const note = req.note;
    note.join = join;
    note.priority = priority;
    note.content = content;
    note.noteStatus = noteStatus;
    note.name = name;
    const data = await note.save();
    return res.json({ success: true, data });
  } catch (error) {
    return next(error);
  }
}

async function remove(req, res, next) {
  try {
    const note = req.note;
    note.status = STATUS.DELETED;
    const data = await note.save();
    return res.json({ success: true, data });
  } catch (error) {
    return next(error);
  }
}


// eslint-disable-next-line consistent-return


function list(req, res, next) {
  const { user } = req.user;
  if (!user) return res.status(500).json({ success: false });
  const { limit = 500, skip = 0, sort, filter = {} } = req.query;
  filter.createdBy = user;
  Note.list({ limit, skip, sort, filter })
    .then(data => res.json(data))
    .catch(e => next(e));
}


module.exports = {
  load,
  get,
  create,
  update,
  list,
  remove
};
