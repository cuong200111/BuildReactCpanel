// const Employee = require('../employee/employee.model')();
const STATUS = require('../../variables/CONST_STATUS').STATUS;
const Notification = require('../notification/notification.model');
const mongoose = require('mongoose');
const roleTask = require('../../api/roleTask/role.model');
// eslint-disable-next-line
const common = require('../../helpers/common');
const axios = require('axios');
const config = require('./../../../config/config');

mongoose.connect(
  config.mongo.host,
  {
    user: config.mongo.user,
    pass: config.mongo.pass,
    server: {
      socketOptions: {
        keepAlive: 1,
      },
    },
    useCreateIndex: true, useNewUrlParser: true, useUnifiedTopology: true
  },

);
async function sendNotice({ title, content, to, link, type = 'System' }) {
  const notification = new Notification({
    title,
    content,
    type,
    link,
    to,
    date: new Date(),
  });
  await notification.save();

  if (global.hshUserSocket[to]) {
    global.io.to(global.hshUserSocket[to]).emit('notice', { content });
  }
}

async function cronRole() {
  try {
    // if (process.env.disableJob) return;
    const EmployeeModel = global.hshCollections.Employee;
    if (EmployeeModel) {
      const employee = await EmployeeModel.findOne({ status: STATUS.ACTIVED, firstLogin: true });
      if (employee) {
        employee.firstLogin = false;
        try {
          if (employee.roleGroupSource) {
            const checkRoles = await common.existRoleGroupCode(employee.roleGroupSource, employee.organizationUnit);
            await Promise.all([
              createOrUpdateRoles(employee._id, checkRoles.listRoles),
              updateRole(employee.userId, checkRoles.foundRoleGroup),
              employee.save(),
            ]);
            // if (employee) {
            //   const roleCached = employee.roleCached ? JSON.parse(JSON.stringify({ ...employee.roleCached })) : {};
            //   ['IncommingDocument', 'OutGoingDocument', 'Letter', 'PersonPlan', 'AuthorityDocument'].forEach(
            //     async (moduleCode) => {
            //       if (!roleCached[moduleCode]) {
            //         roleCached[moduleCode] = {};
            //       }
            //       const roles = checkRoles.listRoles.find((i) => i.moduleCode === moduleCode);
            //       const business = roles.roles.find((r) => r.code === 'BUSSINES' || r.code === 'AUTHORITY');
            //       if (business && business.data) {
            //         business.data.forEach((rol) => {
            //           Object.keys(rol.data).forEach((key) => {
            //             roleCached[moduleCode][`${rol.name}_${key}`] = rol.data[key];
            //           });
            //         });
            //       }
            //     },
            //   );
            //   await EmployeeModel.updateOne({ _id: employee._id }, { roleCached });
            // }
          } else {
            await employee.save();
          }
        } catch (error) {
          console.log(error);
        }
      }
    }
  } catch (error) {
    console.log(error);
  }
}
async function createOrUpdateRoles(empId, listRoles) {
  if (!empId || !listRoles || !listRoles.length) {
    return;
  }
  const insertRoles = listRoles.map((item) => ({ moduleCode: item.moduleCode, userId: empId, roles: item.roles }));
  await roleTask.remove({ userId: empId });
  roleTask.insertMany(insertRoles);
}

async function updateRole(userid, foundGroup) {
  if (!foundGroup || !foundGroup._id || !userid) return;
  const userId = userid.toString();
  const { roles: groupRoles, _id: groupId } = foundGroup;
  const roles = groupRoles.map((i) => ({ ...i, userId }));

  const url = `${process.env.API_ROLE_GROUPS_01}/roles/${userId}`;
  try {
    return await axios.put(`${url}`, JSON.stringify({ userId, roles, groupId }), {
      headers: {
        'Content-Type': 'application/json',
      },
    });
  } catch (error) {
    console.log('============= error ==============', error);
    throw error;
  }
}
// eslint-disable-next-line
async function report() {
  const employees = await mongoose.connection
    .collection('employees')
    .find({ status: STATUS.ACTIVED })
    .toArray();

  employees.map(async (item) => {
    const dataNotice = {
      title: 'Yêu cầu cập nhật tiến độ công việc',
      content: 'Nhắc nhở cập nhật tiến độ dự án',
      type: 'System',
      link: '/Task',
      to: item._id,
      // from: 'Task',
      date: new Date(),
    };
    await sendNotice(dataNotice);
  });
};
// eslint-disable-next-line func-names
function refresh() {
  mongoose.connection.collection('increments').deleteMany();
};

module.exports = {
  cronRole,
  report,
  refresh
};