const Promise = require('bluebird');
const mongoose = require('mongoose');
const httpStatus = require('http-status');
const APIError = require('../../helpers/APIError');
const STATUS = require('../../variables/CONST_STATUS').STATUS;

const hrmConfigSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,

  },
  order: {
    type: Number,
    required: true,
  },
  code: {
    type: String,
    required: true,
  },
  kind: {
    type: Number,
    enum: [1, 2], // loại 1 là dạng có bắt đầu , kết thuc,
    // loại 2 là dạng không có bắt đầu, kết thúc nhưng có cha con
    default: 1,
  },
  // data for kind =2
  data1: [{
    name: String,
    order: Number,
    code: {
      type: String,
    },
    status: {
      type: String,
      enum: ['init', 'success', 'failing', 'others'],
      default: 'others'
    }
  }],
  // data for kind =2
  data2: [{
    name: String,
    order: Number,
    code: {
      type: String,
      unique: true,
    },
    parent: {
      type: String,
      default: '',
    },
  }],
  canDelete: {
    type: Boolean,
    default: true,
  },
  status: {
    type: Number,
    enum: [0, 1, 2, 3],
    default: 1,
  },
}, {
  timestamps: true
});

/**
 * Statics
 */
hrmConfigSchema.statics = {
  /**
   * Get hrmConfig
   *
   * @param {ObjectId} id - The objectId of hrmConfig.
   * @returns {Promise<hrmConfig, APIError>}
   */
  get(id) {
    return this.findOne({
      _id: id,
      status: STATUS.ACTIVED
    })
      .exec()
      .then((hrmConfig) => {
        if (hrmConfig) {
          return hrmConfig;
        }
        const err = new APIError('No such hrmConfig exists!', httpStatus.NOT_FOUND);
        return Promise.reject(err);
      });
  },

  /**
   * List hrmConfigs in descending order of 'createdAt' timestamp.
   *
   * @param {number} skip - Number of hrmConfigs to be skipped.
   * @param {number} limit - Limit number of hrmConfigs to be returned.
   * @returns {Promise<hrmConfig[]>}
   */
  async list({
    skip = 0,
    limit = 500,
    sort = {
      createdAt: -1
    },
    filter = {
      status: 1
    }
  }) {
    return this.find(filter)
      .sort(sort)
      .skip(+skip)
      .limit(+limit)
      .exec();
  }
};

module.exports = mongoose.model('HrmConfig', hrmConfigSchema);
