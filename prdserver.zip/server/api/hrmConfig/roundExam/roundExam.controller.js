/* eslint-disable consistent-return */
const RoundExam = require('./roundExam.model');
const APIError = require('../../../helpers/APIError');
const httpStatus = require('http-status');
const STATUS = require('../../../variables/CONST_STATUS').STATUS;
const Exam = require('../exam/exam.model');
const CandidateLink = require('../candidateLink/candidateLink.model');
const HrmEmployee = require('../../hrmEmployee/hrmEmployee.model')();
async function list(req, res, next) {
  const { limit = 10, skip = 0, filter = {}, sort } = req.query;
  try {
    const data = await RoundExam.list({
      limit,
      skip,
      filter,
      sort,
    });
    return res.json(data);
  } catch (error) {
    console.log(error);
    return next(error);
  }
}

async function create(req, res, next) {
  try {
    const { name, code, exams = [], note, type, autoSend } = req.body;
    const exam = {
      name,
      code,
      exams,
      note,
      type,
      autoSend,
    };
    const dataExam = await RoundExam.create(exam);
    res.json(dataExam);
  } catch (error) {
    console.log('createRoundExam:: ', error);
    next(error);
  }
}

async function updateRoundExam(req, res, next) {
  try {
    const { name, code, exams = [], note, type, autoSend } = req.body;

    const roundExam = req.roundExam;
    roundExam.name = name;
    roundExam.code = code;
    roundExam.exams = exams;
    roundExam.note = note;
    roundExam.type = type;
    autoSend.autoSend = autoSend;
    const dataUp = await roundExam.save();
    return res.json({
      status: 1,
      data: dataUp,
    });
  } catch (error) {
    console.log('updateRoundExam:: ', error);
    next(error);
  }
}

function get(req, res) {
  // return res.transformer.item(req.employee, new EmployeeTransformer()).dispatch();
  return res.json({
    status: 1,
    data: req.roundExam,
  });
}

const load = async (req, res, next, id) => {
  try {
    // eslint-disable-next-line no-param-reassign
    req.roundExam = await RoundExam.findById(id).populate('exams');
    if (!req.roundExam) {
      next(new APIError('Item not found', httpStatus.NOT_FOUND, true));
    }
    next();
  } catch (error) {
    console.log('load roundExam', error);
    next(error);
  }
};
async function remove(req, res, next) {
  try {
    const roundExam = req.roundExam;
    roundExam.status = STATUS.DELETED;
    const data = await roundExam.save();
    return res.json({
      status: 1,
      data,
    });
  } catch (error) {
    console.log('remove:: ', error);
    next(error);
  }
}

async function deleteQue(req, res, next) {
  try {
    const { ids } = req.body;
    if (!ids) {
      return res.json({
        status: 0,
        message: 'Vui lòng nhập vào danh sách cần xóa',
        error: 'ids',
      });
    }
    const data = await RoundExam.updateMany({ _id: { $in: ids } }, { $set: { status: STATUS.DELETED } });
    return res.json({
      status: 1,
      data,
    });
  } catch (error) {
    console.log('deleteQue:: ', error);
    next(error);
  }
}

async function finishExam(req, res, next) {
  try {
    const body = req.body;
    const data = body.data;
    let scores = 0;
    const questions = [];
    const newData = {};
    if (body.hrmEmployeeId && body.hrmEmployeeId._id) {
      const hrmEmployee = await HrmEmployee.findById(body.hrmEmployeeId._id);
      if (!hrmEmployee) {
        res.json({ status: 0, message: 'Không tồn tại ứng viên tương ứng' });
      }
      hrmEmployee.roundExams = data.roundExamId;
      await hrmEmployee.save();
    }
    for (const el of data) {
      const exam = await Exam.findById(el.exam.id).lean();
      const question = el.question.map((m, i) => {
        const item = m;
        exam.question.map(tem => {
          if (item._id === tem._id) {
            if (item.type === 'radio' && tem.type === 'radio' && (item.answer || tem.checked)) {
              if (item.answer.toString() === tem.checked.toString()) {

                scores += item.scores;
              }
            }
            if (item.answer && tem.correctAnswer && item.answer.toString() === tem.correctAnswer.toString()) {
              scores += item.scores;
            }
          }

        })
        return item;
      });
      questions.push({
        exam: {
          id: exam._id,
          name: exam.name,
        },
        question,
      });
      newData.scores = scores;
    }
    console.log('điểm', scores);
    newData.data = questions;
    newData.do = true;
    newData.roundExamId = body.roundExamId;
    newData.vacanciesId = body.vacanciesId;
    newData.recruitmentWaveId = body.recruitmentWaveId;
    newData.recruitmentUnitId = body.recruitmentUnitId;
    newData.hrmEmployeeId = body.hrmEmployeeId;
    const savedData = await CandidateLink.create(newData);
    console.log(':< savedData', savedData)
    return res.json({ success: true, message: 'Cảm ơn bạn đã hoàn thành bài thi' });
  } catch (error) {
    console.log('submitForm:: ', error);
    next(error);
  }
}
async function updateExam(req, res, next) {
  try {
    const id = req.params.finishExamId;
    const body = req.body;
    const data = body.data;
    let scores = 0;
    const questions = [];
    const newData = await CandidateLink.findById(id);
    // let newData = {};
    if (body.hrmEmployeeId && body.hrmEmployeeId._id) {
      const hrmEmployee = await HrmEmployee.findById(body.hrmEmployeeId._id);
      if (!hrmEmployee) {
        res.json({ status: 0, message: 'Không tồn tại ứng viên tương ứng' });
      }
      hrmEmployee.roundExams = data.roundExamId;
      await hrmEmployee.save();
    }
    for (const el of data) {
      const exam = await Exam.findById(el.exam.id).lean();
      // console.log(exam);
      const question = el.question.map((m, i) => {
        const item = m;   
        exam.question.map(tem => {
          if (item._id === tem._id) {
            if (item.type === 'radio' && tem.type === 'radio' && (item.answer || tem.checked)) {
              if (item.answer.toString() === tem.checked.toString()) {
                scores += item.scores;
              }
            }
            if (item.answer && tem.correctAnswer && item.answer.toString() === tem.correctAnswer.toString()) {
              scores += item.scores;
            }
          }

        })
        return item;
      });
      questions.push({
        exam: {
          id: exam._id,
          name: exam.name,
        },
        question,
      });
      newData.scores = scores;
    }
    console.log("điểm", scores);
    newData.data = questions;
    newData.do = true;
    newData.roundExamId = body.roundExamId;
    newData.vacanciesId = body.vacanciesId;
    newData.recruitmentWaveId = body.recruitmentWaveId;
    newData.recruitmentUnitId = body.recruitmentUnitId;
    newData.hrmEmployeeId = body.hrmEmployeeId;
    
    await newData.save();
    // const data111=await CandidateLink.findById(id);
    // console.log(data111);
    return res.json({ success: true, message: 'Cảm ơn bạn đã hoàn thành bài thi' });
  } catch (error) {
    console.log('submitForm:: ', error);
    next(error);
  }
}

module.exports = {
  create,
  load,
  get,
  updateRoundExam,
  remove,
  list,
  deleteQue,
  finishExam,
  updateExam,
};
