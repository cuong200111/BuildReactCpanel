const RoundExam = require('./roundExam.model');
// const moment = require('moment');


async function create({ name, code, exams = [], note }) {
  try {
    const roundExam = new RoundExam({ name, code, exams, note });
    if(!name){
      return {
        status: 0,
        message: 'Vui lòng nhập vào tên vòng thi',
        error: 'name'
      }
    }  
    return {
      status : 1,
      data: await roundExam.save(),
    } 
  } catch (error) {
    console.log( "createSevice:: ",  error);
    throw error;
  }
}

module.exports = {
  create,
}