// eslint-disable-next-line new-cap
const router = require('express').Router();
const roundExamCtrl = require('./roundExam.controller');

router
  .route('/')
  .get(roundExamCtrl.list)
  .post(roundExamCtrl.create)
  .delete(roundExamCtrl.deleteQue);

router
  .route('/finishExam')
  .post(roundExamCtrl.finishExam);
  router
  .route('/examination/:finishExamId')
  .put(roundExamCtrl.updateExam);
router.route('/:roundExamId')
  .get(roundExamCtrl.get)
  .put(roundExamCtrl.updateRoundExam)
  .delete(roundExamCtrl.remove);

router.param('roundExamId', roundExamCtrl.load);

module.exports = router;
