/* eslint-disable no-param-reassign */
const mongoose = require('mongoose');
const { STATUS } = require('../../../variables/CONST_STATUS');
const searchFullText = require('../../../helpers/searchFullText');

const roundExamSchema = new mongoose.Schema(
  {
    name: String,
    code: String,
    exams: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Exam' }], // câu hỏi
    note: String, // 'mô tả'
    type: String,
    autoSend: { type: Boolean, default: false },
    createdAt: { type: Date, default: new Date() },
    updatedAt: { type: Date, default: new Date() },
    status: {
      type: Number,
      enum: [0, 1, 2, 3],
      default: 1,
    },
  },
);

/**
 * Statics
 */
roundExamSchema.statics = {
  async list({
    skip = 0,
    limit = 500,
    sort = {
      createdAt: -1,
    },
    filter = {},
    selector,
  }) {
    filter.status = STATUS.ACTIVED;
    searchFullText(filter);
    const [data, count] = await Promise.all([
      this.find(filter, selector || '')
      .populate('exams')
        .sort(sort)
        .skip(+skip)
        .limit(+limit)
        .exec(),
      this.count(filter),
    ]);
    return {
      data,
      count,
      limit,
      skip,
    };
  },
  async get(id) {
    try {
      if (id) {
        return {
          status: 0,
          messgae: 'Vui lòng nhập vào id',
          error: 'id'
        };
      }
      const data = await this.findById(id);
      return {
        status: 1,
        data,
      };
    } catch (error) {
      console.log('get:: ', error);
      throw error;
    }
  }
};

module.exports = mongoose.model('RoundExam', roundExamSchema);
