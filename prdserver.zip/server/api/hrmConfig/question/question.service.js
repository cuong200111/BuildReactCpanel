/* eslint-disable prefer-arrow-callback */
/* eslint-disable consistent-return */
const Question = require('./question.model');
// const moment = require('moment');


async function create({ name, code, scores, type, data = [], correctAnswer, obligatory, ratio,checked }) {
  try {
    const question = new Question({ name, code, scores, type, data, correctAnswer, obligatory, ratio , checked});
    if (!name) {
      return {
        status: 0,
        message: 'Vui lòng nhập vào tên câu hỏi',
        error: 'name'
      };
    }
    question.validate(function (err) {
      if (err) {
        return {
          status: 0,
          message: err.message || 'Thêm câu hỏi thất bại',
          error: err.error
        };
      }
    });
    return {
      status: 1,
      data: await question.save(),
    };
  } catch (error) {
    console.log('createSevice:: ', error);
    throw error;
  }
}

module.exports = {
  create,
};
