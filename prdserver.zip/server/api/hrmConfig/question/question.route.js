// eslint-disable-next-line new-cap
const router = require('express').Router();
const questionCtrl = require('./question.controller');

router
  .route('/')
  .get(questionCtrl.list)
  .post(questionCtrl.create)
  .delete(questionCtrl.deleteQue);

router.route('/:questionId')
  .get(questionCtrl.get)
  .put(questionCtrl.update)
  .delete(questionCtrl.remove);

router.param('questionId', questionCtrl.load);

module.exports = router;
