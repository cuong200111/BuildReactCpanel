/* eslint-disable no-param-reassign */
const mongoose = require('mongoose');
const { STATUS } = require('../../../variables/CONST_STATUS');
const searchFullText = require('../../../helpers/searchFullText');

const min = [0, 'The value of path `{PATH}` ({VALUE}) is beneath the limit ({MIN}).'];
const max = [100, 'The value of path `{PATH}` ({VALUE}) exceeds the limit ({MAX}).'];

const questionSchema = new mongoose.Schema(
  {
    name: String,
    code: String,
    obligatory: { type: Boolean, default: false },
    ratio: { type: Number, default: 100, min, max }, // tỷ lệ sô điểm đạt được nếu đúng
    scores: {
      type: Number,
      min,
      max,
      default: 10,
    },
    type: String, // [text, checkbox],
    data: [
      {
        content: String,
        checked: { type: Boolean, default: false },
        name: String, // [A, B, C, D]
      }
    ],
    correctAnswer: String, // 'câu trả lời chính xác'
    checked: { type: Boolean, default: false},
    createdAt: { type: Date, default: new Date() },
    updatedAt: { type: Date, default: new Date() },
    status: {
      type: Number,
      enum: [0, 1, 2, 3],
      default: 1,
    },
  },
);

/**
 * Statics
 */
questionSchema.statics = {
  async list({
    skip = 0,
    limit = 500,
    sort = {
      createdAt: -1,
    },
    filter = {},
    selector,
  }) {
    filter.status = STATUS.ACTIVED;
    searchFullText(filter);
    const [data, count] = await Promise.all([
      this.find(filter, selector || '')
        .sort(sort)
        .skip(+skip)
        .limit(+limit)
        .exec(),
      this.count(filter),
    ]);
    return {
      data,
      count,
      limit,
      skip,
    };
  },
};

module.exports = mongoose.model('Question', questionSchema);
