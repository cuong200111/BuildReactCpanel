/* eslint-disable consistent-return */
const Question = require('./question.model');
const APIError = require('../../../helpers/APIError');
const httpStatus = require('http-status');
const STATUS = require('../../../variables/CONST_STATUS').STATUS;

// sevice
const questionService = require('./question.service');

async function list(req, res, next) {
  const { limit = 500, skip = 0, filter = {}, sort } = req.query;
  try {
    const hrm = await Question.list({
      limit,
      skip,
      filter,
      sort,
    });
    return res.json(hrm);
  } catch (error) {
    console.log(error);
    return next(error);
  }
}

async function create(req, res, next) {
  try {
    const { name, code, scores, type, data = [], correctAnswer, obligatory, ratio, checked } = req.body;
    const question = {
      name, code, scores, type, data, correctAnswer, obligatory, ratio, checked 
    };
    const dataQue = await questionService.create(question);
    res.json(dataQue);
  } catch (error) {
    console.log('create:: ', error);
    next(error);
  }
}

async function update(req, res, next) {
  try {
    const { name, scores, type, data = [], correctAnswer, obligatory, ratio, checked } = req.body;

    const question = req.question;
    question.name = name;
    question.scores = scores;
    question.type = type;
    question.data = data;
    question.correctAnswer = correctAnswer;
    question.obligatory = obligatory;
    question.ratio = ratio;
    question.checked = checked;
    const dataUp = await question.save();
    return res.json({
      status: 1,
      data: dataUp,
    });
  } catch (error) {
    console.log('create:: ', error);
    next(error);
  }
}

function get(req, res) {
  // return res.transformer.item(req.employee, new EmployeeTransformer()).dispatch();
  return res.json({
    status: 1,
    data: req.question,
  });
}

const load = async (req, res, next, id) => {
  // eslint-disable-next-line no-param-reassign
  req.question = await Question.findById(id);
  if (!req.question) {
    next(new APIError('Item not found', httpStatus.NOT_FOUND, true));
  }
  next();
};
async function remove(req, res, next) {
  try {
    const question = req.question;
    question.status = STATUS.DELETED;
    const data = await question.save();
    return res.json({
      status: 1,
      data
    });
  } catch (error) {
    console.log('remove:: ', error);
    next(error);
  }
}

async function deleteQue(req, res, next) {
  try {
    const { ids } = req.body;
    if (!ids) {
      return res.json({
        status: 0,
        message: 'Vui lòng nhập vào danh sách cần xóa',
        error: 'ids'
      });
    }
    const data = await Question.updateMany({ _id: { $in: ids } }, { $set: { status: STATUS.DELETED } });
    return res.json({
      status: 1,
      data
    });
  } catch (error) {
    console.log('remove:: ', error);
    next(error);
  }
}
module.exports = {
  create,
  load,
  get,
  update,
  remove,
  list,
  deleteQue
};
