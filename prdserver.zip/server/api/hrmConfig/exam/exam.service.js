/* eslint-disable quotes */
/* eslint-disable no-console */
const Exam = require('./exam.model');
// const moment = require('moment');


async function create({ name, code, pointLadder, scored, num, question = [], note }) {
  try {
    const exam = new Exam({ name, code, pointLadder, scored, num, question, note });
    if (!name) {
      return {
        status: 0,
        message: 'Vui lòng nhập vào tên môn thi',
        error: 'name'
      };
    }
    if (!code) {
      return {
        status: 0,
        message: 'Vui lòng nhập vào mã môn thi',
        error: 'code'
      };
    }
    return {
      status: 1,
      data: await exam.save(),
    };
  } catch (error) {
    console.log('createSevice:: ', error);
    throw error;
  }
}

module.exports = {
  create,
};
