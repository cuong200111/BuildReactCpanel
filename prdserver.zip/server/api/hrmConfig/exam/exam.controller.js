/* eslint-disable consistent-return */
const Exam = require('./exam.model');
const APIError = require('../../../helpers/APIError');
const httpStatus = require('http-status');
const STATUS = require('../../../variables/CONST_STATUS').STATUS;

// sevice
const examService = require('./exam.service');

async function list(req, res, next) {
  const { limit = 10, skip = 0, filter = {}, sort } = req.query;
  try {
    const hrm = await Exam.list({
      limit,
      skip,
      filter,
      sort,
    });
    return res.json(hrm);
  } catch (error) {
    console.log(error);
    return next(error);
  }
}

async function create(req, res, next) {
  try {
    const { name, code, pointLadder, scored, num, question = [], note } = req.body;
    const exam = {
      name, code, pointLadder, scored, num, question, note
    };
    const dataExam = await examService.create(exam);
    res.json(dataExam);
  } catch (error) {
    console.log('create:: ', error);
    next(error);
  }
}

async function update(req, res, next) {
  try {
    const { name, code, pointLadder, scored, num, question = [], note } = req.body;

    const exam = req.exam;
    exam.name = name;
    exam.code = code;
    exam.pointLadder = pointLadder;
    exam.scored = scored;
    exam.num = num;
    exam.question = question;
    exam.note = note;
    const dataUp = await exam.save();
    return res.json({
      status: 1,
      data: dataUp,
    });
  } catch (error) {
    console.log('create:: ', error);
    next(error);
  }
}

function get(req, res) {
  // return res.transformer.item(req.employee, new EmployeeTransformer()).dispatch();
  return res.json({
    status: 1,
    data: req.exam,
  });
}

const load = async (req, res, next, id) => {
  // eslint-disable-next-line no-param-reassign
  req.exam = await Exam.findById(id);
  if (!req.exam) {
    next(new APIError('Item not found', httpStatus.NOT_FOUND, true));
  }
  next();
};
async function remove(req, res, next) {
  try {
    const exam = req.exam;
    exam.status = STATUS.DELETED;
    const data = await exam.save();
    return res.json({
      status: 1,
      data
    });
  } catch (error) {
    console.log('remove:: ', error);
    next(error);
  }
}

async function deleteQue(req, res, next) {
  try {
    const { ids } = req.body;
    if (!ids) {
      return res.json({
        status: 0,
        message: 'Vui lòng nhập vào danh sách cần xóa',
        error: 'ids'
      });
    }
    const data = await Exam.updateMany({ _id: { $in: ids } }, { $set: { status: STATUS.DELETED } });
    return res.json({
      status: 1,
      data
    });
  } catch (error) {
    console.log('remove:: ', error);
    next(error);
  }
}
module.exports = {
  create,
  load,
  get,
  update,
  remove,
  list,
  deleteQue
};
