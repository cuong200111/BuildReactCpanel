// eslint-disable-next-line new-cap
const router = require('express').Router();
const examCtrl = require('./exam.controller');

router
  .route('/')
  .get(examCtrl.list)
  .post(examCtrl.create)
  .delete(examCtrl.deleteQue);

router.route('/:examId')
  .get(examCtrl.get)
  .put(examCtrl.update)
  .delete(examCtrl.remove);

router.param('examId', examCtrl.load);

module.exports = router;
