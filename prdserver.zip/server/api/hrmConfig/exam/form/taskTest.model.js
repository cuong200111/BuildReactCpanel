/* eslint-disable no-param-reassign */
const mongoose = require('mongoose');
const { STATUS } = require('../../../../variables/CONST_STATUS');
const searchFullText = require('../../../../helpers/searchFullText');

const taskTestSchema = new mongoose.Schema(
  {
    name: String,
    code: String,
    pointLadder: { type: Number, default: 10 }, // thang điểm
    scored: { type: Number, default: 0 }, // điểm số cần đạt được
    num: { type: Number, default: 0 }, // số thứ tự
    examId: { type: mongoose.Types.ObjectId, ref: 'Exam' },
    roundExamId: { type: mongoose.Types.ObjectId, ref: 'RoundExam' },
    vacanciesId: { type: mongoose.Types.ObjectId, ref: 'Vacancie' },
    recruitmentWaveId: { type: mongoose.Types.ObjectId, ref: 'HrmRecruitmentWave' },
    question: [], // câu hỏi
    candidate: { // ứng viên,
      hrmEmployeeId: String,
      name: String,
    },
    startDate: { type: Date, default: new Date() },
    endDate: Date,
    note: String, // 'mô tả',
    time: { // thời lượng
      limit: { type: Number, min: 0, default: 0 },
      type: { type: String, enum: ['minutes', 'hours', 'days'] }
    },
    do: { type: Boolean, default: false }, // đã làm
    createdAt: { type: Date, default: new Date() },
    updatedAt: { type: Date, default: new Date() },
    status: {
      type: Number,
      enum: [0, 1, 2, 3],
      default: 1,
    },
  },
);

/**
 * Statics
 */
taskTestSchema.statics = {
  async list({
    skip = 0,
    limit = 500,
    sort = {
      createdAt: -1,
    },
    filter = {},
    selector,
  }) {
    filter.status = STATUS.ACTIVED;
    searchFullText(filter);
    const data = await this.find(filter, selector || '')
      .sort(sort)
      .skip(+skip)
      .limit(+limit)
      .exec();
    const count = await this.find(filter).count();
    return {
      data,
      count,
      limit,
      skip,
    };
  },
};

module.exports = mongoose.model('TaskTest', taskTestSchema);
