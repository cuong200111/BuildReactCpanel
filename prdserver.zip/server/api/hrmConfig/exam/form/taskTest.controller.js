/* eslint-disable consistent-return */
const TaskTest = require('./taskTest.model');
const APIError = require('../../../../helpers/APIError');
const httpStatus = require('http-status');
const STATUS = require('../../../../variables/CONST_STATUS').STATUS;

// sevice
const taskTestService = require('./taskTest.service');

async function list(req, res, next) {
  const { limit = 10, skip = 0, filter = {}, sort } = req.query;
  try {
    const hrm = await TaskTest.list({
      limit,
      skip,
      filter,
      sort,
    });
    return res.json(hrm);
  } catch (error) {
    console.log(error);
    return next(error);
  }
}

async function create(req, res, next) {
  try {
    const { name, code, pointLadder, scored, num, question = [], roundExamId, vacanciesId, startDate, endDate, time, note } = req.body;
    const taskTest = {
      name, code, pointLadder, scored, num, question, note, roundExamId, vacanciesId, startDate, endDate, time,
    };
    const datataskTest = await taskTestService.create(taskTest);
    res.json(datataskTest);
  } catch (error) {
    console.log('create:: ', error);
    next(error);
  }
}

async function update(req, res, next) {
  try {
    const { name, code, pointLadder, scored, num, question = [], note, roundExamId, vacanciesId, startDate, endDate, time, } = req.body;

    const taskTest = req.taskTest;
    taskTest.name = name;
    taskTest.roundExamId = roundExamId;
    taskTest.vacanciesId = vacanciesId;
    taskTest.startDate = startDate;
    taskTest.endDate = endDate;
    taskTest.time = time;
    taskTest.code = code;
    taskTest.pointLadder = pointLadder;
    taskTest.scored = scored;
    taskTest.num = num;
    taskTest.question = question;
    taskTest.note = note;
    const dataUp = await taskTest.save();
    return res.json({
      status: 1,
      data: dataUp,
    });
  } catch (error) {
    console.log('create:: ', error);
    next(error);
  }
}

function get(req, res) {
  // return res.transformer.item(req.employee, new EmployeeTransformer()).dispatch();
  return res.json({
    status: 1,
    data: req.taskTest,
  });
}

const load = async (req, res, next, id) => {
  // eslint-disable-next-line no-param-reassign
  req.taskTest = await TaskTest.findById(id);
  if (!req.taskTest) {
    next(new APIError('Item not found', httpStatus.NOT_FOUND, true));
  }
  next();
};
async function remove(req, res, next) {
  try {
    const taskTest = req.taskTest;
    taskTest.status = STATUS.DELETED;
    const data = await taskTest.save();
    return res.json({
      status: 1,
      data
    });
  } catch (error) {
    console.log('remove:: ', error);
    next(error);
  }
}

async function deleteQue(req, res, next) {
  try {
    const { ids } = req.body;
    if (!ids) {
      return res.json({
        status: 0,
        message: 'Vui lòng nhập vào danh sách cần xóa',
        error: 'ids'
      });
    }
    const data = await TaskTest.updateMany({ _id: { $in: ids } }, { $set: { status: STATUS.DELETED } });
    return res.json({
      status: 1,
      data
    });
  } catch (error) {
    console.log('remove:: ', error);
    next(error);
  }
}

async function getForm(req, res, next) {
  try {
    const examId = req.params.examId;
    const { uid, nameUid } = req.query;
    // return res.send('ok')
    const data = await taskTestService.getOrCreate({ examId, uid, nameUid });
    return res.render(`${__dirname}/form.view.ejs`, { data });
  } catch (error) {
    console.log('getForm:: ', error);
    next(error);
  }
}

async function submitForm(req, res, next) {
  try {
    const taskTeskId = req.body._id;
    const body = req.body;
    delete body._id;
    const taskTest = await TaskTest.findById(taskTeskId);
    const question = taskTest.question.map((m, i) => {
      const item = m;
      item.answer = body[String(i)];
      return item;
    });
    const data = await TaskTest.findByIdAndUpdate(taskTeskId, { $set: { question, do: true } });
    if (data) {
      return res.render(`${__dirname}/form.view.ejs`, { data: { status: 0, message: 'cảm ơn bạn đã hoàn thành môn thi' } });
    }
  } catch (error) {
    console.log('submitForm:: ', error);
    next(error);
  }
}
module.exports = {
  create,
  load,
  get,
  update,
  remove,
  list,
  deleteQue,
  getForm,
  submitForm
};
