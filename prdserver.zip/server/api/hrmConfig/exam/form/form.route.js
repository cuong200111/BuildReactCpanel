// eslint-disable-next-line new-cap
const router = require('express').Router();
const taskTeskCtrl = require('./taskTest.controller');

router
  .route('/submit')
  .post(taskTeskCtrl.submitForm);
//   .get(taskTeskCtrl.list)
//   .post(taskTeskCtrl.create)
//   .delete(taskTeskCtrl.deleteQue)

router.route('/form/:code')
  .get(taskTeskCtrl.examForm);

// router.route('/create/:code')
//   .get(taskTeskCtrl.getForm);
  // .delete(taskTeskCtrl.remove);

// router.param('taskTeskId', taskTeskCtrl.load);

module.exports = router;
