const TaskTesk = require('./taskTest.model');
const Exam = require('../exam.model');
const CandidateLink = require('../../candidateLink/candidateLink.model');

async function getOrCreate({ examId, roundExamId, vacanciesId, startDate, endDate, time, uid, nameUid }) {
  try {
    const [taskUid, examUid] = await Promise.all([
      TaskTesk.findOne({ 'candidate.uid': uid }),
      Exam.findById(examId),
    ]);

    if (!examUid) {
      return {
        status: 0,
        message: 'Không tìm thấy môn thi'
      };
    }

    if (taskUid) {
      if (taskUid.do) {
        return {
          status: 0,
          message: 'Bạn đã hoàn thành bài thi này'
        };
      }
      return {
        status: 1,
        data: taskUid
      };
    }
    const taskTest = new TaskTesk({
      roundExamId,
      vacanciesId,
      startDate,
      endDate,
      time: examUid.time ? examUid.time : time,
      name: examUid.name,
      pointLadder: examUid.pointLadder, // thang điểm
      num: examUid.num, // số thứ tự
      question: examUid.question, // câu hỏi
      note: examUid.note, // 'mô tả',
      candidate: { // ứng viên,
        uid,
        name: nameUid,
      },
      examId,
    });

    const data = await taskTest.save();
    return {
      status: 1,
      data,
    };
  } catch (error) {
    console.log('getOrCreate:: ', error);
    throw error;
  }
}

async function createByCode({ code }) {
  try {
    let result;
    if (!code) {
      result = {
        status: 0,
        message: 'Vui lòng nhập vào mã code',
      };
      return result;
    }

    const [taskTesk, candidate] = await Promise.all([
      TaskTesk.findOne({ code }),
      CandidateLink.findOne({ code }).populate('examId').populate('hrmEmployeeId'),
    ]);

    if (!candidate) {
      return {
        status: 0,
        message: 'Không tìm thấy môn thi'
      };
    }

    if (taskTesk) {
      if (taskTesk.do) {
        return {
          status: 0,
          message: 'Bạn đã hoàn thành bài thi này'
        };
      }
      return {
        status: 1,
        data: taskTesk
      };
    }
    const taskTest = new TaskTesk({
      roundExamId: CandidateLink.roundExamId,
      vacanciesId: CandidateLink.vacanciesId,
      examId: CandidateLink.examId._id,
      question: CandidateLink.examId.question, // câu hỏi
      candidate: { // ứng viên,
        uid: CandidateLink.hrmEmployeeId,
        // name: nameUid,
      },
      pointLadder: CandidateLink.examId.pointLadder, // thang điểm
      // num: examId.num, // số thứ tự
      // note: examUid.note,// 'mô tả',
      // name: examUid.name,
      // time: examUid.time,
      // startDate,
      // endDate,
      // time,
    });

    const data = await taskTest.save();
    return {
      status: 1,
      data,
    };
  } catch (error) {
    console.log('getOrCreate:: ', error);
    throw error;
  }
}

module.exports = {
  getOrCreate,
  createByCode,
};
