// eslint-disable-next-line new-cap
const router = require('express').Router();
const taskTestCtrl = require('./taskTest.controller');

router
  .route('/')
  .get(taskTestCtrl.list)
  .post(taskTestCtrl.create)
  .delete(taskTestCtrl.deleteQue)

router.route('/:taskTestId')
  .get(taskTestCtrl.get)
  .put(taskTestCtrl.update)
  .delete(taskTestCtrl.remove);

router.param('taskTestId', taskTestCtrl.load);

module.exports = router;
