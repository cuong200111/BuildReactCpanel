/* eslint-disable no-param-reassign */
const mongoose = require('mongoose');
const { STATUS } = require('../../../variables/CONST_STATUS');
const searchFullText = require('../../../helpers/searchFullText');

const examSchema = new mongoose.Schema(
  {
    name: String,
    code: String,
    pointLadder: { type: Number, default: 10 }, // thang điểm
    scored: { type: Number, default: 0 }, // điểm số cần đạt được
    num: { type: Number, default: 0 }, // số thứ tự
    question: [], // câu hỏi
    note: String, // 'mô tả'
    createdAt: { type: Date, default: new Date() },
    updatedAt: { type: Date, default: new Date() },
    status: {
      type: Number,
      enum: [0, 1, 2, 3],
      default: 1,
    },
  },
);

/**
 * Statics
 */
examSchema.statics = {
  async list({
    skip = 0,
    limit = 500,
    sort = {
      createdAt: -1,
    },
    filter = {},
    selector,
  }) {
    filter.status = STATUS.ACTIVED;
    searchFullText(filter);
    const [data, count] = await Promise.all([
      this.find(filter, selector || '')
        .sort(sort)
        .skip(+skip)
        .limit(+limit)
        .exec(),
      this.count(filter),
    ]);
    return {
      data,
      count,
      limit,
      skip,
    };
  },
};

module.exports = mongoose.model('Exam', examSchema);
