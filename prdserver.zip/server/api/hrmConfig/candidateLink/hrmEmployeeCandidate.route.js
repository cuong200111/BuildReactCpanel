// eslint-disable-next-line new-cap
const router = require('express').Router();
const hrmEmployeeCandidateCtrl = require('./hrmEmployeeCandidate.controller');

router
  .route('/')
  .get(hrmEmployeeCandidateCtrl.list)
  .post(hrmEmployeeCandidateCtrl.create)
  .delete(hrmEmployeeCandidateCtrl.remove);

router.route('/report-by-channel').get(hrmEmployeeCandidateCtrl.listByChannel);
router.route('/report-by-unit').get(hrmEmployeeCandidateCtrl.listReport);
router.route('/byUnit').get(hrmEmployeeCandidateCtrl.listByUnit);
router.route('/allByUnit').get(hrmEmployeeCandidateCtrl.listAllByUnit);
router.route('/export').get(hrmEmployeeCandidateCtrl.listExportByWave);

router
  .route('/:hrmEmployeeCandidateId')
  .get(hrmEmployeeCandidateCtrl.get)
  .put(hrmEmployeeCandidateCtrl.update);
// .delete(hrmEmployeeCandidateCtrl.remove);

router.param('hrmEmployeeCandidateId', hrmEmployeeCandidateCtrl.load);

module.exports = router;
