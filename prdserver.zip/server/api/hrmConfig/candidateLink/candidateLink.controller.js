/* eslint-disable no-mixed-operators */
/* eslint-disable consistent-return */
const CandidateLink = require('./candidateLink.model');
const APIError = require('../../../helpers/APIError');
const httpStatus = require('http-status');
const STATUS = require('../../../variables/CONST_STATUS').STATUS;

// sevice
const candidateLinkService = require('./candidateLink.service');

async function list(req, res, next) {
  try {
    const {
      limit = 10,
      skip = 0,
      filter = {},
      sort,
      vacanciesId,
      recruitmentWaveId,
      roundExamId,
      candidateId,
    } = req.query;
    if (vacanciesId) filter.vacanciesId = vacanciesId;
    if (recruitmentWaveId) filter.recruitmentWaveId = recruitmentWaveId;
    if (roundExamId) filter.roundExamId = roundExamId;
    if (candidateId) filter.hrmEmployeeId = candidateId;
    // const hrm = await CandidateLink.find(filter);
    const hrm = await CandidateLink.list({
      limit,
      skip,
      filter,
      sort,
    });
    return res.json(hrm);
  } catch (error) {
    console.log(error);
    return next(error);
  }
}

async function create(req, res, next) {
  try {
    const { name, code, pointLadder, scored, num, question = [], note } = req.body;
    const candidateLink = {
      name,
      code,
      pointLadder,
      scored,
      num,
      question,
      note,
    };
    const datacandidateLink = await candidateLinkService.create(candidateLink);
    res.json(datacandidateLink);
  } catch (error) {
    console.log('create:: ', error);
    next(error);
  }
}

async function update(req, res, next) {
  try {
    const { name, code, pointLadder, scored, num, question = [], note, data } = req.body;

    const candidateLink = req.candidateLink;
    candidateLink.name = name;
    candidateLink.code = code;
    candidateLink.pointLadder = pointLadder;
    candidateLink.scored = scored;
    candidateLink.num = num;
    candidateLink.question = question;
    candidateLink.note = note;
    candidateLink.data = data;
    const dataUp = await candidateLink.save();
    return res.json({
      status: 1,
      data: dataUp,
    });
  } catch (error) {
    console.log('create:: ', error);
    next(error);
  }
}

function get(req, res) {
  // return res.transformer.item(req.employee, new EmployeeTransformer()).dispatch();
  return res.json({
    status: 1,
    data: req.candidateLink,
  });
}

const load = async (req, res, next, id) => {
  // eslint-disable-next-line no-param-reassign
  req.candidateLink = await CandidateLink.get(id);
  if (!req.candidateLink) {
    next(new APIError('Item not found', httpStatus.NOT_FOUND, true));
  }
  next();
};
async function remove(req, res, next) {
  try {
    const candidateLink = req.candidateLink;
    candidateLink.status = STATUS.DELETED;
    const data = await candidateLink.save();
    return res.json({
      status: 1,
      data,
    });
  } catch (error) {
    console.log('remove:: ', error);
    next(error);
  }
}

async function deleteQue(req, res, next) {
  try {
    const { ids } = req.body;
    if (!ids) {
      return res.json({
        status: 0,
        message: 'Vui lòng nhập vào danh sách cần xóa',
        error: 'ids',
      });
    }
    const data = await CandidateLink.updateMany({ _id: { $in: ids } }, { $set: { status: STATUS.DELETED } });
    return res.json({
      status: 1,
      data,
    });
  } catch (error) {
    console.log('remove:: ', error);
    next(error);
  }
}

const Exam = require('../exam/exam.model');

async function getForm(req, res) {
  try {
    let data = {
      status: 0,
      message: 'not found!',
    };
    const { code } = req.params;

    if (!code) {
      return res.render(`${__dirname}/form.view.ejs`, { data });
    }
    const canLink = await CandidateLink.findOne({ code }).populate('hrmEmployeeId', 'name');
    if (!canLink) {
      data = {
        status: 0,
        message: 'Không tìm thấy ứng viên',
      };
      return res.render(`${__dirname}/form.view.ejs`, { data });
    }
    if (!canLink.examId) {
      data = {
        status: 0,
        message: 'Không tìm thấy bài thi',
      };
      return res.render(`${__dirname}/form.view.ejs`, { data });
    }
    if (canLink.do) {
      data = {
        status: 0,
        message: 'Bạn đã hoàn thành bài thi',
      };
      return res.render(`${__dirname}/form.view.ejs`, { data });
    }
    const exam = await Exam.findById(canLink.examId).lean();
    const dataQuestion = {
      name: exam.name,
      nameCan: canLink && canLink.hrmEmployeeId ? canLink.hrmEmployeeId.name : '',
      examId: exam._id,
      code,
      question: exam.question,
    };

    return res.render(`${__dirname}/form.view.ejs`, { data: { status: 1, data: dataQuestion } });
  } catch (error) {
    console.log('getForm:: ', error);
    return res.render(`${__dirname}/form.view.ejs`, {
      data: {
        status: 0,
        message: 'Có lỗi trong quá trình xử lý',
        error: String(error),
      },
    });
    // next(error);
  }
}

async function submitForm(req, res, next) {
  try {
    const body = req.body;
    delete body._id;
    const [exam, canUpdate] = await Promise.all([
      Exam.findById(body.examId).lean(),
      CandidateLink.findOne({ code: body.code }),
    ]);
    let scores = 0;
    const question = exam.question.map((m, i) => {
      const item = m;
      item.answer = body[String(i)];
      if (item.answer === item.correctAnswer) {
        scores += item.scores;
      }
      return item;
    });
    canUpdate.data = question;
    canUpdate.scores = scores;
    canUpdate.do = true;
    const data = await canUpdate.save();
    if (data) {
      return res.render(`${__dirname}/form.view.ejs`, {
        data: { status: 0, message: 'cảm ơn bạn đã hoàn thành môn thi' },
      });
    }
  } catch (error) {
    console.log('submitForm:: ', error);
    next(error);
  }
}
function getRandomInt(min, max) {
  const minValue = Math.ceil(min);
  const maxValue = Math.floor(max);
  return Math.floor(Math.random() * (maxValue - minValue) + minValue); // The maximum is exclusive and the minimum is inclusive
}
module.exports = {
  submitForm,
  create,
  load,
  get,
  update,
  remove,
  list,
  deleteQue,
  getForm,
  getRandomInt,
};
