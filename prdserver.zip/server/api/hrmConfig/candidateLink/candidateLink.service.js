const CandidateLink = require('./candidateLink.model');
// const moment = require('moment');

async function create({
  name,
  hrmEmployeeId,
  examId,
  data,
  roundExamId,
  vacanciesId,
  recruitmentWaveId,
  roundName,
  link,
  status = 1,
  score = 0,
  inChargeUsers,
}) {
  try {
    if (!hrmEmployeeId) {
      return {
        status: 0,
        message: 'Vui lòng nhập vào ứng viên',
        error: 'hrmEmployeeId',
      };
    }
    if (!recruitmentWaveId) {
      return {
        status: 0,
        message: 'Vui lòng nhập vào đợt thi tuyển',
        error: 'recruitmentWaveId',
      };
    }
    if (!vacanciesId) {
      return {
        status: 0,
        message: 'Vui lòng nhập vào vi trí thi tuyển',
        error: 'vacanciesId',
      };
    }
    if (!roundExamId) {
      return {
        status: 0,
        message: 'Vui lòng nhập vào vòng thi tuyển',
        error: 'roundExamId',
      };
    }
    // if (!examId) {
    //   return {
    //     status: 0,
    //     message: 'Vui lòng nhập vào môn thi tuyển',
    //     error: 'examId',
    //   };
    // }

    const candidateFind = await CandidateLink.findOne({
      hrmEmployeeId,
      roundExamId,
      vacanciesId,
      recruitmentWaveId,
    });
    if (candidateFind) {
      return {
        status: 1,
        data: candidateFind,
      };
    }
    const candidateLink = new CandidateLink({
      name,
      hrmEmployeeId,
      // examId,
      roundExamId,
      vacanciesId,
      recruitmentWaveId,
      roundName,
      link,
      status,
      data,
      score,
      inChargeUsers,
    });
    return {
      status: 1,
      data: await candidateLink.save(),
    };
  } catch (error) {
    console.log('create_candidateLink_sevice:: ', error);
    throw error;
  }
}

module.exports = {
  create,
};
