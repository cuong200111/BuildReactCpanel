// eslint-disable-next-line new-cap
const router = require('express').Router();
const candidateLinkCtrl = require('./candidateLink.controller');

router
  .route('/submit')
  .post(candidateLinkCtrl.submitForm);
router
  .route('/:code')
  .get(candidateLinkCtrl.getForm);
  // .post(candidateLinkCtrl.create)
  // .delete(candidateLinkCtrl.deleteQue);

// router.route('/:candidateLinkId')
//   .get(candidateLinkCtrl.get)
//   .put(candidateLinkCtrl.update)
  // .delete(candidateLinkCtrl.remove);

// router.param('candidateLinkId', candidateLinkCtrl.load);

module.exports = router;
