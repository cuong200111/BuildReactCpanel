/* eslint-disable consistent-return */
/* eslint-disable no-mixed-operators */
/* eslint-disable no-useless-concat */
/* eslint-disable prefer-template */
/* eslint-disable arrow-parens */
/* eslint-disable no-unused-vars */
/* eslint-disable no-shadow */
const HrmEmployees = require('../../hrmEmployee/hrmEmployee.model')();
const Employees = require('../../employee/employee.model')();
const STATUS = require('../../../variables/CONST_STATUS').STATUS;
// const EmployeeTransformer = require('./hrmEmployee.transformer');
// const OrganizationUnit = require('../organizationUnit/organizationUnit.model');
// const hrmStatus = require('../hrmStatus/hrmStatus.model');
// const kanbanSTT = require('./hrmEmpKanbanContanst');
// const hrmService = require('./hrmPortal.service');
const moment = require('moment');
// const HrmReport = require('./hrmEmployee.report');
// const HrmRecruitment = require('../hrmRecruitment/hrmRecruitment.model')();
// const HrmRecruitmentWave = require('../../hrmRecruitment/hrmRecruitmentWave/hrmRecruitmentWave.model')();
// const axios = require('axios');
const RoundExam = require('../../hrmConfig/roundExam/roundExam.model');
// const Exam = require('../hrmConfig/exam/exam.model');
// const Vacancies = require('../hrmConfig/vacancies/vacancies.model');
const candidateLinkCtrl = require('./candidateLink.controller');
const CandidateLink = require('./candidateLink.model');
const HrmSource = require('../../hrmSource/hrmSource.model')();
// const httpStatus = require('http-status');
// const viewConfigInit = require('../viewConfig/viewConfig.controller');
/**
 * Load user and append to req.
 */
function load(req, res, next, id) {
  HrmEmployees.findById(id)
    .then((employee) => {
      // eslint-disable-next-line no-param-reassign
      req.employee = employee;
      return next();
    })
    .catch((e) => {
      next(e);
    });
}

/**
 * Get Employee
 * @returns {Employee}
 */
function get(req, res) {
  return res.json(req.employee);
}

/**
 * Create new Employee
 *
 * @returns {Employee}
 */

async function create(req, res, next) {
  const {
    name,
    email,
    gender,
    phoneNumber,
    address,
    identityCardNumber,
    note,
    locationProvide,
    dateProvide,
    marriage,
    automatic,
    recruitmentUnit,
    startDate,
    dateOfficial,
    laborStatus,
    decisionNumber,
    decisionDay,
    organizationUnit,
    position,
    title,
    contractNumber,
    contractType,
    contractStartDate,
    contractEndDate,
    bankAccount,
    bank,
    taxCode,
    educateSystem,
    specialize,
    degree,
    informatics,
    language1,
    language2,
    nation,
    religion,
    file,
    avatar,
    rank,
    restStatus,
    inactivityDate,
    insuranceNumber,
    insuranceCode,
    timekeepingCode,
    shift,
    graduateSchool,
    graduateYear,
    bloodGroup,
    healthStatus,
    relationship,
    passport,
    passportDate,
    facebook,
    skype,
    yahoo,
    twitter,
    birthday,
    codeShift,
    certificate,
    description,
    experienceYear,
    role,
    recruitmentChannel,
  } = req.body;
  let { recruitmentWave, code } = req.body;
  if (!recruitmentWave) {
    return res.status(400).json({
      status: 0,
      message: 'Vui lòng nhập vào đợt thi tuyển',
      error: 'recruitmentWave',
    });
  }
  if (!Array.isArray(recruitmentWave)) {
    recruitmentWave = [recruitmentWave];
  }
  if (!code) {
    code = 'UV' + moment().format('x') + candidateLinkCtrl.getRandomInt(0, 1000);
  }
  const candidateCode = code;
  const employee = new HrmEmployees({
    code,
    name,
    email,
    gender,
    phoneNumber,
    address,
    identityCardNumber,
    note,
    locationProvide,
    dateProvide,
    marriage,
    automatic,
    startDate,
    dateOfficial,
    laborStatus,
    recruitmentUnit,
    decisionNumber,
    decisionDay,
    organizationUnit,
    position,
    title,
    contractNumber,
    contractType,
    contractStartDate,
    contractEndDate,
    bankAccount,
    bank,
    taxCode,
    educateSystem,
    specialize,
    degree,
    informatics,
    language1,
    language2,
    nation,
    religion,
    file,
    avatar,
    rank,
    restStatus,
    inactivityDate,
    insuranceNumber,
    insuranceCode,
    timekeepingCode,
    shift,
    graduateSchool,
    graduateYear,
    bloodGroup,
    healthStatus,
    relationship,
    passport,
    passportDate,
    facebook,
    skype,
    yahoo,
    twitter,
    birthday,
    codeShift,
    role,
    recruitmentWave,
    certificate,
    description,
    experienceYear,
    recruitmentChannel,
    candidateCode,
    status: STATUS.LOCKED,
  });

  return employee
    .save()
    .then(async (result) => {
      res.json({
        status: 1,
        data: result,
      });
    })
    .catch((err) =>
      res.json({
        status: 0,
        message: err.message,
      }),
    );
}

/**
 * Update existing Employee
 *
 * @returns {Employee}
 */
async function update(req, res, next) {
  try {
    const body = req.body;
    const employee = req.employee;
    const data = await HrmEmployees.findByIdAndUpdate(employee._id, { $set: body });
    return res.json({
      status: 1,
      data,
    });
  } catch (error) {
    return res.json({
      status: 0,
      message: error.message,
    });
    // next(error);
  }
}
/**
 * Get Employee list.
 * @property {number} req.query.skip - Number of Employees to be skipped.
 * @property {number} req.query.limit - Limit number of Employees to be returned.
 * @property {number} req.query.organizationUnitId - Limit number of Employees to be returned.
 * @returns {Employee[]}
 */
async function list(req, res, next) {
  const {
    limit = 10,
    skip = 0,
    filter = {},
    sort,
    recruitmentUnit,
    recruitmentWave,
    hrmRecruitmentId,
    roundExamId,
  } = req.query;
  try {
    // const selector = req.query.selector || '-user';
    filter.status = STATUS.LOCKED;
    if (recruitmentWave) filter.recruitmentWave = recruitmentWave;
    if (recruitmentUnit) filter.recruitmentUnit = recruitmentUnit;
    if (recruitmentUnit) filter.hrmRecruitmentId = hrmRecruitmentId;
    if (roundExamId) {
      const didExam = await HrmEmployees.distinct('_id', {
        'roundExams._id': roundExamId,
      });
      if (didExam) filter._id = { $nin: didExam };
    }

    const [data, count] = await Promise.all([
      HrmEmployees.find(filter)
        .sort(sort)
        .skip(+skip)
        .limit(+limit),
      HrmEmployees.count(filter),
    ]);
    return res.json({
      status: 1,
      data,
      count,
    });
  } catch (error) {
    return next(error);
  }
}
async function listReport(req, res, next) {
  const {
    limit = 10,
    skip = 0,
    filter = {},
    sort = { createdAt: -1 },
    recruitmentUnit,
    recruitmentWave,
    hrmRecruitmentId,
    position,
    organizationUnit,
    startDate,
    endDate,
  } = req.query;
  try {
    Object.keys(filter).forEach(k => {
      if (!filter[k]) {
        delete filter[k];
      }
    })
    const HrmRecruitmentWave = global.hshCollections['HrmRecruitmentWave'];
    // chi thong ke ung vien trung tuyen
    filter.status = STATUS.ACTIVED;
    filter.recruitmentUnit = {};
    if (recruitmentUnit) filter.recruitmentUnit.$eq = recruitmentUnit;
    if (hrmRecruitmentId) {
      const waveList = await HrmRecruitmentWave.find({ hrmRecruitmentId });
      const codeList = waveList.map((item) => item.code);
      filter.recruitmentWave = { $in: codeList };
    }
    if (recruitmentWave) filter.recruitmentWave = recruitmentWave;
    if (position) filter.position = position;
    if (organizationUnit) filter.organizationUnit = organizationUnit;
    if (startDate && endDate) {
      filter.contractStartDate = {
        $gte: moment(startDate, 'YYYY-MM-DD')
          .startOf('days')
          .toDate(),
        $lte: moment(endDate, 'YYYY-MM-DD')
          .endOf('days')
          .toDate(),
      };
    }
    //chỉ lấy các ứng viên, loại bỏ các nhân viên không qua kênh tuyển dụng
    filter.recruitmentUnit.$exists = true;
    delete filter.beginWorkStartDate;
    delete filter.beginWorkEndDate;
    delete filter.gender;
    const [data, count] = await Promise.all([
      HrmEmployees.find(filter)
        .sort(+sort)
        .skip(+skip)
        .limit(+limit)
        .lean(),
      HrmEmployees.count(filter),
    ]);
    // xử lý dữ liệu trả ra cho FE
    const newData = await Promise.all(data.map(async item => {
      item.recruitmentWaveName = '';
      if (Array.isArray(item.recruitmentWave) && item.recruitmentWave.length) {
        const foundWave = await HrmRecruitmentWave.findOne({
          code: item.recruitmentWave[0],
          status: STATUS.ACTIVED
        });
        if (foundWave) {
          item.recruitmentWaveName = foundWave.name;
        }
      }
      return item;
    }));
    return res.json({
      status: 1,
      data: newData,
      count,
    });
  } catch (error) {
    return next(error);
  }
}
// api biểu đồ tổng hợp hồ sơ tuyển dụng theo nguồn, phân loại ứng viên pass vòng 1, 2
async function listAllByUnit(req, res, next) {
  try {
    let noteArray = [];
    const HrmRecruitmentUnit = global.hshCollections['HrmRecruitmentUnit'];
    // let roundExams = await RoundExam.find({ status: 1 });
    // const recruitmentUnits = await HrmRecruitmentUnit.find({ status: 1 });
    const [countRoundExams, recruitmentUnits] = await Promise.all([
      RoundExam.countDocuments({ status: 1 }),
      HrmRecruitmentUnit.find({ status: 1 })
    ])
    const receivedCode = 'receivedCode'; // dùng để cấu hình, format data cho FE
    const data = [];
    for (let i = 0; i < recruitmentUnits.length; i++) {
      let roundCandidateArray = [];
      let roundCodeArray = [];
      const receivedCandidate = HrmEmployees.countDocuments({
        recruitmentUnit: recruitmentUnits[i].name,
      })
      for (let j = 1; j < countRoundExams - 1; j++) {
        const roundCandidate = HrmEmployees.countDocuments({
          [`roundExams.${j}`]: { "$exists": true },
          recruitmentUnit: recruitmentUnits[i].name,
        })
        roundCandidateArray.push(roundCandidate);
        roundCodeArray.push(j);
      }
      const [receivedCount, ...roundCount] = await Promise.all([receivedCandidate, ...roundCandidateArray]);
      const totalObjectArray = [{ [receivedCode]: receivedCount }];
      for (let k = 0; k < roundCodeArray.length; k++) {
        if (roundCount[k]) {
          totalObjectArray.push({ [roundCodeArray[k]]: roundCount[k] });
        } else {
          totalObjectArray.push({ [roundCodeArray[k]]: 0 });
        }
      }
      //function xu ly chuyen tu array sang object bo qua index, format data cho FE
      const arrayToObject = (arr) => {
        return arr.reduce((obj, item) => {
          const key = Object.keys(item)[0];
          obj[key] = item[key];
          return obj;
        }, {});
      };
      const tempData = arrayToObject(totalObjectArray);
      data.push({
        recruitmentUnit: recruitmentUnits[i].name,
        ...tempData,
      })
    }
    //xử lý data cho FE
    for (let n = 1; n < countRoundExams - 1; n++) {
      let name = `Số lượng hồ sơ đạt phỏng vấn vòng ${n}`;
      let code = n.toString();
      const element = { code, name };
      noteArray.push(element);
    }
    noteArray.unshift({ code: receivedCode, name: 'Số hồ sơ nhận được' });
    return res.json({
      status: 1,
      data,
      noteArray,
    });
  } catch (error) {
    return next(error);
  }
}

async function listExportByWave(req, res, next) {
  try {
    //thống kê toàn bộ ứng viên
    const {
      selector = {},
      limit = 10,
      skip = 0,
      filter = {},
      sort = { createdAt: -1 },
      recruitmentUnit,
      recruitmentWave,
      position,
      organizationUnit,
    } = req.query;
    if (recruitmentWave) filter.recruitmentWave = recruitmentWave;
    if (position) filter.position = position;
    if (organizationUnit) filter.organizationUnit = organizationUnit;
    filter.recruitmentUnit = { $exists: true };
    if (recruitmentUnit) filter.recruitmentUnit.$eq = recruitmentUnit;
    const [data, count] = await Promise.all([
      HrmEmployees.find(filter, selector)
        .sort(+sort)
        .skip(+skip)
        .limit(+limit),
      HrmEmployees.count(filter),
    ]);
    const candidates = { data, count };
    return res.send(JSON.stringify(candidates));
  } catch (error) {
    return next(error);
  }
}

async function listByUnit(req, res, next) {
  try {
    // chi thong ke ung vien trung tuyen
    const { filter = {} } = req.query;
    filter.status = 1;
    const HrmRecruitmentUnit = global.hshCollections['HrmRecruitmentUnit'];
    const HrmRecruitmentWave = global.hshCollections['HrmRecruitmentWave'];
    // chi query cac bang con ton tai
    const recruitmentWaves = await HrmRecruitmentWave.find({ status: 1 });
    const recruitmentUnits = await HrmRecruitmentUnit.find({ status: 1 });
    const recruitmentUnitArray = [];
    let noteArray = recruitmentWaves.map((item) => {
      return {
        code: `${item.code}`,
        name: `${item.name}`,
      };
    });

    let total = 0;
    for (let i = 0; i < recruitmentUnits.length; i++) {
      if (recruitmentUnits[i]) {
        let totalCount = 0;
        const recruitmentWaveArray = [];
        for (let j = 0; j < recruitmentWaves.length; j++) {
          if (recruitmentWaves[j]) {
            let count = await HrmEmployees.count({
              recruitmentUnit: recruitmentUnits[i].name,
              recruitmentWave: [recruitmentWaves[j].code],
              ...filter,
            });
            totalCount += count;
            recruitmentWaveArray.push({
              [recruitmentWaves[j].code]: count,
            });
          }
        }
        //function xu ly chuyen tu array sang object bo qua index, format data cho FE
        const arrayToObject = (arr) => {
          return arr.reduce((obj, item) => {
            const key = Object.keys(item)[0];
            obj[key] = item[key];
            return obj;
          }, {});
        };
        const tempData = arrayToObject(recruitmentWaveArray);
        total += totalCount;
        recruitmentUnitArray.push({
          recruitmentUnit: recruitmentUnits[i].name,
          ...tempData,
        });
      }
    }
    res.json({
      data: recruitmentUnitArray,
      total,
      noteArray,
      status: 1,
    });
  } catch (error) {
    console.log('listByUnit', error);
  }
}
/**
 * Delete Employee.
 * @returns {Employee}
 */
async function remove(req, res, next) {
  const { ids } = req.body;
  const data = await HrmEmployees.updateMany({ _id: { $in: ids } }, { $set: { status: STATUS.DELETED } });
  return res.json({
    status: 1,
    data,
  });
}

async function listByChannel(req, res, next) {
  try {
    const hrmSource = await HrmSource.findOne({ code: 'S31' });
    const data = [];
    for (const item of hrmSource.data) {
      const result = await HrmEmployees.count({ status: STATUS.LOCKED, recruitmentChannel: item.value });
      data.push({ name: item.title, count: result });
    }
    // hrmSource.data.map(async (item) => {
    //   const result = await HrmEmployees.count({ status: STATUS.LOCKED, recruitmentChannel: item.value });
    //   data.push({ name: item.title, count: result });
    //   console.log('(~.~) data', data);
    // });
    // const allCandidates = await HrmEmployees.find({ status: STATUS.LOCKED }, { recruitmentChannel: 1 });
    return res.json({ data });
  } catch (error) {
    next(error);
  }
}
function filterExam(data, numberOfRoundExam) {
  data = data.filter((item) => {
    return item.roundExams.length === numberOfRoundExam + 1;
  });
  return data.length;
}

module.exports = {
  load,
  get,
  create,
  update,
  listByUnit,
  listAllByUnit,
  listExportByWave,
  list,
  listReport,
  remove,
  listByChannel,
};
