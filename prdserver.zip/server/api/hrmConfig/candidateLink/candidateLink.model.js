/* eslint-disable no-mixed-operators */
/* eslint-disable prefer-template */
/* eslint-disable no-param-reassign */
const mongoose = require('mongoose');
const { STATUS } = require('../../../variables/CONST_STATUS');
const searchFullText = require('../../../helpers/searchFullText');
const moment = require('moment');

const candidateLinkSchema = new mongoose.Schema(
  {
    name: String,
    code: {
      type: String,
      unique: true,
    },
    hrmEmployeeId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'hrm',
    }, // ứng viên
    examId: {
      type: mongoose.Schema.Types.ObjectId, // môn
      ref: 'Exam',
    },
    roundExamId: {
      type: mongoose.Schema.Types.ObjectId, // vòng
      ref: 'RoundExam',
    },
    vacanciesId: {
      type: mongoose.Schema.Types.ObjectId, // // vị trí
      ref: 'Vacancie',
    },
    recruitmentWaveId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'HrmRecruitmentWave',
    }, // đợt thi tuyển
    recruitmentUnitId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'HrmRecruitmentUnit',
    }, // nguồn thi tuyển
    roundName: String,
    link: String,
    do: {
      type: Boolean,
      default: false,
    },
    next: {
      type: Boolean,
      default: false,
    },
    status: {
      type: Number,
      default: STATUS.ACTIVED,
      enum: [0, 1, 2, 3],
    },
    scores: {
      type: Number,
      default: 0,
    },
    roundExamsNext: [],
    data: [],
    meetingDate: { type: Date },
    address: String,
    inChargeUsers: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Employee',
      },
    ],
  },
  { timestamps: true },
);

/**
 * Statics
 */

function getRandomInt(min, max) {
  const minValue = Math.ceil(min);
  const maxValue = Math.floor(max);
  return Math.floor(Math.random() * (maxValue - minValue) + minValue); // The maximum is exclusive and the minimum is inclusive
}
candidateLinkSchema.pre('save', async function preSave(next) {
  try {
    if (!this.code) {
      this.code = 'CAN_' + moment().format('x') + getRandomInt(0, 1000);
    }
    if (!this.link && this.code) {
      this.link = `${process.env.APP_URL}/exam/${this.code}`;
    }
    return next();
  } catch (error) {
    return next();
  }
});

candidateLinkSchema.statics = {
  get(id) {
    return this.findOne({
      _id: id,
      // status: STATUS.ACTIVED,
    })
      .populate('hrmEmployeeId', ' name')
      .exec()
      .then((data) => {
        if (data) {
          return data;
        }
        const err = new APIError('No such data exists!', httpStatus.NOT_FOUND);
        return Promise.reject(err);
      });
  },
  async list({
    skip = 0,
    limit = 500,
    sort = {
      createdAt: -1,
    },
    filter = {},
    selector,
  }) {
    filter.status = 1;
    searchFullText(filter);
    const [data, count] = await Promise.all([
      this.find(filter, selector || '')
        .populate('hrmEmployeeId', 'name')
        .populate('examId', 'name')
        .populate('recruitmentWaveId')
        .populate('inChargeUsers', 'name')
        .sort(sort)
        .skip(+skip)
        .limit(+limit)
        .exec(),
      this.count(filter),
    ]);
    return {
      data,
      count,
      limit,
      skip,
    };
  },
};

module.exports = mongoose.model('CandidateLink', candidateLinkSchema);
