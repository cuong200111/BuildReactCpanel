/* eslint-disable consistent-return */
const Vacancies = require('./vacancies.model');
const APIError = require('../../../helpers/APIError');
const httpStatus = require('http-status');
const STATUS = require('../../../variables/CONST_STATUS').STATUS;

// sevice
const vacanciesService = require('./vacancies.service');

async function list(req, res, next) {
  const { limit = 10, skip = 0, filter = {}, sort } = req.query;
  try {
    const data = await Vacancies.list({
      limit,
      skip,
      filter,
      sort,
    });
    return res.json(data);
  } catch (error) {
    console.log(error);
    return next(error);
  }
}

async function create(req, res, next) {
  try {
    const { name, code, startDate, roundExams = [], note } = req.body;
    const position = req.body.position || {};
    position.roleCode = position.code;
    position.roleName = position.name;
    const vacancies = {
      name, code, position, startDate, roundExams, note
    };
    const dataExam = await vacanciesService.create(vacancies);
    res.json(dataExam);
  } catch (error) {
    console.log('create:: ', error);
    next(error);
  }
}

async function update(req, res, next) {
  try {
    const { name, code, startDate, roundExams = [], note } = req.body;
    const position = req.body.position || {};
    const vacancies = req.vacancies;
    // let positionFormat = {};
    vacancies.name = name;
    vacancies.code = code;
    position.roleCode = position.code;
    position.roleName = position.name;
    vacancies.position = position;
    // console.log('vacancies.position:: ', vacancies.position);
    vacancies.startDate = startDate;
    vacancies.roundExams = roundExams;
    vacancies.note = note;
    const dataUp = await vacancies.save();
    return res.json({
      status: 1,
      data: dataUp,
    });
  } catch (error) {
    console.log('create:: ', error);
    next(error);
  }
}

function get(req, res) {
  // return res.transformer.item(req.employee, new EmployeeTransformer()).dispatch();
  return res.json({
    status: 1,
    data: req.vacancies,
  });
}

const load = async (req, res, next, id) => {
  // eslint-disable-next-line no-param-reassign
  req.vacancies = await Vacancies.findById(id); // .populate('roundExams.roundExamId');
  if (!req.vacancies) {
    next(new APIError('Item not found', httpStatus.NOT_FOUND, true));
  }
  next();
};
const getExams = async (req, res, next, id) => {
  // const id = req.params.vacancies;
  // eslint-disable-next-line no-param-reassign
  const data = await Vacancies.findById(id).populate({
    path: 'roundExams.roundExamId',
    populate: {
      path: 'exams'
    }
  });
  if (!data) {
    next(new APIError('Item not found', httpStatus.NOT_FOUND, true));
  }
  res.json(data);
};
async function remove(req, res, next) {
  try {
    const vacancies = req.vacancies;
    vacancies.status = STATUS.DELETED;
    const data = await vacancies.save();
    return res.json({
      status: 1,
      data
    });
  } catch (error) {
    console.log('remove:: ', error);
    next(error);
  }
}

async function deleteQue(req, res, next) {
  try {
    const { ids } = req.body;
    if (!ids) {
      return res.json({
        status: 0,
        message: 'Vui lòng nhập vào danh sách cần xóa',
        error: 'ids'
      });
    }
    const data = await Vacancies.updateMany({ _id: { $in: ids } }, { $set: { status: STATUS.DELETED } });
    return res.json({
      status: 1,
      data
    });
  } catch (error) {
    console.log('remove:: ', error);
    next(error);
  }
}
module.exports = {
  create,
  load,
  get,
  getExams,
  update,
  remove,
  list,
  deleteQue
};
