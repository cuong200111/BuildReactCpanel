// eslint-disable-next-line new-cap
const router = require('express').Router();
const vacanciesCtrl = require('./vacancies.controller');

router
  .route('/')
  .get(vacanciesCtrl.list)
  .post(vacanciesCtrl.create)
  .delete(vacanciesCtrl.deleteQue);

router.route('/:vacanciesId')
  .get(vacanciesCtrl.get)
  .put(vacanciesCtrl.update)
  .delete(vacanciesCtrl.remove);
router.route('/exams/:vacancies')
  .get(vacanciesCtrl.getExams);

router.param('vacanciesId', vacanciesCtrl.load);
router.param('vacancies', vacanciesCtrl.getExams);

module.exports = router;
