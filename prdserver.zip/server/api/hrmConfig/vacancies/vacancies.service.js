const Vacancies = require('./vacancies.model');
// const moment = require('moment');


async function create({ name, code, position, startDate, roundExams = [], note }) {
  try {
    const vacancies = new Vacancies({ name, code, position, startDate, roundExams, note });
    if (!name) {
      return {
        status: 0,
        message: 'Vui lòng nhập vào tên vòng thi',
        error: 'name'
      }
    }
    return {
      status: 1,
      data: await vacancies.save(),
    }
  } catch (error) {
    console.log("createSevice:: ", error);
    throw error;
  }
}

module.exports = {
  create,
}