/* eslint-disable no-param-reassign */
const mongoose = require('mongoose');
const { STATUS } = require('../../../variables/CONST_STATUS');
const searchFullText = require('../../../helpers/searchFullText');

const vacanciesSchema = new mongoose.Schema({
  name: String,
  code: String,
  position: {
    // roleName: String,
    // roleCode: String,
  }, // vị trí tuyển dụng
  roundExams: [
    {
      roundExamId: { type: mongoose.Schema.Types.ObjectId, ref: 'RoundExam' }, // id vòng thi
      name: String,
      examDate: Date, // ngày thi
      order: Number, // số thứ tự
      status: {
        type: Number,
        default: 0,
        enum: [0, 1, 2], // 0: chưa phát thi, 1: đang thi, 2: đã thi
      },
    },
  ], // Vòng thi
  createdAt: { type: Date, default: new Date() },
  updatedAt: { type: Date, default: new Date() },
  startDate: Date,
  note: String,
  status: {
    type: Number,
    enum: [0, 1, 2, 3],
    default: 1,
  },
});

vacanciesSchema.pre('save', async function preSave(next) {
  try {
    next();
  } catch (error) {
    next();
  }
});

/**
 * Statics
 */
vacanciesSchema.statics = {
  async list({
    skip = 0,
    limit = 500,
    sort = {
      createdAt: -1,
    },
    filter = {},
    selector,
  }) {
    filter.status = STATUS.ACTIVED;
    searchFullText(filter);
    const [data, count] = await Promise.all([
      this.find(filter, selector || '')
        // .populate('roundExams.roundExamId')
        .sort(sort)
        .skip(+skip)
        .limit(+limit)
        .exec(),
      this.count(filter),
    ]);
    return {
      data,
      count,
      limit,
      skip,
    };
  },
  async get(id) {
    try {
      if (id) {
        return {
          status: 0,
          messgae: 'Vui lòng nhập vào id',
          error: 'id',
        };
      }
      const data = await this.findById(id);
      return {
        status: 1,
        data,
      };
    } catch (error) {
      console.log('get:: ', error);
      throw error;
    }
  },
};

module.exports = mongoose.model('Vacancie', vacanciesSchema);
