const Promise = require('bluebird');
const mongoose = require('mongoose');
const httpStatus = require('http-status');
const APIError = require('../../helpers/APIError');
const STATUS = require('../../variables/CONST_STATUS').STATUS;


const hrmStatusSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: true,
    },
    originalName: String,
    code: {
      type: String,

    },
    data: [
      {
        name: {
          type: String,
          required: true
        },
        index: Number,
        color: String,
        code: {
          type: Number,
          enum: [1, 2, 3, 4],
          default: 2
        },
        type: { type: String },
        isDelete: {
          type: Boolean,
          default: true,
        },
      },
    ],
    originalData: [
      {
        name: {
          type: String,
          required: true
        },
        index: Number,
        color: String,
        code: {
          type: Number,
          enum: [1, 2, 3, 4],
          default: 2
        },
        type: { type: String },
        isDelete: {
          type: Boolean,
          default: true,
        },
      },
    ],
    status: {
      type: Number,
      enum: [0, 1, 2, 3],
      default: 1
    },
    canDelete: {
      type: Boolean,
      default: true,
    },
  },
  {
    timestamps: true,
  },
);

hrmStatusSchema.method({});

hrmStatusSchema.statics = {
/**
 * Get hrmStatus
 * @param {ObjectId} id - The ObjectId of hrmStatus
 * @returns {Promise<hrmStatus, APIError}
 */
  get(id) {
    return this.findOne({
      _id: id,
      status: STATUS.ACTIVED
    })
        .exec()
        .then((hrmStatus) => {
          if (hrmStatus) {
            return hrmStatus;
          }
          const err = new APIError('No such hrmStatus exists!', httpStatus.NOT_FOUND);
          return Promise.reject(err);
        });
  },
/**
 * List hrmStatus in descending order of 'createdAt' timestamps
 *
 * @param {number} skip - Number of hrmStatus to be skipped.
* @param {number} limit - Limit number of hrmStatus to be returned.
* @returns {Promise<hrmStatus[]>}
 */
  list({
    skip = 0,
    limit = 500,
    sort = {
      createdAt: -1
    },
    filter = {
      status: 1
    }
}) {
    return this.find(filter)
        .sort(sort)
        .skip(+skip)
        .limit(+limit)
        .exec();
  }

};

module.exports = mongoose.model('HrmStatus', hrmStatusSchema);
