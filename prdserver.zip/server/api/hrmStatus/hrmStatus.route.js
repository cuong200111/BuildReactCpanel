// eslint-disable-next-line new-cap
const router = require('express').Router();
const hrmStatusCtrl = require('./hrmStatus.controller');

router
    .route('/')
    .get(hrmStatusCtrl.list)
    .post(hrmStatusCtrl.create);

// router
//     .route('/source')

router
    .route('/:hrmStatusId')
    .put(hrmStatusCtrl.update)
    .get(hrmStatusCtrl.get)
    .delete(hrmStatusCtrl.deleteHrmStatus);

router.param('hrmStatusId', hrmStatusCtrl.load);

router
    .route('/createitem/:hrmStatusId')
    .put(hrmStatusCtrl.createitem)

    .get(hrmStatusCtrl.get);

router.param('hrmStatusId', hrmStatusCtrl.load);

router
    .route('/updateitem/:hrmStatusId')
    .put(hrmStatusCtrl.updateitem)

    .get(hrmStatusCtrl.get);

router.param('hrmStatusId', hrmStatusCtrl.load);

router
    .route('/deleteitem/:hrmStatusId')
    .put(hrmStatusCtrl.deleteitem)

    .get(hrmStatusCtrl.get);

router.param('hrmStatusId', hrmStatusCtrl.load);

router
    .route('/updateIndex/:hrmStatusId')
    .put(hrmStatusCtrl.updateIndex)

    .get(hrmStatusCtrl.get);

router.route('/reset').post(hrmStatusCtrl.reset);

router.param('hrmStatusId', hrmStatusCtrl.load);
// eslint-disable-next-line no-unused-expressions
module.exports = router;
