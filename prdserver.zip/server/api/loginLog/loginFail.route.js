// eslint-disable-next-line new-cap
const router = require('express').Router();
const loginLogCtrl = require('./loginLog.controller');

router.route('/').post(loginLogCtrl.onLoginFailed);

module.exports = router;
