/* eslint-disable consistent-return */
/* eslint-disable camelcase */
const LoginLog = require('./loginLog.model')();
const moment = require('moment');
async function list(req, res, next) {
  try {
    const { limit = 5000, skip = 0, sort, filter = {}, organizationUnitId } = req.query;
    const { startDate, endDate, ...restFilter } = filter;
    const loginTime = {};
    if (startDate && moment(startDate, 'YYYY-MM-DD').isValid()) {
      loginTime.$gte = moment(startDate, 'YYYY-MM-DD').startOf('day').toISOString();
    }
    if (endDate && moment(endDate, 'YYYY-MM-DD').isValid()) {
      loginTime.$lte = moment(endDate, 'YYYY-MM-DD').endOf('day').toISOString();
    }
    if (Object.keys(loginTime).length) {
      restFilter.loginTime = loginTime;
    }
    // if (organizationUnitId) {
    //   const listOrg = await findOrganizationChil(organizationUnitId, 'name');
    //   const listOrgId = listOrg.map(m => m._id);
    //   restFilter.organizationUnitId = { $in: listOrgId };
    // }
    const deliverys = await LoginLog.list({ limit, skip, sort, filter: restFilter });
    res.json(deliverys);
  } catch (e) {
    next(e);
  }
}

async function onLoginFailed(req, res) {
  try {
    const { username } = req.body;
    if (!username) {
      return res.json({
        status: 1,
        message: 'Yêu cầu nhập tên đăng nhập',
      });
    }
    await LoginLog.create({
      ip: req.headers ? req.headers['x-real-ip'] : '',
      username,
    });
    return res.json({
      status: 1,
    });
  } catch (error) {
    return res.json({
      status: 0,
      message: error.message,
    });
  }
}

async function onUserLogout(req, res) {
  try {
    const { token } = req.body;
    if (!token) {
      return res.json({
        status: 0,
        message: 'Yêu cầu nhập mã đăng nhập',
      });
    }
    const record = await LoginLog.findOne({ token, status: 1, logoutDate: { $exists: false } });
    if (!record) {
      return res.json({
        status: 0,
        message: 'Mã đăng nhập không hợp lệ',
      });
    }
    record.logoutDate = new Date();
    await record.save();
    return res.json({
      status: 1
    });
  } catch (error) {
    return res.json({
      status: 0,
      message: error.message,
    });
  }
}

module.exports = {
  list,
  onUserLogout,
  onLoginFailed,
};
