const Promise = require('bluebird');
const mongoose = require('mongoose');
const dynamicSchema = require('../../helpers/dynamic-collection');
const modelHelper = require('../../helpers/model');

// eslint-disable-next-line func-names
module.exports = function(title) {
  const code = 'LoginLog';
  const plugins = [];

  if (Object.prototype.hasOwnProperty.call(global.hshCollections, code)) {
    return global.hshCollections[code];
  }

  // eslint-disable-next-line func-names
  return (async function() {
    const loginLogRaw = {
      ip: String,
      token: String,
      loginTime: Date,
      logoutDate: Date,
      status: {
        type: Number,
        enum: [0, 1]
      },
      username: String,
      organizationUnit: String,
      employeeId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Employee',
      },
      organizationUnitId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'OrganizationUnit',
      }
    };

    const dynamicParsed = modelHelper.parseRawModel(loginLogRaw);
    const LoginLogSchema = new mongoose.Schema(dynamicParsed.schema);

    LoginLogSchema.method({});

    LoginLogSchema.statics = {

      async list({
        skip = 0,
        limit = 5000,
        sort = {
          createdAt: -1,
        },
        filter = {},
      }) {
        const [data, count] = await Promise.all([
          this.find(filter, { token: 0 })
          .populate('employeeId', 'name')
          .populate('organizationUnitId', 'name')
          .sort(sort)
          .skip(+skip)
          .limit(+limit)
          .exec(),
          this.count(filter),
        ]);
        return {
          data,
          count,
          limit,
          skip,
        };
      },
    };

    // eslint-disable-next-line max-len
    const schema = await dynamicSchema.addDynamicCollectionFromCode(dynamicParsed, LoginLogSchema, code, plugins);

    return dynamicSchema.addModelToCode(code, schema, title);
  }());
};
