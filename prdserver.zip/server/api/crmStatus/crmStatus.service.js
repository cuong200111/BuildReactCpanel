/* eslint-disable array-callback-return */
const ViewConfig = require('../viewConfig/viewConfig.model');

const viewConfigDefault = {
  status: 1,
  code: 'reportsBusinessOpportunities',
  listDisplay: {
    type: {
      fields: {
        type: {
          columns: [],
          others: [],
          attributes: [],
        },
      },
      action: [],
    },
  },
  displayer: 'web',
  path: '/crm/reportsBusinessOpportunities',
};
const columnsDefault = [
  {
    name: 'name',
    title: 'Tên nhân viên',
    type: 'String',
    checked: true,
    order: 0,
    isRequire: false,
    checkedRequireForm: false,
    min: null,
    max: null,
    minLength: null,
    maxLength: null,
    checkedShowForm: true,
    isFilter: false,
    isSort: false,
    title_init: 'Tên nhân viên',
    width: 224,
  },
  {
    name: 'organizationUnit.name',
    title: 'Phòng ban',
    type: 'String',
    checked: true,
    order: 1,
    isRequire: false,
    checkedRequireForm: false,
    min: null,
    max: null,
    minLength: null,
    maxLength: null,
    checkedShowForm: true,
    isFilter: false,
    isSort: false,
    title_init: 'Phòng ban',
    width: 224,
  },
  {
    name: 'total',
    title: 'Tổng số CHKD',
    type: 'Number',
    checked: true,
    order: 2,
    isRequire: true,
    checkedRequireForm: true,
    min: null,
    max: null,
    minLength: null,
    maxLength: null,
    checkedShowForm: true,
    isFilter: false,
    isSort: false,
    title_init: 'Tổng số CHKD',
    width: 130,
  },
];
async function getUniqueListBy(arr, key) {
  return [...new Map(arr.map(item => [item[key], item])).values()];
}
async function viewConfigReport({ data, code, viewConfigColums = {}, defaults, init }) {
  try {
    const viewConfig = defaults ? viewConfigDefault : viewConfigColums;
    const columns = defaults ? columnsDefault : viewConfigColums.listDisplay.type.fields.type.columns;
    if (defaults) {
      viewConfig.listDisplay.type.fields.type.columns = columns;
    }
    const dataColums = await getUniqueListBy(data, 'type');
    await ViewConfig.deleteMany({ code });
    const columnsNew = dataColums.map((m, i) => {
      return {
        name: `kanban_${String(m.type).trim().replace(' ', '_')}`,
        title: m.name,
        type: 'Number',
        checked: true,
        order: columns.length + i,
        isRequire: true,
        checkedRequireForm: true,
        min: null,
        max: null,
        minLength: null,
        maxLength: null,
        checkedShowForm: true,
        isFilter: false,
        isSort: false,
        width: 130,
      };
    });
    viewConfig.listDisplay.type.fields.type.columns = [...columns, ...columnsNew];
    if (init) {
      return viewConfig;
    }
    const viewConfigNew = new ViewConfig(viewConfig);
    return await viewConfigNew.save();
  } catch (error) {
    console.log('viewConfigReport:: ', error);
    throw error;
  }
}

module.exports = {
  viewConfigReport
};
