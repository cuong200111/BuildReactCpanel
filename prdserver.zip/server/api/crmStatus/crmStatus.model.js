const Promise = require('bluebird');
const mongoose = require('mongoose');
const httpStatus = require('http-status');
const APIError = require('../../helpers/APIError');
const STATUS = require('../../variables/CONST_STATUS').STATUS;
const crmStatusService = require('./crmStatus.service');

const crmStatusSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: true,
    },
    originalName: String,
    code: {
      type: String,
    },
    originalData: [
      {
        name: {
          type: String,
          required: true,
        },
        index: Number,
        color: String,
        code: {
          type: Number,
          enum: [1, 2, 3, 4],
          default: 2,
        },
        type: { type: String },
        isDelete: {
          type: Boolean,
          default: true,
        },
      },
    ],
    data: [
      {
        name: {
          type: String,
          required: true,
        },
        index: Number,
        color: String,
        code: {
          type: Number,
          enum: [1, 2, 3, 4],
          default: 2,
        },
        type: { type: String },
        isDelete: {
          type: Boolean,
          default: true,
        },
      },
    ],
    status: {
      type: Number,
      enum: [0, 1, 2, 3],
      default: 1,
    },
    canDelete: {
      type: Boolean,
      default: true,
    },
    type: { type: String, default: 'ConfigCRM' },
  },
  {
    timestamps: true,
  },
);

crmStatusSchema.method({});
crmStatusSchema.pre('save', async function preSave(next) {
  try {
    if (this.code && this.code === 'ST01' && this.data) {
      crmStatusService.viewConfigReport({
        data: JSON.parse(JSON.stringify(this.data)),
        code: 'reportsBusinessOpportunities',
        defaults: true,
      });
    }
    return next();
  } catch (error) {
    return next();
  }
});
crmStatusSchema.statics = {
  /**
   * Get CrmStatus
   * @param {ObjectId} id - The ObjectId of CrmStatus
   * @returns {Promise<CrmStatus, APIError}
   */
  get(id) {
    return this.findOne({
      _id: id,
      status: STATUS.ACTIVED,
    })
      .exec()
      .then((crmStatus) => {
        if (crmStatus) {
          return crmStatus;
        }
        const err = new APIError('No such crmStatus exists!', httpStatus.NOT_FOUND);
        return Promise.reject(err);
      });
  },
  /**
   * List CrmStatus in descending order of 'createdAt' timestamps
   *
   * @param {number} skip - Number of CrmStatus to be skipped.
   * @param {number} limit - Limit number of CrmStatus to be returned.
   * @returns {Promise<CrmStatus[]>}
   */
  list({
    skip = 0,
    limit = 500,
    sort = {
      createdAt: -1,
    },
    filter = {
      status: 1,
    },
  }) {
    filter.status = 1;
    return this.find(filter)
      .sort(sort)
      .skip(+skip)
      .limit(+limit)
      .exec();
  },
};

module.exports = mongoose.model('CrmStatus', crmStatusSchema);
