/* eslint-disable no-plusplus */
/* eslint-disable no-param-reassign */
/* eslint-disable eqeqeq */
const CrmStatus = require('./crmStatus.model');
const APIError = require('../../helpers/APIError');
const httpStatus = require('http-status');
const crmStatusInit = require('./crmStatus.init');
const { STATUS } = require('../../variables/CONST_STATUS');
/**
 * Load crmStatus and append to req
 */
const load = async (req, res, next, id) => {
  // eslint-disable-next-line no-param-reassign
  req.crmStatus = await CrmStatus.findById(id);

  if (!req.crmStatus) {
    next(new APIError('Item not found', httpStatus.NOT_FOUND, true));
  }
  next();
};
/**
 * list crmStatus
 */
async function list(req, res, next) {
  try {
    await init();
    const { limit = 500, skip = 0, sort, filter } = req.query;
    CrmStatus.list({ limit, skip, sort, filter })
      .then((crmStatuss) => {
        res.json(crmStatuss);
      })
      .catch(e => next(e));
  } catch (e) {
    next(e);
  }
}
const get = (req, res) => {
  res.json(req.crmStatus);
};
// eslint-disable-next-line consistent-return
const create = async (req, res, next) => {
  try {
    const { title, code, type } = req.body;
    const existTitle = await CrmStatus.findOne({ title });
    const existCode = await CrmStatus.findOne({ code });
    if (existTitle) {
      const err = new APIError('Exist CRM with title');
      return next(err);
    }
    if (existCode) {
      const err = new APIError('Exist CrmStatus with code');
      return next(err);
    }
    const data = [
      {
        name: 'Công việc mới',
        color: '#3EA8EB',
        code: 1,
        type: 1,
        isDelete: false,
      },
      {
        name: 'Công việc đang xử lý',
        color: '#38C6F3',
        index: 1,
        code: 2,
        type: 2,
        isDelete: true,
      },
      {
        name: 'Công việc hoàn thành',
        color: '#008000',
        code: 3,
        type: 3,
        isDelete: false,
      },
      {
        name: 'Công việc thất bại',
        color: '#FF0000',
        index: 1,
        code: 4,
        type: 4,
        isDelete: true,
      },
    ];

    const crmStatus = new CrmStatus({ title, data, code, type });
    return crmStatus
      .save()
      .then((savedCrm) => {
        if (savedCrm) res.json(savedCrm);
        else res.transforemer.errorBadRequest('Can not create item');
      })
      .catch((e) => {
        next(e);
      });
  } catch (e) {
    next(e);
  }
};

// eslint-disable-next-line consistent-return
const update = async (req, res, next) => {
  try {
    const { title } = req.body;
    const crmStatus = req.crmStatus;
    crmStatus.title = title;
    return crmStatus
      .save()
      .then(async (result) => {
        res.json(result);
      })
      .catch((err) => {
        next(err);
      });
  } catch (e) {
    next(e);
  }
};

const deleteCrmStatus = async (req, res, next) => {
  const crmStatus = req.crmStatus;
  if (!crmStatus.canDelete) {
    return res.json({
      status: 0,
      message: 'Không thể xóa trạng thái mặc định',
    });
  }
  crmStatus.status = STATUS.DELETED;
  crmStatus
    .save()
    .then((result) => {
      res.json({
        success: true,
        data: result,
      });
    })
    .catch(e => next(e));
};

const reset = async (req, res) => {
  try {
    await CrmStatus.updateMany({ canDelete: true }, { status: STATUS.DELETED });
    const data = await CrmStatus.find({ canDelete: false });
    if (data) {
      for (let i = 0; i < data.length; i++) {
        if (data[i].title !== data[i].originalName) {
          await CrmStatus.updateOne({ _id: data[i]._id }, { title: data[i].originalName });
        }
      }
    }
    return res.json({ status: 1 });
  } catch (e) {
    return res.json({ status: 0, message: e.message });
  }
};

// eslint-disable-next-line consistent-return
const createitem = async (req, res, next) => {
  try {
    const crmStatus = req.crmStatus;
    const { name, code, type, color } = req.body;
    const { data } = crmStatus;
    // eslint-disable-next-line eqeqeq
    if (!type || data.find(it => it.type == type)) {
      res.status(500).json({ flag: false, message: 'Khong dc trung type' });
      return;
    }
    const i = await data.filter(e => e.code == code);
    const index = i.length + 1;
    data.push({
      name,
      code,
      color,
      index,
      type,
    });

    crmStatus.data = data;
    crmStatus
      .save()
      .then(async result => res.json(result))
      .catch(err => next(err));
  } catch (e) {
    next(e);
  }
};

// eslint-disable-next-line consistent-return
const updateitem = async (req, res, next) => {
  try {
    const crmStatus = req.crmStatus;
    const { name, color, id, index, type } = req.body;
    const { data } = crmStatus;
    // const item = await data.filter(e => e._id == id);
    data.forEach((e) => {
      // eslint-disable-next-line eqeqeq
      if (e._id == id) {
        // eslint-disable-next-line no-param-reassign
        e.name = name;
        // eslint-disable-next-line no-param-reassign
        e.color = color;
        // eslint-disable-next-line no-param-reassign
        e.index = index;
        e.type = type;
      }
    });

    crmStatus.data = data;
    return crmStatus
      .save()
      .then(async (result) => {
        res.json(result);
      })
      .catch((err) => {
        next(err);
      });
  } catch (e) {
    next(e);
  }
};
// eslint-disable-next-line consistent-return
const deleteitem = async (req, res, next) => {
  try {
    const crmStatus = req.crmStatus;
    const { id } = req.body;
    const { data } = crmStatus;
    // eslint-disable-next-line eqeqeq
    const itemDelete = await data.filter(e => e._id == id);

    // eslint-disable-next-line eqeqeq
    const item = await data.filter(e => e._id != id);

    item.forEach((e) => {
      if (e.code === itemDelete[0].code && e.index > itemDelete[0].index) {
        // eslint-disable-next-line no-param-reassign
        e.index -= 1;
      }
    });

    crmStatus.data = item;
    return crmStatus
      .save()
      .then(async (result) => {
        res.json(result);
      })
      .catch((err) => {
        next(err);
      });
  } catch (e) {
    next(e);
  }
};
// eslint-disable-next-line consistent-return
const updateIndex = async (req, res, next) => {
  try {
    const crmStatus = req.crmStatus;
    const arrayCrm = req.crmStatus.data;
    const { data } = req.body;
    data.forEach((e) => {
      arrayCrm.forEach((item) => {
        if (e._id == item._id) {
          item.index = e.index;
        }
      });
    });
    crmStatus.data = arrayCrm;
    return crmStatus
      .save()
      .then(async (result) => {
        res.json(result);
      })
      .catch((err) => {
        next(err);
      });
  } catch (e) {
    next(e);
  }
};
async function init() {
  const crmStatus = await CrmStatus.find();
  const newCrmStatus = crmStatusInit.crmStatus.filter(
    item => !crmStatus.find(crmStatusItem => crmStatusItem.code === item.code),
  );
  if (newCrmStatus.length) {
    await Promise.all(
      newCrmStatus
        .map(item => ({ ...item, originalName: item.title, originalData: [...item.data], canDelete: false }))
        .map(item => new CrmStatus(item).save()),
    );
  }
}

module.exports = {
  load,
  list,
  get,
  create,
  update,
  deleteCrmStatus,
  init,
  createitem,
  updateitem,
  deleteitem,
  updateIndex,
  reset,
};
