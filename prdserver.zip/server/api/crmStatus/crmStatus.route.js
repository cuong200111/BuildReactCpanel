// eslint-disable-next-line new-cap
const router = require('express').Router();
const crmStatusCtrl = require('./crmStatus.controller');

router
  .route('/')
  .get(crmStatusCtrl.list)
  .post(crmStatusCtrl.create);
  // .put(crmStatusCtrl.resetCrmStatus);
// router
//     .route('/source')

router
  .route('/:crmStatusId')
  .put(crmStatusCtrl.update)
  .get(crmStatusCtrl.get)
  .delete(crmStatusCtrl.deleteCrmStatus);

router.param('crmStatusId', crmStatusCtrl.load);

router
  .route('/createitem/:crmStatusId')
  .post(crmStatusCtrl.createitem)

  .get(crmStatusCtrl.get);

router.param('crmStatusId', crmStatusCtrl.load);

router
  .route('/updateitem/:crmStatusId')
  .put(crmStatusCtrl.updateitem)

  .get(crmStatusCtrl.get);

router.param('crmStatusId', crmStatusCtrl.load);

router
  .route('/deleteitem/:crmStatusId')
  .put(crmStatusCtrl.deleteitem)

  .get(crmStatusCtrl.get);

router.param('crmStatusId', crmStatusCtrl.load);

router
  .route('/updateIndex/:crmStatusId')
  .put(crmStatusCtrl.updateIndex)

  .get(crmStatusCtrl.get);

router.route('/reset').post(crmStatusCtrl.reset);

router.param('crmStatusId', crmStatusCtrl.load);

module.exports = router;
