const express = require('express');
const organizationUnitCtrl = require('./organizationUnit.controller');
const validate = require('express-validation');
const organizationUnitValidation = require('./organizationUnit.validation');

const router = express.Router(); // eslint-disable-line new-cap

router
  .route('/')
  /** GET /api/organizations - Get list of organizations */
  .get(organizationUnitCtrl.list)

  /** POST /api/organizations - Create a new organizations */
  .post(validate(organizationUnitValidation.createOrganizationUnit), organizationUnitCtrl.create);

router.delete('/remove-more', organizationUnitCtrl.removeMore);
router.get('/tree-stock', organizationUnitCtrl.listByStock);
router.get('/search', organizationUnitCtrl.search);
router.get('/OrganizationOfEmployee', organizationUnitCtrl.getOrganizationByEmployee);

router.post('/change-working-organization', organizationUnitCtrl.changeWorkingOrganization);

router
.route('/:organizationUnitId')
/** GET /api/organizations/:organizationId - Get a organization */
.get(organizationUnitCtrl.get)

/** POST /api/organizations/:organizationId - update a organization */
.post(validate(organizationUnitValidation.updateOrganizationUnit), organizationUnitCtrl.createChild)

/** PUT /api/organizationUnits/:organizationUnitId - Update organizationUnit */
.put(validate(organizationUnitValidation.updateOrganizationUnit), organizationUnitCtrl.update)

/** DELETE /api/organizationUnits/:organizationUnitId - Delete organizationUnit */
.delete(organizationUnitCtrl.remove);

router
.route('/:organizationUnitId/employees')
/** POST /api/organizations/:organizationId/employees - get employees of a organization */
.get(organizationUnitCtrl.getEmployees);

/** Load user when API with userId route parameter is hit */
router.param('organizationUnitId', organizationUnitCtrl.load);

module.exports = router;
