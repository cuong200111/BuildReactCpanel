const Joi = require('joi');

const validString = Joi.string()
                        .alphanum()
                        .min(5)
                        .max(30)
                        .required();

module.exports = {
  createOrganizationUnit: {
    body: {
      name: Joi.required(),
      code: validString,
      type: Joi.string().trim().allow(['company', 'department', 'stock', 'factory', 'workshop', 'salePoint', 'corporation']).required(),
      priority: Joi.number()
    }
  },

  updateOrganizationUnit: {
    body: {
      name: Joi.required(),
      code: validString,
      type: Joi.string().trim().allow(['company', 'department', 'stock', 'factory', 'workshop', 'salePoint', 'corporation']).required(),
      priority: Joi.number()
    },
    params: {
      organizationUnitId: Joi.string().trim().hex().required()
    }
  },
  validateCode: {
    body: {
      code: validString,
    }
  }
};

