// library
const httpStatus = require('http-status');

// model
const OrganizationUnit = require('./organizationUnit.model');
const Employee = require('../employee/employee.model')();

// controller
const employeeCtrl = require('../employee/employee.controller');

// service

// variable and function global
const getTree = require('../../helpers/common').getTree;
const convertToFullTextSearch = require('../../helpers/convertToFullTextSearch');
const ApiError = require('../../helpers/APIError');
const STATUS = require('../../variables/CONST_STATUS').STATUS;
/**
 * Load a new OrganizationUnit
 *
 * @param {Request} req
 * @param {Response} res
 * @param {next} next
 * @param {id} id
 */
function load(req, res, next, id) {
  OrganizationUnit.get(id)
    .then((organizationUnit) => {
      // eslint-disable-next-line no-param-reassign
      req.organizationUnit = organizationUnit;
      next();
    })
    .catch((e) => next(e));
}

/**
 * Get a new OrganizationUnit
 *
 * @param {Request} req
 * @param {Response} res
 */
function get(req, res) {
  return res.json({
    success: true,
    data: req.organizationUnit,
  });
}

/**
 * Create a new OrganizationUnit
 *
 * @param {Request} req
 * @param {Response} res
 * @param {Function} next
 */
async function create(req, res, next) {
  try {
    const organizationUnit = new OrganizationUnit({
      name: req.body.name,
      type: req.body.type,
      geographicalArea: req.body.geographicalArea,
      priority: req.body.priority,
      oUFunction: req.body.oUFunction,
      duty: req.body.duty,
      note: req.body.note,
      code: req.body.code.trim(),
      accountingBranchCode: req.body.accountingBranchCode,
      accountingDepartmentCode: req.body.accountingDepartmentCode,
      inchargeEmail: req.body.inchargeEmail,
      ccEmails: req.body.ccEmails,
      bccEmails: req.body.bccEmails,
    });

    organizationUnit.root = organizationUnit._id;
    const data = await organizationUnit.save();
    data.path = data._id.toString();
    await data.save();
    if (data) {
      await Employee.updateMany({ status: STATUS.ACTIVED }, { firstLogin: true });
    }
    // Role.updateRoles();
    res.json({ success: true, data });
  } catch (error) {
    next(error);
  }
}

/**
 * Create a new OrganizationUnit
 *
 * @param {Request} req
 * @param {Response} res
 * @param {Function} next
 */
async function createChild(req, res, next) {
  const organizationUnit = req.organizationUnit;
  const organizationUnitByCode = await OrganizationUnit.findOne({ code: req.body.code });
  if (organizationUnitByCode) {
    return next(new ApiError('Existed oranization unit ', 400, true));
  }

  const newOrganizationUnit = new OrganizationUnit({
    name: req.body.name,
    type: req.body.type,
    priority: req.body.priority,
    oUFunction: req.body.oUFunction,
    duty: req.body.duty,
    note: req.body.note,
    code: req.body.code.trim(),
    inchargeEmail: req.body.inchargeEmail,
    ccEmails: req.body.ccEmails,
    bccEmails: req.body.bccEmails,
    accountingBranchCode: req.body.accountingBranchCode,
    accountingDepartmentCode: req.body.accountingDepartmentCode,
  });

  // newOrganizationUnit.path = `${organizationUnit.path}/${}`
  newOrganizationUnit.parent = organizationUnit._id;
  newOrganizationUnit.root = organizationUnit.root;
  newOrganizationUnit.level = organizationUnit.level + 1;

  await newOrganizationUnit.save();
  newOrganizationUnit.path = `${organizationUnit.path}/${newOrganizationUnit._id.toString()}`;
  const data = await newOrganizationUnit.save();
  // Role.updateRoles();
  if (data) {
    await Employee.updateMany({ status: STATUS.ACTIVED }, { firstLogin: true });
  }
  res.json({ success: true, data });
}

/**
 * Update existing organizationUnit
 *
 * @returns {OrganizationUnit}
 */
async function update(req, res, next) {
  try {
    const organizationUnit = req.organizationUnit;
    organizationUnit.name = req.body.name;
    organizationUnit.type = req.body.type;
    organizationUnit.priority = req.body.priority;
    organizationUnit.oUFunction = req.body.oUFunction;
    organizationUnit.duty = req.body.duty;
    organizationUnit.note = req.body.note;
    organizationUnit.code = req.body.code.trim();
    organizationUnit.accountingBranchCode = req.body.accountingBranchCode;
    organizationUnit.accountingDepartmentCode = req.body.accountingDepartmentCode;
    if (organizationUnit.type === 'company') {
      organizationUnit.parent = null;
      organizationUnit.path = organizationUnit._id;
    }
    // organizationUnit.path = organizationUnit.path ? organizationUnit.path : organizationUnit._id.toString();
    let parentPath = '';
    if (req.body.parent === null && organizationUnit.parent) {
      organizationUnit.parent = null;
      organizationUnit.path = organizationUnit._id;
      parentPath = organizationUnit._id;
      updatePathChild(organizationUnit._id, parentPath);
    } else if (req.body.parent) {
      const parentOrriganization = await OrganizationUnit.findById(req.body.parent);

      if (!parentOrriganization) {
        const err = new ApiError('Not search parent organizationUnit !', httpStatus.BAD_REQUEST, true);
        next(err);
      }
      if (parentOrriganization.path.includes(organizationUnit.path)) {
        const err = new ApiError('Cannot accept this parent !', httpStatus.BAD_REQUEST, true);
        next(err);
      }
      if (req.body.parent === req.organizationUnit._id) {
        const err = new ApiError('Parent and child not match !', httpStatus.BAD_REQUEST, true);
        next(err);
      }
      organizationUnit.parent = parentOrriganization._id;
      parentPath = parentOrriganization.path || parentOrriganization._id;
      organizationUnit.path = `${parentPath}/${organizationUnit._id}`;
      if (
        organizationUnit.parent === null ||
        (organizationUnit.parent && String(organizationUnit.parent) !== String(req.body.parent))
      ) {
        updatePathChild(organizationUnit._id, organizationUnit.path);
      }
    }
    // else {
    //   organizationUnit.parent = null;
    // }
    const data = await organizationUnit.save();
    // Role.updateRoles();
    res.json({
      success: true,
      data,
    });
    // if (
    //   !organizationUnit.parent ||
    //   (organizationUnit.parent && String(organizationUnit.parent) !== String(req.body.parent))
    // ) {
    //   organizationUnit.parent = req.body.parent;
    //   parentPath = parentOrriganization.path;
    //   const rex = new RegExp(organizationUnit.path);
    //   const listChild = await OrganizationUnit.find({ path: { $regex: rex } });
    //   const newChildPath = req.body.parent
    //     ? `${parentPath}/${organizationUnit._id.toString()}`
    //     : organizationUnit._id.toString();
    //   const updateChild = listChild.map(async (item) => {
    //     const path = item.path.replace(rex, newChildPath);
    //     item.path = path;
    //     await item.save();
    //   });
    //   await Promise.all(updateChild);
    // }

    // organizationUnit.path = `${parentOrriganization}/${organizationUnit._id.toString()}`;
  } catch (error) {
    next(error);
  }
}
async function updatePathChild(parent, parentPath = '') {
  try {
    const orgChild = await OrganizationUnit.find({ status: STATUS.ACTIVED, parent });
    Promise.all([
      Promise.map(orgChild, async (oc) => {
        oc.path = `${parentPath}/${oc._id}`;
        const ocSave = await oc.save();
        if (ocSave) {
          updatePathChild(ocSave._id, ocSave.path);
        }
      }),
    ]);
  } catch (error) {
    console.log(`updatePathChild:: ${parent} `, error);
  }
}

/**
 * List OrganizationUnits
 *
 * @param {Request} req
 * @param {Response} res
 * @param {Function} next
 */
async function list(req, res, next) {
  try {
    const { filter = {}, shape = 'tree', moduleCode } = req.query;
    filter.status = STATUS.ACTIVED;
    convertToFullTextSearch(filter);
    let orgUnits;
    let getParent;
    if (moduleCode) {
      getParent = true;
      const user = req.user.user;
      const organizationUnitId = req.query.organizationUnitId;
      const data = await roleOrgEmployee({ user, moduleCode, organizationUnitId });
      if (data && data.roleDepartment) {
        orgUnits = data.roleDepartment;
      } else {
        return res.json(data);
      }
    } else {
      orgUnits = await OrganizationUnit.find(filter)
        .lean()
        .exec();
    }
    let result = orgUnits;
    if (shape === 'tree') {
      result = getTree(orgUnits, orgUnits, getParent);
    }
    return res.json(result);
  } catch (e) {
    return next(e);
  }
}
/**
 * List OrganizationUnits
 *
 * @param {Request} req
 * @param {Response} res
 * @param {Function} next
 */
async function search(req, res, next) {
  try {
    const { filter = {} } = req.query;
    // filter.status = STATUS.ACTIVED;
    convertToFullTextSearch(filter);
    const orgUnits = await OrganizationUnit.find(filter)
      .lean()
      .exec();
    res.json(orgUnits);
  } catch (e) {
    next(e);
  }
}

/**
 * List OrganizationUnits
 *
 * @param {Request} req
 * @param {Response} res
 * @param {Function} next
 */
async function listByStock(req, res, next) {
  try {
    const orgUnits = await OrganizationUnit.find({
      status: STATUS.ACTIVED,
      $or: [{ type: 'stock' }, { type: 'salePoint' }],
    })
      .lean()
      .exec();
    res.json(getTree(orgUnits, orgUnits));
  } catch (e) {
    next(e);
  }
}

/**
 * Delete organizationUnit.
 * @returns {OrganizationUnit}
 */
function remove(req, res, next) {
  const organizationUnit = req.organizationUnit;
  organizationUnit.status = STATUS.DELETED;
  organizationUnit.code = '';
  organizationUnit
    .save()
    .then(
      res.transformer
        .noContent()
        .withStatus(httpStatus.OK)
        .dispatch(),
    )
    .catch((e) => next(e));
}
/**
 * Delete organizationUnit.
 * @returns {OrganizationUnits}
 */
async function removeChild(parrentId) {
  const arrChild = await OrganizationUnit.find({ parent: parrentId });
  const removeArrchild = arrChild.map(async (item) => {
    removeChild(item._id);
    const organizationUnit = await OrganizationUnit.findById(item._id);
    organizationUnit.status = STATUS.DELETED;
    organizationUnit.code = '';
    return await organizationUnit.save();
  });
  return Promise.all(removeArrchild);
}
/**
 * Delete organizationUnit.
 * @returns {OrganizationUnits}
 */
async function removeMore(req, res, next) {
  const { organizationUnits } = req.body;
  const regex = new RegExp(`\\b${organizationUnits[0]}\\b`, 'i');
  const findOrg = await OrganizationUnit.find({ path: regex, status: STATUS.ACTIVED })
    .lean()
    .select('_id');
  const orgIds = findOrg.map((item) => item._id);
  const [existsEmpl] = await Promise.all([
    Employee.findOne({ 'organizationUnit.organizationUnitId': { $in: orgIds }, status: STATUS.ACTIVED }),
  ]);
  if (existsEmpl) {
    return res.json({
      status: 0,
      message:
        'Vui lòng thay đổi phòng ban/chi nhánh của nhân sự/người dùng sang phòng ban/chi nhánh khác trước khi xóa',
    });
  }
  const organizationUnitsDelete = organizationUnits.map(async (item) => {
    await removeChild(item);
    const organizationUnit = await OrganizationUnit.findById(item);
    organizationUnit.status = STATUS.DELETED;
    organizationUnit.code = '';
    return organizationUnit.save();
  });
  Promise.all(organizationUnitsDelete)
    .then(async (result) => {
      // Role.updateRoles();
      if (result) {
        await Employee.updateMany({ status: STATUS.ACTIVED }, { firstLogin: true });
      }
      res.json({
        success: true,
        data: result,
      });
    })
    .catch((err) => next(err));
}

/**
 * get a new Employee
 *
 * @param {Request} req
 * @param {Response} res
 * @param {Function} next
 */
async function getEmployees(req, res, next) {
  try {
    const employees = await Employee.find({
      organizationUnit: req.organizationUnit._id,
    }).exec();
    res.json(employees);
  } catch (err) {
    next(new ApiError(err));
  }
}

/**
 * get a new Employee
 *
 * @param {Request} req
 * @param {Response} res
 * @param {Function} next
 */
async function getChildOrganizationUnit(parent, organizationUnitIds) {
  const organizationUnit = await OrganizationUnit.findOne({ parent });
  if (organizationUnit) {
    organizationUnitIds.push(organizationUnit._id);
  }
  if (organizationUnit && organizationUnit.parent) {
    getChildOrganizationUnit(organizationUnit.parent, organizationUnitIds);
  }
}
async function getOrganizationByEmployee(req, res, next) {
  try {
    const employee = await Employee.findOne({ _id: req.user.user });
    const regex = new RegExp(`\\b${employee.organizationUnit.organizationUnitId}\\b`, 'i');
    const organizationUnit = await OrganizationUnit.find({ path: regex, status: STATUS.ACTIVED }).lean();
    if (!organizationUnit) {
      res.status(400).json({ success: false, message: 'Tài khoản chưa thuộc phòng ban nào' });
    }
    organizationUnit[0].parent = null;
    const employees = [];
    await employeeCtrl.getEmployByOrganization(employee.organizationUnit.organizationUnitId, employees);
    // console.log(employees)
    res.json({
      organizationUnitByUser: getTree(organizationUnit, organizationUnit),
      employeeInOrgan: employees,
    });
  } catch (error) {
    next(error);
  }
}

async function changeWorkingOrganization(req, res) {
  const { body, user } = req;
  const { user: userId } = user;
  const { organizationUnitId } = body;
  try {
    if (!organizationUnitId) return res.json({ status: 0, message: 'Đơn vị/ phòng ban không hợp lệ' });
    const employee = await Employee.findOne({ _id: userId });
    const regex = new RegExp(`\\b${employee.organizationUnit.organizationUnitId}\\b`, 'i');
    const foundOrg = await OrganizationUnit.findOne({
      path: regex,
      status: STATUS.ACTIVED,
      _id: organizationUnitId,
    }).lean();
    if (!foundOrg) {
      return res.json({ status: 0, message: 'Đơn vị/ phòng ban không hợp lệ' });
    }
    employee.workingOrganization = foundOrg._id;
    await employee.save();
    return res.json({ status: 1 });
  } catch (error) {
    return res.json({
      status: 0,
      message: error.message,
    });
  }
}
async function listOrg(req, res, next) {
  try {
    const data = await OrganizationUnit.find({ status: STATUS.ACTIVED });
    return res.json({
      status: 1,
      data
    })
  } catch (error) {
    console.log('listOrg:: ', error);
    next(error);
  }
}
module.exports = {
  list,
  create,
  createChild,
  update,
  remove,
  getEmployees,
  load,
  get,
  removeMore,
  listByStock,
  getChildOrganizationUnit,
  search,
  getOrganizationByEmployee,
  changeWorkingOrganization,
  listOrg
};
