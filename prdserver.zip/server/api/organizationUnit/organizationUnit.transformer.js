const AbstractTransformer = require('d-transformer').AbstractTransformer;

/*  eslint-disable  */
class OrganizationUnitTransformer extends AbstractTransformer {
  transform(organizationUnit) {
    return {
      id: organizationUnit._id,
      code: organizationUnit.code,
      name: organizationUnit.name,
      type: organizationUnit.type,
      parent: organizationUnit.parent,
      root: organizationUnit.root,
      level: organizationUnit.level,
      priority: organizationUnit.priority,
      oUFunction: organizationUnit.oUFunction,
      duty: organizationUnit.duty,
      children: organizationUnit.children,
      ...organizationUnit
    };
  }
}

module.exports = OrganizationUnitTransformer;
