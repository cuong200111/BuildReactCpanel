const Promise = require('bluebird');
const mongoose = require('mongoose');
const httpStatus = require('http-status');
const APIError = require('../../helpers/APIError');
const STATUS = require('../../variables/CONST_STATUS').STATUS;
const convertToFullTextSearch = require('../../helpers/convertToFullTextSearch');


const organizationUnitSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
    },
    code: {
      type: String,
    },
    type: {
      type: String,
      enum: ['company', 'department', 'stock', 'factory', 'workshop', 'salePoint', 'corporation'],
      required: true,
      default: 'company',
    },
    parent: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'OrganizationUnit',
      default: null,
    },
    priority: {
      type: Number,
      default: 0,
    },
    oUFunction: {
      type: String,
      default: '',
    },
    duty: {
      type: String,
      default: '',
    },
    note: {
      type: String,
      default: '',
    },
    geographicalArea: {
      _id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'CrmSource',
      },
      title: String,
      value: String,
      Index: Number,
    },
    accountingBranchCode: {
      type: String,
    },
    accountingDepartmentCode: {
      type: String,
      default: '',
    },
    path: String,
    status: {
      type: Number,
      enum: [0, 1, 2, 3],
      default: 1,
    },
    lat: String,
    long: String,
    total: Number,
    others: {},
  },
  { timestamps: true },
);

organizationUnitSchema.index({ name: 'text' });
organizationUnitSchema.method({
  getChildren() {
    return this.model('OrganizationUnit')
      .find({
        parent: this._id,
      })
      .exec();
  },
});

/**
 * Statics
 */
organizationUnitSchema.statics = {
  /**
   * Get organizationUnit
   *  @param {Ob jectId} id - The objectId of organizationUnit.
   * @returns {Promise<User, APIError>}
   */
  get(id) {
    return this.findOne({
      _id: id,
      status: STATUS.ACTIVED,
    })
      .exec()
      .then((organizationUnit) => {
        if (organizationUnit) {
          return organizationUnit;
        }
        const err = new APIError('No such organizationUnit exists!', httpStatus.NOT_FOUND);
        return Promise.reject(err);
      });
  },

  /**
   * List organizationUnits in descending order of 'createdAt' timestamp.
   * @param {number} skip - Number of organizationUnits to be skipped.
   * @param {number} limit - Limit number of organizationUnits to be returned.
   * @returns {Promise<User[]>}
   */
  async list({
    skip = 0,
    limit = 500,
    sort = {
      createdAt: -1,
    },
    filter = {},
  }) {
    /* eslint-disable no-param-reassign */
    filter.status = STATUS.ACTIVED;
    convertToFullTextSearch(filter);
    return this.find(filter)
      .sort(sort)
      .skip(+skip)
      .limit(+limit)
      .exec();
  },
};

module.exports = mongoose.model('OrganizationUnit', organizationUnitSchema);
