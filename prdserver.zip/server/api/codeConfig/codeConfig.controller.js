/* eslint-disable consistent-return */
/* eslint-disable camelcase */
const CodeConfig = require('./codeConfig.model');

const APIError = require('../../helpers/APIError');
const httpStatus = require('http-status');
const STATUS = require('../../variables/CONST_STATUS').STATUS;
const codeConfigInit = require('../codeConfig/codeConfig.init');

/**
 * Load codeConfig and append to req
 */
async function load(req, res, next, id) {
  // eslint-disable-next-line no-param-reassign
  req.codeConfig = await CodeConfig.findById(id);
  if (!req.codeConfig) {
    next(
        new APIError('Item not found', httpStatus.NOT_FOUND, true));
  }
  next();
}
/**
 * list codeConfig
 */
async function list(req, res, next) {
  try {
    const { limit = 500, skip = 0, sort, filter } = req.query;
    const codeConfigs = await CodeConfig.list({ limit, skip, sort, filter });
    res.json(codeConfigs);
  } catch (e) {
    next(e);
  }
}
/**
 * create codeConfig
 */
// eslint-disable-next-line consistent-return
async function create(req, res, next) {
  try {
        // eslint-disable-next-line max-len
    const {
      name,
      code
    } = req.body;
    const existCode = await CodeConfig.findOne({ code });
    if (existCode) {
      const err = new APIError('Exist codeConfig with code');
      return next(err);
    }
    const codeConfig = new CodeConfig({
        // eslint-disable-next-line max-len
      name,
      code,
    });

    return codeConfig.save()
                    .then((savedcodeConfig) => {
                      if (savedcodeConfig) res.json(savedcodeConfig);
                      else res.transforemer.errorBadRequest('Can not create item');
                    })
      .catch((e) => {
        next(e);
      });
  } catch (e) {
    next(e);
  }
}
/**
 * update codeConfig
 */
// eslint-disable-next-line consistent-return
async function update(req, res, next) {
  try {
    const {
      name,
      code,
    } = req.body;
    const existCode = await CodeConfig.findOne({ code });
    if (existCode && code !== req.codeConfig.code) {
      const err = new APIError('Exist codeConfig with code');
      return next(err);
    }
    const codeConfig = req.codeConfig;
    codeConfig.name = name;
    codeConfig.code = code;


    return codeConfig.save().then(async (result) => {
      res.json(result);
    }).catch((err) => {
      next(err);
    });
  } catch (e) {
    next(e);
  }
}

/**
 * Delete costEstimate.
 * @returns codeConfig
 */
function del(req, res, next) {
  const codeConfig = req.codeConfig;
  codeConfig.status = STATUS.DELETED;
  codeConfig.code = '';

  codeConfig
  .save()
  .then((result) => {
    res.json({
      success: true,
      data: result,
    });
  }
  )
  .catch(e => next(e));
}

async function deletedList(req, res, next) {
  try {
    const { ids } = req.body;
    const arrDataDelete = ids.map(async (codeConfigId) => {
      const codeConfig = await CodeConfig.findById(codeConfigId);
      if (codeConfig) {
        codeConfig.status = STATUS.DELETED;
        codeConfig.code = '';
        return codeConfig.save();
      }
    });
    const deletedData = await Promise.all(arrDataDelete);
    res.json({
      success: true,
      data: deletedData,
    });
  } catch (e) {
    next(e);
  }
}
function get(req, res) {
  res.json(req.codeConfig);
}
async function init() {
  const codeConfig = await CodeConfig.find();
  if (codeConfig.length === 0) {
    // eslint-disable-next-line no-undef
    // eslint-disable-next-line array-callback-return
    await Promise.all(codeConfigInit.map(item => new CodeConfig(item).save()));
  }
}

module.exports = {
  list,
  load,
  create,
  update,
  del,
  get,
  deletedList,
  init,
};
