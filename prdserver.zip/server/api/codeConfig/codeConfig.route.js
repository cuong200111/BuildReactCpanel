// eslint-disable-next-line new-cap
const router = require('../../../node_modules/express').Router();
const codeConfigCtrl = require('./codeConfig.controller');

router
    .route('/')
    .get(codeConfigCtrl.list)
    .post(codeConfigCtrl.create)
    .delete(codeConfigCtrl.deletedList);

router
    .route('/:codeConfigId')
    .get(codeConfigCtrl.get)
    .delete(codeConfigCtrl.del)
    .put(codeConfigCtrl.update);
router.param('codeConfigId', codeConfigCtrl.load);

codeConfigCtrl.init();
module.exports = router;
