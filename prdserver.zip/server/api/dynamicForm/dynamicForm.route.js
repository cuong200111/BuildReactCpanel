// eslint-disable-next-line new-cap
const router = require('express').Router();
const dynamicFormCtrl = require('./dynamicForm.controller');
const categoryDynamicFormCtrl = require('./categoryDynamicForm/categoryDynamicForm.controller');


router
  .route('/category')
  .get(categoryDynamicFormCtrl.list)
  .post(categoryDynamicFormCtrl.create)
  .delete(categoryDynamicFormCtrl.delMore);
router.route('/category/:categoryDynamicFormId')
  .get(categoryDynamicFormCtrl.get)
  .put(categoryDynamicFormCtrl.update)
  .delete(categoryDynamicFormCtrl.del);
router.param('categoryDynamicFormId', categoryDynamicFormCtrl.load);
categoryDynamicFormCtrl.init();
router
  .route('/')
  .post(dynamicFormCtrl.create)
  .get(dynamicFormCtrl.list)
  .delete(dynamicFormCtrl.delMore);
router
  .route('/:dynamicFormId')
  .put(dynamicFormCtrl.update)
  .delete(dynamicFormCtrl.del)
  .get(dynamicFormCtrl.get);
router.param('dynamicFormId', dynamicFormCtrl.load);
module.exports = router;
