const Joi = require('joi');

// const validString = Joi.string().trim().min(5).required();
// const phoneRegex = /^\+?\d{1,3}?[- .]?\(?(?:\d{2,3})\)?[- .]?\d\d\d[- .]?\d\d\d\d$/;

module.exports = {
  // POST /api/supplier
  createsupplier: {
    body: {
      title: Joi.string().required().max(200),
      code: Joi.string().required().min(5).max(20),
    }
  },

  // PUT /api/supplier/:supplierId
  updatesupplier: {
    body: {
      title: Joi.string().required().max(200),
      code: Joi.string().required().min(5).max(20),
    },
    params: {
      dynamicFormId: Joi.string().trim().hex().required()
    }
  }
};
