/* eslint-disable consistent-return */
const DynamicForm = require('./dynamicForm.model');
const CategoryDynamicForm = require('./categoryDynamicForm/categoryDynamicForm.model');
const APIError = require('../../helpers/APIError');
const httpStatus = require('http-status');
const STATUS = require('../../variables/CONST_STATUS').STATUS;
/**
 * Load measureUnit and append to req
 */
async function load(req, res, next) {
  const { dynamicFormId } = req.params;
  // eslint-disable-next-line no-param-reassign
  req.dynamicForm = await DynamicForm.findById(dynamicFormId).populate('categoryDynamicForm');
  if (!req.dynamicForm) {
    return next(new APIError('Item not found', httpStatus.BAD_REQUEST, true));
  }
  return next();
}

/**
 * list measureUnit
 */
async function list(req, res, next) {
  try {
    const dynamicForm = await DynamicForm.list({
      skip: req.query.page || 0,
      limit: req.query.perPage || 50,
      filter: req.query.filter
    });

    return res.json(dynamicForm);
  } catch (e) {
    return next(e);
  }
}

function get(req, res) {
  return res.json(req.dynamicForm);
}

async function create(req, res, next) {
  try {
    const { title, code, content, categoryDynamicForm, moduleCode } = req.body;
    if (!code || !title) {
      const err = new APIError('code or title not require', httpStatus.BAD_REQUEST, true);
      return next(err);
    }
    const categoryDynamicFormFindByCode = await DynamicForm.findOne({
      code,
    });
    if (categoryDynamicFormFindByCode) {
      const err = new APIError(`Exist item with code ${code}`, httpStatus.BAD_REQUEST, true);
      return next(err);
    }
    const dynamicForm = new DynamicForm({
      title,
      code,
      content,
      categoryDynamicForm,
      moduleCode,
    });

    const categoryDynamicFormSaved = await dynamicForm.save();
    return res.json({
      success: true,
      data: categoryDynamicFormSaved,
    });
  } catch (e) {
    return next(e);
  }
}

async function update(req, res, next) {
  try {
    const { title, code, content, categoryDynamicForm, moduleCode } = req.body;
    const categoryDynamicFormFind = await CategoryDynamicForm.findById(categoryDynamicForm);
    if (!categoryDynamicFormFind) {
      const err = new APIError('Not search CategoryDynamicForm by id', httpStatus.BAD_REQUEST, true);
      return next(err);
    }
    if (!code || !title) {
      const err = new APIError('code or title not require', httpStatus.BAD_REQUEST, true);
      return next(err);
    }
    const dynamicForm = req.dynamicForm;
    const categoryDynamicFormFindByCode = await DynamicForm.findOne({
      code,
    });
    if (categoryDynamicFormFindByCode && dynamicForm.code !== code) {
      const err = new APIError(`Exist item with code ${code}`, httpStatus.BAD_REQUEST, true);
      return next(err);
    }
    dynamicForm.code = code;
    dynamicForm.content = content;
    dynamicForm.title = title;
    dynamicForm.moduleCode = moduleCode;
    dynamicForm.categoryDynamicForm = categoryDynamicForm;

    const categoryDynamicFormSaved = await dynamicForm.save();
    return res.json({
      success: true,
      data: categoryDynamicFormSaved,
    });
  } catch (e) {
    return next(e);
  }
}

async function del(req, res, next) {
  try {
    const dynamicForm = req.dynamicForm;
    dynamicForm.status = STATUS.DELETED;
    dynamicForm.code = '';
    const categoryDynamicFormDelete = await dynamicForm.save();
    res.json({
      success: true,
      data: categoryDynamicFormDelete,
    });
  } catch (e) {
    return next(e);
  }
}
async function delMore(req, res, next) {
  try {
    const { ids } = req.body;
    const dynamicFormsDeleted = await Promise.all(
      ids.map(async (id) => {
        const dynamicFormDeleted = await DynamicForm.findById(id);
        dynamicFormDeleted.status = STATUS.DELETED;
        dynamicFormDeleted.code = '';
        return dynamicFormDeleted.save();
      }),
    );
    res.json({
      success: true,
      data: dynamicFormsDeleted,
    });
  } catch (e) {
    return next(e);
  }
}

module.exports = {
  load,
  list,
  get,
  create,
  update,
  del,
  delMore,
};
