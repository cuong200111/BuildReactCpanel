const Promise = require('bluebird');
const mongoose = require('mongoose');
const httpStatus = require('http-status');
const APIError = require('../../helpers/APIError');
const STATUS = require('../../variables/CONST_STATUS').STATUS;
const convertToFullTextSearch = require('../../helpers/convertToFullTextSearch');

/**
 * crm-Source Schema
 */
const dynamicFormSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: true,
      maxlength: 200,
    },
    code: String,
    categoryDynamicForm: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'CategoryDynamicForm',
      required: true,
    },
    moduleCode: String,
    content: {
      type: String,
    },
    status: {
      type: Number,
      enum: [0, 1, 2, 3],
      default: 1,
    },
  },
  {
    timestamps: true,
  },
);
dynamicFormSchema.method({});

dynamicFormSchema.statics = {
  /**
   * Get CrmSource
   * @param {ObjectId} id - The ObjectId of CrmSource
   * @returns {Promise<CrmSource, APIError}
   */
  get(id) {
    return this.findOne({
      _id: id,
      status: STATUS.ACTIVED,
    })
      .exec()
      .then((crmSource) => {
        if (crmSource) {
          return crmSource;
        }
        const err = new APIError('No such crmSource exists!', httpStatus.NOT_FOUND);
        return Promise.reject(err);
      });
  },
  /**
   * List crmSource in descending order of 'createdAt' timestamps
   *
   * @param {number} skip - Number of crmSource to be skipped.
   * @param {number} limit - Limit number of crmSource to be returned.
   * @returns {Promise<CrmSource[]>}
   */
  list({
    skip = 0,
    limit = 500,
    sort = {
      createdAt: -1,
    },
    filter = {
      status: 1,
    },
  }) {
    // eslint-disable-next-line no-param-reassign
    filter.status = STATUS.ACTIVED;
    convertToFullTextSearch(filter);
    return this.find(filter)
      .populate('categoryDynamicForm')
      .sort(sort)
      .skip(+skip)
      .limit(+limit)
      .exec();
  },
};

module.exports = mongoose.model('dynamicForm', dynamicFormSchema);
