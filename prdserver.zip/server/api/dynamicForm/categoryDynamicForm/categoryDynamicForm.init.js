const dynamicForm = [
  {
    title: 'Biểu mẫu xuất kho',
    code: 'LBM01',
    alwaysUsed: true,
    isDeleted: false,
  },
  {
    title: 'Biểu mẫu nhập kho',
    code: 'LBM02',
    alwaysUsed: true,
    isDeleted: false,
  },
  {
    title: 'Biểu mẫu hợp đồng bán hàng (mua hàng)',
    code: 'LBM03',
    alwaysUsed: true,
    isDeleted: false,
  },
  {
    title: 'Biểu mẫu hợp đồng nhân sự',
    code: 'LBM04',
    alwaysUsed: true,
    isDeleted: false,
  },

  {
    title: 'Biểu mẫu đánh giá',
    code: 'LBM05',
    alwaysUsed: true,
    isDeleted: false,
  },

  {
    title: 'Biểu mẫu công văn',
    code: 'LBM06',
    alwaysUsed: true,
    isDeleted: false,
  },

  {
    title: 'Biểu mẫu yêu cầu thanh toán',
    code: 'LBM07',
    alwaysUsed: true,
    isDeleted: false,
  },
  {
    title: 'Biểu mẫu yêu cầu phê duyệt',
    code: 'LBM08',
    alwaysUsed: true,
    isDeleted: false,
  },
  {
    title: 'Biểu mẫu sản xuất',
    code: 'LBM09',
    alwaysUsed: true,
    isDeleted: false,
  },
  {
    title: 'Biểu mẫu xuất hàng',
    code: 'LBM10',
    alwaysUsed: true,
    isDeleted: false,
  },
  {
    title: 'Biểu mẫu biên bản bàn giao',
    code: 'LBM11',
    alwaysUsed: true,
    isDeleted: false,
  },

  {
    title: 'Biểu mẫu báo giá',
    code: 'LBM12',
    alwaysUsed: true,
    isDeleted: false,
  },

  {
    title: 'Biểu mẫu bảo hành',
    code: 'LBM13',
    alwaysUsed: true,
    isDeleted: false,
  },
  {
    title: 'Biểu mẫu đặt hàng',
    code: 'LBM14',
    alwaysUsed: true,
    isDeleted: false,
  },
  {
    title: 'Biểu mẫu bảo hành',
    code: 'LBM15',
    alwaysUsed: true,
    isDeleted: false,
  },
];
module.exports = dynamicForm;
