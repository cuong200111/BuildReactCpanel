const Promise = require('bluebird');
const mongoose = require('mongoose');
const httpStatus = require('http-status');
const APIError = require('../../../helpers/APIError');
const STATUS = require('../../../variables/CONST_STATUS').STATUS;

/**
 * crm-Source Schema
 */

const dynamicFormSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: true,
    },
    code: String,
    alwaysUsed: {
      type: Boolean,
      default: false,
    },
    isDeleted: {
      type: Boolean,
      default: true,
    },
    modules: [{ name: String, code: String }],
    status: {
      type: Number,
      enum: [0, 1, 2, 3],
      default: 1,
    },
  },
  {
    timestamps: true,
  },
);
dynamicFormSchema.method({});

dynamicFormSchema.statics = {
  /**
   * Get CategoryDynamicForm
   * @param {ObjectId} id - The ObjectId of CategoryDynamicForm
   * @returns {Promise<CategoryDynamicForm, APIError}
   */
  get(id) {
    return this.findOne({
      _id: id,
      status: STATUS.ACTIVED,
    })
      .exec()
      .then((categoryDynamicForm) => {
        if (categoryDynamicForm) {
          return categoryDynamicForm;
        }
        const err = new APIError('No such catagory dynamic form exists!', httpStatus.NOT_FOUND);
        return Promise.reject(err);
      });
  },
  /**
   * List categoryDynamicForm in descending order of 'createdAt' timestamps
   *
   * @param {number} skip - Number of categoryDynamicForm to be skipped.
   * @param {number} limit - Limit number of categoryDynamicForm to be returned.
   * @returns {Promise<CategoryDynamicForm[]>}
   */
  list({
    skip = 0,
    limit = 500,
    sort = {
      createdAt: -1,
    },
    filter = {
      status: 1,
    },
  }) {
    const count = this.count(filter);
    const data = this.find(filter)
      .sort(sort)
      .skip(+skip)
      .limit(+limit)
      .exec();
    return { data, count };
  },
};

module.exports = mongoose.model('CategoryDynamicForm', dynamicFormSchema);
