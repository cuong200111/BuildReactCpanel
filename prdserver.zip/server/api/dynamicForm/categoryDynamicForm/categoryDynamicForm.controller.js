/* eslint-disable consistent-return */
const CategoryDynamicForm = require('./categoryDynamicForm.model');
const APIError = require('../../../helpers/APIError');
const httpStatus = require('http-status');
const STATUS = require('../../../variables/CONST_STATUS').STATUS;
const categoryDynamicFormInit = require('./categoryDynamicForm.init');
/**
 * Load measureUnit and append to req
 */
async function load(req, res, next) {
  const { categoryDynamicFormId } = req.params;
  // eslint-disable-next-line no-param-reassign
  req.categoryDynamicForm = await CategoryDynamicForm.findById(categoryDynamicFormId);
  if (!req.categoryDynamicForm) {
    return next(new APIError('Item not found', httpStatus.BAD_REQUEST, true));
  }
  return next();
}

/**
 * list measureUnit
 */
async function list(req, res, next) {
  try {
    const categoryDynamicForm = await CategoryDynamicForm.list({
      skip: req.query.page || 0,
      limit: req.query.perPage || 50,
    });
    return res.json(categoryDynamicForm);
  } catch (e) {
    return next(e);
  }
}

function get(req, res) {
  return res.json(req.categoryDynamicForm);
}
async function create(req, res, next) {
  try {
    const { title, code, alwaysUsed, modules } = req.body;
    if (!code || !title) {
      const err = new APIError('code or title not require', httpStatus.BAD_REQUEST, true);
      return next(err);
    }
    const categoryDynamicFormFindByCode = await CategoryDynamicForm.findOne({
      code,
    });
    if (categoryDynamicFormFindByCode) {
      const err = new APIError(`Exist item with code ${code}`, httpStatus.BAD_REQUEST, true);
      return next(err);
    }
    const categoryDynamicForm = new CategoryDynamicForm({
      title,
      code,
      alwaysUsed,
      modules,
    });

    const categoryDynamicFormSaved = await categoryDynamicForm.save();
    return res.json({
      success: true,
      data: categoryDynamicFormSaved,
    });
  } catch (e) {
    return next(e);
  }
}
async function update(req, res, next) {
  try {
    const { title, code, alwaysUsed, modules } = req.body;
    if (!code || !title) {
      const err = new APIError('code or title not require', httpStatus.BAD_REQUEST, true);
      return next(err);
    }
    const categoryDynamicForm = req.categoryDynamicForm;
    if (!categoryDynamicForm.isDeleted) {
      const err = new APIError('Item is not updated', httpStatus.BAD_REQUEST, true);
      next(err);
    }
    const categoryDynamicFormFindByCode = await CategoryDynamicForm.findOne({
      code,
    });
    if (categoryDynamicFormFindByCode && categoryDynamicForm.code !== code) {
      const err = new APIError(`Exist item with code ${code}`, httpStatus.BAD_REQUEST, true);
      return next(err);
    }
    categoryDynamicForm.code = code;
    categoryDynamicForm.title = title;
    categoryDynamicForm.alwaysUsed = alwaysUsed;
    categoryDynamicForm.modules = modules;

    const categoryDynamicFormSaved = await categoryDynamicForm.save();
    return res.json({
      success: true,
      data: categoryDynamicFormSaved,
    });
  } catch (e) {
    return next(e);
  }
}
async function del(req, res, next) {
  try {
    const categoryDynamicForm = req.categoryDynamicForm;
    if (!categoryDynamicForm.isDeleted) {
      const err = new APIError('Item is not deleted', httpStatus.BAD_REQUEST, true);
      next(err);
    }
    categoryDynamicForm.status = STATUS.DELETED;
    categoryDynamicForm.code = '';
    const categoryDynamicFormDelete = await categoryDynamicForm.save();
    res.json({
      success: true,
      data: categoryDynamicFormDelete,
    });
  } catch (e) {
    return next(e);
  }
}

async function init() {
  try {
    const categoryDynamicForms = await CategoryDynamicForm.find();
    if (categoryDynamicForms.length === 0) {
      await Promise.all(categoryDynamicFormInit.map(item => new CategoryDynamicForm(item).save()));
    }
  } catch (error) {
    throw error;
  }
}

async function delMore(req, res, next) {
  try {
    const { ids } = req.body;
    const categoryDynamicFormsDeleted = await Promise.all(
      ids.map(async (id) => {
        const categoryDynamicFormDeleted = await CategoryDynamicForm.findById(id);
        if (categoryDynamicFormDeleted.isDeleted) {
          categoryDynamicFormDeleted.status = STATUS.DELETED;
          categoryDynamicFormDeleted.code = '';
        }
        return categoryDynamicFormDeleted.save();
      }),
    );
    res.json({
      success: true,
      data: categoryDynamicFormsDeleted,
    });
  } catch (e) {
    return next(e);
  }
}

module.exports = {
  load,
  list,
  get,
  create,
  update,
  del,
  init,
  delMore,
};
