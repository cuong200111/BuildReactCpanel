const express = require('express');
// const validate = require('express-validation');
const pluginCtrl = require('./plugin.controller');

const router = express.Router(); // eslint-disable-line new-cap

router
  .route('/:collectionCode')
  // /** POST /api/collection/:collectionCode - Create collection */
  // .post(collectionCtrl.create)

  // // /** PUT /api/collections/:collectionCode - Update dynamicCollection */
  // // .put(dynamicCollectionCtrl.updateNameCodeDCollection)

  // /** GET /api/plugins/:collectionCode - Get list of plugins */
  .get(pluginCtrl.list)

// /** GET /api/collections/:collectionCode - Get list dynamicCollection */
// .delete(dynamicCollectionCtrl.getDynamicCollection)
;

router
  .route('/:collectionCode/:functionName')
  /** GET /api/collections/:collectionCode - Get user */
  .get(pluginCtrl.get)

  /** POST /api/collections/:collectionCode - Get user */
  .post(pluginCtrl.callAction)

  // /** PUT /api/collections/:collectionCode - Update user */
  .patch(pluginCtrl.update)

  // /** DELETE /api/collections/:collectionCode - Delete user */
  .delete(pluginCtrl.remove);


/** Load user when API with collectionCode, dataId route parameter is hit */
router.param('collectionCode', pluginCtrl.load);
router.param('functionName', pluginCtrl.loadFunction);

module.exports = router;
