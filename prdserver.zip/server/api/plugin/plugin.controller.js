// const logger = require('winston');
const ApiError = require('../../helpers/APIError');
const httpStatus = require('http-status');


/**
 * Load collection and append to req.
 */
function load(req, res, next, code) {
  if (!Object.prototype.hasOwnProperty.call(global.hshPlugins, code)) {
    return next(new ApiError('Not found collections', httpStatus.NOT_FOUND));
  }

  const plugin = global.hshPlugins[code];
  // eslint-disable-next-line no-param-reassign
  req.plugin = plugin;

  if (!Object.prototype.hasOwnProperty.call(global.hshCollections, code)) {
    return next(new ApiError('Not found collections', httpStatus.NOT_FOUND));
  }

  const collection = global.hshCollections[code];

  // eslint-disable-next-line no-param-reassign
  req.Collection = collection;


  return next();
}

/**
 * Load collection and append to req.
 */
function loadFunction(req, res, next, name) {
  const type = Number(req.query.type); // 0: statistic, 1: method;

  switch (type) {
    case 0:
      if (!Object.prototype.hasOwnProperty.call(req.Collection.schema.statics, name)) {
        return next(new ApiError('Not found statistic method', httpStatus.NOT_FOUND));
      }
      // eslint-disable-next-line no-param-reassign
      req.function = req.Collection.schema.statics[name];
      break;
    case 1:
      if (!Object.prototype.hasOwnProperty.call(req.Collection.schema.methods, name)) {
        return next(new ApiError('Not found method', httpStatus.NOT_FOUND));
      }
      // eslint-disable-next-line no-param-reassign
      req.function = req.Collection.schema.methods[name];
      break;

    default:
      break;
  }

  return next();
}

function create(req, res, next) {
  const collection = new req.Collection({
    ...req.body
  });
  collection.save()
    .then((savedCollection) => {
      res.json(savedCollection);
    })
    .catch(err => next(err));
}

/**
 * Get collection data list.
 * @property {number} req.query.skip - Number of data in collection to be skipped.
 * @property {number} req.query.limit - Limit number of datas to be returned.
 * @returns {User[]}
 */
// eslint-disable-next-line no-unused-vars
function list(req, res, next) {
  const plugins = req.plugin;
  res.json(plugins);
}


/**
 * Get function of collection
 * @returns {function detail in collection}
 */
function get(req, res) {
  const funcObj = parseFunction(req.function.toString());
  return res.json(funcObj);
}


/**
 * Call function of collection
 * @returns {function detail in collection}
 */
function callAction(req, res, next) {
  callActionByType(req)
    .then(successMess => res.json(successMess))
    .catch(err => next(new ApiError(err)));
}

function callActionByType(req) {
  return new Promise((resolve, reject) => {
    const itemId = req.query.id;
    const type = Number(req.query.type);


    const funcObj = parseFunction(req.function.toString());
    const argValues = [];
    funcObj.args.forEach((key) => {
      argValues.push(req.body[key]);
    });

    if (type === 0) {
      req.function(...argValues);
      resolve('done');
    } else if (type === 1) {
      if (!itemId) {
        reject('item _id error');
      }
      req.Collection.get(itemId)
        .then(doc => doc[funcObj.name](...argValues))
        .then((doc) => {
          resolve(doc);
        })
        .catch(err => reject(err));
    } else {
      reject('type error');
    }
  });
}

/**
 * Update existing Dynamic Collection name or code
 *
 * @returns {Collection}
 */
function update(req, res, next) {
  const datarow = req.data;
  const updateData = req.body;

  Object.keys(updateData).forEach((k) => {
    datarow[k] = updateData[k];
  });


  datarow.save()
    .then(savedData => res.json(savedData))
    .catch(e => next(e));
}

/**
 * Update existing Dynamic Collection name or code
 *
 * @returns {Collection}
 */
function remove(req, res, next) {
  const datarow = req.data;

  datarow.delete()
    .then(savedData => res.json(savedData))
    .catch(e => next(e));
}

function parseFunction(functionString) {
  const bracketIndexFirst = functionString.indexOf('(');
  const bracketIndexLast = functionString.indexOf(')');
  const funcName = functionString.substring(0, bracketIndexFirst).trim();
  const argString = functionString.substring(bracketIndexFirst + 1, bracketIndexLast).trim();
  const args = argString.split(',').map(key => key.trim()).filter(key => key !== '');
  return {
    name: funcName,
    args
  };
}

module.exports = {
  load,
  create,
  callAction,
  loadFunction,
  list,
  get,
  update,
  remove
};
