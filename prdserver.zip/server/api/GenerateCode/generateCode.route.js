const express = require('express');
const generateCode = require('./generateCode.controller');

const router = express.Router(); // eslint-disable-line new-cap

router.route('/').post(generateCode.create);
router.route('/:module').get(generateCode.read);

module.exports = router;
