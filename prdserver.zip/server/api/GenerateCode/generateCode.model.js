const moment = require('moment');
// eslint-disable-next-line
const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const GenarateCodeSchema = new Schema({
  model: { type: String, required: true, index: { unique: true } },
  idx: { type: Number, default: 0 },
  // code: String,
  prefix: { type: String },
  formatDate: {
    type: String,
    enum: [null, 'DDMMYY', 'YYMMDD', 'MMDDYY'],
  },
  numericalOrderFormat: {
    type: Number,
    enum: [2, 3, 4],
  },
  productType: Boolean,
  provincial: Boolean,
  intermediate: String,
  suffixes: {
    type: String,
  },
  nickname: Boolean,
  breakCharacter: {
    type: String,
    enum: ['/', '-'],
    required: true,
  },
});

/**
 * @param {modelName} modelName
 * @param {String} nickname
 */
// eslint-disable-next-line
GenarateCodeSchema.statics.genarateCode = async function(modelName, nickname, provincial, productType, next) {
  try {
    let GenarateCode = await this.findOne({ model: modelName });
    if (!GenarateCode) GenarateCode = await new this({ model: modelName }).save();
    // eslint-disable-next-line
    GenarateCode.idx++;
    const rawCode = [];
    if (GenarateCode.prefix) rawCode.push(GenarateCode.prefix);
    // eslint-disable-next-line
    // console.log(rawCode);
    if (GenarateCode.formatDate) rawCode.push(moment().format(GenarateCode.formatDate));
    if (GenarateCode.numericalOrderFormat) {
      rawCode.push((Math.pow(10, GenarateCode.numericalOrderFormat) + GenarateCode.idx).toString().substr(1));
    }
    if (GenarateCode.intermediate && !GenarateCode.provincial && !GenarateCode.productType) {
      rawCode.push(GenarateCode.intermediate);
    } 
    else if (!GenarateCode.intermediate && GenarateCode.provincial && !GenarateCode.productType) {
      rawCode.push(provincial);
    } else if (!GenarateCode.intermediate && !GenarateCode.provincial && GenarateCode.productType) {
        rawCode.push(productType);
    }
    if (GenarateCode.suffixes) rawCode.push(GenarateCode.suffixes);
    if (GenarateCode.nickname === true) rawCode.push(nickname);
    // GenarateCode.code = await rawCode.join(GenarateCode.breakCharacter);
    GenarateCode.save();
    return rawCode.join(GenarateCode.breakCharacter);
  } catch (error) {
    next(error);
  }
};

module.exports = mongoose.model('GenarateCode', GenarateCodeSchema);
