const Joi = require('joi');

const create = {
  body: {
    moduleType: Joi.number()
      .required()
      .valid(1, 2, 3, 4, 5)
      .default(0),
    prefix: Joi.string(),
    formatDate: Joi.number().valid(0, 1, 2),
    numericalOrderFormat: Joi.number().valid(1, 2, 3),
    suffixes: Joi.string().valid('PALL'),
    nickname: Joi.boolean()
      .truthy(true)
      .falsy(false),
    intermediate: Joi.string(),
    breakCharacter: Joi.number().valid(1, 2),
  },
};

module.exports = { create };
