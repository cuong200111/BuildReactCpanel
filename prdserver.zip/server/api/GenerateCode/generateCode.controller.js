const GenerateCode = require('./generateCode.model');
// const STATUS = require('../../variables/CONST_STATUS').STATUS;
const generateCodeInit = require('./generateCode.init')

const model = ['Task', 'Contract', 'Customer', 'Supplier', 'SalesQuotation'];
const dateType = ['DDMMYY', 'YYMMDD', 'MMDDYY'];
const numericalOrder = [2, 3, 4];
const breakCharacterFormat = ['/', '-'];
async function create(req, res, next) {
  try {
    const {
      moduleType,
      prefix,
      formatDate,
      numericalOrderFormat,
      intermediate,
      suffixes,
      productType,
      provincial,
      nickname,
      breakCharacter,
    } = req.body;
    if (!prefix && !formatDate && !numericalOrderFormat && !intermediate && !suffixes && !nickname) {
      res.status(400).json({ success: false, msg: 'You must enter at least one option' });
    }
    if (provincial && intermediate) {
      res.status(400).json({ success: false, msg: 'You can only choose provincial or intermediate' });
    }
    if (productType && intermediate) {
      res.status(400).json({ success: false, msg: 'You can only choose productType or intermediate' });
    }
    let codeConfig = await GenerateCode.findOne({ model: model[moduleType - 1] });
    if (!codeConfig) codeConfig = await new GenerateCode({ model: model[moduleType - 1] }).save();
    codeConfig.prefix = prefix;
    codeConfig.formatDate = dateType[formatDate - 1];
    codeConfig.numericalOrderFormat = numericalOrder[Number(numericalOrderFormat) - 1];
    codeConfig.intermediate = intermediate;
    codeConfig.provincial = provincial;
    codeConfig.suffixes = suffixes;
    codeConfig.nickname = nickname;
    codeConfig.productType = productType;
    codeConfig.breakCharacter = breakCharacterFormat[Number(breakCharacter) - 1];
    codeConfig.save();
    res.status(200).json({ success: true, msg: 'The rule has been successfully updated', data: req.body });
  } catch (error) {
    next(error);
  }
}
async function read(req, res, next) {
  try {
    // // eslint-disable-next-line
    // console.log(req.params.module);
    let rule = await GenerateCode.findOne({ model: req.params.module }).select('-_id -idx -__v');
    if (!rule) {
     await GenerateCode.insertMany(generateCodeInit.generateCode)
    }
    rule = await GenerateCode.findOne({ model: req.params.module }).select('-_id -idx -__v');
    // res.status(400).send('Cannot find rule for this module, please try again!!!!');
    const result = {};
    result.moduleType = model.indexOf(rule.model) + 1;
    result.prefix = rule.prefix;
    result.formatDate = rule.formatDate ? dateType.indexOf(rule.formatDate) + 1 : undefined;
    result.numericalOrderFormat = rule.numericalOrderFormat
      ? numericalOrder.indexOf(rule.numericalOrderFormat) + 1
      : undefined;
    result.intermediate = rule.intermediate;
    result.suffixes = rule.suffixes;
    result.nickname = rule.nickname;
    result.productType = rule.productType;
    result.provincial = rule.provincial;
    result.breakCharacter = breakCharacterFormat.indexOf(rule.breakCharacter) + 1;
    res.status(200).send(result);
  } catch (error) {
    console.log(error)
    next(error);
  }
}


module.exports = { create, read };
