const generateCode = [
    { 
      "idx" : 0, 
      "model" : "Task", 
      "breakCharacter" : "/", 
      "numericalOrderFormat" : 3, 
      "prefix" : "DA", 
      "formatDate" : "DDMMYY", 
      "nickname" : true, 
      "intermediate" : "az"
  },
  { 
      "idx" : 0, 
      "model" : "Contract", 
      "breakCharacter" : "/", 
      "numericalOrderFormat" : 3, 
      "prefix" : "HD", 
      "formatDate" : "DDMMYY", 
      "nickname" : true, 
      "productType" : true
  },
  { 
      "idx" : 0, 
      "model" : "Customer", 
      "breakCharacter" : "/", 
      "prefix" : "KH", 
      "nickname" : true, 
      "numericalOrderFormat" : 3, 
      "provincial" : true
  },
  { 
      "idx" : 0, 
      "model" : "Supplier", 
      "breakCharacter" : "/", 
      "formatDate" : "DDMMYY", 
      "numericalOrderFormat" : 3, 
      "prefix" : "NCC"
  },
  { 
      "idx" : 0, 
      "model" : "SalesQuotation", 
      "breakCharacter" : "/", 
      "formatDate" : "MMDDYY", 
      "numericalOrderFormat" : 3, 
      "intermediate" : "AB"
  }
]

module.exports = {
  generateCode
};