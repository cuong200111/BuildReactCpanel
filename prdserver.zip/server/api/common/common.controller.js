const mongoose = require('mongoose');
const APIError = require('../../helpers/APIError');
const httpStatus = require('http-status');
const { generalPopulate, filterRole } = require('../../helpers/common');
const { STATE } = require('../../variables/CONST_STATUS');
const { STATUS } = require('../../variables/CONST_STATUS');
const moduleStatic = require('../../variables/moduleStatic');
const ModuleConfig = require('../systemConfig/moduleConfig.model');
const SystemConfig = require('../systemConfig/systemConfig.model');
const OrganizationUnit = require('../organizationUnit/organizationUnit.model');
const { convertToObj } = require('./common.service');
// const DynamicCollection = require('../dynamic-collection/dynamic-collection.model');

/**
 * Get collection data list.
 * @property {number} req.query.skip - Number of data in collection to be skipped.
 * @property {number} req.query.limit - Limit number of datas to be returned.
 * @returns {Model[]}
 */
async function getByIds(req, res, next) {
  const { ids, model } = req.query;
  if (model) {
    try {
      const Model = mongoose.models[model];
      if (Model) {
        const models = await Model.find({
          _id: {
            $in: ids,
          },
        });

        return res.json({
          success: true,
          data: models,
        });
      }
      const error = new APIError('model not found', httpStatus.BAD_REQUEST, true);
      return next(error);
    } catch (error) {
      return next(error);
    }
  } else {
    const error = new APIError('model not found', httpStatus.BAD_REQUEST, true);
    return next(error);
  }
}
/**
 * @property {number} req.params.mdoel
 * @property {number} req.params.id
 * @returns {model}
 */
async function populate(req, res, next) {
  const { model, id } = req.params;
  try {

    let Model = global.hshCollections[model];
    if (Model) {
      console.log(Model)
      const data = await generalPopulate(Model, id);
      if (data) {
        res.json(data);
      }
    }
  } catch (error) {
    next(error);
  }
}
/**
 * @property {number} req.body.mdoel
 * @property {number} req.body.id
 * @returns {model}
 */
// eslint-disable-next-line consistent-return
async function setStatusFinishApprove(req, res, next) {
  const { model, id } = req.body;
  try {
    const Model = global.hshCollections[model];
    if (Model) {
      const documentMode = await Model.findById(id);

      if (!documentMode) {
        return next(new APIError('Không tìm thấy bản ghi', httpStatus.BAD_REQUEST, true));
      }
      if (
        Number(documentMode.state) !== Number(STATE.APPROVED) &&
        Number(documentMode.state) !== Number(STATE.NOT_APPROVAL_REQUIREMENT)
      ) {
        return next(new APIError('Trạng thái chưa được phê duyệt', httpStatus.BAD_REQUEST, true));
      }

      documentMode.state = STATE.FINISHED;
      const documentModeSaved = await documentMode.save();

      res.json(documentModeSaved);
    }
  } catch (error) {
    next(error);
  }
}
/**
 * @returns {model}
 */
// eslint-disable-next-line consistent-return
// mapping tiếng việt
async function getAllModuleDynamic(req, res, next) {
  try {
    await initModuleDynamic();
    const currentModuleConfig = await ModuleConfig.findOne();
    if (currentModuleConfig && currentModuleConfig.data) {
      const mappingName = currentModuleConfig.mappingName || {};
      const hshForCode = {};
      currentModuleConfig.data.forEach((p) => {
        hshForCode[p.code] = {
          title: mappingName[p.code] || p.code,
        };
        if (p.childCodes) {
          p.childCodes.forEach((c) => {
            hshForCode[c] = {
              title: mappingName[c] || c,
            };
          });
        }
      });
      const currentSystemConfig = await SystemConfig.findOne();
      if (currentSystemConfig) {
        currentSystemConfig.moduleConfig = currentModuleConfig.data;
        await currentSystemConfig.save();
      }
      return res.json(hshForCode);
    }

    // console.log(global.hshCollectionsTitle);
    const hshForCode = {
      ...global.hshCollectionsTitle,
    };
    // console.log(hshForCode);
    Object.keys(hshForCode).forEach((item) => {
      if (hshForCode[item].title === 'Test') {
        delete hshForCode[item];
      }
      // if (item === 'HrmEmployee') {
      //   delete hshForCode[item];
      // }
    });
    Object.keys(hshForCode).forEach((item) => {
      if (hshForCode[item].title === undefined) {
        delete hshForCode[item];
      }
    });

    moduleStatic.forEach((item) => {
      hshForCode[item.route] = {
        title: item.title,
      };
    });

    res.json(hshForCode);
  } catch (error) {
    next(error);
  }
}

async function initModuleDynamic() {
  try {
    const currentModuleConfig = await ModuleConfig.findOne();
    if (currentModuleConfig && currentModuleConfig.data) {
      const module = [];
      currentModuleConfig.data.forEach((p) => {
        module.push(p.code);
        if (p.childCodes) {
          module.push(...p.childCodes);
        }
      });
      let checkSave = false;
      await Promise.map(moduleStatic, async (i) => {
        const check = module.find(a => a === i.route);
        if (!check && i && i.route) {
          checkSave = true;
          currentModuleConfig.data.push({ code: i.route });
          currentModuleConfig.mappingName[i.route] = i.title;
        }
      });
      if (checkSave) {
        await ModuleConfig.update(
          { _id: currentModuleConfig._id },
          { $set: { data: currentModuleConfig.data, mappingName: currentModuleConfig.mappingName } }
        );
      }
    }
  } catch (error) {
    console.log('ERROR: ', error);
  }
}

async function list(req, res, next) {
  const { username } = req.params;
  let model = req.params.model;
  try {
    const employee = await global.hshCollections.Employee.findOne({ username });
    // const Model = global.hshCollections[model];
    const checkExist = [...Object.keys(global.hshCollections), ...moduleStatic.map((item) => item.route)];
    if (checkExist.includes(model) && employee) {
      const filter = await filterRole({ user: employee._id, code: model });
      if (['inComingDocument', 'outGoingDocument'].includes(model)) {
        model = 'Documentary';
      }
      const Model = global.hshCollections[model];
      const data = await Model.find(filter, { _id: 1 });
      if (data) {
        res.json(data);
      }
    }
  } catch (error) {
    next(error);
  }
}
async function getByFilter(req, res, next) {
  try {
    const { filter, model, selector, getAll } = req.body;
    let query;
    console.log(':< filter', filter);
    if (typeof filter === 'string') {
      const regex = /'/g;
      query = filter.replace(regex, '"');
      query = JSON.parse(query);
    } else {
      query = filter;
    }
    let Model;
    let data;
    if (model === 'OrganizationUnit') {
      Model = OrganizationUnit;
    } else {
      Model = global.hshCollections[model];
    }
    if (getAll) {
      data = await Model.find({ ...query, status: STATUS.ACTIVED });
    } else {
      data = await Model.find({ ...query, status: STATUS.ACTIVED }).select(selector);
    }
    console.log(':< data', data);
    return res.json(data);
  } catch (error) {
    next(error);
  }
}

async function getInfoById(req, res, next) {
  const { id, model, selector } = req.query;
  if (model) {
    try {
      const Model = mongoose.models[model];
      if (Model) {
        const models = await Model.findOne(
          {
            _id: id,
          },
          selector,
        );

        return res.json({
          success: true,
          data: models,
        });
      }
      const error = new APIError('model not found', httpStatus.BAD_REQUEST, true);
      return next(error);
    } catch (error) {
      return next(error);
    }
  } else {
    const error = new APIError('model not found', httpStatus.BAD_REQUEST, true);
    return next(error);
  }
}
async function getByFilterV2(req, res, next) {
  try {
    const { body } = req.body;
    const data2 = {};
    for (const value of body) {
      const { key, filter, model } = value;
      const selector = value.selector || ' ';
      let Model;
      if (model === 'OrganizationUnit') {
        Model = OrganizationUnit;
      } else {
        Model = global.hshCollections[model];
      }
      const data = await Model.findOne({ ...filter, status: STATUS.ACTIVED }).select(selector);
      data2[key] = data;
    }
    return res.json(data2);
  } catch (error) {
    next(error);
  }
}
async function getAllModuleDynamic4WorkFlow(req, res, next) {
  try {
    const currentModuleConfig = await ModuleConfig.findOne();
    if (currentModuleConfig && currentModuleConfig.data) {
      const mappingName = currentModuleConfig.mappingName || {};
      const hshForCode = {};
      currentModuleConfig.data.forEach((p) => {
        hshForCode[p.code] = {
          title: mappingName[p.code] || p.code,
          name: p.code
        };
        if (p.childCodes) {
          p.childCodes.forEach((c) => {
            hshForCode[c] = {
              title: mappingName[c] || c,
              name: c
            };
          });
        }
      });
      const currentSystemConfig = await SystemConfig.findOne();
      if (currentSystemConfig) {
        currentSystemConfig.moduleConfig = currentModuleConfig.data;
        await currentSystemConfig.save();
      }
      return res.json(hshForCode);
    }
    const hshForCode = {
      ...global.hshCollectionsTitle,
    };
    Object.keys(hshForCode).forEach((item) => {
      if (hshForCode[item].title === 'Test') {
        delete hshForCode[item];
      }
    });
    Object.keys(hshForCode).forEach((item) => {
      if (hshForCode[item].title === undefined) {
        delete hshForCode[item];
      }
    });
    moduleStatic.forEach((item) => {
      hshForCode[item.route] = {
        title: item.title,
      };
    });
    res.json(hshForCode);
  } catch (error) {
    next(error);
  }
}

async function updateByModel(req, res) {
  try {
    let result;
    if (req.method === 'POST') {
      const { moduleCode, documentId, dataUpdate } = req.body;
      const Model = global.hshCollections[moduleCode];

      if (documentId) {
        const model = await Model.findById(documentId);
        if (model && dataUpdate) {
          const keys = Object.keys(dataUpdate);
          keys.forEach((e) => {
            model[e] = dataUpdate[e];
          });
        }
        result = await model.save();
      }
    }
    if (req.method === 'GET') {
      let { moduleCode, documentId, dataUpdate, conditionContent } = req.query;
      dataUpdate = convertToObj(conditionContent);
      const Model = global.hshCollections[moduleCode];
      if (Model === 'Customer') dataUpdate.isConfirm = true;

      if (documentId) {
        const model = await Model.findById(documentId);
        if (model.isConfirm === true) {
          return res.json({
            status: 0,
            message: 'Bạn không thể thao tác lại.',
          });
        }
        if (model && dataUpdate) {
          const keys = Object.keys(dataUpdate);
          keys.forEach((e) => {
            model[e] = dataUpdate[e];
          });
        }
        result = await model.save();
      }
    }
    if (result) {
      return res.json({ status: 1, message: 'success!' });
    } else {
      return res.json({ status: 0, message: 'Fail!' });
    }
  } catch (error) {
    return res.json({
      status: 0,
      message: error.message,
    });
  }
}

// async function changeConfirmationEmail(req, res) {
//   try {
//     const { preCode, statusConfirmation } = req.query;
//     if (statusConfirmation) {
//     }
//     return res.json({
//       status: 1,
//     });
//   } catch (error) {
//     return res.json({
//       status: 0,
//       message: error.message,
//     });
//   }
// }
module.exports = {
  getByIds,
  populate,
  setStatusFinishApprove,
  getAllModuleDynamic,
  list,
  getByFilter,
  getInfoById,
  getByFilterV2,
  updateByModel,
  getAllModuleDynamic4WorkFlow,
  // changeConfirmationEmail,
};
