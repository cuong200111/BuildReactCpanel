function convertToObj(input) {
  try {
    const obj = {};
    const arrs = input
      .replace('{', '')
      .replace('}', '')
      .split(',')
      .filter((e) => e !== '');
    arrs.forEach((e) => {
      const change = e.split('=');
      obj[change[0]] = change[1];
    });
    return obj;
  } catch (error) {
    console.log(error);
  }
}
module.exports = { convertToObj };
