// eslint-disable-next-line new-cap
const router = require('../../../node_modules/express').Router();
const commonCtrl = require('./common.controller');

router.route('/').get(commonCtrl.getByIds);
router.post('/approve/finish', commonCtrl.setStatusFinishApprove);
router.get('/module-dynamic', commonCtrl.getAllModuleDynamic);
router.route('/:model/:id').get(commonCtrl.populate);
router.route('/Kpi/:model/:id').get(commonCtrl.populate);
router.route('/getByFilter').post(commonCtrl.getByFilter);
router.route('/getByFilterV2').post(commonCtrl.getByFilterV2);
router.route('/list/:model/:username').get(commonCtrl.list);
router.route('/getInfoById').get(commonCtrl.getInfoById);
router.route('/updateInfo').post(commonCtrl.updateByModel).get(commonCtrl.updateByModel);
router.route('/module-dynamic-4-workflow').get(commonCtrl.getAllModuleDynamic4WorkFlow);
// router.route('/change-confirmation').post(commonCtrl.changeConfirmationEmail);

module.exports = router;
