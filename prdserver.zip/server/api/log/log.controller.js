/* eslint-disable consistent-return */
/* eslint-disable camelcase */
const Log = require('./log.model');

const APIError = require('../../helpers/APIError');
const httpStatus = require('http-status');
const STATUS = require('../../variables/CONST_STATUS').STATUS;

/**
 * Load log and append to req
 */
async function load(req, res, next, id) {
  // eslint-disable-next-line no-param-reassign
  req.log = await Log.findById(id);
  if (!req.log) {
    next(
        new APIError('Item not found', httpStatus.NOT_FOUND, true));
  }
  next();
}
/**
 * list log
 */
async function list(req, res, next) {
  try {
    const { limit = 500, skip = 0, filter } = req.query;
    const logs = await Log.list({ limit, skip, filter });
    res.json(logs);
  } catch (e) {
    next(e);
  }
}
/**
 * create log
 */
// eslint-disable-next-line consistent-return
async function create(req, res, next) {
  try {
        // eslint-disable-next-line max-len
    const {
      employee,
      model,
      objectId,
      type,
      content,
      meetingId,
    } = req.body;
    let rawFile = {
      employee,
      model,
      objectId,
      type,
      content,
    };
    if (meetingId) {
      rawFile = {
        ...rawFile,
        meetingId
      };
    }

    const log = new Log(rawFile);

    return log.save()
                    .then((savedlog) => {
                      if (savedlog) res.json(savedlog);
                      else res.transforemer.errorBadRequest('Can not create item');
                    })
      .catch((e) => {
        next(e);
      });
  } catch (e) {
    next(e);
  }
}
/**
 * update log
 */
// eslint-disable-next-line consistent-return
async function update(req, res, next) {
  try {
    const {
      employee,
      model,
      objectId,
      type,
      content,
    } = req.body;

    const log = req.log;
    log.employee = employee;
    log.objectId = objectId;
    log.content = content;
    log.type = type;
    log.model = model;


    return log.save().then(async (result) => {
      res.json(result);
    }).catch((err) => {
      next(err);
    });
  } catch (e) {
    next(e);
  }
}

/**
 * Delete costEstimate.
 * @returns log
 */
function del(req, res, next) {
  const log = req.log;
  log.status = STATUS.DELETED;

  log
  .save()
  .then((result) => {
    res.json({
      success: true,
      data: result,
    });
  }
  )
  .catch(e => next(e));
}

async function deletedList(req, res, next) {
  try {
    const { ids } = req.body;
    const arrDataDelete = ids.map(async (logId) => {
      const log = await Log.findById(logId);
      if (log) {
        log.status = STATUS.DELETED;
        return log.save();
      }
    });
    const deletedData = await Promise.all(arrDataDelete);
    res.json({
      success: true,
      data: deletedData,
    });
  } catch (e) {
    next(e);
  }
}
function get(req, res) {
  res.json(req.log);
}

module.exports = {
  list,
  load,
  create,
  update,
  del,
  get,
  deletedList
};
