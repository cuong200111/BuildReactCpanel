// eslint-disable-next-line new-cap
const router = require('../../../node_modules/express').Router();
const logCtrl = require('./log.controller');

router
    .route('/')
    .get(logCtrl.list)
    .post(logCtrl.create)
    .delete(logCtrl.deletedList);

router
    .route('/:logId')
    .get(logCtrl.get)
    .delete(logCtrl.del)
    .put(logCtrl.update);
router.param('logId', logCtrl.load);


module.exports = router;
