const DynamicCollection = require('./dynamic-collection.model');
const logger = require('winston');
const ApiError = require('../../helpers/APIError');
const httpStatus = require('http-status');

const dCollectionHelper = require('../../helpers/dynamic-collection');

/**
 * Load collection and append to req.
 */
function load(req, res, next, code) {
  DynamicCollection.getByCode(code)
  .then((dynamicCollection) => {
    if (!Object.prototype.hasOwnProperty.call(global.hshCollections, code)) {
      next(new ApiError('Not found collections', httpStatus.NOT_FOUND));
    }

    // eslint-disable-next-line no-param-reassign
    req.dynamicCollection = dynamicCollection;

    return next();
  })
  .catch((err) => {
    logger.error(err);
    next(err);
  });
}


// eslint-disable-next-line consistent-return
function create(req, res, next) {
  const dCollection = new DynamicCollection({
    ...req.body
  });


  let savedDoc;

  dCollection.save()
    .then((savedDCollection) => {
      savedDoc = savedDCollection;
      return dCollectionHelper.assignSchema(savedDCollection.code, savedDCollection);
    })
    .then(() => res.json(savedDoc))
    .catch(e => next(e));
}

/**
 * Update existing Dynamic Collection name or code
 *
 * @returns {DynamicCollection}
 */
function updateNameDCollection(req, res, next) {
  const dynamicCollection = req.dynamicCollection;
  // const updateData = req.body;

  // Object.keys(updateData).forEach((k) => {
  //   dynamicCollection[k] = updateData[k];
  // });

  const { name } = req.body;

  dynamicCollection.name = name;

  dynamicCollection.save()
        .then(savedDCollection => res.json(savedDCollection))
        .catch(e => next(e));
}

/**
 *
 * @param {*} req
 * @param {*} res
 */
function getDynamicCollection(req, res) {
  return res.json(req.dynamicCollection);
}


function updateSchema(req, res, next) {
  const dynamicCollection = req.dynamicCollection;

  dynamicCollection.collectionSchema = req.body;

  return dynamicCollection.save()
    .then((savedDCollection) => {
      res.json(savedDCollection);
      logger.info('[SERVER] Server restart due an update schema');
      process.exit();
    })
    .catch(e => next(e));
}

/**
 * Get user list.
 * @property {number} req.query.skip - Number of users to be skipped.
 * @property {number} req.query.limit - Limit number of users to be returned.
 * @returns {User[]}
 */
function list(req, res, next) {
  const { limit = 500, skip = 0 } = req.query;
  DynamicCollection.list({ limit, skip })
    .then(users => res.json(users))
    .catch(e => next(e));
}

/**
 * Delete user.
 * @returns {User}
 */
function removeDCollection(req, res, next) {
  const dynamicCollection = req.dynamicCollection;
  dynamicCollection.delete()
    .then((deletedDCollection) => {
      delete global.hshCollections[deletedDCollection.code];
      return res.json(deletedDCollection);
    })
    .catch(e => next(e));
}


module.exports = {
  load,
  list,
  create,
  updateNameDCollection,
  getDynamicCollection,
  removeDCollection,
  updateSchema
};
