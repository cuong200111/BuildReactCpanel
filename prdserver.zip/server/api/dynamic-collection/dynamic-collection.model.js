/* eslint-disable func-names */
const Promise = require('bluebird');
const mongoose = require('mongoose');
const httpStatus = require('http-status');
const CreatorSchema = require('../../helpers/creator-model').CreatorSchema;
const APIError = require('../../helpers/APIError');
const STATUS = require('../../variables/CONST_STATUS').STATUS;


/**
 * collection Schema
 */
const CollectionSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true
  },
  code: {
    type: String,
    index: true,
    unique: true
  },
  collectionSchema: {},
  // additionFields: [{
  //   from: { type: mongoose.Schema.Types.ObjectId },    // from: Attribute set ID
  //   isAttributeSet: Boolean,
  //   name: { type: String }
  // }],
  plugins: [{
    name: {
      type: String
    },
    code: {
      type: String
    },
    type: {
      type: String,
      default: ''
    },
    data: {},
    isActive: {
      type: Boolean,
      default: true
    },
    creatorInfo: CreatorSchema
  }],
  owner: mongoose.Schema.Types.ObjectId,
  creatorInfo: CreatorSchema,
  status: {
    type: Number,
    enum: [0, 1, 2, 3],
    default: 1
  }
});

/**
 * Add your
 * - pre-save hooks
 * - validations
 * - virtuals
 */

/**
 * Execute before each user save
 */

// // eslint-disable-next-line prefer-arrow-callback
CollectionSchema.pre('save', (next) => {
  next();
});


/**
 * Add your
 * - post-save hooks
 * - validations
 * - virtuals
 */

/**
 * Execute before each user save
 */

// eslint-disable-next-line prefer-arrow-callback
// CollectionSchema.post('save', function (doc) {
//   // send data to somewhere
// });


/**
 * Methods
 */
CollectionSchema.methods = {

  // /**
  //  *
  //  * @param {string} data data want to alert
  //  */
  delete() {
    this.status = STATUS.DELETED;
    return this.save()
      .then(deletedDCollection => deletedDCollection)
      .catch(e => Promise.reject(e));
  }
};

/**
 * Statics
 */
CollectionSchema.statics = {
  /**
   * Get collection
   * @param {ObjectId} id - The objectId of collection.
   * @returns {Promise<collection, APIError>}
   */
  get(id) {
    return this.findById(id)
      .exec()
      .then((collection) => {
        if (collection) {
          return collection;
        }
        const err = new APIError('No such collection exists!', httpStatus.NOT_FOUND);
        return Promise.reject(err);
      });
  },

  getByCode(code) {
    return this.findOne({
      code
    })
      .exec()
      .then((collection) => {
        if (collection) {
          return collection;
        }
        const err = new APIError('No such collection exists!', httpStatus.NOT_FOUND);
        return Promise.reject(err);
      });
  },

  /**
   * List collections in descending order of 'createdAt' timestamp.
   * @param {number} skip - Number of collections to be skipped.
   * @param {number} limit - Limit number of collections to be returned.
   * @returns {Promise<collection[]>}
   */
  list({
    skip = 0,
    limit = 500
  } = {}) {
    return this.find({
      status: 1
    })
      .sort({
        createdAt: -1
      })
      .skip(+skip)
      .limit(+limit)
      .exec();
  }
};

/**
 * @typedef DynamicCollection
 */
module.exports = mongoose.model('DynamicCollection', CollectionSchema);
