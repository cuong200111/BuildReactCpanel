const express = require('express');
const validate = require('express-validation');
const dynamicCollectionValidation = require('./dynamic-collection.validation');
const dynamicCollectionCtrl = require('./dynamic-collection.controller');

const router = express.Router(); // eslint-disable-line new-cap

router
  .route('/')
  /** GET /api/dynamic-collection - Get list of dynamicCollection */
  .get(dynamicCollectionCtrl.list)


  /** POST /api/dynamic-collection - Create new dynamicCollection defination */
  .post(validate(dynamicCollectionValidation.createDynamicCollection),
  dynamicCollectionCtrl.create);


router
  .route('/:collectionCode')
  /** PUT /api/dynamic-collection/:collectionCode - Update dynamicCollection */
  .put(dynamicCollectionCtrl.updateNameDCollection)

  /** GET /api/dynamic-collection/:collectionCode - Get list dynamicCollection */
  .get(dynamicCollectionCtrl.getDynamicCollection)

  /** GET /api/dynamic-collection/:collectionCode - Get list dynamicCollection */
  .delete(dynamicCollectionCtrl.removeDCollection)
  ;

router
  .route('/:collectionCode/schema')
  /** PUT /api/dynamic-collection/:collectionCode/schema - edit schema of dynamicCollection */
  .put(validate(dynamicCollectionValidation.updateDynamicCollectionSchema),
  dynamicCollectionCtrl.updateSchema);

/** PATCH /api/dynamic-collection/:collectionCode/schema/add - edit schema of dynamicCollection */
// router.route('/:collectionCode/schema/add').patch(dynamicCollectionCtrl.updateSchema);

/** PATCH /api/dynamic-collection/:collectionCode/schema/delete
 *  - delete schema of dynamicCollection */
// router.route('/:collectionCode/schema/add').patch(dynamicCollectionCtrl.updateSchema);

//   /** GET /api/dynamic-collection/:collectionCode - Get dynamicCollection */
//   .get(dynamicCollectionCtrl.get)

//   /** PUT /api/dynamic-collection/:collectionCode - Update dynamicCollection */
//   .put(validate(dynamicCollectionValidation.updateDynamicCollection),
// dynamicCollectionCtrl.update)

//   /** DELETE /api/dynamic-collection/:collectionCode - Delete dynamicCollection */
//   .delete(dynamicCollectionCtrl.remove);

// /** Load dynamicCollection when API with collectionCode route parameter is hit */
router.param('collectionCode', dynamicCollectionCtrl.load);

module.exports = router;
