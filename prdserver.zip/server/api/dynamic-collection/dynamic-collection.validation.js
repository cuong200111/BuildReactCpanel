const Joi = require('joi');
Joi.objectId = require('joi-objectid')(Joi);

module.exports = {
  // POST /api/users
  createDynamicCollection: {
    body: Joi.object({
      name: Joi.string().trim().required(),
      code: Joi.string().trim().required(),
      collectionSchema: Joi.object().required(),
      // additionFields: Joi.array().items(Joi.object({
      //   from: Joi.objectId(),
      //   isAttributeSet: Joi.boolean(),
      //   name: Joi.string()
      // })),
      plugins: Joi.array().items(Joi.object({
        id: Joi.objectId(),
        isActive: Joi.boolean()
      })),
      owner: Joi.objectId().allow(null)
    }).unknown(false)
  },

  // UPDATE /api/users/:userId
  updateDynamicCollectionSchema: {
    body: Joi.object().required(),
    params: {
      collectionCode: Joi.string().required()
    }
  }
};
