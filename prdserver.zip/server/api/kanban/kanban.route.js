const express = require('express');
const validate = require('express-validation');
const kanbanValidation = require('./kanban.validation');
const kanbanCtrl = require('./kanban.controller');

const router = express.Router(); // eslint-disable-line new-cap

router
  .route('/')
  /** GET /api/kanbans - Get list of kanbans */
  .get(kanbanCtrl.list)

  /** POST /api/kanbans - Create new kanban */
  .post(validate(kanbanValidation.createKanban), kanbanCtrl.create);

router
  .route('/:kanbanId')
  /** GET /api/kanbans/:kanbanId - Get kanban */
  .get(kanbanCtrl.get)

  /** PUT /api/kanbans/:kanbanId - Update kanban */
  .put(validate(kanbanValidation.updateKanban), kanbanCtrl.update)

  /** PÔST /api/kanbans/:kanbanId - Update kanban */
  .post(validate(kanbanValidation.addStateKanban), kanbanCtrl.addState)

  /** DELETE /api/kanbans/:kanbanId - Delete kanban */
  .delete(kanbanCtrl.remove);

/** Load kanban when API with kanbanId route parameter is hit */
router.param('kanbanId', kanbanCtrl.load);

module.exports = router;
