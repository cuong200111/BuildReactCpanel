const AbstractTransformer = require('d-transformer').AbstractTransformer;

/*  eslint-disable  */
class KanbanTransformer extends AbstractTransformer {
  transform(kanban) {
    return {
      id: kanban._id,
      table: kanban.table,
      states: kanban.states,
      transitions: kanban.transitions,
      display: kanban.display
    };
  }
}

module.exports = KanbanTransformer;
