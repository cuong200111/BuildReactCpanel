const Promise = require('bluebird');
const mongoose = require('mongoose');
const httpStatus = require('http-status');
const APIError = require('../../helpers/APIError');
const STATUS = require('../../variables/CONST_STATUS').STATUS;

const kanbanSchema = new mongoose.Schema({
  table: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Table',
    require: true
  },
  states: {
    type: [{
      code: {
        type: String,
        require: true
      },
      name: {
        type: String,
        require: true,
      },
      order: {
        type: Number,
        default: 0
      }
    }],
    default: [{
      code: 'INIT',
      name: 'Initialization',
      order: 0
    }]
  },
  transitions: {
    type: [{
      from: {
        type: String, // Code of states,
        required: true
      },
      to: {
        type: String, // Code of states or ALL
        required: true
      },
    }],
    default: [{
      from: 'INIT',
      to: 'ALL'
    }]
  },
  display: {
    type: [Number],
    required: true,
    default: [0, 1]
  },
  status: {
    type: Number,
    enum: [0, 1, 2, 3],
    default: 1
  }
}, {
  timestamps: true
});

/**
 * Statics
 */
kanbanSchema.statics = {
  /**
   * Get kanban
   *
   * @param {ObjectId} id - The objectId of kanban.
   * @returns {Promise<Kanban, APIError>}
   */
  get(id) {
    return this.findOne({
      _id: id,
      status: STATUS.ACTIVED
    })
      .exec()
      .then((kanban) => {
        if (kanban) {
          return kanban;
        }
        const err = new APIError('No such kanban exists!', httpStatus.NOT_FOUND);
        return Promise.reject(err);
      });
  },

  /**
   * List kanbans in descending order of 'createdAt' timestamp.
   *
   * @param {number} skip - Number of kanbans to be skipped.
   * @param {number} limit - Limit number of kanbans to be returned.
   * @returns {Promise<Kanban[]>}
   */
  list({
    skip = 0,
    limit = 500
  } = {}) {
    return this.find({
      status: 1
    })
      .sort({
        createdAt: -1
      })
      .skip(+skip)
      .limit(+limit)
      .exec();
  }
};

module.exports = mongoose.model('Kanban', kanbanSchema);
