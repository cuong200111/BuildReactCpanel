const Kanban = require('./kanban.model');
const STATUS = require('../../variables/CONST_STATUS').STATUS;
const KanbanTransformer = require('./kanban.transformer');
const httpStatus = require('http-status');

/**
 * Load kanban and append to req.
 *
 * @param {Request} req
 * @param {Response} res
 * @param {any} next
 * @param {ObjectId} id
 */
function load(req, res, next, id) {
  Kanban.get(id)
    .then((kanban) => {
      // eslint-disable-next-line no-param-reassign
      req.kanban = kanban;
      return next();
    })
    .catch(e => next(e));
}

/**
 * Get a Kanban
 *
 * @param {Request} req
 * @param {Response} res
 */
function get(req, res) {
  return res.transformer.item(req.kanban, new KanbanTransformer()).dispatch();
}

/**
 * Create a new Kanban
 *
 * @param {Request} req
 * @param {Response} res
 * @param {any} next
 * @property {string} req.body.table - The _id of table.
 * @property {string} req.body.states - The states of kanban.
 * @property {number} req.body.transitions - The transitions of kanban.
 * @property {number} req.body.display - The display of kanban.
 * @returns {Kanban}
 */
function create(req, res, next) {
  const kanban = new Kanban({
    table: req.body.table,
    display: req.body.display
  });

  // Add state
  const states = kanban.toObject().states;
  req.body.states.forEach((state) => {
    states.push(state);
  });
  kanban.states = states;

  // Add transitions
  const transitions = kanban.toObject().transitions;
  req.body.transitions.forEach((transition) => {
    transitions.push(transition);
  });
  kanban.transitions = transitions;

  kanban
    .save()
    .then(savedKanban => res.transformer
      .item(savedKanban, new KanbanTransformer()).dispatch())
    .catch(e => next(e));
}

/**
 * Update existing kanban
 * @param {Request} req
 * @param {Response} res
 * @param {any} next
 * @property {string} req.body.table - The _id of table.
 * @property {string} req.body.states - The states of kanban.
 * @property {number} req.body.transitions - The transitions of kanban.
 * @property {number} req.body.display - The display of kanban.
 * @returns {Kanban}
 * @returns {Kanban}
 */
function update(req, res, next) {
  const kanban = req.kanban;

  kanban.table = req.body.table;
  kanban.states = req.body.states;
  kanban.transitions = req.body.transitions;
  kanban.display = req.body.display;

  kanban
    .save()
    .then(savedKanban => res.transformer
      .item(savedKanban, new KanbanTransformer()).dispatch())
    .catch(e => next(e));
}

/**
 * Add a state to existing kanban
 * @returns {kanban}
 */
function addState(req, res, next) {
  const kanban = req.kanban;
  const states = kanban.toObject().states;

  states.push({
    code: req.body.code.trim(),
    name: req.body.name,
    order: req.body.order
  });

  kanban.states = states;

  kanban
    .save()
    .then(savedKanban => res.transformer
      .item(savedKanban, new KanbanTransformer()).dispatch())
    .catch(e => next(e));
}

/**
 * Get kanban list.
 * @property {number} req.query.skip - Number of kanbans to be skipped.
 * @property {number} req.query.limit - Limit number of kanbans to be returned.
 * @returns {Kanban[]}
 */
function list(req, res, next) {
  const {
    limit = 500, skip = 0
  } = req.query;
  Kanban.list({
    limit,
    skip
  })
    .then(kanbans => res.transformer
      .collection(kanbans, new KanbanTransformer()).dispatch())
    .catch(e => next(e));
}

/**
 * Delete kanban.
 * @returns {Kanban}
 */
function remove(req, res, next) {
  const kanban = req.kanban;
  kanban.status = STATUS.DELETED;

  kanban
    .save()
    .then(res.transformer
      .noContent()
      .withStatus(httpStatus.OK)
      .dispatch())
    .catch(e => next(e));
}

module.exports = {
  create,
  update,
  remove,
  load,
  list,
  get,
  addState
};
