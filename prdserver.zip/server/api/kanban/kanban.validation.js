const Joi = require('joi');

const validString = Joi.string().trim().min(5).required();

module.exports = {
  // POST /api/kanbans
  createKanban: {
    body: {
      table: Joi.string().trim().hex().required(),
      /* states: Joi.object().keys({
        code: Joi.string().trim().required(),
        name: Joi.string().trim().required(),
        order: Joi.number()
      }), */
      /* transitions: Joi.object().keys({
        from: Joi.string().trim().required(),
        to: Joi.string().trim().required()
      }) */
    }
  },

  // PUT /api/kanbans/:kanbanId
  updateKanban: {
    body: {
      table: Joi.string().trim().hex().required(),
      states: Joi.object().keys({
        code: validString,
        name: validString,
        order: Joi.number()
      }),
      transitions: Joi.object().keys({
        from: validString,
        to: validString
      })
    },
    params: {
      kanbanId: Joi.string().trim().hex().required()
    }
  },

  // POST /api/kanban/:kanbanId
  addStateKanban: {
    body: {
      code: Joi.string().trim().required(),
      name: Joi.string().trim().required(),
      order: Joi.number()
    },
    params: {
      kanbanId: Joi.string().trim().hex().required()
    }
  }
};
