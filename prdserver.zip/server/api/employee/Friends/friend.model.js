const mongoose = require('mongoose');

const friendSchema = new mongoose.Schema({
  receiver: {
    type: mongoose.Schema.Types.ObjectId,
    required: true,
    ref: 'Employee',
  },
  nameReceiver: {
    type: String,
    required: true
  },
  sender: {
    type: mongoose.Schema.Types.ObjectId,
    required: true,
    ref: 'Employee',
  },
  nameSender: {
    type: String,
    required: true
  },
  status: {
    type: Number,
    enum: [0, 1, 2, 3],
    default: 1,
  },
  relationship: {
    type: Boolean,
    default: false,
  },
  createdAt: {
    type: Date,
    default: new Date(),
  },
});

module.exports = mongoose.model('Friend', friendSchema);
