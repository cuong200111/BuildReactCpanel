const express = require('express');
const router = express.Router();
const employeeCtrl = require('./employee.controller');


router.route('/').post(employeeCtrl.checkDuplicateApp);

module.exports = router;
