const Joi = require('joi');

const validString = Joi.string()
  .trim()
  .min(5)
  .required();

module.exports = {
  createEmployee: {
    body: {
      code: validString,
      name: validString,
      email: Joi.string()
        .trim()
        .email({ minDomainAtoms: 2 })
        .required(),
      beginWork: Joi.date(),
      gender: Joi.string()
        .trim()
        .allow(['male', 'female', 'unknown']),
      user: Joi.required(),
    },
  },
  updateEmployee: {
    body: {
      code: validString,
      name: validString,
      email: Joi.string()
        .trim()
        .email({ minDomainAtoms: 2 })
        .required(),
      gender: Joi.string()
        .trim()
        .allow(['male', 'female', 'unknown']),
    },
    params: {
      employeeId: Joi.string()
        .trim()
        .hex()
        .required(),
    },
  },
  setUser: {
    body: {
      user: Joi.string()
        .trim()
        .hex()
        .required(),
    },
    params: {
      employeeId: Joi.string()
        .trim()
        .hex()
        .required(),
    },
  },
};
