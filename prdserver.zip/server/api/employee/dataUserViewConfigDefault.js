module.exports = [
  {
    username: `AdminEN_${process.env.CLIENT_ID}`,
    password: '12345678',
    name: `AdminEN_${process.env.CLIENT_ID}`,
    email: `AdminEN_${process.env.CLIENT_ID}@lifetek.vn`,
    code: `AdminEN_${process.env.CLIENT_ID}`,
    secret: 'lifetek$1901',
    clientId: process.env.CLIENT_ID,
    status: 0,
  },
  {
    username: `AdminVN_${process.env.CLIENT_ID}`,
    password: '12345678',
    name: `AdminVN_${process.env.CLIENT_ID}`,
    email: `AdminVN_${process.env.CLIENT_ID}@lifetek.vn`,
    code: `AdminVN_${process.env.CLIENT_ID}`,
    secret: 'lifetek$1901',
    clientId: process.env.CLIENT_ID,
    status: 0,
  },
];
