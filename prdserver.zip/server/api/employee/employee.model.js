/* eslint-disable consistent-return */
/* eslint-disable max-len */
const Promise = require('bluebird');
const mongoose = require('mongoose');
const httpStatus = require('http-status');
const APIError = require('../../helpers/APIError');
const STATUS = require('../../variables/CONST_STATUS').STATUS;

// const viewConfigInit = require('../viewConfig/viewConfig.controller');
// const ViewConfig = require('../viewConfig/viewConfig.model');
const dynamicSchema = require('../../helpers/dynamic-collection');
const modelHelper = require('../../helpers/model');
// const convertToFullTextSearch = require('../../helpers/convertToFullTextSearch');
const searchFullText = require('../../helpers/searchFullText');
const getTree = require('../../helpers/common').getTree;
const OrganizationUnit = require('../organizationUnit/organizationUnit.model');
const common = require('../../helpers/common');

// eslint-disable-next-line func-names
module.exports = function (title) {
  const code = 'Employee';
  const plugins = [];

  if (Object.prototype.hasOwnProperty.call(global.hshCollections, code)) {
    return global.hshCollections[code];
  }

  // eslint-disable-next-line func-names
  return (async function () {
    const employeeRaw = {
      user: {
        userId: String,

        accessToken: String,
        refreshToken: String,
        expiresIn: Number,
      },
      username: String,
      organizationUnit: {
        name: String,
        organizationUnitId: {
          type: mongoose.Schema.Types.ObjectId,
          ref: 'OrganizationUnit',
        },
      },
      workingOrganization: String,
      code: {
        type: String,
        required: true,

        index: {
          unique: true,
        },
      },
      name: {
        type: String,
        required: true,
      },
      email: {
        type: String,
        required: true,
      },
      beginWork: {
        type: Date,
      },
      gender: {
        type: String,
        enum: ['male', 'female', 'unknown'],
        default: 'unknown',
      },
      online: Boolean,
      lastActive: Date,
      userId: mongoose.Schema.Types.ObjectId,
      dob: Date,
      identityCardNumber: String,
      phoneNumber: String,
      address: String,
      note: String,
      positions: {},
      avatar: String,
      others: {},
      // type: {
      //   type: String,
      //   default: 1,
      // },
      type: [],
      status: {
        type: Number,
        enum: [0, 1, 2, 3],
        default: 1,
      },
      username_en: String,
      name_en: String,
      code_en: String,
      allowedDepartment: {},
      roleGroupSource: String,
      firstLogin: { type: Boolean, default: true },
      portalHrm: {
        type: Boolean,
        default: false,
      },
      sip_domain: String,
      sip_uri: String,
      sip_password: String,
      sip_active: String,
      admin: { type: Boolean, default: false },
      isChangePwdRequired: { type: Boolean, default: false },
      hasChangedPwd: { type: Boolean, default: false },
      expiredDate: Date,
      resourcePortalUser: { type: Boolean, default: false },
    };

    const dynamicParsed = modelHelper.parseRawModel(employeeRaw);
    const employeeSchema = new mongoose.Schema(dynamicParsed.schema);

    const listEn = ['name', 'code', 'username'];

    employeeSchema.pre('save', async function preSave(next) {
      try {
        global.io.emit('docUpdated', { moduleCode: code, data: this });

        listEn.forEach((field) => {
          if (this[field]) {
            this[`${field}_en`] = common.removeVietnameseTones(this[field]);
          }
        });
        return next();
      } catch (error) {
        return next();
      }
    });
    /**
     * Statics
     */
    employeeSchema.statics = {
      getListEn() {
        return listEn;
      },
      /**
       * Get employee
       * @param {ObjectId} id - The objectId of employee.
       * @returns {Promise<Employee, APIError>}
       */
      get(id) {
        return this.findOne({
          _id: id,
          status: STATUS.ACTIVED,
        })
          .exec()
          .then((employee) => {
            if (employee) {
              return employee;
            }
            const err = new APIError('No such employee exists!', httpStatus.NOT_FOUND);
            return Promise.reject(err);
          });
      },

      /**
       * List employees in descending order of 'createdAt' timestamp.
       * @param {number} skip - Number of employees to be skipped.
       * @param {number} limit - Limit number of employees to be returned.
       * @returns {Promise<Employee[]>}
       */
      async listBy({
        skip = 0,
        limit = 500,
        sort = {
          createdAt: -1,
        },
        filter = {},
        createdBy,
        selector,
        distinct,
      }) {
        /* eslint-disable no-param-reassign */
        filter.status = STATUS.ACTIVED;
        searchFullText(filter);
        // const filterRole = await common.filterRoleTask({ filter: filterOrg, createdBy, code });
        // if (distinct) {
        //   return this.distinct('_id', filterRole);
        // }
        const data = await this.find(filter, selector || '')
          .sort(sort)
          .skip(+skip)
          .limit(+limit)
          .exec();
        const count = await this.find(filter).count();
        return {
          data,
          count,
          limit,
          skip,
          filter,
        };
      },
      async findOneOrCreate(data) {
        // eslint-disable-next-line no-shadow
        const { username, code, name, email, accessToken, refreshToken, expiresIn, userId } = data;
        const employee = await this.model('Employee').findOne({
          username,
        });
        if (employee !== null) {
          // const viewconfigForEmployee = await ViewConfig.find({ owner: employee._id });
          // if (viewconfigForEmployee.length === 0) {
          //   await viewConfigInit.init({ owner: employee._id });
          // }
          const user = {
            accessToken,
            refreshToken,
            expiresIn,
          };
          employee.user = user;
          employee.userId = userId;
          return await employee.save();
        }
        const employeeSaved = await this.model('Employee', employeeSchema)({
          user: {
            accessToken,
            refreshToken,
            expiresIn,
          },
          username,
          code,
          name,
          email,
          userId,
        }).save();
        // await viewConfigInit.init({ owner: employeeSaved._id });
        return employeeSaved;
      },

      async getOrganization(employeeId) {
        try {
          const employee = await this.findOne({ _id: employeeId });
          const regex = new RegExp(`\\b${employee.organizationUnit.organizationUnitId}\\b`, 'i');
          const organizationUnit = await OrganizationUnit.find({ path: regex, status: STATUS.ACTIVED }).lean();
          if (!organizationUnit) {
            throw new Error('Tài khoản chưa thuộc phòng ban nào');
          }
          organizationUnit[0].parent = null;
          return {
            array: organizationUnit,
            tree: getTree(organizationUnit, organizationUnit),
          };
        } catch (error) {
          throw error;
        }
      },
      async getAllEmployeeIdsByOrganization(orgId) {
        try {
          const regex = new RegExp(`\\b${orgId}\\b`, 'i');
          const organizationUnit = await OrganizationUnit.find({ path: regex, status: STATUS.ACTIVED }).lean();
          const employees = await this.find({
            'organizationUnit.organizationUnitId': organizationUnit.map((org) => org._id),
            status: STATUS.ACTIVED,
          });
          return employees.map((e) => e._id);
        } catch (error) {
          throw error;
        }
      },
    };

    const schema = await dynamicSchema.addDynamicCollectionFromCode(dynamicParsed, employeeSchema, code, plugins);
    schema.index({ name: 'text' });

    // use default controller

    return dynamicSchema.addModelToCode(code, schema, title);
  })();
};
