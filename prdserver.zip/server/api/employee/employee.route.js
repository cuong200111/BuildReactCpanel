const express = require('express');
const validate = require('express-validation');
const employeeValidation = require('./employee.validation');
const employeeCtrl = require('./employee.controller');

const router = express.Router(); // eslint-disable-line new-cap

router
  .route('/')
  /** GET /api/employees - Get list of employees */
  .get(employeeCtrl.list)

  /** POST /api/employees - Create new employee */
  // .post(validate(employeeValidation.createEmployee), employeeCtrl.create);
  .delete(employeeCtrl.removeMany)
  .post(employeeCtrl.create);
router.route('/export').get(employeeCtrl.listExport);
router.route('/list-with-msg').get(employeeCtrl.listWithMsg);
router.route('/list-conversation').get(employeeCtrl.listWithMsgByEmployee);
router.route('/first-login').put(employeeCtrl.updateFirstLogin);
router
  .route('/script')
  /** GET /api/employees - Get list of employees */
  .get(employeeCtrl.script);
router
  .route('/profile')
  .get(employeeCtrl.getProfile)
  .patch(employeeCtrl.updateProfile);
router.route('/search').get(employeeCtrl.listSearch);
router.route('/get-by-username').get(employeeCtrl.getByUsername);

// Friend
router.route('/check-relationship')
      .get(employeeCtrl.checkRelationship);     // api check mối quan hệ
router.route('/friend/:employeeId')
      .post(employeeCtrl.addFriend)             // api gửi lời mời kết bạn
      .put(employeeCtrl.unfriend);              // hủy kết bạn
router.route('/friendreply')
      .get(employeeCtrl.getListAddFriend)       // lấy danh sách chờ trả lời kết bạn
      .post(employeeCtrl.replyAddFriend);       // trả lời lời mời kết bạn
router.route('/list-friend')
      .get(employeeCtrl.listFriend);            // lấy danh sách bạn bè
router.route('/invite-send')
      .get(employeeCtrl.inviteSends);           // danh sách những người đã gửi lời mời mời kết bạn
router.route('/remove-invitation/:idRemove')
      .post(employeeCtrl.removeInvitation);     // gỡ bỏ lời mời đã gửi

router
  .route('/:employeeId')
  /** GET /api/employees/:employeeId - Get employee */
  .get(employeeCtrl.get)

  /** PUT /api/employees/:employeeId - Update employee */
  .put(validate(employeeValidation.updateEmployee), employeeCtrl.update)

  /** PATCH /api/employees/:employeeId - Set user for employee */
  .patch(validate(employeeValidation.setUser), employeeCtrl.setUser)

  /** DELETE /api/employees/:employeeId - Delete employee */
  .delete(employeeCtrl.remove);

/** Load employee when API with employeeId route parameter is hit */
router.param('employeeId', employeeCtrl.load);

module.exports = router;
