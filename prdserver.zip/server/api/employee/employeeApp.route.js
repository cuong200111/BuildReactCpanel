const express = require('express');
const employeeAppCtrl = require('./employeeApp.controller');

// eslint-disable-next-line new-cap
const router = express.Router();

router.route('/')
  .post(employeeAppCtrl.create);

router.route('/check')
  .post(employeeAppCtrl.check);

router.route('/userId/:employeeId')
.get(employeeAppCtrl.getUserId);

module.exports = router;
