const AbstractTransformer = require('d-transformer').AbstractTransformer;

/*  eslint-disable  */
class EmployeeTransformer extends AbstractTransformer {
  transform(employee) {
    return {
      id: employee._id,
      organizationUnit: employee.organizationUnit,
      code: employee.code,
      name: employee.name,
      email: employee.email,
      beginWork: employee.beginWork,
      gender: employee.gender,
      identityCardNumber: employee.identityCardNumber,
      phoneNumber: employee.phoneNumber,
      address: employee.address,
      note: employee.note,
      positions: employee.positions,
      dob: employee.dob,
      status: employee.status,
    };
  }
}

module.exports = EmployeeTransformer;
