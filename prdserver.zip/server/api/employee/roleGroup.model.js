const mongoose = require('mongoose');
const conn = require('./appConn');

const roleGroupSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
    },
    code: String,
    clientId: String,
    description: String,
    applyEmployeeOrgToModuleOrg: {
      type: Boolean,
      default: false,
    },
    departments: {},
    order: Number,
    other: {},
    roles: [
      {
        titleFunction: {
          type: String,
          required: true,
        },
        codeModleFunction: {
          type: String,
          required: String,
        },
        clientId: {
          require: true,
          type: String,
        },
        mainRoute: String,
        methods: [
          {
            name: {
              type: String,
              enum: ['GET', 'PATCH', 'DELETE', 'PUT', 'POST', 'IMPORT', 'EXPORT', 'VIEWCONFIG'],
            },
            allow: Boolean,
          },
        ],
      },
    ],
  },
  {
    timestamps: true,
  },
);

module.exports = conn.model('RoleGroup', roleGroupSchema);
