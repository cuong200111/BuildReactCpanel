/* eslint-disable new-cap */
const Employee = require('./employee.model');
const dataUserViewConfigDefault = require('./dataUserViewConfigDefault');
const ENviewConfig = require('./EN_default_viewConfig_js');
const VNviewConfig = require('./VN_default_viewConfig');
const ViewConfig = require('../viewConfig/viewConfig.model');
const http = require('http');

async function createUser() {
  const employee1 = dataUserViewConfigDefault[0];
  const employee2 = dataUserViewConfigDefault[1];
  const findEmploy = await Employee().find({
    $or: [{ username: employee1.username }, { code: employee1.code }, { email: employee1.email }],
  });
  const findEmploy2 = await Employee().find({
    $or: [{ username: employee2.username }, { code: employee2.code }, { email: employee2.email }],
  });
  // console.log(findEmploy);
  if (findEmploy.length === 0 || !findEmploy) {
    await requestOauth(employee1);
  }
  if (findEmploy2.length === 0 || !findEmploy2) {
    await requestOauth(employee2);
  }
}

async function requestOauth(element) {
  const postData = JSON.stringify(element);
  const options = {
    hostname: '103.226.249.215',
    port: 1000,
    path: '/users/create',
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      accept: 'application/json',
    },
  };

  const req = http.request(options, (res) => {
    res.setEncoding('utf8');
    res.on('data', async (chunk) => {
      // console.log(typeof chunk);
      await handleResult(chunk);
      // console.log(`BODY: ${chunk}`);
    });
    res.on('end', () => {
      console.log('No more data in response.');
    });
  });

  req.on('error', (e) => {
    console.error(`problem with request: ${e.message}`);
  });
  req.write(postData);
  req.end();
}

async function handleResult(chunk) {
  try {
    const parseChunk = JSON.parse(chunk);
    if (Object.keys(chunk).length > 0) {
      for (let i = 0; i < dataUserViewConfigDefault.length; i++) {
        if (dataUserViewConfigDefault[i].username === parseChunk.username) {
          const employee = new Employee()({
            name: dataUserViewConfigDefault[i].name,
            username: dataUserViewConfigDefault[i].username,
            email: dataUserViewConfigDefault[i].email,
            code: dataUserViewConfigDefault[i].code,
            user: dataUserViewConfigDefault[i].user,
            beginWork: new Date().toISOString(),
          });
          const rsCreate = await employee.save();
          // console.log(rsCreate);
          if (rsCreate.username === `AdminEN_${process.env.CLIENT_ID}`) {
            await Promise.all(
              ENviewConfig.map((item) => {
                item['owner'] = rsCreate._id;
                // console.log(item);
                return new ViewConfig(item).save();
              }),
            );
          } else if (rsCreate.username === `AdminVN_${process.env.CLIENT_ID}`) {
            await Promise.all(
              VNviewConfig.map((item) => {
                item['owner'] = rsCreate._id;
                return new ViewConfig(item).save();
              }),
            );
          }
        }
      }
    }
  } catch (error) {
    throw error;
  }
}
async function orgEmployee(id) {
  try {
    const employee = await Employee().findById(id);
    if (!employee) {
      return null;
    }
    if (employee.workingOrganization) {
      return employee.workingOrganization;
    } else if (employee.organizationUnit && employee.organizationUnit.organizationUnitId) {
      return employee.organizationUnit.organizationUnitId;
    }
    return null;
  } catch (error) {
    console.log('orgEmployee:: ', error);
    throw error;
  }
}

const axios = require('axios');
async function removeUser(ids) {
  try {
    const URL = process.env.REMOVE_USER;
    if (URL) {
      const listId = await Employee().distinct('userId', { _id: ids });
      axios.delete(URL, {
        headers: {
          'Content-Type': 'application/json',
        },
        data: {
          listId
        }
      }).then(r => {
        return { success: true }
        // console.log('r:: ', r);
      });
    }
    return { success: false }
  } catch (error) {
    console.log('REMOVE_USER:: ', error);
    return { success: false }
  }
}
module.exports = { createUser, orgEmployee, removeUser };
