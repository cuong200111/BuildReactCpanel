/* eslint-disable consistent-return */
/* eslint-disable object-shorthand */
/* eslint-disable no-param-reassign */
const mongoose = require('mongoose');
const Employee = require('./employee.model')();
const http = require('http');
const STATUS = require('../../variables/CONST_STATUS').STATUS;
const EmployeeTransformer = require('./employee.transformer');
const OrganizationUnit = require('../organizationUnit/organizationUnit.model');
const ViewConfig = require('../viewConfig/viewConfig.model');
const dataUserViewConfigDefault = require('./dataUserViewConfigDefault');
const ENviewConfig = require('./EN_default_viewConfig_js');
const VNviewConfig = require('./VN_default_viewConfig');
const Conversation = require('../conversation/conversation.model');
const Message = require('../conversation/message.model');
const { Promise } = require('bluebird');
const axios = require('axios');
const common = require('../../helpers/common');
const _ = require('lodash');
const { removeUser } = require('./employee.service');
const Notification = require('../notification/notification.model');
const Friend = require('./Friends/friend.model');
const promise = require('bluebird/js/release/promise');
const { unknown } = require('joi/lib/types/object');
const moment = require('moment');
// const httpStatus = require('http-status');
// const viewConfigInit = require('../viewConfig/viewConfig.controller');
/**
 * Load user and append to req.
 */
function load(req, res, next, id) {
  Employee.get(id)
    .then((employee) => {
      // eslint-disable-next-line no-param-reassign
      req.employee = employee;
      return next();
    })
    .catch((e) => next(e));
}

/**
 * Get Employee
 * @returns {Employee}
 */
function get(req, res) {
  // return res.transformer.item(req.employee, new EmployeeTransformer()).dispatch();
  return res.json({
    status: 'success',
    data: req.employee,
  });
}

/**
 * Create new Employee
 *
 * @returns {Employee}
 */

async function create(req, res, next) {
  let avatar = req.body.avatar;
  let organizationUnit = req.body.organizationUnit;
  const currentEmployee = await Employee.findById(req.user.user);
  const session = await OrganizationUnit.findOne({ _id: currentEmployee.workingOrganization }, 'name').lean();

  if (avatar === '') {
    req.body.gender === 'male'
      ? (avatar = 'https://g.lifetek.vn:203/api/files/5f8684e931365b51d00afec6')
      : (avatar = 'https://g.lifetek.vn:203/api/files/5f86843131365b51d00afec5');
  }
  if (!organizationUnit) {
    organizationUnit = session._id;
  }

  c
  const findCodeEmp = Employee.find({ code: req.body.code, status: STATUS.ACTIVED });
  const findEmailEmp = Employee.find({ email: req.body.email, status: STATUS.ACTIVED });

  const rsfindCodeEmp = await findCodeEmp;
  const rsfindEmailEmp = await findEmailEmp;

  if (rsfindCodeEmp.length > 0) {
    return res.json({ status: 0, message: 'Mã nhân viên đã tồn tại !!!' });
  }
  if (rsfindEmailEmp.length > 0) {
    return res.json({ status: 0, message: 'Email đã tồn tại !!!' });
  }
  const employee = new Employee({
    organizationUnit: organizationUnit,
    code: req.body.code.trim(),
    name: req.body.name,
    gender: req.body.gender,
    email: req.body.email,
    beginWork: req.body.beginWork,
    identityCardNumber: req.body.identityCardNumber,
    phoneNumber: req.body.phoneNumber,
    address: req.body.address,
    note: req.body.note,
    positions: req.body.positions,
    avatar: avatar,
    dob: req.body.dob,
    user: req.body.user || undefined,
    userId: req.body.user,
    username: req.body.username,
    others: req.body.others,
    type: req.body.type,
    roleGroupSource: req.body.roleGroupSource,
    allowedDepartment: req.body.allowedDepartment,
    sip_domain: req.body.sip_domain,
    sip_uri: req.body.sip_uri,
    sip_password: req.body.sip_password,
    sip_active: req.body.sip_active,
    admin: req.body.admin,
    isChangePwdRequired: req.body.isChangePwdRequired,
    expiredDate: req.body.expiredDate,
  });
  try {
    const result = await employee.save();

    // console.log(req.body.userExtendViewConfig);
    const userExtendViewConfig = req.body.userExtendViewConfig;
    const userExtentViewconfigs = await ViewConfig.find({ owner: userExtendViewConfig }).lean();
    await Promise.all(
      userExtentViewconfigs.map((viewConfig) => {
        delete viewConfig._id;
        delete viewConfig.__v;
        return new ViewConfig({ ...viewConfig, owner: result._id }).save();
      }),
    );
    res.json(result);
  } catch (error) {
    console.log(`${error}`);
    next(error);
  }
}

/**
 * Update existing Employee
 *
 * @returns {Employee}
 */
function update(req, res, next) {
  const employee = req.employee;
  const preOrg = employee.organizationUnit ? employee.organizationUnit.organizationUnitId.toString() : '';
  const newOrg = req.body.organizationUnit ? req.body.organizationUnit.organizationUnitId.toString() : '';
  employee.organizationUnit = req.body.organizationUnit;
  employee.name = req.body.name;
  employee.email = req.body.email;
  employee.beginWork = req.body.beginWork;
  employee.gender = req.body.gender;
  employee.identityCardNumber = req.body.identityCardNumber;
  employee.phoneNumber = req.body.phoneNumber;
  employee.address = req.body.address;
  employee.note = req.body.note;
  employee.positions = req.body.positions;
  employee.avatar = req.body.avatar;
  employee.dob = req.body.dob;
  employee.user = req.body.user || undefined;
  employee.code = req.body.code;
  employee.others = req.body.others;
  employee.type = req.body.type;
  employee.sip_domain = req.body.sip_domain;
  employee.sip_uri = req.body.sip_uri;
  employee.sip_password = req.body.sip_password;
  employee.sip_active = req.body.sip_active;
  employee.allowedDepartment = req.body.allowedDepartment;
  employee.admin = req.body.admin;
  employee.isChangePwdRequired = req.body.isChangePwdRequired;
  employee.expiredDate = req.body.expiredDate;
  employee.resourcePortalUser = req.body.resourcePortalUser;
  employee.status = req.body.status;
  if (req.body.roleGroupSource) {
    employee.roleGroupSource = req.body.roleGroupSource;
    if (preOrg !== newOrg) {
      employee.firstLogin = true;
    }
  }
  employee
    .save()
    .then(async (savedEmployee) => {
      if (req.body.userExtendViewConfig && req.body.userExtendViewConfig != employee._id.toString()) {
        const userExtendViewConfig = req.body.userExtendViewConfig;

        if (userExtendViewConfig && userExtendViewConfig.trim() != '') {
          const currentViewConfigs = await ViewConfig.find({ owner: employee._id.toString() });
          const userExtentViewconfigs = await ViewConfig.find({ owner: userExtendViewConfig }).lean();

          if (currentViewConfigs && currentViewConfigs.length > 0) {
            await Promise.all(currentViewConfigs.map((viewConfig) => viewConfig.remove()));
          }

          if (userExtentViewconfigs && userExtentViewconfigs.length > 0) {
            await Promise.all(
              userExtentViewconfigs.map((viewConfig) => {
                delete viewConfig._id;
                delete viewConfig.__v;
                return new ViewConfig({ ...viewConfig, owner: savedEmployee._id }).save();
              }),
            );
          }
        }
      }

      res.json(savedEmployee);
    })
    .catch((e) => next(e));
}

/**
 * Get Employee list.
 * @property {number} req.query.skip - Number of Employees to be skipped.
 * @property {number} req.query.limit - Limit number of Employees to be returned.
 * @property {number} req.query.organizationUnitId - Limit number of Employees to be returned.
 * @returns {Employee[]}
 */
async function list(req, res, next) {
  // console.log(req.user.user);
  const { limit = 5000, skip = 0, filter = {}, sort } = req.query;
  // if (!Object.keys(filter).includes('organizationUnit.organizationUnitId')) {
  //   Employee.listBy({
  //     limit,
  //     skip,
  //     filter,
  //   })
  //     .then((employees) => res.json(employees))
  //     .catch((e) => next(e));
  // } else {
  //   try {
  //     const employees = [];
  //     await getEmployByOrganization(filter['organizationUnit.organizationUnitId'], employees);
  //     res.json({
  //       limit,
  //       skip,
  //       count: employees.length,
  //       data: employees.splice(skip, limit),
  //     });
  //   } catch (err) {
  //     next(err);
  //   }
  // }
  try {
    const selector = req.query.selector || '-user -allowedDepartment';
    const employees = await Employee.listBy({
      limit,
      skip,
      filter,
      sort,
      createdBy: req.user.user,
      selector,
    });
    return res.json(employees);
  } catch (error) {
    console.log(error);
    return next(error);
  }
}

async function listWithMsg(req, res, next) {
  const { limit = 5000, skip = 0, filter = {}, sort } = req.query;
  try {
    const selector = req.query.selector || '-user -allowedDepartment';
    const employees = await Employee.listBy({
      limit,
      skip,
      filter,
      sort,
      createdBy: req.user.user,
      selector,
    });
    const allIds = employees.data.map((epl) => epl._id.toString());
    const allConversation = await Conversation.find({ join: { $size: 2, $in: allIds } }).lean();
    const allNewestMessage = await Promise.all(
      allConversation.map((c) => Message.findOne({ conversation: c._id }).sort({ createdAt: -1 })),
    );
    employees.allMsg = allNewestMessage;
    employees.allConversation = allConversation;
    return res.json(employees);
  } catch (error) {
    console.log(error);
    return next(error);
  }
}

async function listWithMsgByEmployee(req, res, next) {
  try {
    const { limit = 5000, skip = 0, filter = {}, sort } = req.query;

    const query = { ...filter, join: req.user.user };
    if (filter.type) {
      query.type = filter.type;
    }
    if (filter.$expr) {
      query.$expr = filter.$expr;
    }

    // const allConversation = await Conversation.find(query)
    //   .skip(parseInt(skip))
    //   .limit(parseInt(limit))
    //   .sort({ updatedAt: -1 })
    //   .lean();
    const allConversation = await Conversation.list({ skip, limit, sort, filter: query });
    const arr = [];
    allConversation.data.forEach((item) => {
      arr.push(...item.join);
    });

    const employee = await Employee.find({ _id: { $in: arr } }).select('_id name avatar');

    const allNewestMessage = await Promise.all(
      allConversation.data.map((c) => Message.findOne({ conversation: c._id }).sort({ createdAt: -1 })),
    );
    return res.json({ allConversation, allNewestMessage, employee, filter: allConversation.filter, sort });
  } catch (error) {
    console.log(error);
    return next(error);
  }
}

async function listExport(req, res, next) {
  const { skip = 0, filter = {}, sort } = req.query;
  const limit = req.query.limit || 1000;
  const selector = req.query.selector || 'name organizationUnit address phoneNumber email birthDay gender code';
  try {
    const employees = await Employee.listBy({
      limit,
      skip,
      filter,
      sort,
      createdBy: req.user.user,
      selector,
    });
    employees.data = await common.buildNameMapping('Employee', employees.data);
    return res.send(JSON.stringify(employees));
  } catch (error) {
    console.log(error);
    return next(error);
  }
}
/**
 * Get Employee list.
 * @property {number} req.query.skip - Number of Employees to be skipped.
 * @property {number} req.query.limit - Limit number of Employees to be returned.
 * @property {number} req.query.organizationUnitId - Limit number of Employees to be returned.
 * @returns {Employee[]}
 */
async function listSearch(req, res, next) {
  try {
    const { limit = 5000, skip = 0, sort, filter } = req.query;
    const employees = await Employee.listBy({ limit, skip, sort, filter });
    res.json(employees);
  } catch (error) {
    next(error);
  }
}

/**
 * Get Employee by departmnet.
 * @property {number} req.query.organizationUnitId - Number of Employees to be skipped.
 * @returns {Employee[]}
 */
async function getEmployByOrganization(organizationUnitId, employees) {
  const employeesFind = await Employee.find({
    'organizationUnit.organizationUnitId': organizationUnitId,
    status: STATUS.ACTIVED,
  });
  const organizationUnits = await OrganizationUnit.find({
    status: STATUS.ACTIVED,
    parent: organizationUnitId,
  });
  employeesFind.forEach((item) => {
    employees.push(item);
  });

  if (organizationUnits.length !== 0) {
    for (let i = 0; i < organizationUnits.length; i += 1) {
      await getEmployByOrganization(organizationUnits[i]._id.toString(), employees);
    }
  }

  return employees;
}

function deleteHrmAI(data) {
  try {
    const apiAI = process.env.API_AI;
    if (apiAI) {
      return axios.post(`${apiAI}/delete`, data, { headers: { 'Content-type': 'application/json' } });
    }
  } catch (error) {
    console.log('deleteHrmAI: ' + error);
  }
}
/**
 * Delete Employee.
 * @returns {Employee}
 */
function remove(req, res, next) {
  const employee = req.employee;
  deleteHrmAI({ IDofPerson: employee._id });
  employee.status = STATUS.DELETED;
  // employee.code = '';
  employee
    .save()
    .then(async (result) => {
      await removeUser([result._id]);
      res.json({
        success: true,
        data: result,
      });
    })
    .catch((err) => {
      next(err);
    });
}

/**
 * Set user for Employee.
 * @returns {Employee}
 */
function setUser(req, res, next) {
  const employee = req.employee;
  employee.user = req.body.user;

  employee
    .save()
    .then((setEmployee) => res.transformer.item(setEmployee, new EmployeeTransformer()).dispatch())
    .catch((e) => next(e));
}
/**
 * Set user for Employee.
 * @returns {Employee}
 */
async function getByUsername(req, res, next) {
  try {
    const username = req.query.username;
    const user = await Employee.findOne({ username });
    if (!user) return res.json({ message: 'Không tìm thấy người dùng' })
    return res.json({ user })
  } catch (error) {
    next(error)
  }
};

async function getProfile(req, res, next) {
  const { user } = req.user;
  try {
    const employee = await Employee.findById(user).lean();
    employee.workingOrganization = await OrganizationUnit.findOne({ _id: employee.workingOrganization }, 'name').lean() || {};
    return res.json(employee);
  } catch (error) {
    return next(error);
  }
}
/**
 * Set user for Employee.
 * @returns {Employee}
 */
async function updateProfile(req, res, next) {
  try {
    // eslint-disable-next-line max-len
    const { avatar, name, email, gender, dob, identityCardNumber, phoneNumber, address, note, others } = req.body;
    const { user } = req.user;
    const employee = await Employee.findById(user);
    employee.name = name;
    employee.email = email;
    employee.gender = gender;
    employee.dob = dob;
    employee.identityCardNumber = identityCardNumber;
    employee.phoneNumber = phoneNumber;
    employee.note = note;
    employee.avatar = avatar;
    employee.address = address;
    employee.others = others;
    const employeeSaved = await employee.save();
    res.json({
      success: true,
      data: employeeSaved,
    });
  } catch (error) {
    next(error);
  }
}

async function createUser() {
  const employee1 = dataUserViewConfigDefault[0];
  const employee2 = dataUserViewConfigDefault[1];
  const findEmploy = await Employee.find({
    $or: [{ username: employee1.username }, { code: employee1.code }, { email: employee1.email }],
  });
  const findEmploy2 = await Employee.find({
    $or: [{ username: employee2.username }, { code: employee2.code }, { email: employee2.email }],
  });
  // console.log(findEmploy);
  if (findEmploy.length === 0 || !findEmploy) {
    await requestOauth(employee1);
  }
  if (findEmploy2.length === 0 || !findEmploy2) {
    await requestOauth(employee2);
  }
}

async function checkDuplicateApp(req, res, next) {
  try {
    const findCodeEmp = Employee.find({ code: req.body.code, status: STATUS.ACTIVED });
    const findEmailEmp = Employee.find({ email: req.body.email, status: STATUS.ACTIVED });

    const rsfindCodeHrm = await findCodeHrm;
    const rsfindEmailHrm = await findEmailHrm;
    const rsfindCodeEmp = await findCodeEmp;
    const rsfindEmailEmp = await findEmailEmp;

    if (rsfindCodeEmp.length > 0 || rsfindCodeHrm.length > 0) {
      return res.json({ status: 0, message: 'Mã nhân viên đã tồn tại !!!' });
    }
    if (rsfindEmailEmp.length > 0 || rsfindEmailHrm.length > 0) {
      return res.json({ status: 0, message: 'Email đã tồn tại !!!' });
    }
    res.json({ status: 1, message: '' });
  } catch (error) {
    console.log(error);
    next(error);
  }
}

function removeVietnameseTones(str) {
  if (!str || typeof str !== 'string') return str;
  str = str.replace(/à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ/g, 'a');
  str = str.replace(/è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ/g, 'e');
  str = str.replace(/ì|í|ị|ỉ|ĩ/g, 'i');
  str = str.replace(/ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ/g, 'o');
  str = str.replace(/ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ/g, 'u');
  str = str.replace(/ỳ|ý|ỵ|ỷ|ỹ/g, 'y');
  str = str.replace(/đ/g, 'd');
  str = str.replace(/À|Á|Ạ|Ả|Ã|Â|Ầ|Ấ|Ậ|Ẩ|Ẫ|Ă|Ằ|Ắ|Ặ|Ẳ|Ẵ/g, 'A');
  str = str.replace(/È|É|Ẹ|Ẻ|Ẽ|Ê|Ề|Ế|Ệ|Ể|Ễ/g, 'E');
  str = str.replace(/Ì|Í|Ị|Ỉ|Ĩ/g, 'I');
  str = str.replace(/Ò|Ó|Ọ|Ỏ|Õ|Ô|Ồ|Ố|Ộ|Ổ|Ỗ|Ơ|Ờ|Ớ|Ợ|Ở|Ỡ/g, 'O');
  str = str.replace(/Ù|Ú|Ụ|Ủ|Ũ|Ư|Ừ|Ứ|Ự|Ử|Ữ/g, 'U');
  str = str.replace(/Ỳ|Ý|Ỵ|Ỷ|Ỹ/g, 'Y');
  str = str.replace(/Đ/g, 'D');
  // Some system encode vietnamese combining accent as individual utf-8 characters
  // Một vài bộ encode coi các dấu mũ, dấu chữ như một kí tự riêng biệt nên thêm hai dòng này
  str = str.replace(/\u0300|\u0301|\u0303|\u0309|\u0323/g, ''); // ̀ ́ ̃ ̉ ̣  huyền, sắc, ngã, hỏi, nặng
  str = str.replace(/\u02C6|\u0306|\u031B/g, ''); // ˆ ̆ ̛  Â, Ê, Ă, Ơ, Ư
  // Remove extra spaces
  // Bỏ các khoảng trắng liền nhau
  str = str.replace(/ + /g, ' ');
  str = str.trim();
  // Remove punctuations
  // Bỏ dấu câu, kí tự đặc biệt
  // str = str.replace(/!|@|%|\^|\*|\(|\)|\+|\=|\<|\>|\?|\/|,|\.|\:|\;|\'|\"|\&|\#|\[|\]|~|\$|_|`|-|{|}|\||\\/g, ' ');
  // str = str.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
  // str = str.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
  return str.toLowerCase();
}

async function script(req, res, next) {
  try {
    const emp = await Employee.find({}, function (err, docs) {
      if (err) return res.json(err);
      if (docs) {
        docs.forEach((item) => {
          item['name_en'] = removeVietnameseTones(item.name);
          item['code_en'] = removeVietnameseTones(item.code);
          item['username_en'] = removeVietnameseTones(item.username);
          item.save();
        });
      }
    });
    return res.json(emp);
  } catch (error) {
    console.log(error);
  }
}

async function updateFirstLogin(req, res, next) {
  try {
    const { roleGroupSource } = req.body;
    await Employee.updateMany({ roleGroupSource }, { firstLogin: true });
    res.json({ status: 1, message: 'success' });
  } catch (error) {
    console.log(error);
    return res.json({ status: 0, message: error });
  }
}

const removeMany = async (req, res, next) => {
  try {
    const { ids } = req.body;
    await Employee.updateMany({ _id: { $in: ids } }, { status: STATUS.DELETED }, { new: true }, async (err) => {
      if (err) return res.json({ status: 0, message: 'Xóa không thành công' });
      await removeUser(ids);
      return res.json({ status: 1, message: 'Xóa thành công' });
    });
  } catch (error) {
    next(error);
  }
};

const createTest = async (req, res) => {
  try {
    // lay data de luu vao bang candidateLink
    // const data = req.body.data;
    const employee = new Employee({
      organizationUnit: req.body.organizationUnit,
      code: req.body.code.trim(),
      name: req.body.username,
      gender: req.body.gender,
      email: req.body.email,
      phoneNumber: req.body.phoneNumber,
      address: req.body.address,
    });

    const result = await employee.save();
    // console.log(result)
    // eslint-disable-next-line new-cap
    // luu vao candidateLink
    return res.json({
      status: 1,
      employee: result,
    });
  } catch (error) {
    return res.json({
      status: 0,
    });
  }
};

const addFriend = async (req, res) => {
  try {
    // id của người nhận
    const receiverId = req.params.employeeId;
    // người gửi
    const senderId = req.user.user;
    // người nhận
    const emp = await Employee.findById(receiverId);
    // người gửi
    const userSend = await Employee.findById(senderId);
    if (!emp) {
      return res.json({
        status: 0,
        message: 'Không có data.',
      });
    }
    // check đã gửi lời mời hay chưa
    const friend = await Friend.findOne({
      $or: [
        {
          receiver: receiverId,
          sender: senderId,
        },
        {
          receiver: senderId,
          sender: receiverId,
        },
      ],
    });
    if (friend) {
      return res.json({
        status: 0,
        message: 'Người này đã gửi lời mời rồi.',
      });
    }
    if (!friend) {
      const friendNew = new Friend({
        receiver: receiverId,
        nameReceiver: emp.name,
        sender: senderId,
        nameSender: userSend.name,
      });
      await friendNew.save();
    }
    return res.json({
      status: 1,
      message: 'Đã gửi lời mời kết bạn thành công.',
    });
  } catch (error) {
    return res.json({
      status: 0,
      message: error.message,
    });
  }
};

const replyAddFriend = async (req, res) => {
  try {
    const accept = req.body.accept;
    // người nhận được lời mời
    const receiverId = req.user.user;
    // người gửi lời mời
    const senderId = req.body.senderId;
    const friend = await Friend.findOne({
      $or: [
        { receiver: receiverId, sender: senderId, relationship: false },
        { receiver: senderId, sender: receiverId, relationship: false },
      ],
    });
    if (!friend) {
      return res.json({
        status: 0,
        message: 'Không tìm thấy người gửi lời mời.',
      });
    }
    if (!accept) {
      await friend.remove();
      return res.json({
        status: 1,
        message: 'Đã từ chối.',
      });
    }
    if (accept && friend) {
      // chuyển là bạn bè
      friend.relationship = true;
      await friend.save();
    }

    return res.json({
      status: 1,
      message: 'Đã chấp nhận lời mời.',
    });
  } catch (error) {
    return res.json({
      status: 0,
      message: error.message,
    });
  }
};

const getListAddFriend = async (req, res) => {
  try {
    // id của người nhận lời mời
    const receiverId = req.user.user;
    // lấy ra danh sách lời mời
    const inviteFriends = await Friend.find({
      status: STATUS.ACTIVED,
      receiver: receiverId,
      relationship: false,
    });
    // lấy danh sách người gửi
    const data = await Promise.all(
      inviteFriends.map(async (m) => {
        const emp = await Employee.findById(m.sender);
        const fri = {
          id: emp._id,
          name: emp.name,
          avatar: emp.avatar,
          username: m.username,
        };
        return fri;
      }),
    );
    return res.json({
      status: 1,
      data: data,
    });
  } catch (error) {
    return res.json({
      status: 0,
      message: error.message,
    });
  }
};
// lấy danh sách bạn bè
const listFriend = async (req, res) => {
  try {
    // id của Chủ tài khoản
    const receiverId = req.user.user;
    const id1 = await Friend.distinct('receiver', { sender: receiverId, relationship: true });
    const id2 = await Friend.distinct('sender', { receiver: receiverId, relationship: true });
    const idSearch = [...new Set([...id1, ...id2])];

    const friends = await Employee.find({ _id: { $in: idSearch } });
    // lấy danh sách bạn bè hiện có
    const data = await Promise.all(
      friends.map(async (m) => {
        const fri = {
          id: m._id,
          name: m.name,
          avatar: m.avatar,
          username: m.username,
        };
        return fri;
      }),
    );
    // trả ra kết quả
    return res.json({
      status: 1,
      count: data.length,
      data: data,
    });
  } catch (error) {
    return res.json({
      status: 0,
      message: error.message,
    });
  }
};
// hủy kết bạn
const unfriend = async (req, res) => {
  try {
    // id của người bị hủy kết bạn
    const idUnfriend = req.params.employeeId;
    // id của người hủy
    const user = req.user.user;

    const friend = await Friend.findOne({
      $or: [
        {
          receiver: idUnfriend,
          sender: user,
          relationship: true,
        },
        {
          receiver: user,
          sender: idUnfriend,
          relationship: true,
        },
      ],
    });
    if (friend) {
      await friend.remove();
    }
    return res.json({
      status: 1,
      message: 'Đã hủy kết bạn.',
    });
  } catch (error) {
    return res.json({
      status: 0,
      message: error.message,
    });
  }
};
// danh sách đã gửi lời mời
const inviteSends = async (req, res) => {
  try {
    // id của Chủ tài khoản
    const sendId = req.user.user;
    // danh sách Id của những người đã đc gửi lời mời
    const sendedIds = await Friend.distinct('receiver', { sender: sendId, relationship: false });

    const friends = await Employee.find({ _id: { $in: sendedIds } });
    // lấy danh sách bạn bè hiện có
    const data = await Promise.all(
      friends.map(async (m) => {
        const fri = {
          id: m._id,
          name: m.name,
          avatar: m.avatar,
          username: m.username,
        };
        return fri;
      }),
    );
    // trả ra kết quả
    return res.json({
      status: 1,
      count: data.length,
      data: data,
    });
  } catch (error) {
    return res.json({
      status: 0,
      message: error.message,
    });
  }
};

const checkRelationship = async (req, res) => {
  try {
    // id chủ tài khoản
    const userId = req.user.user;
    // id của người cần check mối quan hệ
    const checkerId = req.query.checkerId;
    if (userId === checkerId) {
      return res.json({
        status: 1,
        data: 'Itself',
      });
    }
    // mối quan hệ
    let isFriend = '';
    const friend = await Friend.findOne({
      $or: [
        {
          receiver: userId,
          sender: checkerId,
        },
        {
          receiver: checkerId,
          sender: userId,
        },
      ],
    });
    // chưa gửi lời mời hay chưa kết bạn
    if (!friend) {
      isFriend = 'No';
    }
    if (friend) {
      // đã gửi lời mời kết bạn
      if (
        friend.relationship === false &&
        friend.receiver.toString() === userId &&
        friend.sender.toString() === checkerId
      ) {
        isFriend = 'Reply';
      }
      if (
        friend.relationship === false &&
        friend.receiver.toString() === checkerId &&
        friend.sender.toString() === userId
      ) {
        isFriend = 'Wait';
      }
      // đã kết bạn
      if (friend.relationship === true) {
        isFriend = 'Yes';
      }
    }

    return res.json({
      status: 1,
      data: isFriend,
    });
  } catch (error) {
    return res.json({
      status: 0,
      message: error.message,
    });
  }
};
// gỡ bỏ lời mời đã gửi
const removeInvitation = async (req, res) => {
  try {
    // id của người muốn gỡ bỏ lời mời
    const idRemove = req.params.idRemove;
    // id của chủ tài khoản ( người muốn gỡ bỏ )
    const userId = req.user.user;
    const friend = await Friend.findOne({
      sender: userId,
      receiver: idRemove,
      relationship: false,
    });
    if (!friend) {
      return res.json({
        status: 0,
        message: 'Lời mời không tồn tại.',
      });
    }
    if (friend) {
      await friend.remove();
    }
    return res.json({
      status: 1,
      message: 'Đã gỡ lời mời.',
    });
  } catch (error) {
    return res.json({
      status: 0,
      message: error.message,
    });
  }
};
module.exports = {
  createUser,
  load,
  get,
  getByUsername,
  create,
  update,
  list,
  remove,
  setUser,
  getProfile,
  updateProfile,
  listSearch,
  getEmployByOrganization,
  checkDuplicateApp,
  script,
  listExport,
  listWithMsg,
  listWithMsgByEmployee,
  updateFirstLogin,
  removeMany,
  createTest,
  addFriend,
  replyAddFriend,
  getListAddFriend,
  listFriend,
  unfriend,
  inviteSends,
  checkRelationship,
  removeInvitation,
};
