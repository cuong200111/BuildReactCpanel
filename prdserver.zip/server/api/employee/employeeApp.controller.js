/* eslint-disable consistent-return */
const Employee = require('./employee.model')();
const tkTest = require('./tkTest.model');

// eslint-disable-next-line consistent-return
async function getUserId(req, res, next) {
  const emplId = req.params.employeeId;
  try {
    const employee = await Employee.findById(emplId).lean();
    return res.json({
      status: 'success',
      data: employee.userId,
    });
  } catch (error) {
    next(error);
  }
}

// eslint-disable-next-line consistent-return
async function create(req, res, next) {
  const { meetingId, password } = req.body;
  try {
    const user = await tkTest.findOne({ meetingId }).lean();
    if (user) {
      return res.json({
        status: 1,
        message: 'Cuộc họp đã tồn tại!'
      });
    }
    const data = new tkTest({ meetingId, password });
    await data.save();
    return res.json({
      status: 0,
      message: 'success'
    });
  } catch (error) {
    next(error);
  }
}

async function check(req, res, next) {
  const { meetingId, password } = req.body;
  try {
    const user = await tkTest.findOne({ meetingId }).lean();
    if (!user) {
      return res.json({
        status: 1,
        message: 'Tên cuộc họp không tồn tại!'
      });
    }
    if (user.password !== password) {
      return res.json({
        status: 1,
        message: 'Sai mật khẩu'
      });
    }
    return res.json({
      status: 0,
      message: 'success'
    });
  } catch (error) {
    next(error);
  }
}

module.exports = {
  getUserId,
  create,
  check,
};
