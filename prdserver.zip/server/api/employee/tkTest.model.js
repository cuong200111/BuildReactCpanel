const Promise = require('bluebird');
const mongoose = require('mongoose');
const httpStatus = require('http-status');
const APIError = require('../../helpers/APIError');
const STATUS = require('../../variables/CONST_STATUS').STATUS;
const convertToFullTextSearch = require('../../helpers/convertToFullTextSearch');
const tkTestSchema = new mongoose.Schema(
  {
    meetingId: String,
    password: String
  },
  {
    timestamps: true,
  },
);

/**
 * Statics
 */
tkTestSchema.statics = {
  /**
   * Get notification
   *
   * @param {ObjectId} id - The objectId of notification.
   * @returns {Promise<notification, APIError>}
   */
  get(id) {
    return this.findOne({
      _id: id,
      status: STATUS.ACTIVED,
    })
      .exec()
      .then((data) => {
        if (data) {
          return data;
        }
        const err = new APIError('No such notification exists!', httpStatus.NOT_FOUND);
        return Promise.reject(err);
      });
  },

  /**
   * List notifications in descending order of 'createdAt' timestamp.
   *
   * @param {number} skip - Number of notifications to be skipped.
   * @param {number} limit - Limit number of notifications to be returned.
   * @returns {Promise<notification[]>}
   */
  async list({
    skip = 0,
    limit = 500,
    sort = {
      createdAt: -1,
    },
    filter = {},
  }) {
    /* eslint-disable no-param-reassign */
    filter.status = STATUS.ACTIVED;
    convertToFullTextSearch(filter);

    const [data, count] = await Promise.all([
      this.find(filter)
        .sort(sort)
        .skip(+skip)
        .limit(+limit)
        .lean()
        .exec(),
      this.count(filter),
    ]);
    return {
      data,
      count,
      limit,
      skip,
    };
  },
};

module.exports = mongoose.model('taikhoantests', tkTestSchema);
