/* eslint-disable no-plusplus */
/* eslint-disable consistent-return */
const HRMSource = require('./hrmSource.model')();
const APIError = require('../../helpers/APIError');
const httpStatus = require('http-status');
const STATUS = require('../../variables/CONST_STATUS').STATUS;
const hrmSourceInit = require('./hrmSource.init');
/**
 * Load measureUnit and append to req
 */
const load = async (req, res, next, id) => {
  // eslint-disable-next-line no-param-reassign
  req.hrmSource = await HRMSource.findById(id);
  if (!req.hrmSource) {
    next(new APIError('Item not found', httpStatus.NOT_FOUND, true));
  }
  next();
};
/**
 * list measureUnit
 */
const list = async (req, res, next) => {
  try {
    await init();
    const hrmSource = await HRMSource.list({
      skip: req.query.page || 0,
      limit: req.query.perPage || 50,
    });
    res.json(hrmSource);

    // await init();
    // const { limit = 500, skip = 0, sort, filter } = req.query;
    // CRMSourcev.list({ limit, skip, sort, filter })
    //     .then((crmSource) => {
    //       res.json(crmSource);
    //     })
    // .catch(e => next(e));
  } catch (e) {
    next(e);
  }
};
async function init() {
  const dbHrmSources = await HRMSource.find();
  const newHrmSources = hrmSourceInit.hrmSource.filter(item => !dbHrmSources.find(dbS => dbS.code === item.code));
  if (newHrmSources.length) {
    await Promise.all(
      newHrmSources
        .map(item => ({ ...item, originalName: item.title, originalData: [...(item.data || [])], canDelete: false }))
        .map(item => new HRMSource(item).save()),
    );
  }
}
const get = (req, res) => {
  res.json(req.hrmSource);
};
const create = async (req, res, next) => {
  try {
    const { title, canDragDrop } = req.body;
    const dataCheck = await HRMSource.findOne({ title, status: 1 });
    if (dataCheck) {
      return res.json({
        status: 0,
        message: 'Tên kiểu loại đã được sử dụng',
      });
    }
    const hrmSource = new HRMSource({ title, canDragDrop });

    return hrmSource
      .save()
      .then((savedHrmSource) => {
        if (savedHrmSource) res.json(savedHrmSource);
        else res.transforemer.errorBadRequest('Can not create item');
      })
      .catch((e) => {
        next(e);
      });
  } catch (e) {
    next(e);
  }
};

const allArr = [];
let index = 0;
function checkChild(arr) {
  // eslint-disable-next-line no-plusplus
  for (let i = 0; i < arr.length; ++i) {
    // eslint-disable-next-line no-param-reassign
    arr[i].index = index;
    index += 1;
    allArr.push({
      index: arr[i].index,
      name: arr[i].name,
      value: arr[i].value,
    });
    if (arr[i].children) {
      checkChild(arr[i].children);
    }
  }
}
const update = async (req, res, next) => {
  try {
    const { title, data } = req.body;
    const hrmSource = req.hrmSource;
    const dataCheck = await HRMSource.find({ title, status: 1, _id: { $ne: hrmSource._id } });
    // console.log('dataCheck:', dataCheck);
    if (dataCheck && Array.isArray(dataCheck) && dataCheck.length > 0) {
      return res.json({
        status: 0,
        message: 'Tên kiểu loại đã được sử dụng',
      });
    }
    // const 0 = 0;
    // const hrmSource = req.hrmSource;
    hrmSource.title = title;
    if (Array.isArray(data)) {
      hrmSource.data = data;
    // eslint-disable-next-line no-plusplus
      for (let i = 0; i < data.length; ++i) {
        data[i].index = index;
        index += 1;
        allArr.push({
          index: data[i].index,
          name: data[i].name,
          value: data[i].value,
        });
        if (data[i].children) {
          checkChild(data[i].children);
        }
      }
    }

    return await hrmSource
      .save()
      .then(async (result) => {
        res.json(result);
      });
  } catch (e) {
    console.log('e', e);
    next(e);
  }
};
const del = async (req, res, next) => {
  try {
    const hrmSource = req.hrmSource;
    if (!hrmSource.canDelete) {
      return res.json({
        status: 0,
        message: 'Không thể xóa kiểu loại mặc định',
      });
    }
    hrmSource.status = STATUS.DELETED;
    hrmSource
      .save()
      .then((result) => {
        res.status(200).json({ status: 1, data: result });
      })
      .catch((e) => {
        next(e);
      });
  } catch (e) {
    next(e);
  }
};

const reset = async (req, res) => {
  try {
    await HRMSource.updateMany({ canDelete: true }, { status: STATUS.DELETED });
    const data = await HRMSource.find({ canDelete: false });
    if (data) {
      for (let i = 0; i < data.length; i++) {
        if (data[i].title !== data[i].originalName) {
          await HRMSource.updateOne({ _id: data[i]._id }, { title: data[i].originalName });
        }
      }
    }
    return res.json({ status: 1 });
  } catch (e) {
    return res.json({ status: 0, message: e.message });
  }
};

module.exports = {
  load,
  list,
  get,
  create,
  update,
  del,
  init,
  reset,
};
