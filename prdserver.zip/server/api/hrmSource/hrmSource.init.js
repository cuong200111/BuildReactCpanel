const hrmHistoryData = require('../../historyData/api/hrmSource/hrmSource.init');
const hrmSource = [
  {
    title: 'Trạng thái lao động',
    canDragDrop: false,
    canDelete: false,
    code: 'S01',
    data: [{ title: 'Đang làm việc', value: 'DLV' }, { title: 'Đã nghỉ hưu', value: 'DNH' }],
  },
  {
    title: 'Trạng thái hôn nhân',
    canDragDrop: false,
    canDelete: false,
    code: 'S02',
    data: [
      {
        title: 'Đã kết hôn',
        value: 'ĐKH',
      },
      {
        title: 'Độc thân',
        value: 'ĐT',
      },
    ],
  },
  {
    title: 'Loại hợp đồng',
    canDragDrop: false,
    canDelete: false,
    code: 'S03',
    data: [
      {
        title: 'Nhân viên chính thức',
        value: 'NVCT',
        cantDelete: true,
      },
      {
        title: 'Nhân viên thử việc',
        value: 'TVC',
        cantDelete: true,
      },
      {
        title: 'Học việc/Thực tập',
        value: 'HV',
        cantDelete: true,
      },
    ],
  },
  {
    title: 'Chức danh',
    canDragDrop: false,
    canDelete: false,
    code: 'S04',
    data: [
      { title: 'Giám đốc điều hành', value: 'GĐĐH' },
      { title: 'Giám đốc sản xuất', value: 'GĐSX' },
      { title: 'Phó giám đốc', value: 'PGĐ' },
      { title: 'Trợ lý Giám đốc', value: 'TLGĐ' },
      { title: 'Trưởng phòng', value: 'TP' },
      { title: 'Phó trưởng phòng', value: 'PTP' },
    ],
  },
  {
    title: 'Hệ đào tạo',
    canDragDrop: false,
    canDelete: false,
    code: 'S05',
  },
  {
    title: 'Ngành học',
    canDragDrop: false,
    canDelete: false,
    code: 'S06',
    data: []
  },
  {
    title: 'Trình độ',
    canDragDrop: false,
    canDelete: false,
    code: 'S07',
    data: [{ title: 'ĐH', value: 'ĐH' }, { title: 'CĐ', value: 'ĐH' }],
  },
  {
    title: 'Tin học',
    canDragDrop: false,
    canDelete: false,
    code: 'S08',
    data: []
  },
  {
    title: 'Ngoại ngữ 1',
    canDragDrop: false,
    canDelete: false,
    code: 'S09',
  },
  {
    title: 'Ngoại ngữ 2',
    canDragDrop: false,
    canDelete: false,
    code: 'S10',
  },
  {
    title: 'Dân tộc',
    canDragDrop: false,
    canDelete: false,
    code: 'S11',
    data: [
      { title: 'Dân tộc Thái', value: 'Thai' },
      { title: 'Dân tộc Nùng', value: 'Nung' },
      { title: 'Dân tộc Ê-đê', value: 'EDe' },
      { title: 'Dân tộc Kinh', value: 'Kinh' },
    ],
  },
  {
    title: 'Tôn giáo',
    canDragDrop: false,
    canDelete: false,
    code: 'S12',
    data: [],
  },
  {
    title: 'Đối tác',
    canDragDrop: false,
    code: 'S97',
    data: [],
  },
  {
    title: 'Hình thức khen thưởng',
    canDragDrop: false,
    code: 'S96',
    data: [],
  },
  {
    title: 'Hệ Đào Tạo',
    canDragDrop: false,
    code: 'S95',
    data: [],
  },
  {
    title: 'Hình thức đào tạo',
    canDragDrop: false,
    code: 'S94',
    data: [],
  },
  {
    title: 'Hồ sơ thủ tục',
    canDragDrop: false,
    code: 'S93',
    data: [],
  },
  {
    title: 'Loại Quyết Định',
    canDragDrop: false,
    code: 'S92',
    data: [],
  },
  {
    title: 'Lý do chuyển cán bộ',
    canDragDrop: false,
    code: 'S91',
    data: [],
  },
  {
    title: 'Lý do nghỉ việc',
    canDragDrop: false,
    code: 'S90',
    data: [],
  },
  {
    title: 'Ngoại ngữ',
    canDragDrop: false,
    code: 'S89',
    data: []
  },
  {
    title: 'Nguồn hồ sơ',
    canDragDrop: false,
    code: 'S88',
    data: []
  },
  {
    title: 'Quốc tịch',
    canDragDrop: false,
    code: 'S87',
    data: []
  },
  {
    title: 'Trạng thái',
    canDragDrop: false,
    code: 'S86',
    data: []
  },
  {
    title: 'Văn bằng',
    canDragDrop: false,
    code: 'S85',
    data: []
  },
  {
    title: 'Ca làm việc',
    canDragDrop: false,
    canDelete: false,
    code: 'S13',
    data: [
      { title: 'Sáng', value: '1234' },
      { title: 'Chiều', value: '2345' },
      { title: 'Tối', value: '567' },
      { title: 'Ca Hành Chính', value: 'CA001' },
    ],
  },
  {
    title: 'Trường tốt nghiệp',
    canDragDrop: false,
    canDelete: false,
    code: 'S14',
    data: []
  },
  {
    title: 'Nhóm máu',
    canDragDrop: false,
    canDelete: false,
    code: 'S15',
    data: [
      { title: 'nhóm máu O', value: 'O' },
      { title: 'nhóm máu A', value: 'A' },
      { title: 'nhóm máu B', value: 'B' },
    ],
  },
  {
    title: 'Chức vụ',
    canDragDrop: false,
    canDelete: false,
    code: 'S16',
    data: [
      {
        title: 'Giám đốc điều hành',
        value: 'gim-c-iu-hnh',
      },
      {
        title: 'Giám đốc sản xuất',
        value: 'gim-c-sn-xut',
      },
      {
        title: 'Phó giám đốc',
        value: 'ph-gim-c',
      },
      {
        title: 'Trợ lý Giám đốc',
        value: 'tr-l-gim-c',
      },
      {
        title: 'Trưởng phòng',
        value: 'trng-phng',
      },
      {
        title: 'Phó trưởng phòng',
        value: 'ph-trng-phng',
      },
      {
        title: 'Trưởng phòng lập trình',
        value: 'trng-phng-lp-trnh',
      },
      {
        title: 'Phó trưởng phòng lập trình',
        value: 'ph-trng-phng-lp-trnh',
      },
      {
        title: 'Trưởng nhóm kỹ thuật',
        value: 'trng-nhm-k-thut',
      },
      {
        title: 'Nhân viên',
        value: 'nhn-vin',
      },
      {
        title: 'Kế toán trưởng',
        value: 'k-ton-trng',
      },
      {
        title: 'Trưởng nhóm lập trình',
        value: 'trng-nhm-lp-trnh',
      },
      {
        title: 'Trưởng nhóm tài liệu và quản lý chất lượng',
        value: 'trng-nhm-ti-liu-v-qun-l-cht-lng',
      },
    ],
  },
  {
    title: 'Thời gian làm việc',
    canDragDrop: false,
    canDelete: false,
    code: 'S17',
  },
  {
    title: 'Mức kỷ luật',
    canDragDrop: false,
    canDelete: false,
    code: 'S18',
  },
  {
    title: 'Loại nghỉ phép',
    canDragDrop: false,
    canDelete: false,
    code: 'S19',
    data: [
      {
        title: 'Nghỉ phép',
        value: 'S19_NP',
        disableDelete: true,
      },
      {
        title: 'Nghỉ không phép',
        value: 'NKP',
        disableDelete: true,
      },
      {

        title: 'Xin đi muộn',
        value: 'XĐM',
        disableDelete: true,
      },
      {

        title: 'Xin về sớm',
        value: 'XVS',
        disableDelete: true,
      },
      {
        title: 'Làm Online',
        value: 'LOL001',
        disableDelete: true,
      },
      {
        title: 'Làm onsite',
        value: 'OS001',
        disableDelete: true,
      }
    ],
  },
  {
    title: 'Cách tính thời gian',
    canDragDrop: false,
    canDelete: false,
    code: 'S20',
    data: [
      {
        title: 'Vào đầu, ra cuối',
        value: 'theoca',
      }
    ]
  },
  {
    title: 'Độ tuổi',
    canDragDrop: false,
    canDelete: false,
    code: 'S21',
  },
  {
    title: 'Vị trí tuyển dụng',
    canDragDrop: false,
    canDelete: false,
    code: 'S30',
    data: [
      {
        title: 'Testter',
        index: 1,
        value: 'Testter',
      },
      {
        title: 'dev',
        index: 2,
        value: 'dev',
      },
    ],
  },
  {
    title: 'Kênh tuyển dụng',
    canDragDrop: false,
    canDelete: false,
    code: 'S31',
    data: [
      {
        title: 'Facebook',
        index: 1,
        value: 'FB',
      },
      {
        title: 'Trang tuyển dụng',
        index: 2,
        value: 'webTT',
      },
    ],
  },
  {
    title: 'Hình thức đào tạo',
    canDragDrop: false,
    canDelete: false,
    code: 'S32',
    data: [
      {
        title: 'Hình thức A',
        index: 1,
        value: 'HHA',
      },
    ],
  },
  {
    title: 'Trung tâm đào tạo',
    canDragDrop: false,
    canDelete: false,
    code: 'S33',
    data: [
      {
        title: 'Trung tâm A',
        index: 1,
        value: 'TTA',
      },
    ],
  },
  {
    title: 'Trạng thái Đào tạo',
    canDragDrop: false,
    canDelete: false,
    code: 'S34',
    data: [
      {
        title: 'Trung tâm A',
        index: 1,
        value: 'TTA',
      },
    ],
  },
  {
    title: 'Xếp loại đào tạo',
    canDragDrop: false,
    canDelete: false,
    code: 'S35',
    data: [
      {
        title: 'Trung tâm A',
        index: 1,
        value: 'TTA',
      },
    ],
  },
  {
    title: 'Chứng chỉ đào tạo',
    canDragDrop: false,
    canDelete: false,
    code: 'S36',
    data: [],
  },
  {
    title: 'Loại thời gian',
    canDragDrop: false,
    canDelete: false,
    code: 'S37',
    data: [],
  },
];
hrmSource.push(...hrmHistoryData.Source);
module.exports = {
  hrmSource,
};
