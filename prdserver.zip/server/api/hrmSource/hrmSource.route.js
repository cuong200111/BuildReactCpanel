// eslint-disable-next-line new-cap
const router = require('../../../node_modules/express').Router();
const HrmSourceCtrl = require('./hrmSource.controller');

router
  .route('/')
  .post(HrmSourceCtrl.create)
  .get(HrmSourceCtrl.list);

router
  .route('/:hrmSourceId')
  .put(HrmSourceCtrl.update)
  .delete(HrmSourceCtrl.del)
  .get(HrmSourceCtrl.get);

router.route('/reset').post(HrmSourceCtrl.reset);

router.param('hrmSourceId', HrmSourceCtrl.load);
module.exports = router;
