const Promise = require('../../../node_modules/bluebird/js/release/bluebird');
const mongoose = require('mongoose');
const httpStatus = require('http-status');
const APIError = require('../../helpers/APIError');
const STATUS = require('../../variables/CONST_STATUS').STATUS;

const dynamicSchema = require('../../helpers/dynamic-collection');
const modelHelper = require('../../helpers/model');

/**
 * crm-Source Schema
 */

// eslint-disable-next-line func-names
module.exports = function(title) {
  const code = 'HrmSource';
  const plugins = [];

  if (Object.prototype.hasOwnProperty.call(global.hshCollections, code)) {
    return global.hshCollections[code];
  }

  // eslint-disable-next-line func-names
  return (async function() {
    const hrmSourceRaw = {
      title: {
        type: String,
        required: true,
      },
      originalName: String,
      canDragDrop: {
        type: Boolean,
        default: true,
      },
      code: {
        type: String,
        default: null,
      },
      data: [
        {
          title: String,
          value: String,
          index: Number,
        },
      ],
      originalData: [],
      status: {
        type: Number,
        enum: [0, 1, 2, 3],
        default: 1,
      },
      canDelete: {
        type: Boolean,
        default: true,
      },
    };

    const dynamicParsed = modelHelper.parseRawModel(hrmSourceRaw);
    const hrmSourceSchema = new mongoose.Schema(dynamicParsed.schema);

    /**
     * Statics
     */
    hrmSourceSchema.statics = {
      /**
       * Get customer
       *
       * @param {ObjectId} id - The objectId of customer.
       * @returns {Promise<Customer, APIError>}
       */
      get(id) {
        return this.findOne({
          _id: id,
          status: STATUS.ACTIVED,
        })
          .exec()
          .then((customer) => {
            if (customer) {
              return customer;
            }
            const err = new APIError('No such customer exists!', httpStatus.NOT_FOUND);
            return Promise.reject(err);
          });
      },

      /**
       * List customers in descending order of 'createdAt' timestamp.
       *
       * @param {number} skip - Number of customers to be skipped.
       * @param {number} limit - Limit number of customers to be returned.
       * @returns {Promise<Customer[]>}
       */
      list({
        skip = 0,
        limit = 500,
        sort = {
          createdAt: -1,
        },
        filter = {
          status: 1,
        },
      }) {
        return this.find(filter)
          .sort(sort)
          .skip(+skip)
          .limit(+limit)
          .exec();
      },
    };

    const schema = await dynamicSchema.addDynamicCollectionFromCode(dynamicParsed, hrmSourceSchema, code, plugins);

    // use default controller

    return dynamicSchema.addModelToCode(code, schema, title);
  })();
};
