const Promise = require('bluebird');
const mongoose = require('mongoose');
const httpStatus = require('http-status');
const APIError = require('../../helpers/APIError');
const STATUS = require('../../variables/CONST_STATUS').STATUS;
const convertToFullTextSearch = require('../../helpers/convertToFullTextSearch');

const logSchema = new mongoose.Schema({
  employee: {
    employeeId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Employee'
    },
    name: String,
  },
  model: String,
  objectId: String,
  objectName: String,
  parentId: String,
  type: String, // call,comment,approve ,view
  content: String,
  rootId: String,
  status: {
    type: Number,
    enum: [0, 1, 2, 3],
    default: 1,
  },
}, {
  timestamps: true
});

/**
 * Statics
 */
logSchema.statics = {
  /**
   * Get log
   *
   * @param {ObjectId} id - The objectId of log.
   * @returns {Promise<log, APIError>}
   */
  get(id) {
    return this.findOne({
      _id: id,
      status: STATUS.ACTIVED
    })
      .exec()
      .then((log) => {
        if (log) {
          return log;
        }
        const err = new APIError('No such log exists!', httpStatus.NOT_FOUND);
        return Promise.reject(err);
      });
  },

  /**
   * List logs in descending order of 'createdAt' timestamp.
   *
   * @param {number} skip - Number of logs to be skipped.
   * @param {number} limit - Limit number of logs to be returned.
   * @returns {Promise<log[]>}
   */
  async list({
    skip = 0,
    limit = 500,
    sort = {
      createdAt: -1
    },
    filter = {
    }
  }) {
    filter.status = STATUS.ACTIVED;
    convertToFullTextSearch(filter);
    const data = await this.find(filter)
    .sort(sort)
    .skip(+skip)
    .limit(+limit)
    .exec();
    const count = await this.find(filter).count();
    return {
      data,
      count,
      limit,
      skip,
    };
  }
};

module.exports = mongoose.model('SourceLog', logSchema);
