/* eslint-disable consistent-return */
/* eslint-disable camelcase */
const Log = require('./log.model');
/**
 * Load log and append to req
 */
/**
 * list log
 */
async function list(req, res, next) {
  try {
    const { model, objectId } = req.query;
    const dbLog = await Log.findOne({ model, objectId });
    if (!dbLog) {
      return res.json([]);
    }
    if (!dbLog.rootId) return res.json([dbLog]);
    const listLogs = await Log.find({ rootId: dbLog.rootId });
    return res.json(listLogs);
  } catch (e) {
    next(e);
  }
}
/**
 * create log
 */
// eslint-disable-next-line consistent-return
async function create(req, res, next) {
  try {
    // eslint-disable-next-line max-len
    const { employee, model, objectId, type, content, rootId, objectName, parentId } = req.body;

    const log = await Log.create({
      // eslint-disable-next-line max-len
      employee,
      model,
      objectId,
      type,
      content,
      rootId,
      objectName,
      parentId
    });
    if (!rootId) {
      log.rootId = log._id;
      await log.save();
    }
    return res.json(log);
  } catch (e) {
    next(e);
  }
}

module.exports = {
  list,
  create,
};
