// eslint-disable-next-line new-cap
const router = require('../../../node_modules/express').Router();
const logCtrl = require('./log.controller');

router
    .route('/')
    .get(logCtrl.list)
    .post(logCtrl.create)

module.exports = router;
