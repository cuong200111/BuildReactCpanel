// const DATATYPES = require('../../variables/CONST_STATUS').DATATYPES;

const initView = [

];

module.exports = initView;
