const ViewConfig = require('./viewConfig.model');
const STATUS = require('../../variables/CONST_STATUS').STATUS;
const ViewConfigTransformer = require('./viewConfig.transformer');
const httpStatus = require('http-status');
const initViewConfig = require('./viewConfig.init');
const APIError = require('../../helpers/APIError');
const Employee = require('../employee/employee.model')();
/**
 * Load viewConfig and append to req.
 *
 * @param {Request} req
 * @param {Response} res
 * @param {any} next
 * @param {ObjectId} id
 */
function load(req, res, next, id) {
  ViewConfig.findById(id)
    .then((viewConfig) => {
      if (!viewConfig) {
        return next(new APIError('Not found view config', httpStatus.NOT_FOUND));
      }

      // eslint-disable-next-line no-param-reassign
      req.viewConfig = viewConfig;
      return next();
    })
    .catch((e) => next(e));
}

/**
 * Get a ViewConfig
 *
 * @param {Request} req
 * @param {Response} res
 */
function get(req, res) {
  return res.transformer.item(req.viewConfig, new ViewConfigTransformer()).dispatch();
}

/**
 * Create a new ViewConfig
 *
 * @param {Request} req
 * @param {Response} res
 * @param {any} next
 *
 * @returns {ViewConfig}
 */

function create(req, res, next) {
  const { owner, creator, code, path, displayer, listDisplay, editDisplay, filterField, filterFieldValue } = req.body;

  const viewConfig = new ViewConfig({
    owner,
    creator,
    code,
    path,
    displayer,
    listDisplay,
    editDisplay,
    filterField,
    filterFieldValue,
  });

  viewConfig
    .save()
    .then((savedViewConfig) => res.transformer.item(savedViewConfig, new ViewConfigTransformer()).dispatch())
    .catch((e) => next(e));
}

function init(data) {
  const { owner, creator } = data;
  const viewConfigs = initViewConfig.map((cuViewConfig) => {
    const { path, code, displayer, listDisplay, editDisplay } = cuViewConfig;

    const viewConfig = new ViewConfig({
      owner,
      creator,
      code,
      path,
      displayer,
      listDisplay,
      editDisplay,
    });
    return viewConfig.save();
  });
  return Promise.all(viewConfigs);
}

/**
 * Update existing viewConfig
 *
 * @returns {ViewConfig}
 */
async function update(req, res, next) {
  const viewConfig = req.viewConfig;

  // update a exist ViewConfig
  const { path, displayer, listDisplay, editDisplay, filterField, filterFieldValue } = req.body;

  const toSaveDoc = await updateOrCreateViewConfigByOwner(viewConfig, req.user);

  toSaveDoc.path = path || toSaveDoc.path;
  toSaveDoc.displayer = displayer || toSaveDoc.displayer;
  toSaveDoc.listDisplay = listDisplay || toSaveDoc.displayer;
  toSaveDoc.editDisplay = editDisplay || toSaveDoc.editDisplay;
  toSaveDoc.filterField = filterField;
  toSaveDoc.filterFieldValue = filterFieldValue;

  toSaveDoc
    .save()
    .then((savedViewConfig) => res.json(savedViewConfig))
    .catch((e) => {
      next(e);
    });
}

async function updateOrCreateViewConfigByOwner(viewConfig, user) {
  let toSaveDoc = viewConfig;

  if (!viewConfig.owner) {
    const obj = viewConfig.toObject();
    delete obj._id;
    delete obj.__v;
    toSaveDoc = new ViewConfig({
      ...obj,
      owner: user.user,
    });
  }

  return toSaveDoc;
}

/**
 * Get viewConfig list.
 * @property {number} req.query.skip - Number of viewConfigs to be skipped.
 * @property {number} req.query.limit - Limit number of viewConfigs to be returned.
 * @returns {ViewConfig[]}
 */
function list(req, res, next) {
  const { limit = 500, skip = 0 } = req.query;
  ViewConfig.list({
    limit,
    skip,
  })
    .then((viewConfigs) => res.transformer.collection(viewConfigs, new ViewConfigTransformer()).dispatch())
    .catch((e) => next(e));
}
/**
 * Get viewConfig list.
 * @property {number} req.query.skip - Number of viewConfigs to be skipped.
 * @property {number} req.query.limit - Limit number of viewConfigs to be returned.
 * @returns {ViewConfig[]}
 */
function getByUser(req, res, next) {
  const { user } = req.user;
  const or = [
    {
      owner: user,
    },
  ];
  if (global.product_config_type) {
    or.push({ owner: { $exists: false }, product_config_type: global.product_config_type });
  } else {
    or.push({ owner: { $exists: false } });
  }
  const filter = {
    $or: or,
  };
  ViewConfig.find(filter)
    .then((viewConfigs) => {
      if (viewConfigs !== null) {
        const retObj = {};
        viewConfigs.forEach((view) => {
          const code = view.code;
          if (!Object.prototype.hasOwnProperty.call(retObj, code)) {
            retObj[code] = view;
          } else if (view.owner) {
            retObj[code] = view;
          }
        });

        const ret = Object.keys(retObj).map((k) => retObj[k]);

        res.json(ret);
      } else {
        const error = new APIError('Not search view config ', 400, true);
        next(error);
      }
    })
    .catch((e) => next(e));
}
/**
 * Get viewConfig list.
 * @property {number} req.query.skip - Number of viewConfigs to be skipped.
 * @property {number} req.query.limit - Limit number of viewConfigs to be returned.
 * @returns {ViewConfig[]}
 */
function patchViewConfig(req, res, next) {
  const { user } = req.user;

  ViewConfig.find({
    owner: user,
  })
    .then(async (viewConfigs) => {
      const removeViewconfig = await Promise.all(viewConfigs.map((item) => item.remove()));
      res.json(removeViewconfig);
    })
    .catch((e) => next(e));
}

/**
 * Delete viewConfig.
 * @returns {ViewConfig}
 */
function remove(req, res, next) {
  const viewConfig = req.viewConfig;
  viewConfig.status = STATUS.DELETED;

  viewConfig
    .save()
    .then(
      res.transformer
        .noContent()
        .withStatus(httpStatus.OK)
        .dispatch(),
    )
    .catch((e) => next(e));
}

function addField(req, res, next) {
  const viewConfig = req.viewConfig;

  const toSaveDoc = updateOrCreateViewConfigByOwner(viewConfig, req.user);

  // init others array if it null
  if (!toSaveDoc.listDisplay.type.fields.type.others) {
    toSaveDoc.listDisplay.type.fields.type.others = [];
  }

  // init others array if it null
  if (!toSaveDoc.editDisplay.type.fields.type.others) {
    toSaveDoc.editDisplay.type.fields.type.others = [];
  }

  const { name, title, order, type } = req.body;
  const otherObj = {
    name,
    type,
    title,
    order,
    checked: true,
  };

  toSaveDoc.listDisplay.type.fields.type.others.push(otherObj);
  toSaveDoc.editDisplay.type.fields.type.others.push(otherObj);

  toSaveDoc
    .save()
    .then((savedViewConfig) => res.json(savedViewConfig))
    .catch((e) => {
      next(e);
    });
}

async function updateAllSystem(req, res, next) {
  try {
    const { path, code, displayer, listDisplay, editDisplay, filterField, filterFieldValue } = req.body;
    const hrmEmployee = await Employee.findById(req.user.user);
    if (!hrmEmployee) {
      return res.json({ status: 0, message: ' Không tìm thấy nhân viên' });
    }
    if (hrmEmployee.admin === false || !hrmEmployee.admin) {
      return res.json({ status: 0, message: ' Bạn không có quyền cập nhật toàn bộ hệ thống' });
    }

    const toSaveDoc = await ViewConfig.update(
      { path, code },
      { $set: { path, code, displayer, listDisplay, editDisplay, filterField, filterFieldValue } },
      { multi: true },
      (err, writeResult) => {
        if (err) {
          return res.status(400).json({ status: 0, message: 'Cập nhật thất bại' });
        }
        return res.status(200).json({ status: 1, message: 'Cập nhật thành công' });
      },
    );
    // toSaveDoc.path = path || toSaveDoc.path;
    // toSaveDoc.displayer = displayer || toSaveDoc.displayer;
    // toSaveDoc.listDisplay = listDisplay || toSaveDoc.displayer;
    // toSaveDoc.editDisplay = editDisplay || to  SaveDoc.editDisplay;
    // toSaveDoc.filterField = filterField;
    // toSaveDoc.filterFieldValue = filterFieldValue;
  } catch (error) {
    next(error);
  }
}

module.exports = {
  create,
  update,
  remove,
  load,
  list,
  get,
  init,
  getByUser,
  addField,
  patchViewConfig,
  updateAllSystem,
};
