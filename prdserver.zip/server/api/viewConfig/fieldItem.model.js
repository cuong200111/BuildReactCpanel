const mongoose = require('mongoose');
/**
 * FieldItem Schema
 */
const FieldItemSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
  title: {
    type: String,
  },
  checked: {
    type: Boolean,
    required: true,
    default: true,
  },
  order: {
    type: Number,
    required: true,
    default: 0,
  },
  type: {
    type: String,
    required: true,
    default: 'String'
  },
  isRequired: {
    type: Boolean,
    default: false,
  },
  isFilter: {
    type: Boolean,
    default: false,
  },
  isSort: {
    type: Boolean,
    default: false,
  }

});

/**
 * @typedef FieldItem
 */

module.exports = FieldItemSchema;
