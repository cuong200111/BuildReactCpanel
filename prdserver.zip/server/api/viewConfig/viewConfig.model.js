const Promise = require('bluebird');
const mongoose = require('mongoose');
const httpStatus = require('http-status');
const APIError = require('../../helpers/APIError');
const STATUS = require('../../variables/CONST_STATUS').STATUS;
const FieldItem = require('./fieldItem.model');

/**
 * ViewConfig Schema
 */
const ViewConfigSchema = new mongoose.Schema({
  // owner: {
  //   type: {
  //     type: {
  //       type: String,
  //       default: 'user'
  //     },
  //     ownerId: mongoose.Schema.Types.ObjectId
  //   }
  // },
  owner: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Employee',
    default: undefined
  },
  creator: mongoose.Schema.Types.ObjectId,
  code: {
    type: String,
    required: true
  },
  path: {
    type: String,
    required: true
  },
  displayer: {
    type: String,
    enum: ['web', 'api', 'mobile'],
    required: true
  },
  listDisplay: {
    type: {
      pageEntries: {
        type: Number,
        default: 5
      },
      search: {
        type: Boolean,
        default: true
      },
      filters: {
        type: Boolean,
        default: true
      },
      bulkActions: {
        type: Boolean,
        default: true
      },
      fields: {
        type: {
          columns: [FieldItem],
          others: [FieldItem],
          attributes: [FieldItem]
        }
      },
      actions: [{
        name: {
          type: String,
          required: true
        },
        path: String
      }]
    }
  },
  editDisplay: {
    type: {
      fields: {
        type: {
          columns: [FieldItem],
          others: [FieldItem],
          attributes: [FieldItem]
        }
      },
      actions: [{
        name: {
          type: String,
          required: true
        },
        path: String
      }]
    }
  },
  filterField: String,
  filterFieldValue: {},
  status: {
    type: Number,
    enum: [0, 1, 2, 3],
    default: 1
  }
}, {
  timestamps: true,
});


ViewConfigSchema.index({ owner: 1, code: 1 }, { unique: true });

/**
 * Add your
 * - pre-save hooks
 * - validations
 * - virtuals
 */

/**
 * Methods
 */
ViewConfigSchema.method({});

/**
 * Statics
 */
ViewConfigSchema.statics = {
  /**
   * Get viewConfig
   * @param {ObjectId} id - The objectId of viewConfig.
   * @returns {Promise<ViewConfig, APIError>}
   */
  get(code) {
    return this.findOne({
      code,
      status: STATUS.ACTIVED
    })
      .exec()
      .then((viewConfig) => {
        if (viewConfig) {
          return viewConfig;
        }
        const err = new APIError('No such viewConfig exists!', httpStatus.NOT_FOUND);
        return Promise.reject(err);
      });
  },

  /**
   * List viewConfigs in descending order of 'createdAt' timestamp.
   * @param {number} skip - Number of viewConfigs to be skipped.
   * @param {number} limit - Limit number of viewConfigs to be returned.
   * @returns {Promise<ViewConfig[]>}
   */
  list({
    skip = 0,
    limit = 500
  } = {}) {
    return this.find({
      status: STATUS.ACTIVED
    })
      .sort({
        createdAt: -1
      })
      .skip(+skip)
      .limit(+limit)
      .exec();
  },
};

/**
 * @typedef ViewConfig
 */
module.exports = mongoose.model('ViewConfig', ViewConfigSchema);
