const express = require('express');
const viewLayoutConfigCtrl = require('./viewConfig.controller');

const router = express.Router(); // eslint-disable-line new-cap

router
  .route('/')
  /** GET /api/viewLayoutConfigs - Get list of viewLayoutConfigs */
  .get(viewLayoutConfigCtrl.list)

  /** POST /api/viewLayoutConfigs - Create new viewLayoutConfig */
  .post(viewLayoutConfigCtrl.create);

router.route('/updateAllSystem').post(viewLayoutConfigCtrl.updateAllSystem);
router.get('/myconfig', viewLayoutConfigCtrl.getByUser);
router.patch('/myconfig', viewLayoutConfigCtrl.patchViewConfig);
router
  .route('/:viewLayoutConfigId')
  /** GET /api/viewLayoutConfigs/:viewLayoutConfigId - Get viewLayoutConfig */
  .get(viewLayoutConfigCtrl.get)

  /** PUT /api/viewLayoutConfigs/:viewLayoutConfigId - Update viewLayoutConfig */
  .put(viewLayoutConfigCtrl.update)

   /** DELETE /api/viewLayoutConfigs/:viewLayoutConfigId - Delete viewLayoutConfig */
  .delete(viewLayoutConfigCtrl.remove);
/** Load viewLayoutConfig when API with viewLayoutConfigId route parameter is hit */

router.route('/add-field/:viewLayoutConfigId')
  /** PATCH /api/viewLayoutConfigs/:viewLayoutConfigId - Add a field to others viewLayoutConfig */
  .patch(viewLayoutConfigCtrl.addField);


router.param('viewLayoutConfigId', viewLayoutConfigCtrl.load);

module.exports = router;
