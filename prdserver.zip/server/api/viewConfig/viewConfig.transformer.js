const AbstractTransformer = require('d-transformer').AbstractTransformer;

/*  eslint-disable  */
class ViewConfigTransformer extends AbstractTransformer {
  transform(viewConfig) {
    return {
      id: viewConfig._id,
      owner: viewConfig.owner,
      creator: viewConfig.creator,
      code: viewConfig.code,
      path: viewConfig.path,
      displayer: viewConfig.displayer,
      listDisplay: viewConfig.listDisplay,
      editDisplay: viewConfig.editDisplay
    };
  }
}

module.exports = ViewConfigTransformer;
