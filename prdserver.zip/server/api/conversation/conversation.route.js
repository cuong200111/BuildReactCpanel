const express = require('express');
// const validate = require('express-validation');
// eslint-disable-next-line import/newline-after-import
const validate = require('express-validation');
const conversationValidation = require('./conversation.validation');

const conversationCtl = require('./conversation.controller');

const router = express.Router(); // eslint-disable-line new-cap

router
  .route('/')
  /** GET /api/costEstimates - Get list of costEstimates */
  .get(conversationCtl.list)

  /** POST /api/costEstimates - Create new balesQuotation */
  .post(validate(conversationValidation.create), conversationCtl.create);

// jhj
router
  .route('/message/unRead')
  .get(conversationCtl.countUnreadMessages);
  router
  .route('/message/unreadConversation')
  .get(conversationCtl.countUnreadConversation);
router
  .route('/message/:conversation')
  /** GET /api/costEstimates/:costEstimate - Get balesQuotation */
  .get(conversationCtl.getMessages);
router
  .route('/message/removeMessage/:id')
  .delete(conversationCtl.removeMessage);
router
  .route('/message/editMessage/:id')
  .put(conversationCtl.editMessage);
router
  .route('/message/updateEmotion/:id')
  .put(conversationCtl.updateEmotion);
router
  .route('/check')
  /** GET /api/costEstimates/:costEstimate - Get balesQuotation */
  .get(conversationCtl.findByIdModule);
router
  .route('/:conversation')
  /** GET /api/costEstimates/:costEstimate - Get balesQuotation */
  .get(conversationCtl.get)
  /** PUT /api/costEstimates/:costEstimate - Update balesQuotation */
  .post(conversationCtl.createMessage);

/** DELETE /api/costEstimates/:costEstimate - Delete balesQuotation */
// .delete(deliveryCtrl.remove);

/** Load balesQuotation when API with costEstimate route parameter is hit */
router.param('conversation', conversationCtl.load);

module.exports = router;
