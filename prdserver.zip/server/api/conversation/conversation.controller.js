/* eslint-disable indent */
const Conversation = require('./conversation.model');
const Message = require('./message.model');
const STATUS = require('../../variables/CONST_STATUS').STATUS;
const ObjectId = require('mongoose').Types.ObjectId;

async function load(req, res, next, id) {
  Conversation.findById(id)
    .populate('join', 'name')
    .then((data) => {
      // eslint-disable-next-line no-param-reassign
      req.conversation = data;
      return next();
    })
    .catch((e) => next(e));
}

function get(req, res) {
  return res.json(req.conversation);
}

async function create(req, res, next) {
  // console.log('UERRR', req.body);
  try {
    const { join, type, name, moduleName, id } = req.body;
    if (type === 0) {
      const conversation = await Conversation.findOne({
        join: { $all: join.map((item) => Object(item)) },
        type: 0,
      });
      if (conversation) {
        return res.json({ success: true, data: conversation, mess: 'Ton tai cuoc tro chuyen ca nhan' });
      }
    }

    if (type === 1 && id && moduleName) {
      const conversation = await Conversation.findOne({
        id,
        moduleName,
      });
      if (conversation) {
        return res.json({ success: true, data: conversation, mess: 'Da ton tai cuoc tro chuyen nay' });
      }
    }
    const body = { join, type, name, moduleName, id };
    const data = new Conversation(body);
    const dataSaved = await data.save();
    // console.log("GGGGGGGGGGGGGGGGGGGGGGGGGGG",dataSaved);

    return res.json({ success: true, data: dataSaved });
  } catch (error) {
    return next(error);
  }
}

async function update(req, res, next) {
  try {
    const { name, join } = req.body;
    const conversation = req.conversation;
    if (conversation.type === 1) conversation.join = join;
    conversation.name = name;
    const data = await conversation.save();
    return res.json({ success: true, data });
  } catch (error) {
    return next(error);
  }
}

async function createMessage(req, res, next) {
  try {
    const { user } = req.user;
    const conversation = req.conversation;
    const { content } = req.body;
    const body = { content, conversation: conversation._id, user };
    body.read = user;
    const data = new Message(body);
    await Conversation.updateOne({ _id: conversation._id }, { updatedAt: new Date().toLocaleString('vi') });
    const dataSaved = await data.save();
    return res.json({ success: true, data: dataSaved });
  } catch (error) {
    console.log(error);
    return next(error);
  }
}

// eslint-disable-next-line consistent-return
async function getMessages(req, res, next) {
  try {
    const userId = ObjectId(req.user.user);
    const conversation = req.conversation;
    const { limit = 500, skip = 0, sort, filter = {} } = req.query;
    filter.conversation = conversation._id;
    const data = await Message.list({ limit, skip, sort, filter });
    //
    const unReadMessages = data.data.filter((item) => {
      return !item.read.includes(userId);
    });
    const messageArray = [];
    unReadMessages.forEach((item) => {
      item.read.push(userId);
      messageArray.push(item.save());
    });
    await Promise.all(messageArray);
    //
    res.json(data);
  } catch (error) {
    return next(error);
  }
}

async function countUnreadMessages(req, res, next) {
  try {
    const userId = ObjectId(req.user.user);
    const conversations = await Conversation.find({ join: userId }).lean();
    if (conversations) {
      const ids = conversations.map((item) => item._id);
      const count = await Message.countDocuments({
        conversation: { $in: ids },
        read: { $ne: userId },
        status: STATUS.ACTIVED,
      });
      return res.json({ status: 1, count });
    }
    return res.json({ status: 0, message: 'Không tìm thấy thông tin người dùng' });
  } catch (error) {
    next(error);
  }
}

async function countUnreadConversation(req, res, next) {
  try {
    const userId = ObjectId(req.user.user);
    const conversations = await Conversation.find({ join: userId }).lean();
    if (!conversations.length) {
      return res.json({ status: 0, message: 'Không tìm thấy thông tin người dùng' });
    }
    const ids = conversations.map((item) => item._id);
    const query = { conversation: { $in: ids }, read: { $ne: userId }, status: STATUS.ACTIVED };
    const [data, unreadConversation] = await Promise.all([
      Message.aggregate([
        { $match: query },
        {
          $group: {
            _id: '$conversation',
            count: { $sum: 1 },
          },
        },
      ]),
      Message.aggregate([{ $match: query }, { $group: { _id: '$conversation' } }, { $count: 'unreadConversation' }]),
    ]);
    return res.json({ data, unreadConversation });
  } catch (error) {
    next(error);
  }
}

function list(req, res, next) {
  const { user } = req.user;

  const { limit = 500, skip = 0, sort, filter = {} } = req.query;
  filter.join = { $in: [user] };
  // console.log("TTT",filter);
  Conversation.list({ limit, skip, sort, filter })
    .then((data) => res.json(data))
    .catch((e) => next(e));
}

function findByIdModule(req, res, next) {
  const { id, moduleName } = req.query;
  Conversation.findOne({ id, moduleName })
    .populate('join', 'name')
    .then((data) => {
      if (data) return res.json({ success: true, message: 'Da ton tai nhom' });
      return res.json({ success: false, message: 'Chua co nhom' });
    })
    .catch((e) => next(e));
}

async function editMessage(req, res, next) {
  try {
    const id = req.params.id;
    const userId = req.user.user;
    let { content } = req.body;
    const message = await Message.findById(id);

    if (!message) return res.json({ status: 0, message: 'Tin nhắn không tồn tại' });

    const diff_second = (Date.now() - message.createdAt.getTime()) / 1000;
    const messageTime = Number.parseInt(process.env.MESSAGE_TIME) || 600;
    if (diff_second > messageTime) return res.json({ status: 0, message: 'Vượt quá thời gian chỉnh sửa tin nhắn này' });

    if (message.user.toString() !== userId)
      return res.json({ status: 0, message: 'Bạn không có quyền sửa tin nhắn này' });

    if (content && message.user.toString() === userId) {
      message.history.push({ content: message.content });
      message.content = content;
      await message.save();
    }
    return res.json({ status: 1, message: 'Updated done' });
  } catch (error) {
    console.log('editMessage', error);
    next(error);
  }
}

async function updateEmotion(req, res, next) {
  try {
    const id = req.params.id;
    const userId = req.user.user;
    let { emotion } = req.body;
    const message = await Message.findById(id);

    if (!message) return res.json({ status: 0, message: 'Tin nhắn không tồn tại' });
    const checkArray = [null, 0, 1, 2, 3, 4, 5];
    if (emotion === undefined || !checkArray.includes(emotion)) {
      return res.json({ status: 0, message: 'Bày tỏ cảm xúc thất bại' });
    }

    let isEmployee = false;
    let emotionArrayLength = message.emotion.length;
    for (let i = 0; i < emotionArrayLength; i++) {
      if (message.emotion[i].userId.toString() === userId) {
        isEmployee = true;
        message.emotion[i].emotion = emotion;
        break;
      }
    }
    if (!isEmployee) {
      message.emotion.push({
        emotion,
        userId,
      });
    }
    await message.save();
    return res.json({ status: 1, message: 'Bạn đã bày tỏ cảm xúc cho tin nhắn này!' });
  } catch (error) {
    console.log('updateEmotion', error);
    next(error);
  }
}

async function removeMessage(req, res, next) {
  try {
    const id = req.params.id;
    if (id) {
      await Message.updateMany({ _id: { $in: id } }, { status: STATUS.DELETED }, { new: true }, (err) => {
        if (err) return res.status(400).json({ status: 0, message: 'Detete failed' });
        return res.status(200).json({ status: 1, message: 'Deleted done' });
      });
    }
  } catch (error) {
    return next(error);
  }
}
module.exports = {
  load,
  get,
  create,
  update,
  list,
  createMessage,
  getMessages,
  countUnreadMessages,
  countUnreadConversation,
  updateEmotion,
  editMessage,
  findByIdModule,
  removeMessage,
};
