const Promise = require('bluebird');
const mongoose = require('mongoose');
const httpStatus = require('http-status');
const APIError = require('../../helpers/APIError');
const STATUS = require('../../variables/CONST_STATUS').STATUS;
const convertToFullTextSearch = require('../../helpers/convertToFullTextSearch');

const messageSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Employee',
      required: true,
    },
    conversation: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Conversation',
      required: true,
    },
    content: {
      type: String,
    },
    read: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Employee',
      }
    ],
    history: [
      {
        content: String,
        updatedAt: {
          type: Date,
          default: Date.now()
        },
      }
    ],
    status: {
      type: Number,
      enum: [0, 1, 2, 3],
      default: 1,
    },
    emotion: [
      {
        emotion: {
          type: Number,
          enum: [0, 1, 2, 3, 4, 5, null],
        },
        userId: {
          type: mongoose.Schema.Types.ObjectId,
          ref: 'Employee',
        },
      }
    ],
    attachFile: [],
    toUser: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Employee'
      }
    ]
  },
  {
    timestamps: true,
  },
);

/**
 * Statics
 */
messageSchema.statics = {
  /**
   * Get notification
   *
   * @param {ObjectId} id - The objectId of notification.
   * @returns {Promise<notification, APIError>}
   */
  get(id) {
    return this.findOne({
      _id: id,
      status: STATUS.ACTIVED,
    })
      .exec()
      .then((data) => {
        if (data) {
          return data;
        }
        const err = new APIError('No such notification exists!', httpStatus.NOT_FOUND);
        return Promise.reject(err);
      });
  },

  /**
   * List notifications in descending order of 'createdAt' timestamp.
   *
   * @param {number} skip - Number of notifications to be skipped.
   * @param {number} limit - Limit number of notifications to be returned.
   * @returns {Promise<notification[]>}
   */
  async list({
    skip = 0,
    limit = 500,
    sort = {
      createdAt: 1,
    },
    filter = {},
  }) {
    /* eslint-disable no-param-reassign */
    filter.status = STATUS.ACTIVED;
    convertToFullTextSearch(filter);
    const data = await this.find(filter).populate('user', 'name avatar').populate('emotion.userId', 'name avatar')
      .sort(sort)
      .skip(+skip)
      .limit(+limit)
      .exec();
    const count = await this.find(filter).count();
    return {
      data,
      count,
      limit,
      skip,
    };
  },
};

messageSchema.index({ conversation: 1 });
module.exports = mongoose.model('Message', messageSchema);
