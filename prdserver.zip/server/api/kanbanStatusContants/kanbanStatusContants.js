const KANBAN_STATUS = {
  PREPARE: 1,
  IN_PROGRESS: 2,
  FINISH: 3,
  CLOSE: 4,
  PAUSE: 5,
  NOT_DO: 6,
};

module.exports = {
  KANBAN_STATUS,
  KANBAN_STATUS_WF: {
    [KANBAN_STATUS.PREPARE]: {
      kanbanStatus: KANBAN_STATUS.PREPARE,
      nextKanbans: [
        {
          kanbanStatus: KANBAN_STATUS.PREPARE,
        },
        {
          kanbanStatus: KANBAN_STATUS.IN_PROGRESS,
        },
        {
          kanbanStatus: KANBAN_STATUS.FINISH,
        },
        {
          kanbanStatus: KANBAN_STATUS.CLOSE,
        },
        {
          kanbanStatus: KANBAN_STATUS.PAUSE,
        },
        {
          kanbanStatus: KANBAN_STATUS.NOT_DO,
        },
      ],
    },
    [KANBAN_STATUS.IN_PROGRESS]: {
      kanbanStatus: KANBAN_STATUS.IN_PROGRESS,
      nextKanbans: [
        {
          kanbanStatus: KANBAN_STATUS.FINISH,
        },
        {
          kanbanStatus: KANBAN_STATUS.IN_PROGRESS,
        },
        {
          kanbanStatus: KANBAN_STATUS.CLOSE,
        },
        {
          kanbanStatus: KANBAN_STATUS.PAUSE,
        },
        {
          kanbanStatus: KANBAN_STATUS.NOT_DO,
        },
      ],
    },
    [KANBAN_STATUS.FINISH]: {
      kanbanStatus: KANBAN_STATUS.FINISH,
      nextKanbans: [
        {
          kanbanStatus: KANBAN_STATUS.FINISH,
        },
      ],
    },
    [KANBAN_STATUS.CLOSE]: {
      kanbanStatus: KANBAN_STATUS.CLOSE,
      nextKanbans: [
        {
          kanbanStatus: KANBAN_STATUS.CLOSE,
        },
      ],
    },
    [KANBAN_STATUS.PAUSE]: {
      kanbanStatus: KANBAN_STATUS.PAUSE,
      nextKanbans: [
        {
          kanbanStatus: KANBAN_STATUS.PAUSE,
        },
        {
          kanbanStatus: KANBAN_STATUS.IN_PROGRESS,
        },
        {
          kanbanStatus: KANBAN_STATUS.FINISH,
        },
        {
          kanbanStatus: KANBAN_STATUS.CLOSE,
        },
        {
          kanbanStatus: KANBAN_STATUS.NOT_DO,
        },
      ],
    },
    [KANBAN_STATUS.NOT_DO]: {
      kanbanStatus: KANBAN_STATUS.NOT_DO,
      nextKanbans: [
        {
          kanbanStatus: KANBAN_STATUS.NOT_DO,
        },
        {
          kanbanStatus: KANBAN_STATUS.IN_PROGRESS,
        },
        {
          kanbanStatus: KANBAN_STATUS.FINISH,
        },
        {
          kanbanStatus: KANBAN_STATUS.CLOSE,
        },
        {
          kanbanStatus: KANBAN_STATUS.PAUSE,
        },
      ],
    },
  },
};
