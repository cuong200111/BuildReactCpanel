const mongoose = require('mongoose');
const ApiError = require('../../helpers/APIError');
const _ = require('lodash');

const conn = mongoose.createConnection(
  `mongodb://${process.env.MONGO_OAUTH_USERNAME}:${process.env.MONGO_OAUTH_PASSWORD}@${process.env.MONGO_OAUTH_HOST}:${
    process.env.MONGO_OAUTH_PORT
  }/${process.env.MONGO_OAUTH}`,
);

const userSchema = new mongoose.Schema({
  name: String,
  email: {
    type: String,
    index: {
      unique: true,
    },
  },
  scopes: {
    type: String,
    default: 'user',
  },
  code: {
    required: true,
    type: String,
  },
  username: String,
});

userSchema.statics = {
  async createTemporaryIfNotExists(query, data) {
    const user = await this.model('User').findOne(query);
    if (user) throw new ApiError('Account already exists', 400, true);

    return this.model('User', userSchema)(data);
  },
  /**
   * List businessOpportunitiess in descending order of 'createdAt' timestamp.
   *
   * @param {number} skip - Number of businessOpportunitiess to be skipped.
   * @param {number} limit - Limit number of businessOpportunitiess to be returned.
   * @returns {Promise<BusinessOpportunities[]>}
   */
  async list({
    skip = 0,
    limit = 500,
    sort = {
      createdAt: -1,
    },
    filter = {},
  }) {
    /* eslint-disable no-param-reassign */
    const data = await this.find(filter)
      .sort(sort)
      .skip(+skip)
      .limit(+limit)
      .exec();
    const count = await this.find(filter).count();
    return {
      data,
      count,
      limit,
      skip,
    };
  },
};

userSchema.methods = {
  async updateSafe(data) {
    const validFields = ['name', 'email', 'mobileNumber', 'code', 'gender', 'dob', 'idCard', 'address'];
    const [userByEmail, userByCode] = await Promise.all([
      data.email ? this.model('User').findOne({ email: data.email }) : null,
      data.code ? this.model('User').findOne({ code: data.code }) : null,
    ]);
    if (userByEmail) throw new ApiError('Email duplicated', 400, true);
    if (userByCode) throw new ApiError('Code duplicated', 400, true);

    const cleanData = _.pickBy(data, (value, key) => _.includes(validFields, key));

    _.forEach(cleanData, (value, key) => {
      this.set(key, value);
    });

    await this.save();
  },
};

// module.exports = mongoose.model('User', userSchema);
module.exports = conn.model('User', userSchema);
