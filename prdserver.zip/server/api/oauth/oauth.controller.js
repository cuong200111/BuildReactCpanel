// const axios = require('axios').default.create({
//   headers: {
//     'content-type': 'application/x-www-form-urlencoded;charset=utf-8',
//   },
// });
const qs = require('querystring');
const config = require('config');
const jwt = require('jsonwebtoken');
const httpStatus = require('http-status');

const Employee = require('../employee/employee.model')();
const ApiError = require('../../helpers/APIError');
const TokenTransformer = require('./token.transformer');
const STATUS = require('../../variables/CONST_STATUS').STATUS;
const common = require('../../helpers/common');
const roleTask = require('../roleTask/role.model');
const axios = require('axios');
const LoginLog = require('../loginLog/loginLog.model')();
const OrganizationUnit = require('../organizationUnit/organizationUnit.model');
const moment = require('moment');

async function createList(data) {
  const reponse = await axios.post(
    config.get('oauth.createList'),
    JSON.stringify({ secret: config.get('oauth.clientSecret'), data }),
  );
  return reponse;
}

const callback = async (req, res, next) => {
  try {
    const { code } = req.query;
    if (code) {
      let responseData = await axios.post(
        config.get('oauth.tokenUrl'),
        qs.stringify({
          code,
          grant_type: 'authorization_code',
          redirect_uri: config.get('oauth.redirectUri'),
        }),
        {
          auth: {
            username: config.get('oauth.clientId'),
            password: config.get('oauth.clientSecret'),
          },
        },
      );
      const { access_token, refresh_token, expires_in } = responseData.data;
      responseData = await axios.get(`${config.get('oauth.resourceUrl')}`, {
        headers: {
          Authorization: `Bearer ${access_token}`, // eslint-disable-line
        },
      });
      const { name, email, username } = responseData.data.data.user;
      if (!email) throw new ApiError('User Not Found', 400, true);
      const employee = await Employee.findOneOrCreate({
        name,
        username,
        email,
        code: responseData.data.data.user.code,
        accessToken: access_token,
        refreshToken: refresh_token,
        expiresIn: expires_in,
        userId: responseData.data.data.user.userId,
      });
      const expiredDate = moment(employee.expiredDate).toDate();
      const toDay = moment().toDate();
      // console.log(222222, "expiredDate", expiredDate, 111, "toDay", toDay, expiredDate <= toDay);
      if (employee.expiredDate && expiredDate <= toDay) {
        return res.status(400).json({ success: false, msg: 'Bạn đã hết hạn đăng nhập' });
      }
      if (!employee.roleGroupSource && `${employee.code}App` === `Admin${process.env.CLIENT_ID}`) {
        await Employee.updateOne({ _id: employee._id }, { roleGroupSource: 'Admin' });
        employee.roleGroupSource = 'Admin';
      }
      if (employee.status === STATUS.NOT_ACTIVED) {
        return next(new ApiError('User is not active', httpStatus.UNAUTHORIZED, true));
      }
      if (employee.status === STATUS.LOCKED) {
        return next(new ApiError('User is locked', httpStatus.UNAUTHORIZED, true));
      }
      if (employee.status === STATUS.DELETED) {
        return next(new ApiError('Username and password is wrong', httpStatus.UNAUTHORIZED, true));
      }
      const [findemp, foundOrg] = await Promise.all([
        Employee.findOne({ username, status: STATUS.ACTIVED }),
        OrganizationUnit.findOne({ status: STATUS.ACTIVED }),
      ]);
      if ((!findemp.organizationUnit || !findemp.organizationUnit.organizationUnitId) && !foundOrg) {
        console.log('1');
        const clientId = process.env.CLIENT_ID;
        const newOrg = await OrganizationUnit.create({
          name: clientId,
          code: clientId,
          type: 'company',
          parent: null,
          priority: 0,
          oUFunction: '',
          duty: '',
          note: '',
          accountingDepartmentCode: '',
          path: '',
          status: 1,
        });

        newOrg.path = newOrg._id;
        findemp.organizationUnit = {
          name: clientId,
          organizationUnitId: newOrg._id,
        };
        findemp.workingOrganization = newOrg._id;
        await newOrg.save();
        await findemp.save();
      } else if (findemp.organizationUnit && findemp.organizationUnit.organizationUnitId) {
        const clientId = process.env.CLIENT_ID;
        findemp.organizationUnit = {
          name: clientId,
          organizationUnitId: findemp.organizationUnit.organizationUnitId,
        };
      }

      if (findemp.firstLogin && findemp.roleGroupSource) {
        const checkRoles = await common.existRoleGroupCode(findemp.roleGroupSource, findemp.organizationUnit);
        if (!checkRoles) {
          return next(new ApiError('Role Group not found', httpStatus.UNAUTHORIZED, true));
        }
        await Promise.all([
          createOrUpdateRoles(employee._id, checkRoles.listRoles),
          updateRole(employee.userId, checkRoles.foundRoleGroup),
          Employee.updateOne({ _id: findemp._id }, { firstLogin: false }),
        ]);
      } else {
        await Employee.updateOne({ _id: findemp._id }, { firstLogin: false });
      }
      const token = jwt.sign(
        {
          user: employee._id,
        },
        config.get('local.jwtSecret'),
        {
          expiresIn: 12000000,
        },
      );
      // console.log(employee);
      LoginLog.create({
        ip: req.headers ? req.headers['x-real-ip'] : '',
        username,
        status: 1,
        loginTime: new Date(),
        employeeId: employee._id,
        organizationUnitId:
          employee.organizationUnit && employee.organizationUnit.organizationUnitId
            ? employee.organizationUnit.organizationUnitId
            : null,
        token,
      });
      return res.transformer.item(token, new TokenTransformer()).dispatch();
    }
    return res.transformer.errorUnauthorized('Invalid Authorization Code');
  } catch (e) {
    return next(e);
  }
};

async function createOrUpdateRoles(empId, listRoles) {
  if (!empId || !listRoles || !listRoles.length) {
    return;
  }
  const insertRoles = listRoles.map((item) => ({ moduleCode: item.moduleCode, userId: empId, roles: item.roles }));
  await roleTask.remove({ userId: empId });
  roleTask.insertMany(insertRoles);
  // return await Promise.all(listRoles.map(async (item) => {
  //   const foundRole = await roleTask.findOne({ moduleCode: item.moduleCode, userId: empId });
  //   if (foundRole) {
  //     foundRole.roles = item.roles;
  //     return await foundRole.save();
  //   }
  //   return await roleTask.create({ moduleCode: item.moduleCode, userId: empId, roles: item.roles });
  // }));
}

async function updateRole(userid, foundGroup) {
  if (!foundGroup || !foundGroup._id || !userid) return;
  const userId = userid.toString();
  console.log('userId', userId);
  const { roles: groupRoles, _id: groupId } = foundGroup;
  const roles = groupRoles.map((i) => ({ ...i, userId }));

  const url = `${process.env.API_ROLE_GROUPS_01}/roles/${userId}`;
  try {
    return await axios.put(`${url}`, JSON.stringify({ userId, roles, groupId }), {
      headers: {
        'Content-Type': 'application/json',
      },
    });
  } catch (error) {
    console.log('error', error);
    throw error;
  }
}

const upRole = async (req, res, next) => {
  const { foundGroup } = req.body;
  const { userid } = req.body;
  // if (!foundGroup || !foundGroup._id || !userid) return;
  const userId = userid.toString();
  // console.log('userId', userId);
  const { roles: groupRoles, _id: groupId } = foundGroup;
  const roles = groupRoles.map((i) => ({ ...i, userId }));

  const url = `${process.env.API_ROLE_GROUPS_01}/roles/${userId}`;
  try {
    // eslint-disable-next-line no-unused-expressions
    await axios.put(`${url}`, JSON.stringify({ userId, roles, groupId }), {
      headers: {
        'Content-Type': 'application/json',
      },
    });
    res.json('ok');
  } catch (error) {
    console.log('error', error);
    throw error;
  }
};

module.exports = { callback, createList, upRole };
