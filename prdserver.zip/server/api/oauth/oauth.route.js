const router = require('express').Router(); // eslint-disable-line
const oauthCtrl = require('./oauth.controller');

router.get('/callback', oauthCtrl.callback);
router.put('/uprole', oauthCtrl.upRole);

module.exports = router;
