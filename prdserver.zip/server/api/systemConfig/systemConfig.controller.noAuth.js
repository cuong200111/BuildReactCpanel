const SystemConfig = require('./systemConfig.model');

/**
 * Get a SystemConfig
 *
 * @param {Request} req
 * @param {Response} res
 */

const getVersionConfig = async (req, res) => {
  try {
    const systemConfig = await SystemConfig.findOne();
    const versionConfig = systemConfig.versionNo;

    return res.json({
      status: 1,
      versionConfig,
    });
  } catch (error) {
    return res.json({
      status: 0,
      message: error.message,
    });
  }
};

module.exports = {
  getVersionConfig,
};
