const Joi = require('joi');

const validString = Joi.string().trim().min(5).required();

module.exports = {

  // PUT /api/systemConfigs/:systemConfigId
  updateSystemConfig: {
    body: {
      name: validString
    },

  }
};
