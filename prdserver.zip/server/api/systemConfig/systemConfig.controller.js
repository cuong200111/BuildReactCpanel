const SystemConfig = require('./systemConfig.model');
// const STATUS = require('../../variables/CONST_STATUS').STATUS;
// const SystemConfigTransformer = require('./systemConfig.transformer');
// const httpStatus = require('http-status');

/**
 * Get a SystemConfig
 *
 * @param {Request} req
 * @param {Response} res
 */

async function get(req, res, next) {
  try {
    const systemConfig = await SystemConfig.findOne();
    res.json(systemConfig);
  } catch (error) {
    next(error);
  }
}
async function getLocation(req, res, next) {
  try {
    const systemConfig = await SystemConfig.findOne().lean();
    const data = {
      headquarters: 'Trụ sở chính',
      headquartersAddr: 'Tòa nhà Mipec Tower - Số 229, Tây Sơn, Đống Đa, Hà Nội',
      currLocaltion: [
        {
          currLocName: 'Chi nhánh Nghệ An',
          currLocAddr: 'mipecquanlytoanha',
        },
      ],
      ...systemConfig,
    };
    res.json({ status: 1, data });
  } catch (error) {
    next(error);
  }
}
/**
 * Update existing systemConfig
 *
 * @returns {SystemConfig}
 */
async function update(req, res, next) {
  try {
    // console.log('RED', req.body);
    const {
      name,
      displayName,
      website,
      email,
      logo,
      dateFomat,
      timeFomat,
      firstDayOfTheWeek,
      workingTime,
      workingDays,
      holidays,
      mailServer,
      passServer,
      serviceServer,
      language,
      smsBrandname,
      smsAccount,
      smsPass,
      facebook,
      bankAccount,
      recruitmentBg,
      agencyCode,
      versionNo,
      linkedIn,
      youtube,
      zalo
    } = req.body;
    const systemConfig = await SystemConfig.findOne();
    systemConfig.name = name;
    systemConfig.displayName = displayName;
    systemConfig.website = website;
    systemConfig.email = email;
    systemConfig.logo = logo;
    systemConfig.mailServer = mailServer;
    systemConfig.passServer = passServer;
    systemConfig.serviceServer = serviceServer;
    systemConfig.smsBrandname = smsBrandname;
    systemConfig.smsAccount = smsAccount;
    systemConfig.smsPass = smsPass;
    systemConfig.dateFomat = dateFomat;
    systemConfig.timeFomat = timeFomat;
    systemConfig.firstDayOfTheWeek = firstDayOfTheWeek;
    systemConfig.workingTime = workingTime;
    systemConfig.workingDays = workingDays;
    systemConfig.holidays = holidays;
    systemConfig.language = language;
    systemConfig.facebook = facebook;
    systemConfig.bankAccount = bankAccount;
    systemConfig.recruitmentBg = recruitmentBg;
    systemConfig.agencyCode = agencyCode;
    systemConfig.versionNo = versionNo;
    systemConfig.linkedIn = linkedIn;
    systemConfig.youtube = youtube;
    systemConfig.zalo = zalo;

    const systemConfigSaved = await systemConfig.save();
    res.json({
      success: true,
      data: systemConfigSaved,
    });
  } catch (error) {
    next(error);
  }
}

module.exports = {
  update,
  get,
  getLocation,
};
