const express = require('express');
const systemConfigCtrlNoAuth = require('./systemConfig.controller.noAuth');
const init = require('./systemConfig.init');

const router = express.Router(); // eslint-disable-line new-cap

router.route('/version')
      .get(systemConfigCtrlNoAuth.getVersionConfig);

init();

module.exports = router;
