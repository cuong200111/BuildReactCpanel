/* eslint-disable prettier/prettier */
const mongoose = require('mongoose');

const branchSchema = new mongoose.Schema(
  {
    data: [],
    profession: String,
    softwarePackage: String,
    mappingName: {}
  },
  {
    timestamps: true,
  }
);
branchSchema.statics = {
  
}
module.exports = mongoose.model('ModuleConfig', branchSchema);
