const WEEKDAY = require('../../variables/CONST_STATUS').WEEKDAY;
const TIME_FORMAT = require('../../variables/CONST_STATUS').TIME_FORMAT;
const LANGUAGE = require('../../variables/CONST_STATUS').LANGUAGE;
const SConfig = require('./systemConfig.model');

const config = {
  // name: null,
  // displayName: null,
  // website: null,
  // email: null,
  dateFormat: 'DD/MM/yyyy',
  timeFormat: TIME_FORMAT.MILITARY_HOURS,
  firstDayOfTheWeek: WEEKDAY.MONDAY,
  workingTime: {
    start: new Date(0, 0, 0, 8, 0, 0, 0),
    end: new Date(0, 0, 0, 17, 30, 0, 0),
  },
  workingDays: [
    WEEKDAY.MONDAY,
    WEEKDAY.TUESDAY,
    WEEKDAY.WEDNESDAY,
    WEEKDAY.THURSDAY,
    WEEKDAY.FRIDAY,
    WEEKDAY.SATURDAY,
  ],
  holiday: [
    // WEEKDAY.SUNDAY,
  ],
  language: LANGUAGE.VI_VN
};

module.exports = async () => {
  await SConfig.createDefault(config);
};
