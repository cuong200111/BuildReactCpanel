const express = require('express');
const validate = require('express-validation');
const systemConfigValidation = require('./systemConfig.validation');
const systemConfigCtrl = require('./systemConfig.controller');
const init = require('./systemConfig.init');

const router = express.Router(); // eslint-disable-line new-cap

router
  .route('/')
  /** GET /api/systemConfigs - Get list of systemConfigs */
  .get(systemConfigCtrl.get)
  /** PUT /api/systemConfigs - Create new systemConfig */
  .put(validate(systemConfigValidation.updateSystemConfig), systemConfigCtrl.update);

router
  .route('/location')
  /** GET /api/systemConfigs - Get list of systemConfigs */
  .get(systemConfigCtrl.getLocation);
// Init
init();

module.exports = router;
