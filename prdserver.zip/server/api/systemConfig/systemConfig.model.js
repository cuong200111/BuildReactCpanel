const Promise = require('bluebird');
const mongoose = require('mongoose');
const httpStatus = require('http-status');
const APIError = require('../../helpers/APIError');
const STATUS = require('../../variables/CONST_STATUS').STATUS;

const systemConfigSchema = new mongoose.Schema(
  {
    name: String,
    displayName: String,
    website: String,
    email: String,
    logo: { type: String, default: '' },
    dateFomat: {
      type: String,
    },
    timeFomat: {
      type: String,
    },
    smsBrandname: String,
    smsAccount: String,
    smsPass: String,
    mailServer: String,
    passServer: String,
    serviceServer: String,
    firstDayOfTheWeek: {
      type: String,
    },
    workingTime: {
      start: String,
      end: String,
    },
    workingDays: [String],
    holidays: [String],
    language: {
      type: String,
    },
    facebook: String,
    bankAccount: String,
    moduleConfig: [],
    taxCode: String,
    recruitmentBg: String,
    linkedIn: String,
    youtube: String,
    zalo: String,
    versionNo: {
      type: Number,
      required: true,
    },
    agencyCode: String,
    allowRefreshConfig: {
      type: Boolean,
      default: false,
    },
    allowInitSource: {
      type: Boolean,
      default: true,
    },
  },
  {
    timestamps: true,
  },
);

/**
 * Statics
 */
systemConfigSchema.statics = {
  /**
   * Get systemConfig
   *
   * @param {ObjectId} id - The objectId of systemConfig.
   * @returns {Promise<SystemConfig, APIError>}
   */
  get(id) {
    return this.findOne({
      _id: id,
      status: STATUS.ACTIVED,
    })
      .exec()
      .then((systemConfig) => {
        if (systemConfig) {
          return systemConfig;
        }
        const err = new APIError('No such systemConfig exists!', httpStatus.NOT_FOUND);
        return Promise.reject(err);
      });
  },

  /**
   * List systemConfigs in descending order of 'createdAt' timestamp.
   *
   * @param {number} skip - Number of systemConfigs to be skipped.
   * @param {number} limit - Limit number of systemConfigs to be returned.
   * @returns {Promise<SystemConfig[]>}
   */
  list({ skip = 0, limit = 500 } = {}) {
    return this.find({
      status: 1,
    })
      .sort({
        createdAt: -1,
      })
      .skip(+skip)
      .limit(+limit)
      .exec();
  },

  async createDefault(config) {
    try {
      const systemConfig = await this.model('SystemConfig', systemConfigSchema).findOne();
      if (!systemConfig) {
        await this.model('SystemConfig', systemConfigSchema)(config).save();
      }
    } catch (error) {
      throw error;
    }
  },
};

module.exports = mongoose.model('SystemConfig', systemConfigSchema);
