const AbstractTransformer = require('d-transformer').AbstractTransformer;

/*  eslint-disable  */
class SystemConfigTransformer extends AbstractTransformer {
  transform(systemConfig) {
    return {
      id: systemConfig._id,
      key: systemConfig.key,
      value: systemConfig.value,
      options: systemConfig.options
    };
  }
}

module.exports = SystemConfigTransformer;
