/* eslint-disable import/newline-after-import */
const express = require('express');
// middleware
const auth = require('./server/middleware/auth-strategy');

const oauthRoutes = require('./server/api/oauth/oauth.route');

const configRoutes = require('./server/api/config/config.route');
const systemConfigRoutes = require('./server/api/systemConfig/systemConfig.route');

// organization structure
const organizationUnitRoutes = require('./server/api/organizationUnit/organizationUnit.route');
const employeeRoutes = require('./server/api/employee/employee.route');
// view mangager
const viewConfigRoutes = require('./server/api/viewConfig/viewConfig.route');
const kanbanRoutes = require('./server/api/kanban/kanban.route');
// eslint-disable-next-line no-unused-vars
const crmSourceRoute = require('./server/api/crmSource/crmSource.route');
const crmStatusRoute = require('./server/api/crmStatus/crmStatus.route');
// Collection mangager

// plugins

// Stock

// crm - config
const crmConfigRoutes = require('./server/api/crmConfig/crmConfig.route');
// const crmConfigHrmRoutes = require('./server/api/crmConfig/crmConfig.route');

// measureUnit

// money
// location
// currency
// eslint-disable-next-line no-unused-vars

// supplier

// contract

// dynamic Form Control
// dynamic Form Control


// generateCode
const generateCodeRoutes = require('./server/api/GenerateCode/generateCode.route');

// chart

const commonRoutes = require('./server/api/common/common.route');
const logRoutes = require('./server/api/log/log.route');
const sourceLogRoutes = require('./server/api/sourceLog/log.route');
const notificationRoutes = require('./server/api/notification/notification.route');

const commentRoutes = require('./server/api/comment/comment.route');
const roleTaskRoutes = require('./server/api/roleTask/role.route');
const fieldRoutes = require('./server/api/field/field.route');
// import
const importHelper = require('./server/helpers/import');


const router = express.Router(); // eslint-disable-line new-cap
// cyber bill

// mount organizations routes at /organizations
router.use('/oauth', oauthRoutes);
router.use('/common', auth.isAuthenticated, commonRoutes);
router.use('/commonList', commonRoutes);
router.use('/field', auth.isAuthenticated, fieldRoutes);

// mount organizations routes at /organizations
router.use('/organization-units', auth.isAuthenticated, organizationUnitRoutes);

// mount employees routes at /employees
router.use('/employees', auth.isAuthenticated, employeeRoutes);
// mount system-configs routes at /system-configs
router.use('/system-config', auth.isAuthenticated, systemConfigRoutes);

// mount viewConfigs routes at /view-configs
router.use('/view-configs', auth.isAuthenticated, viewConfigRoutes);

// mount viewconfigs routes at /view-configs
router.use('/kanbans', auth.isAuthenticated, kanbanRoutes);

// mount inventory routes at /inventory


// mount money routes at /money


// mount inventory routes at /units

// mount crm-source routes at /units
router.use('/crm-source', auth.isAuthenticated, crmSourceRoute);
// mount crm-source routes at /units
router.use('/crm-status', auth.isAuthenticated, crmStatusRoute);
// mount crm-source routes at /units
// mount crm-source routes at /units

// mount BusinessOpportunities routes at /units

// mount exchangingAgreement routes at /units

// // Dynamic Collection
// router.use('/dynamic-collections', auth.isAuthenticated, dynamicCollectionRoute);
// // collection
// router.use('/collections', auth.isAuthenticated, collection);
// // Dynamic Collection


//
router.use('/generate', generateCodeRoutes);

// collection

// plugins
// location
// tax

// contract
// supplier
// dynamic-forms
// bales-quotations

router.use('/logs', auth.isAuthenticated, logRoutes);
router.use('/source-log', auth.isAuthenticated, sourceLogRoutes);

// COng viec du an

router.use('/notifications', auth.isAuthenticated, notificationRoutes);
// Báo cáo thời gian thực


// router.use('/business-opportunities', auth.isAuthenticated, businessOpportunities);

router.post('/import', auth.isAuthenticated, importHelper.importFormClient);
router.post('/import-field', auth.isAuthenticated, importHelper.importInField);
router.post('/import-user', auth.isAuthenticated, importHelper.importUserFromClient);
// router.post('/import-role', auth.isAuthenticated, importHelper.roleUpdateItems);
// router.get('/get-schema', importHelper.getSchemaByModelName);

// HRM LT

// eslint-disable-next-line import/newline-after-import



router.use('/comment', auth.isAuthenticated, commentRoutes);

router.use('/roleApp', auth.isAuthenticated, roleTaskRoutes);
const userLoginRouter = require('./server/api/loginLog/loginLog.route');
router.use('/user-login', auth.isAuthenticated, userLoginRouter);

const userLoginFailRouter = require('./server/api/loginLog/loginFail.route');
router.use('/user-login-fail', userLoginFailRouter);

// get versionConfig no Auth
const systemConfigCtrlNoAuthRoutes = require('./server/api/systemConfig/systemConfig.route.noAuth');
router.use('/version-system', systemConfigCtrlNoAuthRoutes);

const routesHistory = require('./server/historyData/index.route');
router.use('/historyData', routesHistory);

module.exports = router;
