# Before Developing
- Make sure to copy [.env.example](.env.example) to [.env](.env)
- Create database for testing (with authentication)
provided in [.env](.env) fole

# 01_UserManagement

