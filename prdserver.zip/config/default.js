require('dotenv').config();

const express = require('./modules/express.config');
const local = require('./modules/local.config');
const oauth = require('./modules/oauth.config');
const amqp = require('./modules/amqp.config');

module.exports = {
  express,
  local,
  oauth,
  amqp
};
