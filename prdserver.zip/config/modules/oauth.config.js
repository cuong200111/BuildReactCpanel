const Joi = require('joi');

const envVarsSchema = Joi.object({
  TOKEN_URL: Joi.string(),
  REDIRECT: Joi.string(),
  RESOURCE_URL: Joi.string(),
  CLIENT_ID: Joi.string(),
  CLIENT_NOTIFICATION: Joi.string(),
  CLIENT_SECRET: Joi.string(),
  CREATE_LIST: Joi.string()
})
  .unknown()
  .required();

const { error, value: envVars } = Joi.validate(process.env, envVarsSchema);
if (error) throw new Error(`Config validation error: ${error.message}`);
 
const config = {
  tokenUrl: envVars.TOKEN_URL,
  redirectUri: envVars.REDIRECT,
  resourceUrl: envVars.RESOURCE_URL,
  clientId: envVars.CLIENT_ID,
  clientNotification: envVars.CLIENT_NOTIFICATION,
  clientSecret: envVars.CLIENT_SECRET,
  createList: envVars.CREATE_LIST,
  apiRoleGroups: envVars.API_ROLE_GROUPS,
};

module.exports = config;
