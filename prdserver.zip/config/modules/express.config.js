module.exports = {
  router: {
    caseSensitive: true,
    mergeParams: true,
    strict: false,
  },
};
