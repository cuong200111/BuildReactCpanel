const Joi = require('joi');

const envVarsSchema = Joi.object({
  AMQP_HOST:
    Joi.string()
      .default('g.lifetek.vn'),
  AMQP_PORT:
    Joi.number()
      .default(5672),
  AMQP_AUTH:
    Joi.boolean().default(false),
  AMQP_USERNAME:
    Joi.string().default('guest'),
  AMQP_PASSWORD:
    Joi.string().default('guest'),

}).unknown().required();

const { error, value: envVars } = Joi.validate(process.env, envVarsSchema);
if (error) throw new Error(`Config validation error: ${error.message}`);

const config = {
  auto: 'auto',
  clientAuto: process.env.CLIENT_AUTO ||  '08_CRM',
  connections: {
    default: {
      host: envVars.AMQP_HOST,
      port: envVars.AMQP_PORT,
    },
    auth: {
      enabled: envVars.AMQP_AUTH,
      username: envVars.AMQP_USERNAME,
      password: envVars.AMQP_PASSWORD,
    }
  },
  prefetch: 10,
  exchange: {
    config: { durable: false },
    name: 'logs'
  },
  queue: {
    config: {},
  }
};
module.exports = config;
