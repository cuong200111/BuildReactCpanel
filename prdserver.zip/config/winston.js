const winston = require('winston');
require('dotenv').config();

// eslint-disable-next-line no-unused-vars
let logLevel = 'silly';
const env = process.env.NODE_ENV;
if (env === 'product') {
  logLevel = 'warn';
} else if (env === 'test') {
  logLevel = 'debug';
} else {
  logLevel = 'silly';
}

const logger = new (winston.Logger)({
  transports: [
    // new (winston.transports.Console)({
    //   name: 'console',
    //   level: logLevel,
    //   colorize: true
    // }),
    new (winston.transports.File)({
      name: 'silly-file',
      filename: 'silly.log',
      level: 'silly'
    }),
    new (winston.transports.File)({
      name: 'debug-file',
      filename: 'debug.log',
      level: 'debug'
    }),
    new (winston.transports.File)({
      name: 'error-file',
      filename: 'error.log',
      level: 'warn'
    })
  ]
});

module.exports = logger;
