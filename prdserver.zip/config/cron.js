const cron = require('cron');
const { report, refresh, cronRole } = require('./../server/api/cron/cron');

const morning = new cron.CronJob({
  cronTime: '00 00 11 * * 1-6', // Thông báo lúc 11h00 từ t2-t7
  onTick() {
    report();
  },
  start: true,
  timeZone: 'Asia/Ho_Chi_Minh', // Lưu ý set lại time zone cho đúng
});
const afternoon = new cron.CronJob({
  cronTime: '00 00 16 * * 1-6',
  onTick() {
    report();
  },
  start: true,
  timeZone: 'Asia/Ho_Chi_Minh',
});
const refreshId = new cron.CronJob({
  cronTime: '0 0 0 1 Jan *',
  onTick() {
    refresh();
  },
  start: true,
  timeZone: 'Asia/Ho_Chi_Minh', // Lưu ý set lại time zone cho đúng
});


const updateRole = new cron.CronJob({
  cronTime: '*/5 * * * * *',
  onTick() {
    cronRole();
  },
  start: true,
  timeZone: 'Asia/Ho_Chi_Minh', // Lưu ý set lại time zone cho đúng
});

module.exports = { morning, afternoon, refreshId, updateRole };
