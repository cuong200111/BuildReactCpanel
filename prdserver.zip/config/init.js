const dCollectionHelper = require('../server/helpers/dynamic-collection');
// const dbHelper = require('../server/helpers/database');
// const initNotice = require('../server/helpers/agenda');
const crmStatusCtrl = require('../server/api/crmStatus/crmStatus.controller');
const hrmStatusCtrl = require('../server/api/hrmStatus/hrmStatus.controller');
const systemConfig = require('../server/api/systemConfig/systemConfig.model');
const logger = require('winston');

const initConfig = async () => {
  try {
    const currentConfig = await systemConfig.findOne({});
    if (currentConfig.profession && currentConfig.softwarePackage) {
      global.product_config_type = `${currentConfig.profession}_${currentConfig.softwarePackage}`;
    }
  } catch (error) {
    console.log('error', error);
  }
}

function init(app) {
  dCollectionHelper
    .loadAllSchema()
    .then(() => app.updateRoute())
    .then(() => {
      crmStatusCtrl.init();
      hrmStatusCtrl.init();
      initConfig();
    })
    .catch((err) => logger.error(err));
}

module.exports = init;
