/* eslint-disable arrow-parens */
/* eslint-disable global-require */
const express = require('express');
const logger = require('morgan');
const bodyParser = require('body-parser');
const cookieParser = require('cookie-parser');
const compress = require('compression');
const session = require('express-session');
const redis = require('redis');

const redisClient = redis.createClient({ host: process.env.REDIS_HOST, port: process.env.REDIS_PORT });
const RedisStore = require('connect-redis')(session);

// const methodOverride = require('method-override');
const cors = require('cors');
const httpStatus = require('http-status');
const expressWinston = require('express-winston');
const expressValidation = require('express-validation');
const helmet = require('helmet');
const path = require('path');
const winstonInstance = require('./winston');
const config = require('./config');
const transformer = require('d-transformer').middleware;
const APIError = require('../server/helpers/APIError');
// eslint-disable-next-line
const { morning, afternoon, refreshId, syncRole, getTokenFromCyberBill, getTokenFromCyberCare, getTokenFromMInvoice, updateRole } = require('./cron');
const app = express();
redisClient.on('error', (err) => {
  console.log('Redis error: ', err);
});

redisClient.on('connect', (err) => {
  console.log('Redis connect: ', err);
});

if (config.env === 'development') {
  app.use(logger('dev'));
}
app.use(
  session({
    secret: 'secretKey',
    resave: false,
    saveUninitialized: true,
    store: new RedisStore({
      host: process.env.REDIS_HOST,
      port: process.env.REDIS_PORT,
      client: redisClient,
      ttl: 86400,
    }),
  }),
);
// parse body params and attache them to req.body
// const socketClientAi = aiClient('http://192.168.1.238:5000');
// console.log('socketClientAi', socketClientAi);
// socketClientAi.on('connect', () => {
//   console.log('connect to ai server');
// });

// socketClientAi.on('disconnect', () => {
//   console.log('disconnect to ai server');
// });

// socketClientAi.on('register-result', (data) => {
//   console.log('data', data);
//   global.io.emit(data.clientSid, data);
// });

// socketClientAi.on('result-camera', (data) => {
//   console.log('data', data);
//   global.io.emit(data.clientSid, data);
// });

// global.io.on('on_camera_register', (data) => {
//   console.log('data', data);
//   if (!data.clientSid) {
//     return;
//   }
//   socketClientAi.emit('on_camera_register', data);
// });

// global.io.on('my_message', (data) => {
//   console.log('data', data);
//   if (!data.clientSid) {
//     return;
//   }
//   socketClientAi.emit('my_message', data);
// });

// socketClientAi.on('on-result-image', (data) => {
//   console.log('data', data);
//   global.io.emit(data.clientSid, data);
// });

app.use(bodyParser.json({ limit: '5mb' }));
app.use(bodyParser.urlencoded({ extended: true }));
app.set('view engine', 'ejs');
app.use(cookieParser());
app.use(compress());
// app.use(methodOverride());

app.use('/static', express.static(path.join(__dirname, '../server/public')));

// secure apps by setting various HTTP headers
app.use(helmet());

// enable CORS - Cross Origin Resource Sharing
app.use(cors());

// enable transformer
app.use(transformer);

// enable detailed API logging in dev env
if (config.env === 'development') {
  expressWinston.requestWhitelist.push('body');
  expressWinston.responseWhitelist.push('body');
  app.use(
    expressWinston.logger({
      winstonInstance,
      meta: true, // optional: log meta data about request (defaults to true)
      msg: 'HTTP {{req.method}} {{req.url}} {{res.statusCode}} {{res.responseTime}}ms',
      colorStatus: true, // Color the status code (default green, 3XX cyan, 4XX yellow, 5XX red).
    }),
  );
}

// eslint-disable-next-line func-names
app.updateRoute = function() {
  // eslint-disable-next-line global-require
  const routes = require('../index.route');

  // mount all routes on /api path
  app.use('/api', routes);
  // if error is not an instanceOf APIError, convert it.
  app.use((err, req, res, next) => {
    if (err instanceof expressValidation.ValidationError) {
      // validation error contains errors which is an array of error each containing message[]
      const unifiedErrorMessage = err.errors.map((error) => error.messages.join('. ')).join(' and ');
      const error = new APIError(unifiedErrorMessage, err.status, true);
      return next(error);
    } else if (!(err instanceof APIError)) {
      const apiError = new APIError(err.stack, err.status, err.isPublic);
      return next(apiError);
    }
    return next(err);
  });

  // catch 404 and forward to error handler
  app.use((req, res, next) => {
    const err = new APIError('API not found', httpStatus.NOT_FOUND);
    return next(err);
  });

  // log error in winston transports except when executing test suite
  if (config.env !== 'test') {
    app.use(
      expressWinston.errorLogger({
        winstonInstance,
      }),
    );
  }
  morning.start();
  afternoon.start();
  refreshId.start();
  updateRole.start();
  // error handler, send stacktrace only during development
  app.use((
    err,
    req,
    res,
    next, // eslint-disable-line no-unused-vars
  ) =>
    res.status(err.status).json({
      err: err.message,
      message: err.isPublic ? err.message : httpStatus[err.status],
      stack: config.env === 'development' ? err.stack : {},
    }),
  );
};

module.exports = app;
