const express = require('express');
const cheerio = require('cheerio');
const puppeteer = require('puppeteer');
const fs = require('fs');
const sharp = require('sharp');
const axios = require('axios');
const cors = require('cors');
const bodyParser = require('body-parser');
const app = express()

app.use(cors({
  origin: "*"
}))
app.use(bodyParser.urlencoded({ extended: true }))
app.use(bodyParser.json())
const dowloadFile = async (destinationFolder, fieldName, urlWeb, classHtml, maxKb) => {
  const path = `${destinationFolder}`
  const browser = await puppeteer.launch({ headless: false });
  const page = await browser.newPage();

  try {
    await page.goto(urlWeb, { waitUntil: 'networkidle2', timeout: 0 });
    const html = await page.content();
    if (html) {
      const $ = cheerio.load(html);
      const imgs = $(classHtml)
      let arr = []
      imgs.each((index, element) => {
        arr.push(element.attribs['src'])
      })
      const filterArr = arr.filter(item => item !== undefined)

      for (let i = 0; i < filterArr.length; i++) {
        const link = filterArr[i]
        const response = await axios({
          url: link,
          method: 'GET',
          responseType: 'arraybuffer'
        })

        while (response.data.byteLength > 100000 && maxKb > 10) {
          const compressImg = await sharp(response.data).jpeg({ quality: maxKb }).toBuffer()
          response.data = compressImg
          maxKb -= 10
        }
        fs.writeFileSync(`${path}/${fieldName + (i + 1)}.png`, response.data)
      }
    }

  } catch (error) {
    console.log(error)
    await browser.close();
    if (error) throw error
  }

  await browser.close();
}

const destinationFolder = './upload';
app.post('/downloadCompressPng', (req, res, next) => {
  const { fieldName, urlWeb, classHtml, maxKb } = req.body
  dowloadFile(destinationFolder, fieldName, urlWeb, classHtml, Number(maxKb)).then(item => {    res.send({ data: 'success', msg: "Tải thành công" }) }).catch(err => {
    res.send({ data: 'failed', msg: "Dữ liệu nhập không hợp lệ" })
  });

})


app.listen(4500)
