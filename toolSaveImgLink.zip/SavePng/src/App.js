import React, { useEffect, useRef, useState } from 'react';
import './App.css';
import axios from 'axios'
function App() {
  const [maxKb, setmaxKb] = useState('')
  const [classHtml, setclassHtml] = useState('')
  const [urlWeb, seturlWeb] = useState('')
  const [fieldName, setfieldName] = useState('')
  const handleCompressImg = async ()=>{
    const body = {maxKb,classHtml,urlWeb,fieldName}
    const response = await axios.post('http://localhost:4500/downloadCompressPng',body);
    if(response.data.data === 'success'){
      alert('Lưu file thành công')
    }else{
      alert('Dữ liệu truyền vào không đúng')
    }
  }
  return (
    <>
      <div style={{ display: "flex", flexDirection: "column", alignItems: "center" }}>
        <input onChange={(element) => {
          seturlWeb(element.target.value)
        }} type='text' placeholder='Địa chỉ hình ảnh' />
        <input onChange={(element) => {
          setclassHtml(element.target.value)
        }} type='text' placeholder='Class element đó' />
        <input onChange={(element) => {
          setfieldName(element.target.value)
        }} type='text' placeholder='Tên ảnh đó' />
        <input onChange={(element) => {
          setmaxKb(element.target.value)
        }} type='text' placeholder='Giới hạn dung lượng hình ảnh' />
        <button onClick={handleCompressImg} style={{ margin: "10px 0" }}>Nén</button>
      </div>

    </>
  );
}

export default App;