export const MSG_ADD_TO_CART_SUCCESS = 'Mua hàng thành công !';
export const MSG_UPDATE_CART_SUCCESS = 'Cập nhật giỏ hàng thành công !';
export const MSG_DELETE_PRODUCT_IN_CART_SUCCESS = 'Xóa sản phẩm khỏi giỏ hàng thành công !';
export const MSG_CART_EMPTY = 'Chưa có sản phẩm nào trong giỏ hàng';
export const MSG_WELCOME = 'Chào mừng đến với Shopping Online';
