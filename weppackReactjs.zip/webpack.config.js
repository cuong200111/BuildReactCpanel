const path = require('path');
const HtmlWebpackPlugin = require("html-webpack-plugin");
const CopyWebpackPlugin = require('copy-webpack-plugin')
module.exports = {
  entry: "./src/index.js",
  output: {
    path: path.join(__dirname, '/dist'),
    filename: "index_bundel.js"
  },
  devServer: {
    historyApiFallback: true,
  },
  module: {
    rules: [
      {
        test: /\.js$/,
        exclude: /node_modules/,
        use: {
          loader: "babel-loader",
        }
      },
      {
        test: /\.scss$/,
        exclude: /node_modules/,
        use: [
          {
            loader: 'style-loader' // tạo các thẻ <style> và chèn mã CSS vào trang HTML
          },
          {
            loader: 'css-loader' // biên dịch CSS thành JavaScript
          },
          {
            loader: 'sass-loader', // biên dịch SASS/SCSS thành CSS
            options: {
              implementation: require('node-sass') // sử dụng node-sass để biên dịch SASS/SCSS
            }
          }
        ]
      },
      {
        test: /\.css$/,
        use: ["style-loader", "css-loader"],
      }
    ]
  },
  plugins: [
    new HtmlWebpackPlugin({
      template: "./src/index.html"
    }),
    new CopyWebpackPlugin({
      patterns: [
        {
          from: 'public', // thư mục bao gồm tất cả các tệp tin bạn muốn sao chép
          to: ''// thư mục đích để sao chép tệp tin (thư mục đầu ra của Webpack)

        }
      ]
    })
  ]
}